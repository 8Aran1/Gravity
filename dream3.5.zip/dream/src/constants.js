export const STORAGE_KEYS = {
  DATA_KEY: 'dream_saving_camp_data',
  CAMPS_KEY: 'dream_camps_data',
  JOINED_KEY: 'dream_joined_camps'
};

export const APP_DATA_KEYS = [
  STORAGE_KEYS.DATA_KEY,
  STORAGE_KEYS.CAMPS_KEY,
  STORAGE_KEYS.JOINED_KEY
];

export const VALIDATION_RULES = {
  GOAL_NAME_MIN: 1,
  GOAL_NAME_MAX: 20,
  GOAL_AMOUNT_MIN: 0.01,
  GOAL_AMOUNT_MAX: 999999.99,
  NOTE_MAX: 50,
  WARNING_DAYS: 7,
  WARNING_PROGRESS: 80
};

export const ACHIEVEMENTS = [
  {
    badgeId: 'streak_7',
    name: '坚持一周',
    unlockCondition: '连续储蓄7天',
    unlocked: false,
    unlockedDate: null
  },
  {
    badgeId: 'streak_30',
    name: '坚持一月',
    unlockCondition: '连续储蓄30天',
    unlocked: false,
    unlockedDate: null
  },
  {
    badgeId: 'first_goal_done',
    name: '首梦成真',
    unlockCondition: '完成第一个引力源',
    unlocked: false,
    unlockedDate: null
  }
];

export const DATA_VERSION = 1;

export const WITHDRAW_COOLDOWN_HOURS = 48;

export const WITHDRAW_COOLDOWN_OPTIONS = [0, 24, 48];

export const CAMP_RULES = {
  CAMP_NAME_MIN: 1,
  CAMP_NAME_MAX: 20,
  NICKNAME_MIN: 1,
  NICKNAME_MAX: 12,
  MESSAGE_MAX: 100,
  MEMBERS_MIN: 1,
  MEMBERS_MAX: 20
};

export const USER_PROFILE_RULES = {
  NICKNAME_MIN: 1,
  NICKNAME_MAX: 20,
  DEFAULT_NICKNAME: '梦想家',
  DEFAULT_AVATAR_KEY: 'star'
};

export const PRESET_AVATARS = [
  { key: 'star', emoji: '⭐', isDefault: true },
  { key: 'rocket', emoji: '🚀', isDefault: false },
  { key: 'fire', emoji: '🔥', isDefault: false },
  { key: 'sun', emoji: '☀️', isDefault: false },
  { key: 'moon', emoji: '🌙', isDefault: false },
  { key: 'rainbow', emoji: '🌈', isDefault: false },
  { key: 'gem', emoji: '💎', isDefault: false },
  { key: 'crown', emoji: '👑', isDefault: false },
  { key: 'cat', emoji: '🐱', isDefault: false },
  { key: 'dog', emoji: '🐶', isDefault: false },
  { key: 'panda', emoji: '🐼', isDefault: false },
  { key: 'fox', emoji: '🦊', isDefault: false }
];

export const BACKGROUND_THEMES = [
  {
    key: 'nebula',
    name: '星云紫',
    gradient: 'linear-gradient(135deg, #4B0082 0%, #2D0A4E 45%, #0A0A1A 100%)',
    type: 'linear',
    isDefault: true
  },
  {
    key: 'dawn',
    name: '晨曦黄',
    gradient: 'radial-gradient(circle at 30% 25%, #FFF8DC 0%, #FFD580 45%, #FF8C42 100%)',
    type: 'radial',
    isDefault: false
  },
  {
    key: 'cyber',
    name: '赛博蓝',
    gradient: 'linear-gradient(135deg, #0B1E3F 0%, #0A4D8C 50%, #00E5FF 100%)',
    type: 'linear',
    isDefault: false
  }
];

export const DEFAULT_THEME_KEY = 'nebula';

export const CAMP_UI_HINTS = {
  DISCLAIMER_HINT: '💡 提示：本功能为纯前端模拟，组队码仅在当前电脑/浏览器内生效。用于演示多人互动效果。',
  HELP_GUIDE: '请打开无痕窗口模拟另一个成员加入'
};