import { goalService } from '../services/goalService.js';
import { progressService } from '../services/progressService.js';
import { toYuan } from '../utils/moneyUtils.js';
import { progressBar } from './progressBar.js';
import { modal } from './modal.js';
import { WITHDRAW_COOLDOWN_HOURS } from '../constants.js';

function formatCountdown(ms) {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const withdrawView = {
  _timer: null,

  render(goalId) {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }

    const app = document.getElementById('app');
    app.innerHTML = '';

    const detail = goalService.getById(goalId);
    if (!detail) {
      modal.toast('目标不存在或已被删除');
      window.location.hash = '#/';
      return;
    }
    const { goal } = detail;

    if (goal.status === '已支取') {
      const container = document.createElement('div');
      container.className = 'page-container';
      container.innerHTML = `
        <a class="back-link" id="withdraw-done-back" href="#/">← 返回首页</a>
        <div class="withdraw-done">
          <div class="withdraw-done-icon">💸</div>
          <h2 class="form-title">已逃逸</h2>
          <p class="form-hint">已取出 ¥${toYuan(goal.withdrawnAmount || 0)}，目标"${goal.name}"已关闭</p>
        </div>
      `;
      app.appendChild(container);
      const doneBack = document.getElementById('withdraw-done-back');
      if (doneBack) doneBack.addEventListener('click', (e) => { e.preventDefault(); window.location.hash = '#/'; });
      return;
    }

    const status = goalService.getWithdrawStatus(goalId);
    if (!status || !status.pending) {
      window.location.hash = `#/goal/${goalId}`;
      return;
    }

    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = `#/goal/${goalId}`;
    backLink.textContent = '← 返回目标';
    backLink.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.hash = `#/goal/${goalId}`;
    });
    container.appendChild(backLink);

    const card = document.createElement('div');
    card.className = 'withdraw-card';

    const icon = document.createElement('div');
    icon.className = 'withdraw-icon';
    icon.textContent = '⏳';
    card.appendChild(icon);

    const heading = document.createElement('h2');
    heading.className = 'withdraw-title';
    heading.textContent = '支取冷静期';
    card.appendChild(heading);

    const encourage = document.createElement('p');
    encourage.className = 'withdraw-encourage';
    encourage.textContent = '再想想你的梦想';
    card.appendChild(encourage);

    const progress = progressService.calcProgress(goal.currentAmount, goal.targetAmount);
    const completed = progressService.isCompleted(goal.currentAmount, goal.targetAmount);

    const goalInfo = document.createElement('div');
    goalInfo.className = 'withdraw-goal-info';
    goalInfo.innerHTML = `
      <div class="withdraw-goal-name">${goal.name}</div>
      <div class="goal-card-amounts">
        <span class="goal-current-amount">已存 ¥${toYuan(goal.currentAmount)}</span>
        <span class="goal-target-amount">目标 ¥${toYuan(goal.targetAmount)}</span>
      </div>
    `;
    card.appendChild(goalInfo);
    card.appendChild(progressBar.render(progress, completed));

    const wd = goal.pendingWithdrawDetail;
    if (wd) {
      const detailEl = document.createElement('div');
      detailEl.className = 'withdraw-detail';
      detailEl.innerHTML = `
        <div class="withdraw-detail-row"><span class="withdraw-detail-label">用途</span><span class="withdraw-detail-value">${wd.purpose || '未填写'}</span></div>
        <div class="withdraw-detail-row"><span class="withdraw-detail-label">备注时间</span><span class="withdraw-detail-value">${wd.noteTime || '-'}</span></div>
        <div class="withdraw-detail-row"><span class="withdraw-detail-label">支取金额</span><span class="withdraw-detail-value">¥${toYuan(wd.amount || 0)}</span></div>
        <div class="withdraw-detail-row"><span class="withdraw-detail-label">冷静期</span><span class="withdraw-detail-value">${wd.cooldownHours === 0 ? '无冷静期' : (wd.cooldownHours || 48) + ' 小时'}</span></div>
      `;
      card.appendChild(detailEl);
    }

    const countdownWrap = document.createElement('div');
    countdownWrap.className = 'withdraw-countdown-wrap';
    const countdownLabel = document.createElement('div');
    countdownLabel.className = 'withdraw-countdown-label';
    const countdownEl = document.createElement('div');
    countdownEl.className = 'withdraw-countdown';
    if (status.cooldownHours === 0) {
      countdownLabel.textContent = '未设冷静期';
      countdownEl.textContent = '可立即支取';
      countdownEl.style.fontSize = '1.6rem';
      countdownEl.style.color = 'var(--color-primary)';
    } else {
      countdownLabel.textContent = '距离可支取还有';
      countdownEl.textContent = formatCountdown(status.remainingMs);
    }
    countdownWrap.appendChild(countdownLabel);
    countdownWrap.appendChild(countdownEl);
    card.appendChild(countdownWrap);

    const btnArea = document.createElement('div');
    btnArea.className = 'withdraw-btn-area';
    card.appendChild(btnArea);

    container.appendChild(card);
    app.appendChild(container);

    const renderButtons = (canWithdraw) => {
      btnArea.innerHTML = '';
      if (canWithdraw) {
        const tip = document.createElement('p');
        tip.className = 'form-hint';
        tip.textContent = '冷静期已结束，你可以确认支取或继续坚持';
        btnArea.appendChild(tip);

        const confirmBtn = document.createElement('button');
        confirmBtn.className = 'btn btn-danger';
        confirmBtn.textContent = '确认支取';
        confirmBtn.addEventListener('click', () => {
          const wd = goal.pendingWithdrawDetail || {};
          const amt = wd.amount || goal.currentAmount;
          modal.show(`确定以逃逸速度取出 ¥${toYuan(amt)}？\n\n支取后储蓄记录会保留。`, () => {
            const result = goalService.confirmWithdraw(goalId);
            if (result.success) {
              modal.toast('支取成功');
              this.render(goalId);
            } else {
              modal.toast(result.error || '操作失败');
            }
          });
        });

        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = '再想想，继续坚持';
        cancelBtn.addEventListener('click', () => {
          const result = goalService.cancelWithdraw(goalId);
          if (result.success) {
            modal.toast('已取消支取，继续为梦想加油！');
            window.location.hash = `#/goal/${goalId}`;
          }
        });

        btnArea.appendChild(confirmBtn);
        btnArea.appendChild(cancelBtn);
      } else {
        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn btn-secondary';
        cancelBtn.textContent = '取消支取申请';
        cancelBtn.addEventListener('click', () => {
          modal.show('确定取消支取申请？已存金额将继续保留在该目标中。', () => {
            const result = goalService.cancelWithdraw(goalId);
            if (result.success) {
              modal.toast('已取消支取申请');
              window.location.hash = `#/goal/${goalId}`;
            }
          });
        });
        btnArea.appendChild(cancelBtn);
      }
    };

    renderButtons(status.canWithdraw);
    btnArea.dataset.done = status.canWithdraw ? '1' : '0';

    this._timer = setInterval(() => {
      if (window.location.hash !== `#/goal/${goalId}/withdraw`) {
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
        return;
      }
      const s = goalService.getWithdrawStatus(goalId);
      if (!s || !s.pending) {
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
        this.render(goalId);
        return;
      }
      countdownEl.textContent = formatCountdown(s.remainingMs);
      if (s.canWithdraw && btnArea.dataset.done !== '1') {
        btnArea.dataset.done = '1';
        renderButtons(true);
      }
    }, 1000);
  }
};