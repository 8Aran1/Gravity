export const termMapping = {
  GRAVITY_SOURCE: {
    term: '引力源',
    plain: '你要存钱实现的目标',
    detail: '比如买一部新手机、去一次旅行。在首页点"新建引力源"就能建立一个'
  },
  GRAVITY_FIELD: {
    term: '引力场',
    plain: '一起存钱的小组',
    detail: '一群人一起存钱、互相打气的小组。在首页点"引力场"看看'
  },
  GRAVITY_ASSISTANT: {
    term: '引力小助手',
    plain: '能聊天的智能存钱顾问',
    detail: '一个能用大白话聊天的智能存钱顾问，你可以直接打字问它问题。点右下角气泡就能聊'
  },
  ESCAPE_VELOCITY: {
    term: '逃逸速度',
    plain: '提前把钱取出来',
    detail: '就是提前支取。取钱前会给你一段时间冷静冷静（冷静期倒计时），倒计时结束才能真正取'
  },
  CHECK_IN: {
    term: '打卡',
    plain: '每天标记坚持存钱',
    detail: '每天点一下，证明你今天也坚持存钱啦。连续打卡能解锁成就徽章'
  }
};

termMapping.ALL = [
  termMapping.GRAVITY_SOURCE,
  termMapping.GRAVITY_FIELD,
  termMapping.GRAVITY_ASSISTANT,
  termMapping.ESCAPE_VELOCITY,
  termMapping.CHECK_IN
];