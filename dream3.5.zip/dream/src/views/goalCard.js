import { toYuan } from '../utils/moneyUtils.js';
import { progressBar } from './progressBar.js';
import { progressService } from '../services/progressService.js';
import { recordService } from '../services/recordService.js';
import { achievementService } from '../services/achievementService.js';
import { modal } from './modal.js';
import { today } from '../utils/dateUtils.js';
import { homeView } from './homeView.js';

export const goalCard = {
  render(goal) {
    const card = document.createElement('div');
    card.className = 'goal-card';
    card.dataset.goalId = goal.id;

    const progress = progressService.calcProgress(goal.currentAmount, goal.targetAmount);
    const completed = progressService.isCompleted(goal.currentAmount, goal.targetAmount);
    const remaining = progressService.getRemaining(goal.currentAmount, goal.targetAmount);
    const warning = progressService.getWarning(goal.plannedDate, progress);

    const header = document.createElement('div');
    header.className = 'goal-card-header';

    const name = document.createElement('h3');
    name.className = 'goal-card-name';
    name.textContent = goal.name;

    header.appendChild(name);

    if (goal.status === '已支取') {
      const badge = document.createElement('span');
      badge.className = 'goal-status-badge goal-status-done';
      badge.textContent = '已支取';
      header.appendChild(badge);
    } else if (completed) {
      const badge = document.createElement('span');
      badge.className = 'goal-status-badge goal-status-done';
      badge.textContent = '已达成';
      header.appendChild(badge);
    }

    card.appendChild(header);

    const amounts = document.createElement('div');
    amounts.className = 'goal-card-amounts';

    const current = document.createElement('span');
    current.className = 'goal-current-amount';
    current.textContent = goal.status === '已支取'
      ? `已取出 ¥${toYuan(goal.withdrawnAmount || 0)}`
      : `已存 ¥${toYuan(goal.currentAmount)}`;

    const target = document.createElement('span');
    target.className = 'goal-target-amount';
    target.textContent = `目标 ¥${toYuan(goal.targetAmount)}`;

    amounts.appendChild(current);
    amounts.appendChild(target);
    card.appendChild(amounts);

    const bar = progressBar.render(progress, completed);
    card.appendChild(bar);

    const inProgress = goal.status === '进行中';

    if (!completed && inProgress) {
      const remainEl = document.createElement('div');
      remainEl.className = 'goal-remaining';
      remainEl.textContent = `还差 ¥${remaining}`;
      card.appendChild(remainEl);
    }

    if (warning && inProgress) {
      const warnEl = document.createElement('div');
      warnEl.className = 'goal-warning';
      warnEl.textContent = warning;
      card.appendChild(warnEl);
    }

    if (inProgress && goal.pendingWithdrawAt) {
      const pendingEl = document.createElement('div');
      pendingEl.className = 'goal-warning';
      const cd = goal.pendingWithdrawDetail && goal.pendingWithdrawDetail.cooldownHours;
      pendingEl.textContent = cd === 0 ? '⏳ 待确认支取' : '⏳ 支取冷静期中';
      card.appendChild(pendingEl);
    }

    if (!completed && inProgress) {
      const actionEl = document.createElement('div');
      actionEl.className = 'goal-card-action';
      const checkInBtn = document.createElement('button');
      checkInBtn.className = 'btn btn-accent goal-checkin-btn';
      checkInBtn.textContent = '存钱打卡';
      checkInBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._showCheckInDialog(goal.id);
      });
      actionEl.appendChild(checkInBtn);
      card.appendChild(actionEl);
    }

    card.addEventListener('click', () => {
      window.location.hash = `#/goal/${goal.id}`;
    });

    return card;
  },

  _showCheckInDialog(goalId) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const dialog = document.createElement('div');
    dialog.className = 'modal-dialog form-dialog';

    dialog.innerHTML = `
      <h3 class="form-title">存钱打卡</h3>
      <p class="form-hint">本次存入金额（模拟记账，不涉及真实资金）</p>
      <div class="form-group">
        <label>金额（元）</label>
        <input type="number" id="checkin-amount" step="0.01" min="0.01" placeholder="请输入存入金额">
        <span class="form-error" id="error-amount"></span>
      </div>
      <div class="modal-btn-group">
        <button class="btn btn-secondary" id="checkin-cancel">取消</button>
        <button class="btn btn-primary" id="checkin-submit">确认打卡</button>
      </div>
    `;

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const close = () => {
      if (overlay.parentNode) document.body.removeChild(overlay);
    };

    document.getElementById('checkin-cancel').addEventListener('click', close);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });

    document.getElementById('checkin-submit').addEventListener('click', () => {
      const amount = document.getElementById('checkin-amount').value;
      document.getElementById('error-amount').textContent = '';

      const result = recordService.create({ goalId, amount, date: today(), note: '' });
      if (result.success) {
        close();
        modal.toast('打卡成功！');
        const newBadge = achievementService.checkAndUnlock();
        if (newBadge) {
          setTimeout(() => modal.toast(`🎉 解锁徽章：${newBadge.name}！`), 500);
        }
        homeView.render();
      } else if (result.errors && result.errors.amount) {
        document.getElementById('error-amount').textContent = result.errors.amount;
      } else {
        modal.toast(result.error || '操作失败');
      }
    });
  }
};