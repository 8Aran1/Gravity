import { campService } from '../services/campService.js';
import { goalService } from '../services/goalService.js';
import { progressService } from '../services/progressService.js';
import { modal } from './modal.js';

function formatTime(ts) {
  const d = new Date(ts);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  return `${m}-${day} ${h}:${min}`;
}

export const campDetailView = {
  async render(code) {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const data = campService.getCampByCode(code);
    if (!data) {
      const msg = document.createElement('div');
      msg.className = 'page-container';
      const t = document.createElement('p');
      t.className = 'empty-text';
      t.textContent = '小组不存在或已被解散';
      msg.appendChild(t);
      const backBtn = document.createElement('button');
      backBtn.className = 'btn btn-primary';
      backBtn.textContent = '返回引力场';
      backBtn.addEventListener('click', () => { window.location.hash = '#/camps'; });
      msg.appendChild(backBtn);
      app.appendChild(msg);
      return;
    }

    const { camp, members, messages } = data;
    const myMembership = campService.getJoinedByCode(code);
    const isMember = !!myMembership;
    const isCreator = isMember && camp.creator_member_id === myMembership.memberId;

    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/camps';
    backLink.textContent = '← 返回引力场';
    backLink.addEventListener('click', (e) => { e.preventDefault(); window.location.hash = '#/camps'; });
    container.appendChild(backLink);

    const header = document.createElement('div');
    header.className = 'detail-header';
    const title = document.createElement('h2');
    title.className = 'detail-title';
    title.textContent = `🏕️ ${camp.name}`;
    header.appendChild(title);
    container.appendChild(header);

    const codeBox = document.createElement('div');
    codeBox.className = 'camp-code-box';
    codeBox.innerHTML = `
      <span class="camp-code-label">组队码</span>
      <span class="camp-code-value">${camp.code}</span>
      <button class="camp-code-copy" id="code-copy">复制</button>
    `;
    container.appendChild(codeBox);
    codeBox.querySelector('#code-copy').addEventListener('click', () => {
      navigator.clipboard?.writeText(camp.code).then(() => {
        modal.toast('组队码已复制');
      }).catch(() => {
        modal.toast('复制失败，请手动记录');
      });
    });

    if (isMember) {
      const progressSection = document.createElement('div');
      progressSection.className = 'camp-update-progress';
      progressSection.innerHTML = `
        <h3 class="records-title">更新我的进度</h3>
        <div class="camp-update-row">
          <select id="my-goal-select" class="camp-member-goal">
            <option value="">不关联</option>
          </select>
          <button class="btn btn-secondary" id="my-progress-btn">上报进度</button>
        </div>
      `;
      container.appendChild(progressSection);

      const goals = goalService.getAll();
      const goalSelect = progressSection.querySelector('#my-goal-select');
      for (const g of goals) {
        const opt = document.createElement('option');
        opt.value = g.id;
        opt.textContent = g.name;
        goalSelect.appendChild(opt);
      }

      progressSection.querySelector('#my-progress-btn').addEventListener('click', () => {
        const goalId = goalSelect.value;
        let goalName = '';
        let progress = 0;
        if (goalId) {
          const detail = goalService.getById(goalId);
          if (detail) {
            goalName = detail.goal.name;
            progress = progressService.calcProgress(detail.goal.currentAmount, detail.goal.targetAmount);
          }
        }
        campService.updateProgress(code, myMembership.memberId, progress, goalName);
        modal.toast('进度已更新');
        this.render(code);
      });
    }

    const membersTitle = document.createElement('h3');
    membersTitle.className = 'records-title';
    membersTitle.textContent = `搭子进度（${members.length}/${camp.max_members || 3}）`;
    container.appendChild(membersTitle);

    const memberList = document.createElement('div');
    memberList.className = 'camp-member-list';
    for (const member of members) {
      const item = document.createElement('div');
      item.className = 'camp-member-item';
      if (isMember && member.id === myMembership.memberId) {
        item.classList.add('camp-member-me');
      }

      const info = document.createElement('div');
      info.className = 'camp-member-info';
      const nick = document.createElement('span');
      nick.className = 'camp-member-nick-name';
      nick.textContent = member.nickname + (member.id === camp.creator_member_id ? ' (创建者)' : '');
      info.appendChild(nick);

      const progressEl = document.createElement('span');
      progressEl.className = 'camp-member-progress-text';
      if (member.progress !== null && member.progress !== undefined) {
        progressEl.textContent = `${member.progress}%`;
      } else {
        progressEl.textContent = '未上报';
        progressEl.classList.add('camp-progress-na');
      }
      info.appendChild(progressEl);
      item.appendChild(info);

      const barTrack = document.createElement('div');
      barTrack.className = 'progress-bar-track';
      const barFill = document.createElement('div');
      barFill.className = 'progress-bar-fill progress-bar-active';
      barFill.style.width = `${Math.min(member.progress || 0, 100)}%`;
      barTrack.appendChild(barFill);
      item.appendChild(barTrack);

      memberList.appendChild(item);
    }
    container.appendChild(memberList);

    const msgTitle = document.createElement('h3');
    msgTitle.className = 'records-title';
    msgTitle.textContent = '留言打气';
    container.appendChild(msgTitle);

    if (isMember) {
      const msgForm = document.createElement('div');
      msgForm.className = 'camp-message-form';

      const msgInput = document.createElement('input');
      msgInput.type = 'text';
      msgInput.className = 'camp-message-input';
      msgInput.maxLength = 100;
      msgInput.placeholder = '给搭子加个油吧～';

      const sendBtn = document.createElement('button');
      sendBtn.className = 'btn btn-primary';
      sendBtn.textContent = '发送';

      msgForm.appendChild(msgInput);
      msgForm.appendChild(sendBtn);
      container.appendChild(msgForm);

      const msgError = document.createElement('span');
      msgError.className = 'form-error';
      container.appendChild(msgError);

      sendBtn.addEventListener('click', () => {
        const text = msgInput.value.trim();
        msgError.textContent = '';
        if (!text) { msgError.textContent = '留言不能为空'; return; }
        const result = campService.sendMessage(code, myMembership.memberId, myMembership.nickname, text);
        if (result.success) {
          msgInput.value = '';
          this.render(code);
        } else {
          msgError.textContent = result.error || '发送失败';
        }
      });
    }

    const sortedMsgs = [...messages].sort((a, b) => a.created_at - b.created_at);
    if (sortedMsgs.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'empty-records';
      empty.textContent = isMember ? '还没有留言，给搭子发第一条打气吧！' : '还没有留言';
      container.appendChild(empty);
    } else {
      const list = document.createElement('div');
      list.className = 'camp-message-list';
      for (const msg of sortedMsgs) {
        const item = document.createElement('div');
        item.className = 'camp-message-item';
        const head = document.createElement('div');
        head.className = 'camp-message-head';
        const nickEl = document.createElement('span');
        nickEl.className = 'camp-message-nick';
        nickEl.textContent = msg.nickname;
        const timeEl = document.createElement('span');
        timeEl.className = 'camp-message-time';
        timeEl.textContent = formatTime(msg.created_at);
        head.appendChild(nickEl);
        head.appendChild(timeEl);
        item.appendChild(head);

        const body = document.createElement('div');
        body.className = 'camp-message-body';
        body.textContent = msg.text;
        item.appendChild(body);

        if (isMember && msg.member_id === myMembership.memberId) {
          const delBtn = document.createElement('button');
          delBtn.className = 'btn-icon';
          delBtn.textContent = '🗑';
          delBtn.addEventListener('click', () => {
            modal.show('确定删除这条留言？', () => {
              campService.deleteMessage(code, msg.id);
              this.render(code);
            });
          });
          item.appendChild(delBtn);
        }

        list.appendChild(item);
      }
      container.appendChild(list);
    }

    if (isMember) {
      const dangerRow = document.createElement('div');
      dangerRow.className = 'modal-btn-group camp-danger-row';

      if (isCreator) {
        const delCampBtn = document.createElement('button');
        delCampBtn.className = 'btn btn-danger';
        delCampBtn.textContent = '解散小组';
        delCampBtn.addEventListener('click', () => {
          modal.show('确定解散该小组？所有成员和留言将被删除。', () => {
            campService.disbandCamp(code);
            modal.toast('小组已解散');
            window.location.hash = '#/camps';
          });
        });
        dangerRow.appendChild(delCampBtn);
      } else {
        const leaveBtn = document.createElement('button');
        leaveBtn.className = 'btn btn-danger';
        leaveBtn.textContent = '退出小组';
        leaveBtn.addEventListener('click', () => {
          modal.show('确定退出该小组？', () => {
            campService.leaveCamp(code, myMembership.memberId);
            modal.toast('已退出小组');
            window.location.hash = '#/camps';
          });
        });
        dangerRow.appendChild(leaveBtn);
      }
      container.appendChild(dangerRow);
    }

    app.appendChild(container);
  }
};
