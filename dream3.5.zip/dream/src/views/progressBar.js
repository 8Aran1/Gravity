export const progressBar = {
  render(progressPercent, isCompleted) {
    const colorClass = isCompleted ? 'progress-bar-completed' : 'progress-bar-active';
    const bar = document.createElement('div');
    bar.className = 'progress-bar-container';

    const track = document.createElement('div');
    track.className = 'progress-bar-track';

    const fill = document.createElement('div');
    fill.className = `progress-bar-fill ${colorClass}`;
    fill.style.width = `${Math.min(progressPercent, 100)}%`;

    track.appendChild(fill);
    bar.appendChild(track);

    const label = document.createElement('div');
    label.className = 'progress-bar-label';
    label.textContent = `${progressPercent}%`;

    bar.appendChild(label);
    return bar;
  }
};