import { knowledgeService } from '../services/knowledgeService.js';

const COPY = {
  notFoundTitle: '文章走丢啦',
  notFoundHint: '可能被流星带走啦，回列表看看其他的吧',
  backToList: '返回列表',
  minutesSuffix: ' 分钟'
};

export const knowledgeDetailView = {
  render(id) {
    try {
      const app = document.getElementById('app');
      if (!app) return;
      app.innerHTML = '';

      const container = document.createElement('div');
      container.className = 'knowledge-detail-page';

      const result = knowledgeService.getArticleById(id);

      if (result.found === true) {
        container.appendChild(this._renderArticle(result.article));
        app.appendChild(container);
        try { knowledgeService.markAsRead(id); } catch (e) {}
      } else {
        container.appendChild(this._renderNotFound());
        app.appendChild(container);
      }
    } catch (e) {
      try {
        const app = document.getElementById('app');
        if (app) {
          app.innerHTML = '';
          app.appendChild(document.createElement('span'));
        }
      } catch (ee) {}
    }
  },

  _renderArticle(article) {
    try {
      const wrapper = document.createElement('div');
      wrapper.className = 'knowledge-detail-wrapper';

      const backBtn = document.createElement('button');
      backBtn.className = 'knowledge-detail-back';
      backBtn.textContent = COPY.backToList;
      backBtn.addEventListener('click', () => { window.location.hash = '#/knowledge'; });
      wrapper.appendChild(backBtn);

      const title = document.createElement('h1');
      title.className = 'knowledge-detail-title';
      title.textContent = article.title;
      wrapper.appendChild(title);

      const meta = document.createElement('div');
      meta.className = 'knowledge-detail-meta';
      meta.textContent = article.readMinutes + COPY.minutesSuffix;
      wrapper.appendChild(meta);

      const content = document.createElement('div');
      content.className = 'knowledge-detail-content';
      const paragraphs = (article.content || '').split('\n\n');
      for (const para of paragraphs) {
        if (para.trim() === '') continue;
        const p = document.createElement('p');
        p.textContent = para;
        content.appendChild(p);
      }
      wrapper.appendChild(content);

      return wrapper;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderNotFound() {
    try {
      const wrapper = document.createElement('div');
      wrapper.className = 'knowledge-detail-not-found';

      const title = document.createElement('div');
      title.className = 'knowledge-detail-not-found-title';
      title.textContent = COPY.notFoundTitle;
      wrapper.appendChild(title);

      const hint = document.createElement('p');
      hint.textContent = COPY.notFoundHint;
      wrapper.appendChild(hint);

      const backBtn = document.createElement('button');
      backBtn.className = 'knowledge-detail-back';
      backBtn.textContent = COPY.backToList;
      backBtn.addEventListener('click', () => { window.location.hash = '#/knowledge'; });
      wrapper.appendChild(backBtn);

      return wrapper;
    } catch (e) {
      return document.createElement('span');
    }
  }
};