import { campService } from '../services/campService.js';
import { goalService } from '../services/goalService.js';
import { progressService } from '../services/progressService.js';
import { CAMP_RULES, CAMP_UI_HINTS } from '../constants.js';
import { modal } from './modal.js';

export const campFormView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/camps';
    backLink.textContent = '← 取消';
    backLink.addEventListener('click', (e) => { e.preventDefault(); window.location.hash = '#/camps'; });
    container.appendChild(backLink);

    const form = document.createElement('div');
    form.className = 'form-card';

    const title = document.createElement('h2');
    title.className = 'form-title';
    title.textContent = '创建存钱小组';
    form.appendChild(title);

    const hint = document.createElement('p');
    hint.className = 'form-hint';
    hint.textContent = '创建后系统会生成一个6位组队码，分享给搭子即可加入';
    form.appendChild(hint);

    form.insertAdjacentHTML('beforeend', `
      <div class="form-group">
        <label>小组名称</label>
        <input type="text" id="camp-name" maxlength="${CAMP_RULES.CAMP_NAME_MAX}" placeholder="如：毕业旅行小分队">
        <span class="form-error" id="error-name"></span>
      </div>
      <div class="form-group">
        <label>你的昵称</label>
        <input type="text" id="camp-nick" maxlength="${CAMP_RULES.NICKNAME_MAX}" placeholder="如：小明">
        <span class="form-error" id="error-nick"></span>
      </div>
      <div class="form-group">
        <label>最大人数</label>
        <select id="camp-max-members" class="camp-member-goal">
          ${Array.from({length: 9}, (_, i) => i + 2).map(n => `<option value="${n}"${n === 3 ? ' selected' : ''}>${n} 人</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>关联引力源（可选，用于展示进度）</label>
        <select id="camp-goal" class="camp-member-goal">
          <option value="">不关联</option>
        </select>
      </div>
      <div class="modal-btn-group">
        <button class="btn btn-secondary" id="camp-cancel">取消</button>
        <button class="btn btn-primary" id="camp-submit">创建小组</button>
      </div>
    `);

    const disclaimer = document.createElement('p');
    disclaimer.className = 'form-disclaimer';
    disclaimer.textContent = CAMP_UI_HINTS.DISCLAIMER_HINT;
    form.appendChild(disclaimer);

    container.appendChild(form);
    app.appendChild(container);

    const goals = goalService.getAll();
    const goalSelect = document.getElementById('camp-goal');
    if (goalSelect && goals && goals.length > 0) {
      for (const g of goals) {
        const opt = document.createElement('option');
        opt.value = g.id;
        opt.textContent = g.name;
        goalSelect.appendChild(opt);
      }
    }

    document.getElementById('camp-cancel').addEventListener('click', () => { window.location.hash = '#/camps'; });

    document.getElementById('camp-submit').addEventListener('click', () => {
      const name = document.getElementById('camp-name').value.trim();
      const nick = document.getElementById('camp-nick').value.trim();
      const goalId = goalSelect.value;
      const maxMembers = parseInt(document.getElementById('camp-max-members').value, 10);
      document.getElementById('error-name').textContent = '';
      document.getElementById('error-nick').textContent = '';

      if (!name) { document.getElementById('error-name').textContent = '请输入小组名称'; return; }
      if (!nick) { document.getElementById('error-nick').textContent = '请输入昵称'; return; }

      let goalName = '';
      let progress = 0;
      if (goalId) {
        const detail = goalService.getById(goalId);
        if (detail) {
          goalName = detail.goal.name;
          progress = progressService.calcProgress(detail.goal.currentAmount, detail.goal.targetAmount);
        }
      }

      const result = campService.create(name, nick, goalName, progress, maxMembers);
      if (result.campId) {
        modal.toast(`创建成功！组队码：${result.code}`);
        setTimeout(() => { window.location.hash = `#/camp/${result.code}`; }, 800);
      } else {
        modal.toast(result.error || '创建失败');
      }
    });
  }
};
