import { goalService } from '../services/goalService.js';
import { habitService } from '../services/habitService.js';
import { achievementService } from '../services/achievementService.js';
import { goalCard } from './goalCard.js';
import { toYuan } from '../utils/moneyUtils.js';
import { disclaimerView } from './disclaimerView.js';
import { userService } from '../services/userService.js';
import { charityView } from './charityView.js';
import { knowledgeListView } from './knowledgeListView.js';

export const homeView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const page = document.createElement('div');
    page.className = 'home-page';

    const goals = goalService.getAll();
    const streak = habitService.getStreakDays();
    const motivation = habitService.getMotivationText(streak);
    const totalSavedFen = goals.reduce((s, g) => s + (g.currentAmount || 0), 0);
    const activeCount = goals.filter(g => g.status === '进行中').length;
    const doneCount = goals.filter(g => g.status === '已达成' || g.currentAmount >= g.targetAmount).length;

    page.appendChild(this._renderIdentityBar());
    page.appendChild(this._renderHero(streak));
    page.appendChild(this._renderKnowledgeEntry());
    page.appendChild(this._renderStats(totalSavedFen, activeCount, doneCount, streak));
    page.appendChild(this._renderMotivation(streak, motivation));
    page.appendChild(this._renderCharityHint());
    page.appendChild(this._renderBadges());
    page.appendChild(this._renderGoalsSection(goals));
    page.appendChild(disclaimerView.render());
    page.appendChild(this._renderSettingsEntry());

    app.appendChild(page);
  },

  _renderSettingsEntry() {
    const btn = document.createElement('button');
    btn.className = 'home-settings-entry btn btn-secondary';
    btn.innerHTML = '<span class="home-settings-icon">⚙</span><span>数据管理</span>';
    btn.addEventListener('click', () => { window.location.hash = '#/settings'; });
    return btn;
  },

  _renderIdentityBar() {
    try {
      const profile = userService.getProfile();
      const bar = document.createElement('div');
      bar.className = 'home-identity-bar';

      const avatar = document.createElement('div');
      avatar.className = 'home-identity-avatar';
      avatar.textContent = userService.getAvatarEmojiByKey(profile.avatarKey);

      const nickname = document.createElement('div');
      nickname.className = 'home-identity-nickname';
      nickname.textContent = profile.nickname;

      const arrow = document.createElement('div');
      arrow.className = 'home-identity-arrow';
      arrow.textContent = '→';

      bar.appendChild(avatar);
      bar.appendChild(nickname);
      bar.appendChild(arrow);
      bar.addEventListener('click', () => { window.location.hash = '#/profile'; });
      return bar;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderHero(streak) {
    const hero = document.createElement('section');
    hero.className = 'home-hero';

    const decor = document.createElement('div');
    decor.className = 'home-hero-decor';
    decor.innerHTML = '<span class="home-hero-orb home-hero-orb-1"></span><span class="home-hero-orb home-hero-orb-2"></span><span class="home-hero-orb home-hero-orb-3"></span>';
    hero.appendChild(decor);

    const content = document.createElement('div');
    content.className = 'home-hero-content';
    content.innerHTML = `
      <p class="home-hero-eyebrow">DREAM SAVER</p>
      <h1 class="home-hero-title">引力</h1>
      <p class="home-hero-slogan">用潮牌徽章，奖励你的每一次克制</p>
    `;

    const campBtn = document.createElement('button');
    campBtn.className = 'home-hero-camp';
    campBtn.innerHTML = '<span class="home-hero-camp-icon">🏕</span><span>引力场</span><span class="home-hero-camp-arrow">→</span>';
    campBtn.addEventListener('click', () => { window.location.hash = '#/camps'; });
    content.appendChild(campBtn);

    hero.appendChild(content);
    return hero;
  },

  _renderStats(totalSavedFen, activeCount, doneCount, streak) {
    const stats = document.createElement('section');
    stats.className = 'home-stats';
    stats.innerHTML = `
      <div class="home-stat">
        <span class="home-stat-value">¥${toYuan(totalSavedFen)}</span>
        <span class="home-stat-label">累计储蓄</span>
      </div>
      <div class="home-stat">
        <span class="home-stat-value">${activeCount}<span class="home-stat-sub">/${activeCount + doneCount}</span></span>
        <span class="home-stat-label">进行中</span>
      </div>
      <div class="home-stat">
        <span class="home-stat-value home-stat-streak">${streak}</span>
        <span class="home-stat-label">连续天数</span>
      </div>
    `;
    return stats;
  },

  _renderMotivation(streak, motivation) {
    const el = document.createElement('section');
    el.className = 'home-motivation';
    const icon = streak > 0 ? '🔥' : '🌱';
    el.innerHTML = `
      <span class="home-motivation-icon">${icon}</span>
      <div class="home-motivation-body">
        <p class="home-motivation-streak">${streak} 天连续储蓄</p>
        <p class="home-motivation-text">${motivation}</p>
      </div>
    `;
    return el;
  },

  _renderKnowledgeEntry() {
    try {
      const btn = document.createElement('button');
      btn.className = 'home-knowledge-entry';
      btn.innerHTML = '<span class="home-knowledge-entry-icon">📚</span><span class="home-knowledge-entry-text">金融小课堂</span>';
      btn.addEventListener('click', () => { window.location.hash = '#/knowledge'; });
      return btn;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderCharityHint() {
    try {
      const wrapper = document.createElement('div');
      const card = charityView.renderHintCard(wrapper, (goalId) => charityView.openRedemptionModal(goalId));
      if (card) wrapper.appendChild(card);
      return wrapper;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderBadges() {
    const achievements = achievementService.getAll();
    const unlocked = achievements.filter(a => a.unlocked);
    if (unlocked.length === 0) return document.createElement('span');

    const el = document.createElement('section');
    el.className = 'home-badges';
    const row = document.createElement('div');
    row.className = 'home-badge-row';
    for (const badge of unlocked) {
      const item = document.createElement('div');
      item.className = 'home-badge';
      item.innerHTML = `<span class="home-badge-icon">${badge.badgeId === 'charity_guardian' ? '💝' : '🏆'}</span><span class="home-badge-name">${badge.name}</span>`;
      row.appendChild(item);
    }
    el.appendChild(row);
    return el;
  },

  _renderGoalsSection(goals) {
    const section = document.createElement('section');
    section.className = 'home-goals';

    const header = document.createElement('div');
    header.className = 'home-goals-header';

    const title = document.createElement('h2');
    title.className = 'home-goals-title';
    title.textContent = goals.length > 0 ? '我的梦想' : '';

    const createBtn = document.createElement('button');
    createBtn.className = 'home-create-btn';
    createBtn.innerHTML = '<span class="home-create-plus">+</span><span>新建引力源</span>';
    createBtn.addEventListener('click', () => { window.location.hash = '#/goal/new'; });

    header.appendChild(title);
    header.appendChild(createBtn);
    section.appendChild(header);

    if (goals.length === 0) {
      section.appendChild(this._renderEmpty());
    } else {
      const list = document.createElement('div');
      list.className = 'home-goal-list';
      for (const goal of goals) {
        list.appendChild(goalCard.render(goal));
      }
      section.appendChild(list);
    }

    return section;
  },

  _renderEmpty() {
    const el = document.createElement('div');
    el.className = 'home-empty';
    el.innerHTML = `
      <div class="home-empty-art">
        <span class="home-empty-ring home-empty-ring-1"></span>
        <span class="home-empty-ring home-empty-ring-2"></span>
        <span class="home-empty-seed">🌱</span>
      </div>
      <h3 class="home-empty-title">种下你的第一个梦想</h3>
      <p class="home-empty-text">每一笔储蓄都是一次浇灌<br>点击「新建引力源」，开始为梦想存钱</p>
    `;
    return el;
  }
};
