export const disclaimerView = {
  render() {
    const el = document.createElement('div');
    el.className = 'home-disclaimer';
    el.innerHTML = `
      <span class="home-disclaimer-icon">💡</span>
      <span class="home-disclaimer-text">本应用为模拟记账，不涉及真实资金交易</span>
    `;
    return el;
  }
};