export const modal = {
  show(message, onConfirm, onCancel) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const dialog = document.createElement('div');
    dialog.className = 'modal-dialog';

    const msg = document.createElement('p');
    msg.className = 'modal-message';
    msg.textContent = message;
    dialog.appendChild(msg);

    const btnGroup = document.createElement('div');
    btnGroup.className = 'modal-btn-group';

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-secondary';
    cancelBtn.textContent = '取消';

    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'btn btn-danger';
    confirmBtn.textContent = '确认';

    btnGroup.appendChild(cancelBtn);
    btnGroup.appendChild(confirmBtn);
    dialog.appendChild(btnGroup);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const close = () => {
      document.body.removeChild(overlay);
    };

    cancelBtn.addEventListener('click', () => {
      close();
      if (onCancel) onCancel();
    });

    confirmBtn.addEventListener('click', () => {
      close();
      if (onConfirm) onConfirm();
    });

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        close();
        if (onCancel) onCancel();
      }
    });
  },

  toast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('toast-show');
    }, 10);
    setTimeout(() => {
      toast.classList.remove('toast-show');
      setTimeout(() => {
        if (toast.parentNode) document.body.removeChild(toast);
      }, 300);
    }, 2000);
  }
};