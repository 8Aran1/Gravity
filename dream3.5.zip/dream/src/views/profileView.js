import { userService } from '../services/userService.js';
import { themeService } from '../services/themeService.js';
import { modal } from './modal.js';
import { USER_PROFILE_RULES } from '../constants.js';

export const profileView = {
  render() {
    try {
      const app = document.getElementById('app');
      app.innerHTML = '';

      const page = document.createElement('div');
      page.className = 'page-container profile-page';

      const backLink = document.createElement('a');
      backLink.className = 'back-link';
      backLink.href = '#/';
      backLink.textContent = '← 返回首页';
      page.appendChild(backLink);

      const title = document.createElement('h2');
      title.className = 'form-title';
      title.textContent = '个人资料';
      page.appendChild(title);

      const card = document.createElement('div');
      card.className = 'form-card';

      const profile = userService.getProfile();
      let selectedAvatarKey = profile.avatarKey;
      let selectedThemeKey = themeService.getCurrentThemeKey();

      const nickLabel = document.createElement('label');
      nickLabel.className = 'form-label';
      nickLabel.textContent = '昵称';
      card.appendChild(nickLabel);

      const nickInput = document.createElement('input');
      nickInput.type = 'text';
      nickInput.id = 'profile-nickname';
      nickInput.className = 'form-input';
      nickInput.maxLength = USER_PROFILE_RULES.NICKNAME_MAX;
      nickInput.value = profile.nickname;
      card.appendChild(nickInput);

      const avatarLabel = document.createElement('label');
      avatarLabel.className = 'form-label';
      avatarLabel.textContent = '选择头像';
      avatarLabel.style.marginTop = '16px';
      card.appendChild(avatarLabel);

      const grid = document.createElement('div');
      grid.className = 'profile-avatar-grid';
      const avatarSet = userService.getAvatarSet();
      for (const avatar of avatarSet) {
        const item = document.createElement('div');
        item.className = 'profile-avatar-item';
        if (avatar.key === selectedAvatarKey) {
          item.classList.add('selected');
        }
        item.dataset.key = avatar.key;
        item.textContent = avatar.emoji;
        item.addEventListener('click', () => {
          grid.querySelectorAll('.profile-avatar-item').forEach(el => el.classList.remove('selected'));
          item.classList.add('selected');
          selectedAvatarKey = avatar.key;
        });
        grid.appendChild(item);
      }
      card.appendChild(grid);

      this._renderThemeSection(card, (key) => { selectedThemeKey = key; });

      const saveBtn = document.createElement('button');
      saveBtn.className = 'btn btn-primary';
      saveBtn.textContent = '保存';
      saveBtn.style.marginTop = '20px';
      saveBtn.addEventListener('click', () => this._handleSave(nickInput, selectedAvatarKey, selectedThemeKey));
      card.appendChild(saveBtn);

      page.appendChild(card);
      app.appendChild(page);
    } catch (e) {
      const app = document.getElementById('app');
      if (app) {
        app.innerHTML = '<div class="page-container"><div class="empty-state"><div class="empty-icon">⚠️</div><p class="empty-text">页面加载出错</p><button class="btn btn-primary" onclick="location.hash=\'#/\'">返回首页</button></div></div>';
      }
    }
  },

  _handleSave(nickInput, avatarKey, themeKey) {
    const nickname = nickInput.value;
    const result = userService.saveProfile({ nickname, avatarKey, themeKey });
    if (result.success) {
      themeService.applyTheme(themeKey);
      modal.toast('保存成功');
      window.location.hash = '#/';
    } else if (result.errors) {
      modal.toast(result.errors.nickname || result.errors.avatar);
    } else if (result.error) {
      modal.toast(result.error);
    }
  },

  _renderThemeSection(card, onSelect) {
    try {
      const themeLabel = document.createElement('label');
      themeLabel.className = 'form-label';
      themeLabel.textContent = '更换背景';
      themeLabel.style.marginTop = '16px';
      card.appendChild(themeLabel);

      const grid = document.createElement('div');
      grid.className = 'profile-theme-grid';
      const themeSet = themeService.getThemeSet();
      const currentKey = themeService.getCurrentThemeKey();
      for (const theme of themeSet) {
        const item = document.createElement('div');
        item.className = 'profile-theme-item';
        if (theme.key === currentKey) {
          item.classList.add('selected');
        }
        item.dataset.key = theme.key;

        const preview = document.createElement('div');
        preview.className = 'profile-theme-preview';
        preview.style.background = theme.gradient;

        const name = document.createElement('div');
        name.className = 'profile-theme-name';
        name.textContent = theme.name;

        item.appendChild(preview);
        item.appendChild(name);
        item.addEventListener('click', () => {
          grid.querySelectorAll('.profile-theme-item').forEach(el => el.classList.remove('selected'));
          item.classList.add('selected');
          if (typeof onSelect === 'function') onSelect(theme.key);
        });
        grid.appendChild(item);
      }
      card.appendChild(grid);
    } catch (e) {}
  }
};