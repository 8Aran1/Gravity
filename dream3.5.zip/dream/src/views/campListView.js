import { campService } from '../services/campService.js';
import { CAMP_UI_HINTS } from '../constants.js';

export const campListView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const page = document.createElement('div');
    page.className = 'home-page';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/';
    backLink.textContent = '← 返回首页';
    backLink.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.hash = '#/';
    });
    page.appendChild(backLink);

    const hero = document.createElement('section');
    hero.className = 'home-hero';
    hero.innerHTML = `
      <div class="home-hero-decor">
        <span class="home-hero-orb home-hero-orb-1"></span>
        <span class="home-hero-orb home-hero-orb-2"></span>
        <span class="home-hero-orb home-hero-orb-3"></span>
      </div>
      <div class="home-hero-content">
        <p class="home-hero-eyebrow">Savings Camp</p>
        <h1 class="home-hero-title">引力场</h1>
        <p class="home-hero-slogan">和搭子一起存钱，互相打气</p>
      </div>
    `;
    page.appendChild(hero);

    const camps = campService.getJoinedCamps();
    const section = document.createElement('section');
    section.className = 'home-goals';

    const header = document.createElement('div');
    header.className = 'home-goals-header';

    const title = document.createElement('h2');
    title.className = 'home-goals-title';
    title.textContent = camps.length > 0 ? '我的小组' : '';

    const btnGroup = document.createElement('div');
    btnGroup.className = 'camp-list-actions';

    const joinBtn = document.createElement('button');
    joinBtn.className = 'home-create-btn camp-join-btn';
    joinBtn.innerHTML = '<span class="home-create-plus">↗</span><span>加入小组</span>';
    joinBtn.addEventListener('click', () => { window.location.hash = '#/camp/join'; });

    const createBtn = document.createElement('button');
    createBtn.className = 'home-create-btn';
    createBtn.innerHTML = '<span class="home-create-plus">+</span><span>新建小组</span>';
    createBtn.addEventListener('click', () => { window.location.hash = '#/camp/new'; });

    btnGroup.appendChild(joinBtn);
    btnGroup.appendChild(createBtn);
    header.appendChild(title);
    header.appendChild(btnGroup);
    section.appendChild(header);

    if (camps.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'home-empty';
      empty.innerHTML = `
        <div class="home-empty-art">
          <span class="home-empty-ring home-empty-ring-1"></span>
          <span class="home-empty-ring home-empty-ring-2"></span>
          <span class="home-empty-seed">🏕️</span>
        </div>
        <h3 class="home-empty-title">拉上搭子一起存钱</h3>
        <p class="home-empty-text">一个人走得快，一群人走得远<br>「新建小组」生成组队码，或「加入小组」输入搭子分享的码</p>
      `;
      section.appendChild(empty);
    } else {
      const list = document.createElement('div');
      list.className = 'home-goal-list';
      for (const camp of camps) {
        const card = document.createElement('div');
        card.className = 'goal-card camp-joined-card';
        card.innerHTML = `
          <div class="goal-card-header">
            <h3 class="goal-card-name">🏕️ ${camp.campName}</h3>
          </div>
          <div class="camp-code-badge">组队码 ${camp.code}</div>
          <div class="camp-card-meta">你的昵称：${camp.nickname}</div>
        `;
        card.addEventListener('click', () => { window.location.hash = `#/camp/${camp.code}`; });
        list.appendChild(card);
      }
      section.appendChild(list);
    }

    page.appendChild(section);

    const helpFab = document.createElement('button');
    helpFab.className = 'camp-help-fab';
    helpFab.textContent = '?';

    const helpDialog = document.createElement('div');
    helpDialog.className = 'camp-help-dialog';
    helpDialog.style.display = 'none';

    const overlay = document.createElement('div');
    overlay.className = 'camp-help-dialog-overlay';

    const dialogContent = document.createElement('div');
    dialogContent.className = 'camp-help-dialog-content';

    const helpTitle = document.createElement('h3');
    helpTitle.textContent = '如何测试多人互动？';

    const helpText = document.createElement('p');
    helpText.textContent = CAMP_UI_HINTS.HELP_GUIDE;

    const closeBtn = document.createElement('button');
    closeBtn.className = 'camp-help-dialog-close';
    closeBtn.textContent = '知道了';

    dialogContent.appendChild(helpTitle);
    dialogContent.appendChild(helpText);
    dialogContent.appendChild(closeBtn);
    helpDialog.appendChild(overlay);
    helpDialog.appendChild(dialogContent);

    helpFab.addEventListener('click', () => {
      helpDialog.style.display = 'flex';
    });
    overlay.addEventListener('click', () => {
      helpDialog.style.display = 'none';
    });
    closeBtn.addEventListener('click', () => {
      helpDialog.style.display = 'none';
    });

    page.appendChild(helpFab);
    page.appendChild(helpDialog);

    app.appendChild(page);
  }
};
