import { campService } from '../services/campService.js';
import { goalService } from '../services/goalService.js';
import { progressService } from '../services/progressService.js';
import { CAMP_RULES, CAMP_UI_HINTS } from '../constants.js';
import { modal } from './modal.js';

export const campJoinView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/camps';
    backLink.textContent = '← 取消';
    backLink.addEventListener('click', (e) => { e.preventDefault(); window.location.hash = '#/camps'; });
    container.appendChild(backLink);

    const form = document.createElement('div');
    form.className = 'form-card';

    const title = document.createElement('h2');
    title.className = 'form-title';
    title.textContent = '加入存钱小组';
    form.appendChild(title);

    const hint = document.createElement('p');
    hint.className = 'form-hint';
    hint.textContent = '输入搭子分享的6位组队码，一起存钱';
    form.appendChild(hint);

    form.innerHTML += `
      <div class="form-group">
        <label>组队码</label>
        <input type="text" id="join-code" maxlength="6" placeholder="6位数字" inputmode="numeric">
        <span class="form-error" id="error-code"></span>
      </div>
      <div class="form-group">
        <label>你的昵称</label>
        <input type="text" id="join-nick" maxlength="${CAMP_RULES.NICKNAME_MAX}" placeholder="如：小红">
        <span class="form-error" id="error-nick"></span>
      </div>
      <div class="form-group">
        <label>关联引力源（可选，用于展示进度）</label>
        <select id="join-goal" class="camp-member-goal">
          <option value="">不关联</option>
        </select>
      </div>
      <div class="modal-btn-group">
        <button class="btn btn-secondary" id="join-cancel">取消</button>
        <button class="btn btn-primary" id="join-submit">加入小组</button>
      </div>
    `;

    const disclaimer = document.createElement('p');
    disclaimer.className = 'form-disclaimer';
    disclaimer.textContent = CAMP_UI_HINTS.DISCLAIMER_HINT;
    form.appendChild(disclaimer);

    container.appendChild(form);
    app.appendChild(container);

    const goals = goalService.getAll();
    const goalSelect = document.getElementById('join-goal');
    for (const g of goals) {
      const opt = document.createElement('option');
      opt.value = g.id;
      opt.textContent = g.name;
      goalSelect.appendChild(opt);
    }

    const codeInput = document.getElementById('join-code');
    codeInput.addEventListener('input', () => {
      codeInput.value = codeInput.value.replace(/\D/g, '');
    });

    document.getElementById('join-cancel').addEventListener('click', () => { window.location.hash = '#/camps'; });

    document.getElementById('join-submit').addEventListener('click', () => {
      const code = codeInput.value.trim();
      const nick = document.getElementById('join-nick').value.trim();
      const goalId = goalSelect.value;
      document.getElementById('error-code').textContent = '';
      document.getElementById('error-nick').textContent = '';

      if (!code) { document.getElementById('error-code').textContent = '请输入组队码'; return; }
      if (code.length !== 6) { document.getElementById('error-code').textContent = '组队码为6位数字'; return; }
      if (!nick) { document.getElementById('error-nick').textContent = '请输入昵称'; return; }

      let goalName = '';
      let progress = 0;
      if (goalId) {
        const detail = goalService.getById(goalId);
        if (detail) {
          goalName = detail.goal.name;
          progress = progressService.calcProgress(detail.goal.currentAmount, detail.goal.targetAmount);
        }
      }

      const result = campService.join(code, nick, goalName, progress);
      if (result.success) {
        modal.toast('加入成功！');
        setTimeout(() => { window.location.hash = `#/camp/${code}`; }, 600);
      } else {
        modal.toast(result.error || '加入失败');
      }
    });
  }
};