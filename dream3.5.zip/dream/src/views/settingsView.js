import { backupService } from '../services/backupService.js';
import { fileUtils } from '../utils/fileUtils.js';
import { modal } from './modal.js';
import { onboardingTutorial } from './onboardingTutorial.js';

function pad(n) {
  return String(n).padStart(2, '0');
}

function buildFilename() {
  const d = new Date();
  return `dream-backup-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}.json`;
}

export const settingsView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const page = document.createElement('div');
    page.className = 'settings-page';

    const header = document.createElement('div');
    header.className = 'settings-header';
    header.innerHTML = '<h2 class="settings-title">数据管理</h2>';
    const backBtn = document.createElement('button');
    backBtn.className = 'btn btn-secondary settings-back';
    backBtn.textContent = '返回首页';
    backBtn.addEventListener('click', () => { location.hash = '#/'; });
    header.appendChild(backBtn);
    page.appendChild(header);

    page.appendChild(this._renderExportCard());
    page.appendChild(this._renderImportCard());
    page.appendChild(this._renderClearCard());
    page.appendChild(this._renderTutorialCard());

    app.appendChild(page);
  },

  _renderExportCard() {
    const card = document.createElement('div');
    card.className = 'settings-card';
    card.innerHTML = `
      <span class="settings-card-icon">📥</span>
      <div class="settings-card-body">
        <div class="settings-card-title">导出数据</div>
        <div class="settings-card-desc">将全部数据下载为 JSON 文件</div>
      </div>
    `;
    const btn = document.createElement('button');
    btn.className = 'btn btn-primary settings-card-btn';
    btn.textContent = '导出';
    btn.addEventListener('click', () => this._handleExport());
    card.appendChild(btn);
    return card;
  },

  _renderImportCard() {
    const card = document.createElement('div');
    card.className = 'settings-card';
    card.innerHTML = `
      <span class="settings-card-icon">📤</span>
      <div class="settings-card-body">
        <div class="settings-card-title">导入数据</div>
        <div class="settings-card-desc">从 JSON 备份恢复数据，将覆盖现有数据</div>
      </div>
    `;
    const btn = document.createElement('button');
    btn.className = 'btn btn-secondary settings-card-btn';
    btn.textContent = '导入';
    btn.addEventListener('click', () => this._handleImport());
    card.appendChild(btn);
    return card;
  },

  _renderClearCard() {
    const card = document.createElement('div');
    card.className = 'settings-card settings-card-danger';
    card.innerHTML = `
      <span class="settings-card-icon">🗑</span>
      <div class="settings-card-body">
        <div class="settings-card-title">清空所有数据</div>
        <div class="settings-card-desc">移除全部本地数据，不可恢复</div>
      </div>
    `;
    const btn = document.createElement('button');
    btn.className = 'btn btn-danger settings-card-btn';
    btn.textContent = '清空';
    btn.addEventListener('click', () => this._handleClear());
    card.appendChild(btn);
    return card;
  },

  _handleExport() {
    const result = backupService.exportData();
    if (!result.success) {
      modal.toast(result.error);
      return;
    }
    const filename = buildFilename();
    const dl = fileUtils.downloadJson(filename, result.data);
    if (dl.success) {
      modal.toast('导出成功');
    } else {
      modal.toast(dl.error);
    }
  },

  async _handleImport() {
    let picked;
    try {
      picked = await fileUtils.pickJsonFile();
    } catch (e) {
      if (e && e.canceled) return;
      if (e && e.parseError) {
        modal.toast('文件解析失败，请确认其为本应用导出的 JSON 备份');
        return;
      }
      return;
    }
    const { parsed } = picked;
    const v = backupService.validateBackup(parsed);
    if (!v.valid) {
      modal.toast(v.reason);
      return;
    }
    modal.show(
      '导入将覆盖现有全部数据且不可恢复，是否继续？',
      () => {
        const r = backupService.applyImport(parsed);
        if (r.success) {
          location.reload();
        } else {
          modal.toast(r.error);
        }
      },
      null
    );
  },

  _handleClear() {
    modal.show(
      '将清空全部引力源、打卡记录、引力场等数据且不可恢复，是否继续？',
      () => {
        const r = backupService.clearAllData();
        if (r.success) {
          location.reload();
        } else {
          modal.toast(r.error);
        }
      },
      null
    );
  },

  _renderTutorialCard() {
    const card = document.createElement('div');
    card.className = 'settings-card';
    card.innerHTML = `
      <span class="settings-card-icon">🎓</span>
      <div class="settings-card-body">
        <div class="settings-card-title">重新观看教程</div>
        <div class="settings-card-desc">重新学习引力系术语与功能</div>
      </div>
    `;
    const btn = document.createElement('button');
    btn.className = 'btn btn-secondary settings-card-btn';
    btn.textContent = '观看';
    btn.addEventListener('click', () => {
      try {
        onboardingTutorial.restart();
        modal.toast('教程已重置');
      } catch (e) {
        modal.toast('教程启动失败，请重试');
      }
    });
    card.appendChild(btn);
    return card;
  }
};