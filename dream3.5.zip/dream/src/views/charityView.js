import { charityService } from '../services/charityService.js';
import { modal } from './modal.js';

const HINT_COPY = {
  title: '昨天没坚持住，没关系',
  body: '来做点好事，把陪伴补回来吧',
  cta: '来做点好事修复吧',
  closeAria: '关闭提示'
};

export const charityView = {
  renderHintCard(container, onOpenModal) {
    try {
      const detection = charityService.detectYesterdayMiss();
      if (!detection.missed || charityService.isHintClosedToday()) return null;

      const card = document.createElement('div');
      card.className = 'charity-hint-card';

      const text = document.createElement('div');
      text.className = 'charity-hint-text';
      const title = document.createElement('div');
      title.className = 'charity-hint-title';
      title.textContent = HINT_COPY.title;
      const body = document.createElement('div');
      body.className = 'charity-hint-body';
      body.textContent = HINT_COPY.body;
      text.appendChild(title);
      text.appendChild(body);
      card.appendChild(text);

      const cta = document.createElement('button');
      cta.className = 'charity-hint-cta';
      cta.textContent = HINT_COPY.cta;
      cta.addEventListener('click', () => {
        if (typeof onOpenModal === 'function') onOpenModal(detection.goalId);
      });
      card.appendChild(cta);

      const close = document.createElement('button');
      close.className = 'charity-hint-close';
      close.textContent = '×';
      close.setAttribute('aria-label', HINT_COPY.closeAria);
      close.addEventListener('click', () => {
        charityService.markHintClosed();
        if (card.parentNode) card.parentNode.removeChild(card);
      });
      card.appendChild(close);

      return card;
    } catch (e) {
      return null;
    }
  },

  openRedemptionModal(goalId) {
    try {
      const overlay = document.createElement('div');
      overlay.className = 'charity-modal-overlay';
      overlay._charityGoalId = goalId;

      const dialog = document.createElement('div');
      dialog.className = 'charity-modal-dialog';
      overlay.appendChild(dialog);

      this._renderTaskSelect(dialog, goalId);

      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this._closeModal(overlay);
      });

      document.body.appendChild(overlay);
    } catch (e) {
      try { modal.toast('稍后再试'); } catch (ee) {}
    }
  },

  _renderTaskSelect(dialog, goalId) {
    try {
      dialog.innerHTML = '';
      const title = document.createElement('div');
      title.className = 'charity-modal-title';
      title.textContent = '做点好事，修复昨天';
      dialog.appendChild(title);

      const subtitle = document.createElement('div');
      subtitle.className = 'charity-modal-subtitle';
      subtitle.textContent = '选择一种方式，把陪伴补回来';
      dialog.appendChild(subtitle);

      const stepsEntry = document.createElement('button');
      stepsEntry.className = 'charity-task-entry';
      stepsEntry.innerHTML = '<span class="charity-task-icon">👣</span><span>捐赠步数</span>';
      stepsEntry.addEventListener('click', () => this._renderStepsPanel(dialog, goalId));
      dialog.appendChild(stepsEntry);

      const quizEntry = document.createElement('button');
      quizEntry.className = 'charity-task-entry';
      quizEntry.innerHTML = '<span class="charity-task-icon">🛡</span><span>反诈答题</span>';
      quizEntry.addEventListener('click', () => this._renderQuizPanel(dialog, goalId));
      dialog.appendChild(quizEntry);
    } catch (e) {
      try { modal.toast('稍后再试'); } catch (ee) {}
    }
  },

  _renderStepsPanel(dialog, goalId) {
    try {
      dialog.innerHTML = '';
      const title = document.createElement('div');
      title.className = 'charity-modal-title';
      title.textContent = '模拟捐赠步数';
      dialog.appendChild(title);

      const subtitle = document.createElement('div');
      subtitle.className = 'charity-modal-subtitle';
      subtitle.textContent = '点击下方按钮，生成今日步数';
      dialog.appendChild(subtitle);

      const trigger = document.createElement('button');
      trigger.className = 'charity-steps-trigger';
      trigger.textContent = '生成步数';
      dialog.appendChild(trigger);

      trigger.addEventListener('click', () => {
        if (trigger.disabled) return;
        trigger.disabled = true;

        const result = charityService.generateSteps();
        const display = document.createElement('div');
        display.className = 'charity-steps-display';
        display.textContent = result.steps + ' 步';
        dialog.appendChild(display);

        const hint = document.createElement('div');
        hint.className = 'charity-steps-hint';
        hint.textContent = '正在修复…';
        dialog.appendChild(hint);

        setTimeout(() => {
          try {
            const repair = charityService.repairYesterdayCheckIn(goalId);
            if (repair.success) {
              const badgeResult = charityService.unlockGuardianBadge();
              this._renderSuccessPanel(dialog, badgeResult.badge);
            } else {
              try { modal.toast(repair.message); } catch (ee) {}
              trigger.disabled = false;
              if (display.parentNode) display.parentNode.removeChild(display);
              if (hint.parentNode) hint.parentNode.removeChild(hint);
            }
          } catch (e) {
            try { modal.toast('稍后再试'); } catch (ee) {}
            trigger.disabled = false;
          }
        }, 600);
      });
    } catch (e) {
      try { modal.toast('稍后再试'); } catch (ee) {}
    }
  },

  _renderQuizPanel(dialog, goalId) {
    try {
      dialog.innerHTML = '';
      const question = charityService.getAntiFraudQuestion();

      const title = document.createElement('div');
      title.className = 'charity-modal-title';
      title.textContent = '反诈知识小问答';
      dialog.appendChild(title);

      const stem = document.createElement('div');
      stem.className = 'charity-quiz-stem';
      stem.textContent = question.stem;
      dialog.appendChild(stem);

      const optionsContainer = document.createElement('div');
      optionsContainer.className = 'charity-quiz-options';
      for (let i = 0; i < question.options.length; i++) {
        const opt = document.createElement('button');
        opt.className = 'charity-quiz-option';
        opt.textContent = question.options[i];
        const selectedIndex = i;
        opt.addEventListener('click', () => {
          if (opt.disabled) return;
          const check = charityService.isAnswerCorrect(question, selectedIndex);
          if (check.correct) {
            opt.classList.add('charity-quiz-option--correct');
            optionsContainer.querySelectorAll('.charity-quiz-option').forEach(b => b.disabled = true);
            setTimeout(() => {
              try {
                const repair = charityService.repairYesterdayCheckIn(goalId);
                if (repair.success) {
                  const badgeResult = charityService.unlockGuardianBadge();
                  this._renderSuccessPanel(dialog, badgeResult.badge);
                } else {
                  try { modal.toast(repair.message); } catch (ee) {}
                }
              } catch (e) {
                try { modal.toast('稍后再试'); } catch (ee) {}
              }
            }, 800);
          } else {
            opt.classList.add('charity-quiz-option--wrong');
            try { modal.toast('再想想看，答对即可修复'); } catch (ee) {}
            setTimeout(() => {
              opt.classList.remove('charity-quiz-option--wrong');
            }, 1000);
          }
        });
        optionsContainer.appendChild(opt);
      }
      dialog.appendChild(optionsContainer);
    } catch (e) {
      try { modal.toast('稍后再试'); } catch (ee) {}
    }
  },

  _renderSuccessPanel(dialog, badge) {
    try {
      dialog.innerHTML = '';
      const title = document.createElement('div');
      title.className = 'charity-modal-title';
      title.textContent = '昨天的陪伴已经补回来啦';
      dialog.appendChild(title);

      const badgeEl = document.createElement('div');
      badgeEl.className = 'charity-success-badge';
      const icon = document.createElement('div');
      icon.className = 'charity-success-badge-icon';
      icon.textContent = '💝';
      const name = document.createElement('div');
      name.className = 'charity-success-badge-name';
      name.textContent = (badge && badge.name) || '公益守护者';
      const cond = document.createElement('div');
      cond.className = 'charity-success-badge-cond';
      cond.textContent = (badge && badge.unlockCondition) || '完成一次公益赎回';
      badgeEl.appendChild(icon);
      badgeEl.appendChild(name);
      badgeEl.appendChild(cond);
      dialog.appendChild(badgeEl);

      const backBtn = document.createElement('button');
      backBtn.className = 'charity-success-btn';
      backBtn.textContent = '返回';
      backBtn.addEventListener('click', () => {
        const overlay = dialog.parentElement;
        this._closeModal(overlay);
      });
      dialog.appendChild(backBtn);

      const viewBtn = document.createElement('button');
      viewBtn.className = 'charity-success-btn charity-success-btn--secondary';
      viewBtn.textContent = '查看徽章';
      viewBtn.addEventListener('click', () => {
        const overlay = dialog.parentElement;
        this._closeModal(overlay);
        try { modal.toast('徽章已收藏到徽章墙'); } catch (ee) {}
      });
      dialog.appendChild(viewBtn);
    } catch (e) {
      try { modal.toast('修复成功'); } catch (ee) {}
      const overlay = dialog.parentElement;
      this._closeModal(overlay);
    }
  },

  _closeModal(overlay) {
    try {
      if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
    } catch (e) {}
  }
};