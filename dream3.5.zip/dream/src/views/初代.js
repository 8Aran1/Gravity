import { campService } from '../services/campService.js';

export const campListView = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/';
    backLink.textContent = '← 返回首页';
    container.appendChild(backLink);

    const header = document.createElement('header');
    header.className = 'app-header';
    const title = document.createElement('h1');
    title.className = 'app-title';
    title.textContent = '储蓄营';
    const slogan = document.createElement('p');
    slogan.className = 'app-slogan';
    slogan.textContent = '和搭子一起存钱，互相打气';
    header.appendChild(title);
    header.appendChild(slogan);
    container.appendChild(header);

    const createBtn = document.createElement('button');
    createBtn.className = 'btn btn-primary btn-large';
    createBtn.textContent = '创建存钱小组';
    createBtn.addEventListener('click', () => { window.location.hash = '#/camp/new'; });

    const camps = campService.getAll();

    if (camps.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      const icon = document.createElement('div');
      icon.className = 'empty-icon';
      icon.textContent = '🏕️';
      const t = document.createElement('p');
      t.className = 'empty-text';
      t.textContent = '还没有存钱小组，拉上搭子一起为梦想存钱吧！';
      empty.appendChild(icon);
      empty.appendChild(t);
      empty.appendChild(createBtn);
      container.appendChild(empty);
    } else {
      const wrap = document.createElement('div');
      wrap.className = 'btn-wrapper';
      wrap.appendChild(createBtn);
      container.appendChild(wrap);

      const list = document.createElement('div');
      list.className = 'goal-card-list';
      for (const camp of camps) {
        const card = document.createElement('div');
        card.className = 'goal-card';
        const cardHeader = document.createElement('div');
        cardHeader.className = 'goal-card-header';
        const cardName = document.createElement('h3');
        cardName.className = 'goal-card-name';
        cardName.textContent = `🏕️ ${camp.name}`;
        cardHeader.appendChild(cardName);
        card.appendChild(cardHeader);
        const meta = document.createElement('div');
        meta.className = 'camp-card-meta';
        meta.textContent = `${camp.members.length} 位搭子 · ${camp.messages.length} 条留言`;
        card.appendChild(meta);
        card.addEventListener('click', () => { window.location.hash = `#/camp/${camp.id}`; });
        list.appendChild(card);
      }
      container.appendChild(list);
    }

    app.appendChild(container);
  }
};