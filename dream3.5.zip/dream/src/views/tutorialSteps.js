import { termMapping } from './termMapping.js';

export const tutorialSteps = {
  ALL: [
    {
      id: 0,
      title: '第一步：建立引力源',
      plainText: '第一步：点击这里，写下你的存钱目标。',
      termRef: termMapping.GRAVITY_SOURCE,
      targetHash: '#/',
      targetSelector: '.home-create-btn',
      targetHint: '看，这就是"新建引力源"的按钮，点它就能创建一个目标',
      fallback: '点击首页"新建引力源"按钮创建你的存钱目标',
      buttons: { showSkip: true },
      sensing: {
        hashchange: true,
        storagePoll: null,
        mutationObserver: null,
        condition: { hash: '#/goal/new' },
        pollInterval: null
      }
    },
    {
      id: 1,
      title: '第二步：打卡',
      plainText: '第二步：点这里存入一笔钱，进度条就会增长！',
      termRef: termMapping.CHECK_IN,
      targetHash: '#/',
      targetSelector: '.home-stats',
      targetHint: '点这里的打卡区域，存入一笔钱试试',
      fallback: '在首页打卡区域存入一笔钱，进度条会增长',
      buttons: { showSkip: true },
      sensing: {
        hashchange: true,
        storagePoll: { key: 'dream_saving_camp_data' },
        mutationObserver: { selector: '.home-stats' },
        condition: { storageChanged: true, domAppears: null, hash: null },
        pollInterval: 1500
      }
    },
    {
      id: 2,
      title: '第三步：引力小助手/引力场',
      plainText: '第三步：点这里，找个搭子一起存钱，或者问问AI顾问！',
      termRef: termMapping.GRAVITY_ASSISTANT,
      targetHash: '#/',
      targetSelector: '.advisor-fab',
      targetHint: '点右下角气泡找AI顾问聊聊，或点"引力场"找搭子',
      fallback: '点右下角引力小助手或首页引力场入口',
      buttons: { showSkip: true },
      sensing: {
        hashchange: true,
        storagePoll: null,
        mutationObserver: { selector: '.advisor-root' },
        condition: { hash: '#/camps', domAppears: '.advisor-root', storageChanged: false },
        pollInterval: null
      }
    }
  ]
};

tutorialSteps.TOTAL = tutorialSteps.ALL.length;
