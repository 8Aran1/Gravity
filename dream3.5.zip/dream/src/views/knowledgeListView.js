import { knowledgeService } from '../services/knowledgeService.js';

const COPY = {
  listTitle: '金融小课堂',
  emptyHint: '暂时还没有内容哦',
  backToHome: '返回首页',
  readTag: '已读',
  minutesSuffix: ' 分钟'
};

export const knowledgeListView = {
  render() {
    try {
      const app = document.getElementById('app');
      if (!app) return;
      app.innerHTML = '';

      const container = document.createElement('div');
      container.className = 'knowledge-list-page';

      container.appendChild(this._renderHeader());

      const articles = knowledgeService.getAllArticles();
      const readIds = knowledgeService.getReadIds();

      if (articles.length === 0) {
        container.appendChild(this._renderEmpty());
      } else {
        for (const article of articles) {
          if (!article.id || !article.title || !article.summary || !article.content || !article.readMinutes) continue;
          container.appendChild(this._renderCard(article, readIds.includes(article.id)));
        }
      }

      app.appendChild(container);
    } catch (e) {
      try {
        const app = document.getElementById('app');
        if (app) {
          app.innerHTML = '';
          app.appendChild(document.createElement('span'));
        }
      } catch (ee) {}
    }
  },

  _renderHeader() {
    try {
      const header = document.createElement('div');
      header.className = 'knowledge-list-header';

      const title = document.createElement('h1');
      title.className = 'knowledge-list-title';
      title.textContent = COPY.listTitle;
      header.appendChild(title);

      const backBtn = document.createElement('button');
      backBtn.className = 'knowledge-back-btn';
      backBtn.textContent = COPY.backToHome;
      backBtn.addEventListener('click', () => { window.location.hash = '#/'; });
      header.appendChild(backBtn);

      return header;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderCard(article, isRead) {
    try {
      const card = document.createElement('div');
      card.className = 'knowledge-card';

      const title = document.createElement('div');
      title.className = 'knowledge-card-title';
      title.textContent = article.title;
      card.appendChild(title);

      const summary = document.createElement('div');
      summary.className = 'knowledge-card-summary';
      summary.textContent = article.summary;
      card.appendChild(summary);

      const meta = document.createElement('div');
      meta.className = 'knowledge-card-meta';

      const minutes = document.createElement('span');
      minutes.textContent = article.readMinutes + COPY.minutesSuffix;
      meta.appendChild(minutes);

      if (isRead === true) {
        const tag = document.createElement('span');
        tag.className = 'knowledge-card-read-tag';
        tag.textContent = COPY.readTag;
        meta.appendChild(tag);
      }

      card.appendChild(meta);

      card.addEventListener('click', () => {
        window.location.hash = '#/knowledge/' + article.id;
      });

      return card;
    } catch (e) {
      return document.createElement('span');
    }
  },

  _renderEmpty() {
    try {
      const empty = document.createElement('div');
      empty.className = 'knowledge-empty';

      const hint = document.createElement('p');
      hint.textContent = COPY.emptyHint;
      empty.appendChild(hint);

      const backBtn = document.createElement('button');
      backBtn.className = 'knowledge-back-btn';
      backBtn.textContent = COPY.backToHome;
      backBtn.addEventListener('click', () => { window.location.hash = '#/'; });
      empty.appendChild(backBtn);

      return empty;
    } catch (e) {
      return document.createElement('span');
    }
  }
};