import { goalService } from '../services/goalService.js';
import { today } from '../utils/dateUtils.js';
import { toYuan } from '../utils/moneyUtils.js';
import { modal } from './modal.js';

export const goalFormView = {
  renderCreate() {
    this._renderForm(null);
  },

  renderEdit(goalId) {
    const detail = goalService.getById(goalId);
    if (!detail) {
      modal.toast('目标不存在或已被删除');
      window.location.hash = '#/';
      return;
    }
    this._renderForm(detail.goal);
  },

  _renderForm(existingGoal) {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const isEdit = !!existingGoal;
    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = isEdit ? `#/goal/${existingGoal.id}` : '#/';
    backLink.textContent = '← 取消';
    backLink.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.hash = isEdit ? `#/goal/${existingGoal.id}` : '#/';
    });
    container.appendChild(backLink);

    const form = document.createElement('div');
    form.className = 'form-card';

    const title = document.createElement('h2');
    title.className = 'form-title';
    title.textContent = isEdit ? '编辑引力源' : '建立引力源';
    form.appendChild(title);

    const nameGroup = document.createElement('div');
    nameGroup.className = 'form-group';
    nameGroup.innerHTML = `
      <label>目标名称</label>
      <input type="text" id="goal-name" maxlength="20" placeholder="如：换新电脑" value="${isEdit ? existingGoal.name : ''}">
      <span class="form-error" id="error-name"></span>
    `;
    form.appendChild(nameGroup);

    const amountGroup = document.createElement('div');
    amountGroup.className = 'form-group';
    amountGroup.innerHTML = `
      <label>目标金额（元）</label>
      <input type="number" id="goal-amount" step="0.01" min="0.01" max="999999.99" placeholder="如：8000" value="${isEdit ? toYuan(existingGoal.targetAmount) : ''}">
      <span class="form-error" id="error-targetAmount"></span>
    `;
    form.appendChild(amountGroup);

    const dateGroup = document.createElement('div');
    dateGroup.className = 'form-group';
    dateGroup.innerHTML = `
      <label>计划完成日期</label>
      <input type="date" id="goal-date" min="${this._tomorrow()}" value="${isEdit ? existingGoal.plannedDate : ''}">
      <span class="form-error" id="error-plannedDate"></span>
    `;
    form.appendChild(dateGroup);

    const withdrawGroup = document.createElement('div');
    withdrawGroup.className = 'form-group';
    withdrawGroup.innerHTML = `
      <label class="form-check">
        <input type="checkbox" id="goal-allow-withdraw" ${isEdit ? (existingGoal.allowWithdraw !== false ? 'checked' : '') : 'checked'}>
        <span>开启逃逸（可中途按需取出已存金额，须经冷静期）</span>
      </label>
    `;
    form.appendChild(withdrawGroup);

    const btnGroup = document.createElement('div');
    btnGroup.className = 'modal-btn-group';

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-secondary';
    cancelBtn.textContent = '取消';
    cancelBtn.addEventListener('click', () => {
      window.location.hash = isEdit ? `#/goal/${existingGoal.id}` : '#/';
    });

    const submitBtn = document.createElement('button');
    submitBtn.className = 'btn btn-primary';
    submitBtn.textContent = isEdit ? '保存修改' : '建立引力源';

    btnGroup.appendChild(cancelBtn);
    btnGroup.appendChild(submitBtn);
    form.appendChild(btnGroup);

    container.appendChild(form);
    app.appendChild(container);

    submitBtn.addEventListener('click', () => {
      const name = document.getElementById('goal-name').value;
      const targetAmount = document.getElementById('goal-amount').value;
      const plannedDate = document.getElementById('goal-date').value;

      document.querySelectorAll('.form-error').forEach(el => el.textContent = '');

      if (isEdit) {
        const allowWithdraw = document.getElementById('goal-allow-withdraw').checked;
        const result = goalService.update(existingGoal.id, { name, targetAmount, plannedDate, allowWithdraw });
        if (result.success) {
          if (result.warning) {
            modal.show(result.warning + '\n\n是否确认保存？', () => {
              modal.toast('修改成功');
              window.location.hash = `#/goal/${existingGoal.id}`;
            });
          } else {
            modal.toast('修改成功');
            window.location.hash = `#/goal/${existingGoal.id}`;
          }
        } else if (result.errors) {
          for (const [field, msg] of Object.entries(result.errors)) {
            const errEl = document.getElementById(`error-${field}`);
            if (errEl) errEl.textContent = msg;
          }
        } else {
          modal.toast(result.error || '操作失败');
        }
      } else {
        const allowWithdraw = document.getElementById('goal-allow-withdraw').checked;
        const result = goalService.create({ name, targetAmount, plannedDate, allowWithdraw });
        if (result.success) {
          modal.toast('创建成功！');
          window.location.hash = '#/';
        } else if (result.errors) {
          for (const [field, msg] of Object.entries(result.errors)) {
            const errEl = document.getElementById(`error-${field}`);
            if (errEl) errEl.textContent = msg;
          }
        } else {
          modal.toast(result.error || '操作失败');
        }
      }
    });
  },

  _tomorrow() {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
};