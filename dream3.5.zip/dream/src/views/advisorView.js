import { advisorService } from '../services/advisorService.js';

const QUICK_COMMANDS = [
  { text: '帮我制定存钱计划', emoji: '🎯' },
  { text: '我总是冲动消费', emoji: '🛒' },
  { text: '看看我的进度', emoji: '📊' },
  { text: '存5000怎么存', emoji: '📅' },
  { text: '你好', emoji: '👋' }
];

export const advisorView = {
  _mounted: false,

  mount() {
    if (this._mounted) return;
    this._mounted = true;

    const root = document.createElement('div');
    root.className = 'advisor-root';

    const fab = document.createElement('button');
    fab.className = 'advisor-fab';
    fab.innerHTML = '<span class="advisor-fab-pulse"></span><span class="advisor-fab-icon">💬</span>';
    fab.title = '引力小助手';

    const panel = document.createElement('div');
    panel.className = 'advisor-panel';

    const header = document.createElement('div');
    header.className = 'advisor-header';
    header.innerHTML = `
      <div class="advisor-header-info">
        <span class="advisor-header-avatar">💡</span>
        <div>
          <span class="advisor-header-title">引力小助手</span>
          <span class="advisor-header-status">在线</span>
        </div>
      </div>
    `;
    const closeBtn = document.createElement('button');
    closeBtn.className = 'advisor-close';
    closeBtn.textContent = '×';
    closeBtn.title = '收起';
    header.appendChild(closeBtn);

    const body = document.createElement('div');
    body.className = 'advisor-body';

    const quickRow = document.createElement('div');
    quickRow.className = 'advisor-quick-row';
    for (const cmd of QUICK_COMMANDS) {
      const tag = document.createElement('button');
      tag.className = 'advisor-quick-tag';
      tag.textContent = cmd.emoji + ' ' + cmd.text;
      tag.addEventListener('click', () => {
        input.value = cmd.text;
        send();
      });
      quickRow.appendChild(tag);
    }

    const inputRow = document.createElement('div');
    inputRow.className = 'advisor-input-row';
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'advisor-input';
    input.placeholder = '问我任何存钱问题…';
    const sendBtn = document.createElement('button');
    sendBtn.className = 'btn btn-primary advisor-send';
    sendBtn.textContent = '发送';
    inputRow.appendChild(input);
    inputRow.appendChild(sendBtn);

    panel.appendChild(header);
    panel.appendChild(body);
    panel.appendChild(quickRow);
    panel.appendChild(inputRow);

    root.appendChild(panel);
    root.appendChild(fab);
    document.body.appendChild(root);

    const addMessage = (text, who) => {
      const msg = document.createElement('div');
      msg.className = `advisor-msg advisor-msg-${who}`;
      const avatar = document.createElement('span');
      avatar.className = 'advisor-msg-avatar';
      avatar.textContent = who === 'bot' ? '💡' : '🙂';
      const bubble = document.createElement('div');
      bubble.className = 'advisor-bubble';
      bubble.textContent = text;
      msg.appendChild(avatar);
      msg.appendChild(bubble);
      body.appendChild(msg);
      body.scrollTop = body.scrollHeight;
    };

    addMessage(advisorService.answer('你好'), 'bot');

    const toggle = (open) => {
      root.classList.toggle('advisor-open', open);
      if (open) input.focus();
    };

    fab.addEventListener('click', () => toggle(true));
    closeBtn.addEventListener('click', () => toggle(false));

    const send = () => {
      const text = input.value.trim();
      if (!text) return;
      addMessage(text, 'user');
      input.value = '';
      const typing = document.createElement('div');
      typing.className = 'advisor-msg advisor-msg-bot advisor-typing';
      typing.innerHTML = '<span class="advisor-msg-avatar">💡</span><div class="advisor-bubble"><span class="advisor-typing-dot"></span><span class="advisor-typing-dot"></span><span class="advisor-typing-dot"></span></div>';
      body.appendChild(typing);
      body.scrollTop = body.scrollHeight;
      setTimeout(() => {
        typing.remove();
        const reply = advisorService.answer(text);
        addMessage(reply, 'bot');
      }, 500);
    };
    sendBtn.addEventListener('click', send);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') send();
    });
  }
};
