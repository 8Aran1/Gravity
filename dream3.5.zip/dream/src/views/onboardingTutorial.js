import { tutorialStorage } from '../storage/tutorialStorage.js';
import { tutorialSteps } from './tutorialSteps.js';
import { modal } from './modal.js';

export const onboardingTutorial = {
  _mounted: false,
  _currentStep: 0,
  _bubbleEl: null,
  _hashHandler: null,
  _storagePollTimer: null,
  _mutationObserver: null,
  _storageSnapshot: null,

  start() {
    try {
      const step = tutorialStorage.read();
      if (step >= tutorialSteps.TOTAL) return;
      this._currentStep = step;
      this._mounted = true;

      const config = tutorialSteps.ALL[this._currentStep];
      const currentHash = window.location.hash || '#/';
      if (config && currentHash === config.targetHash) {
        this._updateBubble(this._currentStep);
      }
      this._startSensing(config);
    } catch (e) {
      this._removeBubble();
    }
  },

  restart() {
    try {
      this.destroy();
      tutorialStorage.reset();
      this._currentStep = 0;
      this._mounted = true;

      const config = tutorialSteps.ALL[0];
      const currentHash = window.location.hash || '#/';
      if (currentHash === config.targetHash) {
        this._updateBubble(0);
      }
      this._startSensing(config);
    } catch (e) {
      this._removeBubble();
      try { modal.toast('教程启动失败，请重试'); } catch (ee) {}
    }
  },

  destroy() {
    try {
      this._stopSensing();
      this._removeBubble();
      this._mounted = false;
    } catch (e) {}
  },

  _skip() {
    try {
      tutorialStorage.complete();
      this.destroy();
    } catch (e) {
      this._removeBubble();
    }
  },

  _complete() {
    try {
      tutorialStorage.complete();
      this.destroy();
    } catch (e) {
      this._removeBubble();
    }
  },

  _startSensing(stepConfig) {
    try {
      const sensing = stepConfig && stepConfig.sensing;
      if (!sensing) return;

      if (sensing.hashchange) {
        this._hashHandler = () => { this._onHashChange(); };
        window.addEventListener('hashchange', this._hashHandler);
      }

      if (sensing.storagePoll && sensing.storagePoll.key) {
        try {
          this._storageSnapshot = localStorage.getItem(sensing.storagePoll.key);
        } catch (e) {
          this._storageSnapshot = null;
        }
        const interval = sensing.pollInterval || 1500;
        this._storagePollTimer = setInterval(() => { this._onStoragePoll(); }, interval);
      }

      if (sensing.mutationObserver && sensing.mutationObserver.selector) {
        try {
          const target = document.querySelector(sensing.mutationObserver.selector);
          if (target && typeof MutationObserver !== 'undefined') {
            this._mutationObserver = new MutationObserver((records) => { this._onMutation(records); });
            this._mutationObserver.observe(target, { attributes: true, attributeFilter: ['class'], childList: true, subtree: true });
          }
        } catch (e) {}
      }
    } catch (e) {}
  },

  _stopSensing() {
    try {
      if (this._hashHandler) {
        window.removeEventListener('hashchange', this._hashHandler);
        this._hashHandler = null;
      }
      if (this._storagePollTimer) {
        clearInterval(this._storagePollTimer);
        this._storagePollTimer = null;
      }
      if (this._mutationObserver) {
        this._mutationObserver.disconnect();
        this._mutationObserver = null;
      }
      this._storageSnapshot = null;
    } catch (e) {}
  },

  _onHashChange() {
    try {
      if (!this._mounted) return;
      const hash = window.location.hash || '#/';
      this._updateBubbleForRoute(hash);
      this._tryAdvance('hash', hash);
    } catch (e) {
      this._removeBubble();
    }
  },

  _onStoragePoll() {
    try {
      const config = tutorialSteps.ALL[this._currentStep];
      if (!config || !config.sensing || !config.sensing.storagePoll) return;
      const newValue = localStorage.getItem(config.sensing.storagePoll.key);
      if (newValue !== this._storageSnapshot) {
        this._storageSnapshot = newValue;
        this._tryAdvance('storage', newValue);
      }
    } catch (e) {}
  },

  _onMutation(records) {
    try {
      this._tryAdvance('mutation', records);
    } catch (e) {}
  },

  _tryAdvance(signalType, signalData) {
    try {
      const config = tutorialSteps.ALL[this._currentStep];
      if (!config || !config.sensing || !config.sensing.condition) return;

      const condition = config.sensing.condition;
      let matched = false;

      if (signalType === 'hash' && condition.hash) {
        matched = (signalData === condition.hash);
      } else if (signalType === 'storage' && condition.storageChanged === true) {
        matched = true;
      } else if (signalType === 'mutation' && condition.domAppears) {
        try {
          const el = document.querySelector(condition.domAppears);
          if (el && el.classList.contains('advisor-open')) {
            matched = true;
          }
        } catch (e) {}
      }

      if (!matched) return;

      this._currentStep++;
      tutorialStorage.write(this._currentStep);
      this._stopSensing();

      if (this._currentStep >= tutorialSteps.TOTAL) {
        this._complete();
        return;
      }

      const nextConfig = tutorialSteps.ALL[this._currentStep];
      const currentHash = window.location.hash || '#/';
      if (nextConfig && currentHash === nextConfig.targetHash) {
        this._updateBubble(this._currentStep);
      } else {
        this._removeBubble();
      }
      this._startSensing(nextConfig);
    } catch (e) {
      this._removeBubble();
    }
  },

  _updateBubbleForRoute(hash) {
    try {
      const config = tutorialSteps.ALL[this._currentStep];
      if (!config) return;

      if (hash === config.targetHash) {
        if (this._bubbleEl) {
          this._positionBubble(this._bubbleEl, this._currentStep);
        } else {
          this._updateBubble(this._currentStep);
        }
      } else {
        this._removeBubble();
      }
    } catch (e) {
      this._removeBubble();
    }
  },

  _renderBubble(step) {
    try {
      const config = tutorialSteps.ALL[step];
      if (!config) return null;

      const bubble = document.createElement('div');
      bubble.className = 'tutorial-bubble';

      const title = document.createElement('div');
      title.className = 'tutorial-bubble-title';
      title.textContent = config.title;
      bubble.appendChild(title);

      const plain = document.createElement('div');
      plain.className = 'tutorial-bubble-plain';
      plain.textContent = config.plainText;
      bubble.appendChild(plain);

      if (config.termRef) {
        const term = document.createElement('div');
        term.className = 'tutorial-bubble-term';
        term.textContent = config.termRef.term + ' = ' + config.termRef.plain + '。' + config.termRef.detail;
        bubble.appendChild(term);
      }

      if (config.targetHint) {
        const hint = document.createElement('div');
        hint.className = 'tutorial-bubble-plain';
        hint.textContent = '💡 ' + config.targetHint;
        bubble.appendChild(hint);
      }

      const progress = document.createElement('div');
      progress.className = 'tutorial-bubble-progress';
      progress.textContent = '第 ' + (step + 1) + ' 步 / 共 ' + tutorialSteps.TOTAL + ' 步';
      bubble.appendChild(progress);

      const actions = document.createElement('div');
      actions.className = 'tutorial-bubble-actions';

      if (config.buttons && config.buttons.showSkip) {
        const skipBtn = document.createElement('button');
        skipBtn.className = 'tutorial-bubble-btn tutorial-bubble-btn-secondary';
        skipBtn.textContent = '跳过';
        skipBtn.addEventListener('click', () => this._skip());
        actions.appendChild(skipBtn);
      }

      bubble.appendChild(actions);
      return bubble;
    } catch (e) {
      return null;
    }
  },

  _positionBubble(bubble, step) {
    try {
      const config = tutorialSteps.ALL[step];
      if (!config) return;

      const hash = window.location.hash || '#/';
      let targetEl = null;

      if (hash === config.targetHash && config.targetSelector) {
        try {
          targetEl = document.querySelector(config.targetSelector);
        } catch (e) {
          targetEl = null;
        }
      }

      const oldArrow = bubble.querySelector('.tutorial-bubble-arrow');
      if (oldArrow) oldArrow.remove();

      const bubbleRect = bubble.getBoundingClientRect();
      const bubbleW = bubbleRect.width || 340;
      const bubbleH = bubbleRect.height || 200;
      const margin = 12;

      if (targetEl) {
        const rect = targetEl.getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        const spaceAbove = rect.top;

        let left = rect.left + (rect.width - bubbleW) / 2;
        left = Math.max(margin, Math.min(left, window.innerWidth - bubbleW - margin));

        let top;
        let arrowClass;

        if (spaceBelow >= bubbleH + margin) {
          top = rect.bottom + margin;
          arrowClass = 'tutorial-bubble-arrow-up';
        } else if (spaceAbove >= bubbleH + margin) {
          top = rect.top - bubbleH - margin;
          arrowClass = 'tutorial-bubble-arrow-down';
        } else {
          top = window.innerHeight - bubbleH - margin;
          arrowClass = null;
        }

        bubble.style.left = left + 'px';
        bubble.style.top = top + 'px';

        if (arrowClass) {
          const arrow = document.createElement('div');
          arrow.className = 'tutorial-bubble-arrow ' + arrowClass;
          arrow.style.left = (rect.left + rect.width / 2 - left - 7) + 'px';
          bubble.appendChild(arrow);
        }
      } else {
        let left = window.innerWidth - bubbleW - margin;
        left = Math.max(margin, left);
        bubble.style.left = left + 'px';
        bubble.style.top = (margin + 60) + 'px';
      }
    } catch (e) {}
  },

  _updateBubble(step) {
    try {
      if (this._bubbleEl) {
        this._removeBubble();
      }
      const bubble = this._renderBubble(step);
      if (!bubble) return;
      document.body.appendChild(bubble);
      this._bubbleEl = bubble;
      this._positionBubble(bubble, step);
    } catch (e) {
      this._removeBubble();
    }
  },

  _removeBubble() {
    try {
      if (this._bubbleEl && this._bubbleEl.parentNode === document.body) {
        document.body.removeChild(this._bubbleEl);
      }
      this._bubbleEl = null;
    } catch (e) {
      this._bubbleEl = null;
    }
  }
};
