import { goalService } from '../services/goalService.js';
import { recordService } from '../services/recordService.js';
import { progressService } from '../services/progressService.js';
import { habitService } from '../services/habitService.js';
import { achievementService } from '../services/achievementService.js';
import { toYuan } from '../utils/moneyUtils.js';
import { today } from '../utils/dateUtils.js';
import { progressBar } from './progressBar.js';
import { modal } from './modal.js';
import { WITHDRAW_COOLDOWN_HOURS } from '../constants.js';

export const goalDetailView = {
  render(goalId) {
    const app = document.getElementById('app');
    app.innerHTML = '';

    const detail = goalService.getById(goalId);
    if (!detail) {
      const msg = document.createElement('div');
      msg.className = 'empty-state';
      msg.innerHTML = '<p class="empty-text">目标不存在或已被删除</p>';
      const backBtn = document.createElement('button');
      backBtn.className = 'btn btn-primary';
      backBtn.textContent = '返回首页';
      backBtn.addEventListener('click', () => { window.location.hash = '#/'; });
      msg.appendChild(backBtn);
      app.appendChild(msg);
      return;
    }

    const { goal, records } = detail;
    const container = document.createElement('div');
    container.className = 'page-container';

    const backLink = document.createElement('a');
    backLink.className = 'back-link';
    backLink.href = '#/';
    backLink.textContent = '← 返回首页';
    backLink.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.hash = '#/';
    });
    container.appendChild(backLink);

    const header = document.createElement('div');
    header.className = 'detail-header';

    const title = document.createElement('h2');
    title.className = 'detail-title';
    title.textContent = goal.name;
    header.appendChild(title);

    if (goal.status === '已达成') {
      const badge = document.createElement('span');
      badge.className = 'goal-status-badge goal-status-done';
      badge.textContent = '🎉 已达成';
      header.appendChild(badge);
    } else if (goal.status === '已支取') {
      const badge = document.createElement('span');
      badge.className = 'goal-status-badge goal-status-done';
      badge.textContent = '💸 已支取';
      header.appendChild(badge);
    }
    container.appendChild(header);

    const info = document.createElement('div');
    info.className = 'detail-info';
    info.innerHTML = `
      <div class="info-item"><span class="info-label">目标金额</span><span class="info-value">¥${toYuan(goal.targetAmount)}</span></div>
      <div class="info-item"><span class="info-label">已储蓄</span><span class="info-value">¥${toYuan(goal.currentAmount)}</span></div>
      <div class="info-item"><span class="info-label">计划完成</span><span class="info-value">${goal.plannedDate}</span></div>
    `;
    container.appendChild(info);

    if (goal.status === '已支取') {
      const withdrawnEl = document.createElement('div');
      withdrawnEl.className = 'goal-warning';
      withdrawnEl.textContent = `已逃逸取出 ¥${toYuan(goal.withdrawnAmount || 0)}，该目标已关闭`;
      container.appendChild(withdrawnEl);
    }

    const progress = progressService.calcProgress(goal.currentAmount, goal.targetAmount);
    const completed = progressService.isCompleted(goal.currentAmount, goal.targetAmount);
    container.appendChild(progressBar.render(progress, completed));

    if (!completed) {
      const remainEl = document.createElement('div');
      remainEl.className = 'goal-remaining';
      remainEl.textContent = `还差 ¥${progressService.getRemaining(goal.currentAmount, goal.targetAmount)}`;
      container.appendChild(remainEl);
    }

    const warning = progressService.getWarning(goal.plannedDate, progress);
    if (warning) {
      const warnEl = document.createElement('div');
      warnEl.className = 'goal-warning';
      warnEl.textContent = warning;
      container.appendChild(warnEl);
    }

    const actionRow = document.createElement('div');
    actionRow.className = 'action-row';

    const editBtn = document.createElement('button');
    editBtn.className = 'btn btn-secondary';
    editBtn.textContent = '编辑';

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn btn-danger';
    deleteBtn.textContent = '删除';

    actionRow.appendChild(editBtn);
    actionRow.appendChild(deleteBtn);

    if (goal.status === '进行中') {
      const addBtn = document.createElement('button');
      addBtn.className = 'btn btn-primary';
      addBtn.textContent = '记一笔';
      addBtn.addEventListener('click', () => {
        this._showAddRecordForm(goalId);
      });
      actionRow.insertBefore(addBtn, editBtn);

      const checkInBtn = document.createElement('button');
      checkInBtn.className = 'btn btn-accent';
      const checkedToday = habitService.hasCheckedInToday(goalId);
      checkInBtn.textContent = checkedToday ? '今日已打卡 ✓' : '今日打卡';
      checkInBtn.disabled = checkedToday;
      checkInBtn.addEventListener('click', () => {
        const result = habitService.checkIn(goalId);
        modal.toast(result.message);
        if (result.success) {
          const newBadge = achievementService.checkAndUnlock();
          if (newBadge) {
            modal.toast(`🎉 解锁徽章：${newBadge.name}！`);
          }
          this.render(goalId);
        }
      });
      actionRow.appendChild(checkInBtn);

      if (goal.allowWithdraw !== false) {
        const withdrawStatus = goalService.getWithdrawStatus(goalId);
        const withdrawBtn = document.createElement('button');
        if (withdrawStatus && withdrawStatus.pending) {
          withdrawBtn.className = 'btn btn-secondary';
          withdrawBtn.textContent = withdrawStatus.cooldownHours === 0 ? '待确认支取' : '冷静期中 ⏳';
          withdrawBtn.addEventListener('click', () => {
            window.location.hash = `#/goal/${goalId}/withdraw`;
          });
        } else {
          withdrawBtn.className = 'btn btn-danger';
          withdrawBtn.textContent = '逃逸速度';
          withdrawBtn.addEventListener('click', () => {
            this._showWithdrawForm(goalId, goal);
          });
        }
        actionRow.appendChild(withdrawBtn);
      }
    }

    container.appendChild(actionRow);

    editBtn.addEventListener('click', () => {
      window.location.hash = `#/goal/${goalId}/edit`;
    });

    deleteBtn.addEventListener('click', () => {
      modal.show('确定删除该目标？删除后无法恢复', () => {
        const result = goalService.remove(goalId);
        if (result.success) {
          window.location.hash = '#/';
        } else {
          modal.toast(result.error || '删除失败');
        }
      });
    });

    const recordsSection = document.createElement('div');
    recordsSection.className = 'records-section';

    const recordsTitle = document.createElement('h3');
    recordsTitle.className = 'records-title';
    recordsTitle.textContent = '储蓄记录';
    recordsSection.appendChild(recordsTitle);

    if (records.length === 0) {
      const emptyRecords = document.createElement('p');
      emptyRecords.className = 'empty-records';
      emptyRecords.textContent = '还没有储蓄记录，点击"记一笔"开始吧！';
      recordsSection.appendChild(emptyRecords);
    } else {
      const recordsList = document.createElement('div');
      recordsList.className = 'records-list';
      for (const record of records) {
        const item = document.createElement('div');
        item.className = 'record-item';

        const recordInfo = document.createElement('div');
        recordInfo.className = 'record-info';
        recordInfo.innerHTML = `
          <span class="record-amount">+¥${toYuan(record.amount)}</span>
          <span class="record-date">${record.date}</span>
        `;
        item.appendChild(recordInfo);

        if (record.note) {
          const noteEl = document.createElement('div');
          noteEl.className = 'record-note';
          noteEl.textContent = record.note;
          item.appendChild(noteEl);
        }

        const delBtn = document.createElement('button');
        delBtn.className = 'btn-icon';
        delBtn.textContent = '🗑';
        delBtn.addEventListener('click', () => {
          modal.show('确定删除这条储蓄记录？', () => {
            const result = recordService.remove(record.id);
            if (result.success) {
              modal.toast('删除成功');
              this.render(goalId);
            } else {
              modal.toast(result.error || '删除失败');
            }
          });
        });
        item.appendChild(delBtn);

        recordsList.appendChild(item);
      }
      recordsSection.appendChild(recordsList);
    }

    container.appendChild(recordsSection);
    app.appendChild(container);
  },

  _showAddRecordForm(goalId) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const dialog = document.createElement('div');
    dialog.className = 'modal-dialog form-dialog';

    dialog.innerHTML = `
      <h3 class="form-title">记一笔储蓄</h3>
      <div class="form-group">
        <label>金额（元）</label>
        <input type="number" id="record-amount" step="0.01" min="0.01" placeholder="请输入储蓄金额">
        <span class="form-error" id="error-amount"></span>
      </div>
      <div class="form-group">
        <label>日期</label>
        <input type="date" id="record-date" value="${today()}">
        <span class="form-error" id="error-date"></span>
      </div>
      <div class="form-group">
        <label>备注（可选）</label>
        <input type="text" id="record-note" maxlength="50" placeholder="不超过50个字符">
        <span class="form-error" id="error-note"></span>
      </div>
      <div class="modal-btn-group">
        <button class="btn btn-secondary" id="record-cancel">取消</button>
        <button class="btn btn-primary" id="record-submit">确认</button>
      </div>
    `;

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const close = () => {
      if (overlay.parentNode) document.body.removeChild(overlay);
    };

    document.getElementById('record-cancel').addEventListener('click', close);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });

    document.getElementById('record-submit').addEventListener('click', () => {
      const amount = document.getElementById('record-amount').value;
      const date = document.getElementById('record-date').value;
      const note = document.getElementById('record-note').value;

      document.querySelectorAll('.form-error').forEach(el => el.textContent = '');

      const result = recordService.create({ goalId, amount, date, note });
      if (result.success) {
        close();
        modal.toast('储蓄成功！');
        const newBadge = achievementService.checkAndUnlock();
        if (newBadge) {
          setTimeout(() => modal.toast(`🎉 解锁徽章：${newBadge.name}！`), 500);
        }
        this.render(goalId);
      } else if (result.errors) {
        for (const [field, msg] of Object.entries(result.errors)) {
          const errEl = document.getElementById(`error-${field}`);
          if (errEl) errEl.textContent = msg;
        }
      } else {
        modal.toast(result.error || '操作失败');
      }
    });
  },

  _showWithdrawForm(goalId, goal) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    const dialog = document.createElement('div');
    dialog.className = 'modal-dialog form-dialog withdraw-form-dialog';
    dialog.innerHTML = `
      <h3 class="form-title">逃逸申请</h3>
      <p class="form-hint">逃逸允许你按需取出已存金额（模拟记账，不涉及真实资金）。提交后进入冷静期，冷静期结束方可确认支取。</p>
      <div class="form-group">
        <label>用途说明</label>
        <textarea id="withdraw-purpose" rows="2" maxlength="50" placeholder="如：应急周转"></textarea>
        <span class="form-error" id="error-purpose"></span>
      </div>
      <div class="form-group">
        <label>备注时间</label>
        <input type="date" id="withdraw-note-time" value="${today()}">
        <span class="form-error" id="error-noteTime"></span>
      </div>
      <div class="form-group">
        <label>虚拟金额（元）· 最多 ¥${toYuan(goal.currentAmount)}</label>
        <input type="number" id="withdraw-amount" step="0.01" min="0.01" max="${toYuan(goal.currentAmount)}" value="${toYuan(goal.currentAmount)}" placeholder="不超过已存金额">
        <span class="form-error" id="error-amount"></span>
      </div>
      <div class="form-group">
        <label>冷静期时长</label>
        <div class="cooldown-options">
          <label class="form-check"><input type="radio" name="cooldown" value="0"><span>不设冷静期</span></label>
          <label class="form-check"><input type="radio" name="cooldown" value="24"><span>24 小时</span></label>
          <label class="form-check"><input type="radio" name="cooldown" value="48" checked><span>48 小时</span></label>
        </div>
        <span class="form-error" id="error-cooldown"></span>
      </div>
      <div class="modal-btn-group">
        <button class="btn btn-secondary" id="withdraw-cancel">取消</button>
        <button class="btn btn-primary" id="withdraw-submit">提交申请</button>
      </div>
    `;
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const close = () => { if (overlay.parentNode) document.body.removeChild(overlay); };
    document.getElementById('withdraw-cancel').addEventListener('click', close);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

    document.getElementById('withdraw-submit').addEventListener('click', () => {
      const purpose = document.getElementById('withdraw-purpose').value;
      const noteTime = document.getElementById('withdraw-note-time').value;
      const amount = document.getElementById('withdraw-amount').value;
      const cooldownChecked = document.querySelector('input[name="cooldown"]:checked');
      const cooldownHours = cooldownChecked ? cooldownChecked.value : '';
      document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
      const result = goalService.requestWithdraw(goalId, { purpose, noteTime, amount, cooldownHours });
      if (result.success) {
        close();
        modal.toast('已进入冷静期');
        window.location.hash = `#/goal/${goalId}/withdraw`;
      } else if (result.errors) {
        for (const [field, msg] of Object.entries(result.errors)) {
          const errEl = document.getElementById(`error-${field}`);
          if (errEl) errEl.textContent = msg;
        }
      } else {
        modal.toast(result.error || '操作失败');
      }
    });
  }
};