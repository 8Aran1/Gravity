import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { STORAGE_KEYS, VALIDATION_RULES, WITHDRAW_COOLDOWN_HOURS, WITHDRAW_COOLDOWN_OPTIONS } from '../constants.js';
import { toFen, toYuan } from '../utils/moneyUtils.js';
import { idUtils } from '../utils/idUtils.js';
import { today } from '../utils/dateUtils.js';

function validateGoalData(name, targetAmount, plannedDate) {
  const errors = {};
  if (!name || name.trim().length < VALIDATION_RULES.GOAL_NAME_MIN || name.trim().length > VALIDATION_RULES.GOAL_NAME_MAX) {
    errors.name = '请输入1-20个字符的目标名称';
  }
  const amount = Number(targetAmount);
  if (!amount || amount < VALIDATION_RULES.GOAL_AMOUNT_MIN || amount > VALIDATION_RULES.GOAL_AMOUNT_MAX) {
    errors.targetAmount = '请输入有效金额（0.01-999999.99元）';
  }
  if (!plannedDate || plannedDate <= today()) {
    errors.plannedDate = '完成日期必须晚于今天';
  }
  return errors;
}

export const goalService = {
  create(goalData) {
    const { name, targetAmount, plannedDate, allowWithdraw } = goalData;
    const errors = validateGoalData(name, targetAmount, plannedDate);
    if (Object.keys(errors).length > 0) {
      return { success: false, errors };
    }
    const data = localStorageAdapter.getData();
    const goal = {
      id: idUtils.generate(),
      name: name.trim(),
      targetAmount: toFen(Number(targetAmount)),
      plannedDate,
      createdAt: today(),
      currentAmount: 0,
      status: '进行中',
      allowWithdraw: allowWithdraw !== false
    };
    data.goals.push(goal);
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    }
    return { success: true, data: goal };
  },

  getAll() {
    const data = localStorageAdapter.getData();
    return data.goals;
  },

  getById(goalId) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return null;
    const records = data.records.filter(r => r.goalId === goalId);
    return { goal, records };
  },

  update(goalId, updates) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) {
      return { success: false, error: '目标不存在或已被删除' };
    }
    const newName = updates.name !== undefined ? updates.name : goal.name;
    const newTargetAmount = updates.targetAmount !== undefined ? updates.targetAmount : toYuan(goal.targetAmount);
    const newPlannedDate = updates.plannedDate !== undefined ? updates.plannedDate : goal.plannedDate;
    const errors = validateGoalData(newName, newTargetAmount, newPlannedDate);
    if (Object.keys(errors).length > 0) {
      return { success: false, errors };
    }
    const newTargetFen = toFen(Number(newTargetAmount));
    let warning = null;
    goal.name = newName.trim();
    goal.targetAmount = newTargetFen;
    goal.plannedDate = newPlannedDate;
    if (updates.allowWithdraw !== undefined) goal.allowWithdraw = updates.allowWithdraw;
    if (newTargetFen <= goal.currentAmount) {
      goal.status = '已达成';
      warning = '目标金额小于已储蓄金额，该目标将标记为已完成';
    } else {
      goal.status = '进行中';
    }
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    }
    const result = { success: true, data: goal };
    if (warning) result.warning = warning;
    return result;
  },

  remove(goalId) {
    const data = localStorageAdapter.getData();
    const goalIndex = data.goals.findIndex(g => g.id === goalId);
    if (goalIndex === -1) {
      return { success: false, error: '目标不存在或已被删除' };
    }
    const backup = JSON.parse(JSON.stringify(data));
    data.goals.splice(goalIndex, 1);
    data.records = data.records.filter(r => r.goalId !== goalId);
    data.checkIns = data.checkIns.filter(c => c.goalId !== goalId);
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      localStorageAdapter.saveData(backup);
      return { success: false, error: '删除失败，数据已保留' };
    }
    return { success: true };
  },

  requestWithdraw(goalId, options = {}) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return { success: false, error: '目标不存在或已被删除' };
    if (goal.allowWithdraw === false) return { success: false, error: '该目标未开启逃逸' };
    if (goal.status !== '进行中') return { success: false, error: '该目标不可申请支取' };
    if (goal.pendingWithdrawAt) return { success: false, error: '已处于支取冷静期' };
    if (goal.currentAmount <= 0) return { success: false, error: '该目标尚无储蓄金额，无需支取' };

    const { purpose, noteTime, amount, cooldownHours } = options;
    const withdrawAmount = Number(amount);
    if (!withdrawAmount || withdrawAmount <= 0) {
      return { success: false, errors: { amount: '请输入有效的支取金额' } };
    }
    const amountFen = toFen(withdrawAmount);
    if (amountFen > goal.currentAmount) {
      return { success: false, errors: { amount: '支取金额不能超过已存金额' } };
    }
    if (!WITHDRAW_COOLDOWN_OPTIONS.includes(Number(cooldownHours))) {
      return { success: false, errors: { cooldown: '请选择冷静期时长' } };
    }

    goal.pendingWithdrawAt = Date.now();
    goal.pendingWithdrawDetail = {
      purpose: (purpose || '').trim(),
      noteTime: noteTime || today(),
      amount: amountFen,
      cooldownHours: Number(cooldownHours)
    };
    const ok = localStorageAdapter.saveData(data);
    if (!ok) return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    return { success: true };
  },

  cancelWithdraw(goalId) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return { success: false, error: '目标不存在或已被删除' };
    if (!goal.pendingWithdrawAt) return { success: false, error: '未处于支取冷静期' };
    delete goal.pendingWithdrawAt;
    delete goal.pendingWithdrawDetail;
    const ok = localStorageAdapter.saveData(data);
    if (!ok) return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    return { success: true };
  },

  confirmWithdraw(goalId) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return { success: false, error: '目标不存在或已被删除' };
    if (!goal.pendingWithdrawAt) return { success: false, error: '未申请支取' };
    const detail = goal.pendingWithdrawDetail || {};
    const cooldown = detail.cooldownHours !== undefined ? detail.cooldownHours : WITHDRAW_COOLDOWN_HOURS;
    const elapsed = Date.now() - goal.pendingWithdrawAt;
    if (cooldown > 0 && elapsed < cooldown * 3600 * 1000) {
      return { success: false, error: '冷静期未结束，暂不可支取' };
    }
    const withdrawAmount = detail.amount || goal.currentAmount;
    goal.withdrawnAmount = (goal.withdrawnAmount || 0) + withdrawAmount;
    goal.currentAmount = Math.max(0, goal.currentAmount - withdrawAmount);
    if (goal.currentAmount <= 0) {
      goal.status = '已支取';
    }
    goal.withdrawnAt = today();
    delete goal.pendingWithdrawAt;
    delete goal.pendingWithdrawDetail;
    const ok = localStorageAdapter.saveData(data);
    if (!ok) return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    return { success: true, data: { withdrawnAmount: withdrawAmount } };
  },

  getWithdrawStatus(goalId) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) return null;
    if (!goal.pendingWithdrawAt) return { pending: false, remainingMs: 0, canWithdraw: false };
    const detail = goal.pendingWithdrawDetail || {};
    const cooldown = detail.cooldownHours !== undefined ? detail.cooldownHours : WITHDRAW_COOLDOWN_HOURS;
    const endTime = goal.pendingWithdrawAt + cooldown * 3600 * 1000;
    const remainingMs = Math.max(0, endTime - Date.now());
    return { pending: true, remainingMs, canWithdraw: remainingMs === 0, endTime, cooldownHours: cooldown, detail };
  }
};