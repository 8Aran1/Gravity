import { APP_DATA_KEYS, STORAGE_KEYS, DATA_VERSION } from '../constants.js';

function readMainData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DATA_KEY);
    if (!raw) return { goals: [], records: [], checkIns: [], camps: [], achievements: [] };
    const parsed = JSON.parse(raw);
    return parsed || { goals: [], records: [], checkIns: [], camps: [], achievements: [] };
  } catch (e) {
    return { goals: [], records: [], checkIns: [], camps: [], achievements: [] };
  }
}

function readCampsData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CAMPS_KEY);
    if (!raw) return { camps: [] };
    const parsed = JSON.parse(raw);
    return parsed || { camps: [] };
  } catch (e) {
    return { camps: [] };
  }
}

function readJoinedData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.JOINED_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

export const backupService = {
  exportData() {
    try {
      const data = {
        _version: DATA_VERSION,
        dream_saving_camp_data: readMainData(),
        dream_camps_data: readCampsData(),
        dream_joined_camps: readJoinedData()
      };
      JSON.stringify(data);
      return { success: true, data };
    } catch (e) {
      return { success: false, error: '导出失败，数据异常，请联系开发者' };
    }
  },

  validateBackup(parsed) {
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      return { valid: false, reason: '文件格式不合法，非本应用备份文件' };
    }
    if (typeof parsed._version !== 'number' || !Number.isInteger(parsed._version)) {
      return { valid: false, reason: '文件格式不合法，非本应用备份文件' };
    }
    if (parsed._version > DATA_VERSION) {
      return { valid: false, reason: '备份文件版本过高，请升级应用后重试' };
    }
    const main = parsed.dream_saving_camp_data;
    if (typeof main !== 'object' || main === null || Array.isArray(main)) {
      return { valid: false, reason: '文件格式不合法，非本应用备份文件' };
    }
    if (!Array.isArray(main.goals) || !Array.isArray(main.records) ||
        !Array.isArray(main.checkIns) || !Array.isArray(main.achievements)) {
      return { valid: false, reason: '文件格式不合法，非本应用备份文件' };
    }
    return { valid: true };
  },

  applyImport(parsed) {
    try {
      const main = parsed.dream_saving_camp_data || { goals: [], records: [], checkIns: [], achievements: [] };
      const camps = parsed.dream_camps_data || { camps: [] };
      const joined = parsed.dream_joined_camps || [];
      localStorage.setItem(STORAGE_KEYS.DATA_KEY, JSON.stringify(main));
      localStorage.setItem(STORAGE_KEYS.CAMPS_KEY, JSON.stringify(camps));
      localStorage.setItem(STORAGE_KEYS.JOINED_KEY, JSON.stringify(joined));
      return { success: true };
    } catch (e) {
      return { success: false, error: '导入失败，本地存储空间不足或不可用' };
    }
  },

  clearAllData() {
    try {
      for (const key of APP_DATA_KEYS) {
        localStorage.removeItem(key);
      }
      localStorage.removeItem('tutorialStep');
      return { success: true };
    } catch (e) {
      return { success: false, error: '清空失败，浏览器存储不可用，请手动清理浏览器数据' };
    }
  }
};