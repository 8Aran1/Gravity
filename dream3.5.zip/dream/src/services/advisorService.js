import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { habitService } from './habitService.js';
import { progressService } from './progressService.js';
import { toYuan } from '../utils/moneyUtils.js';
import { today, daysBetween, format } from '../utils/dateUtils.js';

function monthOf(dateStr) {
  return dateStr.slice(0, 7);
}

const INTENTS = [
  {
    name: 'plan',
    priority: 1,
    keywords: /计划|存多少|怎么存|如何存|怎样存|存\d|帮我制定|制定.*计划|存.*元|存.*块/,
    templates: [
      '🎯 好的，来帮你制定存钱计划！\n\n📅 每天需存 ¥{perDay}，每周需存 ¥{perWeek}。\n坚持下去，{goalName}一定能实现！✨',
      '📅 存钱计划来啦～\n\n按 {days} 天算：每天 ¥{perDay}、每周 ¥{perWeek}。\n🎯 目标「{goalName}」，我们一起加油！',
      '✨ 你的专属存钱方案：\n\n💰 每日 ¥{perDay} / 每周 ¥{perWeek}\n📅 距截止还有 {days} 天\n坚持就是胜利！💪'
    ],
    templatesNoDate: [
      '🎯 来帮你规划！想存 ¥{amount} 的话：\n\n📅 每天存 ¥{perDay}，一周就能存 ¥{perWeek}。\n坚持下去，积少成多！✨',
      '📅 存 ¥{amount} 的方案：\n\n💡 每日 ¥{perDay} / 每周 ¥{perWeek}\n🎯 一笔一笔来，梦想不远了！',
      '✨ 专属计划：存 ¥{amount}\n\n💰 每天只需 ¥{perDay}，每周 ¥{perWeek}\n💪 小钱也能攒出大梦想！'
    ],
    templatesNoGoal: [
      '🎯 想存 ¥{amount}？好目标！\n\n📅 建议每天存 ¥{perDay}，每周存 ¥{perWeek}。\n先去首页建立引力源，我帮你跟踪进度！✨',
      '📅 ¥{amount} 的存钱计划：\n\n💡 每日 ¥{perDay} / 每周 ¥{perWeek}\n🌱 去首页建立引力源，开启你的梦想之旅！',
      '✨ 存 ¥{amount}，每天只需 ¥{perDay}！\n\n💰 每周 ¥{perWeek}，一个月就是 ¥{perMonth}\n🎯 先建立引力源，再一起加油！💪'
    ],
    templatesNoAmount: [
      '🎯 想制定存钱计划？告诉我你想存多少！\n比如「存5000怎么存」，我帮你算出每日方案 ✨',
      '📅 制定计划很简单！\n试试输入「存3000怎么存」，我立刻帮你算出每天该存多少 💡',
      '✨ 告诉我你的目标金额，比如「存800怎么存」\n我来帮你拆解成每日每周的存款计划！🎯'
    ]
  },
  {
    name: 'emotion',
    priority: 2,
    keywords: /冲动|想买|坚持不下去|没钱|消费|乱花钱|花钱|剁手|买买买|控制不住|又买了|管不住手|穷|空了|花光|见底|余额不足|吃土|口袋空|放弃|不想存|退掉|算了|想退|不想坚持|太累了|好难|太难|困难|存不下来|存不起|压力|焦虑|烦|崩溃|没信心|做不到|存不到/,
    templates: []
  },
  {
    name: 'progress',
    priority: 3,
    keywords: /进度|还差|剩余|还要|差多少|离目标|缺口|完成多少|百分|目标|梦想|有哪些|列表|几个|本月|这个月|一个月|能存多少|预估|预计/,
    templates: []
  },
  {
    name: 'greeting',
    priority: 4,
    keywords: /你好|在吗|hi|hello|嗨|哈喽|谢谢|感谢|辛苦|棒|厉害|赞|不错/,
    templates: [
      '👋 我是你的引力小助手小梦！\n可以帮你分析进度、制定计划、预估月存～\n💬 试试问我「存5000怎么存」或「看看我的进度」',
      '😊 嗨～很高兴见到你！\n🌱 我可以帮你制定存钱计划、查看进度、聊聊存钱心态。\n✨ 试试「我总是冲动消费」或「帮我制定存钱计划」',
      '👋 你好呀！我是引力小助手小梦 💡\n📅 想知道每天该存多少？问我「存3000怎么存」\n📊 想看进度？问我「看看我的进度」'
    ]
  }
];

const EMOTION_TEMPLATES = [
  '🛒 冲动消费很正常，你不是一个人！\n💡 试试「延迟满足」：看到想买的先等 48 小时。\n很多时候冷静一天后，你会发现其实也没那么想买。\n🛡️ 把想买的东西写进备忘录，月底再回头看～',
  '🫂 想买的心情能理解，但每次忍住不花，\n就是在为未来的自己攒底气 ✨\n💡 48 小时冷静期是对抗冲动的神器，\n🎯 想想你的梦想，它比一时的冲动更值得！',
  '😔 坚持不下去的时候，先深呼吸，允许自己有这个念头。\n💡 试试降低每日存入金额，压力小了习惯反而更容易保持～\n🤝 也可以去引力场找搭子互相打气，\n一个人会累，一群人走得远 💪'
];

const EMOTION_BROKE_TEMPLATES = [
  '🫂 没钱的感觉不好受，但换个角度想——\n你来找我聊天，说明你已经在想办法了，这就很棒！\n💡 建议从「记账」开始，先搞清楚钱花在哪了。\n🌱 穷只是暂时的，有存钱意识的人不会穷太久 💪',
  '🌱 存钱不嫌少，哪怕每天 5 块、10 块，\n一个月下来也有 150~300 元，积少成多！\n💡 砍掉不必要的开支，省下来的钱自动存进目标～\n✨ 你已经在路上了，继续就好！',
  '🫂 觉得难，是因为你在认真对待这件事。\n轻松的事谁都能做，存钱难才说明它值得。\n🌱 难是暂时的，习惯一旦养成，\n以后就不需要靠意志力了 ✨'
];

export const advisorService = {
  _context() {
    const data = localStorageAdapter.getData();
    const goals = data.goals;
    const records = data.records;
    const todayStr = today();
    const thisMonth = monthOf(todayStr);

    const activeGoals = goals.filter(g => g.status === '进行中');
    const doneGoals = goals.filter(g => g.status === '已达成');
    const withdrawnGoals = goals.filter(g => g.status === '已支取');

    const totalTarget = goals.reduce((s, g) => s + g.targetAmount, 0);
    const totalSaved = goals.reduce((s, g) => s + g.currentAmount, 0);

    const monthRecords = records.filter(r => monthOf(r.date) === thisMonth);
    const monthSaved = monthRecords.reduce((s, r) => s + r.amount, 0);

    const thirtyAgo = new Date();
    thirtyAgo.setDate(thirtyAgo.getDate() - 29);
    const recentRecords = records.filter(r => r.date >= format(thirtyAgo));
    const recentSum = recentRecords.reduce((s, r) => s + r.amount, 0);
    const recentDays = records.length
      ? Math.max(1, daysBetween(
          records.slice().sort((a, b) => a.date.localeCompare(b.date))[0].date, todayStr) + 1)
      : 0;
    const dailyAvg = recentDays ? recentSum / recentDays : 0;

    const streak = habitService.getStreakDays();

    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const monthLeftDays = daysInMonth - now.getDate();
    const forecastMonth = monthSaved + dailyAvg * monthLeftDays;

    return {
      goals, activeGoals, doneGoals, withdrawnGoals,
      totalTarget, totalSaved, monthSaved, dailyAvg,
      streak, monthLeftDays, forecastMonth, records
    };
  },

  _extractAmount(question) {
    try {
      const matches = (question || '').match(/\d+(\.\d+)?/g);
      if (!matches) return { valid: false, value: 0 };
      for (const m of matches) {
        const v = parseFloat(m);
        if (Number.isFinite(v) && v > 0) return { valid: true, value: v };
      }
      return { valid: false, value: 0 };
    } catch (e) {
      return { valid: false, value: 0 };
    }
  },

  _calcPlan(amount, goal) {
    try {
      if (!goal || !goal.plannedDate) return {};
      const days = daysBetween(today(), goal.plannedDate);
      if (days <= 0) return {};
      const perDay = amount / days;
      const perWeek = perDay * 7;
      if (!Number.isFinite(perDay) || !Number.isFinite(perWeek)) return {};
      return {
        perDay: Math.round(perDay),
        perWeek: Math.round(perWeek),
        days
      };
    } catch (e) {
      return {};
    }
  },

  _pickTemplate(templates) {
    try {
      if (!Array.isArray(templates) || templates.length === 0) {
        return this._defaultGuide({});
      }
      return templates[Math.floor(Math.random() * templates.length)];
    } catch (e) {
      return this._defaultGuide({});
    }
  },

  _maybeStreakHint(ctx) {
    try {
      if (ctx && ctx.streak === 0) {
        return '\n💡 顺便提醒：今天还没打卡哦～';
      }
      return '';
    } catch (e) {
      return '';
    }
  },

  _defaultGuide(ctx) {
    try {
      const c = ctx || {};
      const lines = [];
      lines.push('👋 我是你的引力小助手小梦，可以帮你分析储蓄进度、制定计划、给出建议。');
      if (c.goals && c.goals.length > 0) {
        lines.push(`📊 你目前有 ${c.goals.length} 个目标，已累计存入 ¥${toYuan(c.totalSaved || 0)}。`);
      } else {
        lines.push('🌱 你还没有建立引力源，先去首页创建一个吧！');
      }
      lines.push('');
      lines.push('💬 试试问我：');
      lines.push('   「存5000怎么存」');
      lines.push('   「看看我的进度」');
      lines.push('   「我总是冲动消费怎么办」');
      return lines.join('\n');
    } catch (e) {
      return '👋 我是引力小助手小梦，试试问我「存5000怎么存」或「看看我的进度」～';
    }
  },

  _fillTemplate(tpl, vars) {
    let result = tpl;
    for (const [k, v] of Object.entries(vars)) {
      result = result.replace(new RegExp('\\{' + k + '\\}', 'g'), v);
    }
    return result;
  },

  _handlePlan(question, ctx) {
    const { valid, value } = this._extractAmount(question);
    if (!valid) {
      return this._pickTemplate(INTENTS[0].templatesNoAmount);
    }
    const amount = Math.round(value);
    const goal = ctx.activeGoals && ctx.activeGoals.length > 0 ? ctx.activeGoals[0] : null;
    if (goal) {
      const plan = this._calcPlan(amount, goal);
      if (plan.days && plan.perDay) {
        const tpl = this._pickTemplate(INTENTS[0].templates);
        return this._fillTemplate(tpl, {
          perDay: plan.perDay,
          perWeek: plan.perWeek,
          days: plan.days,
          goalName: goal.name || '目标'
        });
      }
      const tpl = this._pickTemplate(INTENTS[0].templatesNoDate);
      const perDay = Math.round(amount / 30);
      return this._fillTemplate(tpl, {
        amount,
        perDay,
        perWeek: perDay * 7
      });
    }
    const tpl = this._pickTemplate(INTENTS[0].templatesNoGoal);
    const perDay = Math.round(amount / 30);
    return this._fillTemplate(tpl, {
      amount,
      perDay,
      perWeek: perDay * 7,
      perMonth: perDay * 30
    });
  },

  _handleEmotion(question, ctx) {
    if (/冲动|消费|乱花钱|花钱|剁手|买买买|控制不住|想买|又买了|管不住手/.test(question)) {
      const templates = [
        '🛒 冲动消费很正常，你不是一个人！\n💡 试试「延迟满足」：看到想买的先等 48 小时。\n很多时候冷静一天后，你会发现其实也没那么想买。\n🛡️ 把想买的东西写进备忘录，月底再回头看～',
        '🫂 想买的心情能理解，但每次忍住不花，\n就是在为未来的自己攒底气 ✨\n💡 48 小时冷静期是对抗冲动的神器，\n🎯 想想你的梦想，它比一时的冲动更值得！',
        '🛒 冲动是魔鬼，先深呼吸！\n💡 把想买的东西加入购物车但不付款，\n48 小时后再回头看，大部分东西你都不想买了。\n✨ 忍住一次，离梦想就近一步！'
      ];
      let tpl = templates[Math.floor(Math.random() * templates.length)];
      if (ctx.activeGoals && ctx.activeGoals.length > 0) {
        const g = ctx.activeGoals[0];
        const p = progressService.calcProgress(g.currentAmount, g.targetAmount);
        tpl += `\n🎯 想想你的目标「${g.name}」，已经存到 ${p}% 了！\n每次忍住不花，就是离梦想更近一步 ✨`;
      }
      return tpl;
    }
    if (/没钱|穷|空了|花光|见底|余额不足|吃土|口袋空/.test(question)) {
      let tpl = this._pickTemplate(EMOTION_BROKE_TEMPLATES);
      if (ctx.records && ctx.records.length > 0) {
        tpl = `🫂 没钱的感觉不好受，但换个角度想——\n📊 其实你已经存了 ¥${toYuan(ctx.totalSaved)} 了！\n� 建议从「记账」开始，砍掉不必要的开支。\n🌱 穷只是暂时的，有存钱意识的人不会穷太久 💪`;
      }
      return tpl;
    }
    if (/放弃|坚持不下去|不想存|算了|想退|不想坚持|太累了/.test(question)) {
      const templates = [
        '😔 想放弃时，说明你坚持了很久，已经很辛苦了。\n先深呼吸，允许自己有这个念头，这很正常。\n💡 试试降低每日存入金额，压力小了习惯反而更容易保持～\n🤝 去引力场找搭子互相打气，一群人走得远 💪',
        '🫂 坚持不下去的感觉我懂，你已经很努力了。\n💡 不必勉强，先把每日存入降到最小（哪怕 1 元），\n保持习惯比金额重要 🌱\n🤝 引力场的搭子们也在为你加油！',
        '😔 放弃的念头说明你在认真对待这件事。\n💡 暂停一天也没关系，但别彻底放弃。\n🌱 走了这么远，离终点真的不远了，再坚持一下 ✨'
      ];
      let tpl = templates[Math.floor(Math.random() * templates.length)];
      if (ctx.streak > 0) {
        tpl = `😔 想放弃时，说明你坚持了很久。\n🔥 你已经连续存了 ${ctx.streak} 天！现在放弃多可惜呀。\n💡 试试降低每日存入金额，压力小了习惯更容易保持～\n🤝 去引力场找搭子互相打气，一群人走得远 💪`;
      }
      return tpl;
    }
    if (/好难|太难|困难|存不下来|存不起|压力|焦虑|崩溃|没信心|做不到|存不到/.test(question)) {
      const templates = [
        '🫂 觉得难，是因为你在认真对待这件事。\n轻松的事谁都能做，存钱难才说明它值得。\n🌱 难是暂时的，习惯一旦养成，\n以后就不需要靠意志力了 ✨',
        '💪 觉得难就对了，说明你在成长！\n💡 几个小建议：\n1️⃣ 目标别定太大，先从「每天存 10 元」开始\n2️⃣ 用 48 小时冷静期对抗冲动支取\n3️⃣ 完成小目标后奖励自己 🎉\n🌱 你比想象中更厉害！',
        '🫂 压力大的时候，先对自己温柔一点。\n💡 存钱不是比赛，按自己的节奏来就好。\n🌱 哪怕每天只存 1 元，也是在向前走 ✨'
      ];
      let tpl = templates[Math.floor(Math.random() * templates.length)];
      if (ctx.dailyAvg > 0) {
        tpl = `🫂 觉得难，是因为你在认真对待这件事。\n📊 你近 30 天日均存 ¥${toYuan(Math.round(ctx.dailyAvg))}，\n能坚持存钱的人其实不多，你已经超过很多人了！\n🌱 难是暂时的，习惯一旦养成就不需要靠意志力了 ✨`;
      }
      return tpl;
    }
    const templates = [
      '🫂 我理解你的感受，存钱路上难免有起伏。\n💡 试试「延迟满足」：想花钱时先等 48 小时。\n🌱 你已经在路上了，继续就好 ✨',
      '💪 不管遇到什么，你愿意来聊聊就说明你在乎。\n💡 把大目标拆成小步骤，每天前进一点点。\n🤝 引力场的搭子们陪你一起走！',
      '🫂 换个角度看，你已经在为梦想努力了，这本身就很棒！\n🌱 允许自己有低谷，但别停下脚步。\n✨ 每一小步都算数！'
    ];
    let tpl = templates[Math.floor(Math.random() * templates.length)];
    if (ctx.activeGoals && ctx.activeGoals.length > 0) {
      const g = ctx.activeGoals[0];
      const p = progressService.calcProgress(g.currentAmount, g.targetAmount);
      tpl += `\n🎯 想想你的目标「${g.name}」，已经存到 ${p}% 了！\n每次坚持，就是离梦想更近一步 ✨`;
    }
    return tpl;

  },

  _handleProgress(question, ctx) {
    if (/还差|剩余|还要|差多少|离目标|缺口/.test(question)) {
      if (!ctx.activeGoals || ctx.activeGoals.length === 0) {
        return '✅ 当前没有进行中的目标，无需再存入。\n🌱 去首页新建一个引力源吧！';
      }
      const lines = ['📋 各目标剩余金额：'];
      for (const g of ctx.activeGoals) {
        const remain = progressService.getRemaining(g.currentAmount, g.targetAmount);
        lines.push(`• ${g.name}：还差 ¥${remain}`);
      }
      const totalRemain = ctx.activeGoals.reduce((s, g) => s + (g.targetAmount - g.currentAmount), 0);
      lines.push('');
      lines.push(`💰 合计还需存入约 ¥${toYuan(totalRemain)}。`);
      lines.push('⏰ 建议优先冲刺截止日期最近的目标～');
      return lines.join('\n');
    }
    if (/本月|这个月|一个月|能存多少|预估|预计/.test(question)) {
      if (!ctx.records || ctx.records.length === 0) {
        return '📝 你还没有储蓄记录呢。\n先建立引力源、存入第一笔，\n之后我就能帮你预估本月能存多少啦～ 💰';
      }
      const lines = [];
      lines.push(`📅 截至今天，你本月已存 ¥${toYuan(ctx.monthSaved)}。`);
      if (ctx.dailyAvg > 0) {
        lines.push(`📊 近30天日均约 ¥${toYuan(Math.round(ctx.dailyAvg))}，本月还剩 ${ctx.monthLeftDays} 天。`);
        lines.push(`🔮 按当前节奏，预计本月可存约 ¥${toYuan(Math.round(ctx.forecastMonth))}。`);
      }
      return lines.join('\n');
    }
    if (ctx.goals && ctx.goals.length === 0) {
      return '📝 你还没有建立引力源。\n去首页点「新建引力源」开始吧！ 🌟';
    }
    const templates = [
      () => {
        const lines = ['📊 各目标进度：'];
        for (const g of ctx.goals) {
          const p = progressService.calcProgress(g.currentAmount, g.targetAmount);
          const bar = '█'.repeat(Math.floor(p / 10)) + '░'.repeat(10 - Math.floor(p / 10));
          lines.push(`• ${g.name} ${bar} ${p}%（${g.status}）`);
        }
        return lines.join('\n');
      },
      () => {
        const lines = ['✅ 目标进展一览：'];
        for (const g of ctx.goals) {
          const p = progressService.calcProgress(g.currentAmount, g.targetAmount);
          const remain = progressService.getRemaining(g.currentAmount, g.targetAmount);
          lines.push(`� ${g.name}：${p}% | 还差 ¥${remain}（${g.status}）`);
        }
        return lines.join('\n');
      },
      () => {
        const lines = ['📋 你的引力源：'];
        for (const g of ctx.goals) {
          const emoji = g.status === '进行中' ? '🔄' : g.status === '已达成' ? '✅' : '💸';
          const p = progressService.calcProgress(g.currentAmount, g.targetAmount);
          lines.push(`${emoji} ${g.name}（${p}% - ${g.status}）`);
        }
        lines.push('');
        lines.push(`� 累计已存 ¥${toYuan(ctx.totalSaved)}，加油！`);
        return lines.join('\n');
      }
    ];
    return templates[Math.floor(Math.random() * templates.length)]();
  },

  answer(question) {
    try {
      const q = (question || '').trim();
      if (!q) return '请输入你的问题～';
      const ctx = this._context();

      const sorted = INTENTS.slice().sort((a, b) => a.priority - b.priority);
      let matched = null;
      for (const intent of sorted) {
        if (intent.keywords.test(q)) {
          matched = intent;
          break;
        }
      }

      let reply;
      if (matched) {
        if (matched.name === 'plan') {
          reply = this._handlePlan(q, ctx);
        } else if (matched.name === 'emotion') {
          reply = this._handleEmotion(q, ctx);
        } else if (matched.name === 'progress') {
          reply = this._handleProgress(q, ctx);
        } else {
          reply = this._pickTemplate(matched.templates);
        }
      } else {
        reply = this._defaultGuide(ctx);
      }

      reply += this._maybeStreakHint(ctx);
      return reply;
    } catch (e) {
      try {
        return this._defaultGuide(this._context());
      } catch (e2) {
        return '👋 我是引力小助手小梦，试试问我「存5000怎么存」或「看看我的进度」～';
      }
    }
  },

  _default(ctx) {
    return this._defaultGuide(ctx);
  }
};
