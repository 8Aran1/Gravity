import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { VALIDATION_RULES } from '../constants.js';
import { toFen, toYuan, add, sub } from '../utils/moneyUtils.js';
import { idUtils } from '../utils/idUtils.js';
import { today, isBeforeToday } from '../utils/dateUtils.js';

export const recordService = {
  create(recordData) {
    const { goalId, amount, date, note } = recordData;
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) {
      return { success: false, error: '目标不存在或已被删除' };
    }
    const errors = {};
    const amountFen = toFen(Number(amount));
    const remaining = sub(goal.targetAmount, goal.currentAmount);
    if (!amount || amountFen <= 0) {
      errors.amount = '请输入有效金额';
    } else if (amountFen > remaining) {
      errors.amount = `本次储蓄最多可存入 ${toYuan(remaining)} 元（剩余目标金额）`;
    }
    if (!date || !isBeforeToday(date)) {
      errors.date = '储蓄日期不能晚于今天';
    }
    if (note && note.length > VALIDATION_RULES.NOTE_MAX) {
      errors.note = '备注不超过50个字符';
    }
    if (Object.keys(errors).length > 0) {
      return { success: false, errors };
    }
    const record = {
      id: idUtils.generate(),
      goalId,
      amount: amountFen,
      date,
      note: note || '',
      createdAt: Date.now()
    };
    data.records.push(record);
    goal.currentAmount = this.calcTotal(goalId, data);
    if (goal.currentAmount >= goal.targetAmount) {
      goal.status = '已达成';
    } else {
      goal.status = '进行中';
    }
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    }
    return { success: true, data: record };
  },

  getByGoalId(goalId) {
    const data = localStorageAdapter.getData();
    return data.records
      .filter(r => r.goalId === goalId)
      .sort((a, b) => {
        if (a.date !== b.date) return b.date.localeCompare(a.date);
        return b.createdAt - a.createdAt;
      });
  },

  remove(recordId) {
    const data = localStorageAdapter.getData();
    const record = data.records.find(r => r.id === recordId);
    if (!record) {
      return { success: false, error: '记录不存在或已被删除' };
    }
    const goalId = record.goalId;
    data.records = data.records.filter(r => r.id !== recordId);
    const goal = data.goals.find(g => g.id === goalId);
    if (goal) {
      goal.currentAmount = this.calcTotal(goalId, data);
      if (goal.currentAmount >= goal.targetAmount) {
        goal.status = '已达成';
      } else {
        goal.status = '进行中';
      }
    }
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      return { success: false, error: '本地存储空间不足，建议清理浏览器数据后重试' };
    }
    return { success: true };
  },

  calcTotal(goalId, data) {
    const d = data || localStorageAdapter.getData();
    return d.records
      .filter(r => r.goalId === goalId)
      .reduce((sum, r) => add(sum, r.amount), 0);
  }
};