import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { ACHIEVEMENTS } from '../constants.js';
import { today } from '../utils/dateUtils.js';
import { habitService } from './habitService.js';

export const achievementService = {
  getAll() {
    const data = localStorageAdapter.getData();
    const streak = habitService.getStreakDays();
    const hasCompletedGoal = data.goals.some(g => g.status === '已达成');
    const baseBadges = ACHIEVEMENTS.map(rule => {
      let unlocked = false;
      if (rule.badgeId === 'streak_7') unlocked = streak >= 7;
      if (rule.badgeId === 'streak_30') unlocked = streak >= 30;
      if (rule.badgeId === 'first_goal_done') unlocked = hasCompletedGoal;
      const stored = data.achievements.find(a => a.badgeId === rule.badgeId);
      const unlockedDate = unlocked ? (stored && stored.unlockedDate ? stored.unlockedDate : today()) : null;
      return {
        ...rule,
        unlocked,
        unlockedDate
      };
    });
    const charityBadge = (data.achievements || []).find(a => a.badgeId === 'charity_guardian' && a.unlocked === true);
    if (charityBadge) {
      baseBadges.push({
        badgeId: 'charity_guardian',
        name: charityBadge.name || '公益守护者',
        unlockCondition: charityBadge.unlockCondition || '完成一次公益赎回',
        unlocked: true,
        unlockedDate: charityBadge.unlockedDate || today()
      });
    }
    return baseBadges;
  },

  checkAndUnlock() {
    const data = localStorageAdapter.getData();
    const streak = habitService.getStreakDays();
    const hasCompletedGoal = data.goals.some(g => g.status === '已达成');
    let newBadge = null;
    if (!data.achievements || data.achievements.length === 0) {
      data.achievements = ACHIEVEMENTS.map(a => ({ ...a }));
    }
    for (const rule of ACHIEVEMENTS) {
      let shouldUnlock = false;
      if (rule.badgeId === 'streak_7') shouldUnlock = streak >= 7;
      if (rule.badgeId === 'streak_30') shouldUnlock = streak >= 30;
      if (rule.badgeId === 'first_goal_done') shouldUnlock = hasCompletedGoal;
      const stored = data.achievements.find(a => a.badgeId === rule.badgeId);
      if (shouldUnlock && stored && !stored.unlocked) {
        stored.unlocked = true;
        stored.unlockedDate = today();
        newBadge = { ...stored };
      } else if (shouldUnlock && stored) {
        stored.unlocked = true;
        if (!stored.unlockedDate) stored.unlockedDate = today();
      }
    }
    localStorageAdapter.saveData(data);
    return newBadge;
  }
};