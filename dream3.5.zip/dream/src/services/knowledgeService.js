const READ_KEY = 'read_knowledge_ids';

const KNOWLEDGE_ARTICLES = [
  {
    id: 'week52_saving',
    title: '52周存钱法：无痛攒下第一桶金',
    summary: '按周递增的小额储蓄法，一年攒下一笔可观的梦想基金',
    content: `第一周存 10 元，第二周存 20 元，第三周存 30 元……依此类推，第 52 周存 520 元。

听起来很简单，但一年下来你能攒下 13780 元。这就是"52 周存钱法"的魅力——门槛极低，却能积少成多。

为什么它有效？关键在于"递增"带来的习惯养成。每周的金额都在增长，你会不知不觉地把储蓄纳入生活节奏，而不是等到月底"有钱再存"。

如果你觉得递增有压力，也可以试试"反向 52 周"：先存 520 元，最后一周存 10 元。这样前期压力大但越往后越轻松，适合刚发年终奖的朋友。

还有"随机 52 周"：把 10 到 520 的数字打乱，每周随机挑一个金额存。适合喜欢新鲜感的人，存钱也能有盲盒的快乐。

无论哪种变体，核心都是同一件事：把储蓄变成一个可量化、可追踪的游戏。当你在日历上打勾的那一刻，成就感会推着你继续走下去。

存钱从来不是靠意志力硬撑，而是靠方法让坚持变得自然。52 周存钱法，就是给意志力装上轮子。`,
    readMinutes: 5
  },
  {
    id: 'anti_pig_butcher',
    title: '警惕"杀猪盘"：高收益背后的陷阱',
    summary: '识别网络交友诱导投资诈骗的常见话术与应对方法',
    content: `"杀猪盘"是近年来最高发的网络诈骗之一。骗子先以恋爱交友之名"养猪"，等感情稳定后再诱导你投资，最后卷款消失——这就是"杀猪"。

识别话术第一招：对方总是"完美人设"。事业有成、温柔体贴、嘘寒问暖，却总在引导你聊投资、聊理财、聊某个"稳赚不赔"的平台。

识别话术第二招：强调"内部渠道"或"漏洞套利"。声称有亲戚在金融公司、发现了系统漏洞、带你一起赚钱——任何需要"特殊通道"才能赚的钱，都值得高度警惕。

识别话术第三招：先让你尝甜头。首次投入 1000 元，第二天返你 1200 元。你以为找到了财富密码，其实那只是诱饵。等你投入 10 万，平台就"维护中"了。

识别话术第四招：催促"加仓"和"别告诉别人"。骗子会说"机会难得，多投多赚"，"为了咱们的未来别告诉家人"——越是这样，越要停下来想想。

记住一个铁律：凡是网上认识的人引导你到非正规平台投资、要求转账到个人账户的，99.9% 是诈骗。

万一已经投入，别因为羞耻感而沉默。第一时间拨打 96110 反诈热线，保留聊天记录和转账凭证，越早报警追回概率越高。

真正的理财不会让你在深夜焦虑，更不会需要你借钱去"加仓"。保护好自己的钱包，就是保护好未来。`,
    readMinutes: 4
  },
  {
    id: 'compound_power',
    title: '复利的力量：时间才是最好的杠杆',
    summary: '理解复利曲线与长期持有带来的累积效应',
    content: `爱因斯坦说复利是"世界第八大奇迹"。理解它的人能赚到它，不理解的人会付出它。

复利的数学很简单：本金产生利息，利息再加入本金继续产生利息——利滚利。公式是 A = P(1+r)^n，其中 n 是时间，它处在指数位置上。

来看一个故事：小王 25 岁起每年存 1 万元，存 10 年后停手，共投入 10 万。小李 35 岁才开始，每年也存 1 万元，一直存到 60 岁，共投入 25 万。假设年化收益 7%，到 60 岁时谁的钱更多？

答案是小王。虽然他只存了 10 年、投入少了一倍多，但他的钱多滚了 10 年复利，最终反而领先。这就是时间的杠杆。

复利有三个关键变量：本金、收益率、时间。其中时间是你唯一不需要任何门槛就能拥有的——越早开始，杠杆越长。

很多人觉得"等有钱了再理财"，但复利的逻辑恰恰相反：不是有钱才理财，而是理财才有钱。哪怕每月只存 500 元，30 年后也是一笔可观的数目。

复利也有"暗面"——债务的复利。信用卡分期 18% 的年化，同样在指数增长，只是方向相反。所以理财第一步永远是：先还清高息债务。

理解复利不是为了让你变成数学家，而是让你明白一个朴素的道理：坚持比聪明更重要，时间比运气更可靠。种一棵树最好的时间是十年前，其次是现在。`,
    readMinutes: 6
  },
  {
    id: 'emergency_fund',
    title: '应急基金：给生活留一把备用钥匙',
    summary: '为什么你需要 3-6 个月生活费的应急储备，以及如何建立',
    content: `生活总有意外：突然失业、生病、家电坏了、车子要修……如果没有应急储备，你只能被迫动用长期投资，或者更糟——借高息贷款。

应急基金就是你的"生活安全气囊"：一笔随时可取、不用于消费、专门应对突发支出的钱。

多少才够？通用建议是 3 到 6 个月的生活费。如果你是单身、工作稳定，3 个月可能足够；如果有家庭、收入波动大，建议存到 6 个月甚至更多。

放在哪里？关键原则是"流动 + 安全"。货币基金、银行活期、短期存款都是好选择。千万别放进股市或长期理财——等你急用钱的时候，可能正好是市场低点。

怎么开始存？不用一蹴而就。先定一个小目标：存够 1 个月生活费。达成后再向 3 个月、6 个月推进。每月固定转一笔钱进应急账户，像还房贷一样雷打不动。

一个常见误区：把应急基金和"梦想储蓄"混在一起。应急基金是防御，梦想储蓄是进攻，两者职责不同，账户也要分开。

有了应急基金，你会发现一个奇妙的变化：面对工作和生活的心态更从容了。因为你知道，即使突发变故，也有一个缓冲垫在托底。

理财的第一步不是追求收益最大化，而是先把下行风险兜住。应急基金，就是那张兜底的网。`,
    readMinutes: 4
  },
  {
    id: 'rational_investing',
    title: '理性理财：别让情绪替你做决定',
    summary: '认识常见的行为偏误，建立属于自己的投资纪律',
    content: `行为金融学告诉我们：人不是理性的经济动物。在理财中，情绪偏误造成的损失，往往比市场波动本身更大。

偏误一：追涨杀跌。看到别人赚钱就冲进去，看到下跌就恐慌抛售。结果买在高点、卖在低点，完美反向操作。解药是"定投"——固定金额、固定时间，让纪律代替情绪。

偏误二：损失厌恶。亏 100 元的痛苦，是赚 100 元快乐的 2 倍。所以我们死守亏损不卖，却对盈利过早落袋。解药是"事前定规则"：买入时就写好何时止盈、何时止损，到了就执行。

偏误三：过度自信。觉得自己能"跑赢市场"，频繁交易。统计显示，交易越频繁，收益往往越低——因为手续费和错误决策在累积。解药是"长期持有"：选好标的就少动，让复利工作。

偏误四：从众心理。大家都在买某只基金，我也买。但市场的共识往往意味着价格已经反映了预期，跟风买入常常是接盘。解药是"独立思考"：只投自己看得懂的东西。

偏误五：锚定效应。买入价 10 元，跌到 7 元就觉得"便宜了"想加仓。但市场不关心你的买入价，7 元贵不贵要看价值，不是看它从 10 元跌下来。解药是"忘掉成本"：每次决策都问"如果我现在空仓，会买入吗"。

建立投资纪律的核心，是承认自己有情绪偏误，然后用规则把情绪隔离开。定投、再平衡、止盈止损线，都是帮我们"反人性"的工具。

理财不是预测市场，而是管理自己。能管住情绪的人，时间会站在他这边。`,
    readMinutes: 5
  }
];

try {
  if (!Array.isArray(KNOWLEDGE_ARTICLES) || KNOWLEDGE_ARTICLES.length < 3 || KNOWLEDGE_ARTICLES.length > 5) {
    console.warn('knowledgeService self-check: articles count out of range [3,5]');
  }
  const ids = KNOWLEDGE_ARTICLES.map(a => a.id);
  if (new Set(ids).size !== ids.length) {
    console.warn('knowledgeService self-check: duplicate article ids detected');
  }
  for (const a of KNOWLEDGE_ARTICLES) {
    if (!a.id || !a.title || !a.summary || !a.content || typeof a.readMinutes !== 'number' || a.readMinutes <= 0) {
      console.warn('knowledgeService self-check: article field invalid for id=' + a.id);
    }
  }
  const hasSaving = KNOWLEDGE_ARTICLES.some(a => a.id.includes('saving') || a.id.includes('week52') || a.title.includes('存钱'));
  const hasRisk = KNOWLEDGE_ARTICLES.some(a => a.id.includes('pig') || a.id.includes('anti') || a.title.includes('杀猪盘') || a.title.includes('陷阱'));
  const hasCompound = KNOWLEDGE_ARTICLES.some(a => a.id.includes('compound') || a.title.includes('复利') || a.title.includes('理性'));
  if (!hasSaving || !hasRisk || !hasCompound) {
    console.warn('knowledgeService self-check: missing required content direction');
  }
} catch (e) {
  console.warn('knowledgeService self-check failed:', e);
}

export const knowledgeService = {
  getAllArticles() {
    try {
      if (!Array.isArray(KNOWLEDGE_ARTICLES)) return [];
      return KNOWLEDGE_ARTICLES.map(a => ({ ...a }));
    } catch (e) {
      console.warn('knowledgeService.getAllArticles fallback');
      return [];
    }
  },

  getArticleById(id) {
    try {
      if (typeof id !== 'string' || id === '') return { found: false, article: null };
      const article = KNOWLEDGE_ARTICLES.find(a => a.id === id);
      if (article) return { found: true, article };
      return { found: false, article: null };
    } catch (e) {
      return { found: false, article: null };
    }
  },

  getReadIds() {
    try {
      const raw = localStorage.getItem(READ_KEY);
      if (raw === null) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(x => typeof x === 'string');
    } catch (e) {
      console.warn('knowledgeService.getReadIds fallback');
      return [];
    }
  },

  isRead(id) {
    try {
      if (typeof id !== 'string' || id === '') return false;
      const readIds = this.getReadIds();
      return readIds.includes(id);
    } catch (e) {
      return false;
    }
  },

  markAsRead(id) {
    try {
      if (typeof id !== 'string' || id === '') return { success: false, alreadyRead: false };
      const readIds = this.getReadIds();
      if (readIds.includes(id)) return { success: true, alreadyRead: true };
      readIds.push(id);
      localStorage.setItem(READ_KEY, JSON.stringify(readIds));
      return { success: true, alreadyRead: false };
    } catch (e) {
      console.warn('knowledgeService.markAsRead fallback');
      return { success: false, alreadyRead: false };
    }
  }
};