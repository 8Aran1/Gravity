import { STORAGE_KEYS } from '../constants.js';

function getData() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.CAMPS_KEY) || '{"camps":[]}');
  } catch (e) {
    return { camps: [] };
  }
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEYS.CAMPS_KEY, JSON.stringify(data));
}

function getJoined() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.JOINED_KEY) || '[]');
  } catch (e) {
    return [];
  }
}

function saveJoined(list) {
  localStorage.setItem(STORAGE_KEYS.JOINED_KEY, JSON.stringify(list));
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

function genCode(camps) {
  for (let i = 0; i < 100; i++) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    if (!camps.find(c => c.code === code)) return code;
  }
  throw new Error('无法生成唯一组队码');
}

export const campService = {
  create(name, nickname, goalName, progress, maxMembers) {
    const data = getData();
    const code = genCode(data.camps);
    const memberId = genId();
    const max = Math.min(10, Math.max(2, maxMembers || 3));
    const now = new Date().toISOString().slice(0, 10);
    const camp = {
      id: genId(),
      code,
      name,
      max_members: max,
      creator_member_id: memberId,
      created_at: now,
      members: [{
        id: memberId,
        nickname,
        goal_name: goalName || null,
        progress: progress || 0,
        joined_at: now
      }],
      messages: []
    };
    data.camps.push(camp);
    saveData(data);
    saveJoined([...getJoined(), { campId: camp.id, code, memberId, nickname, campName: name }]);
    return { campId: camp.id, code, memberId };
  },

  join(code, nickname, goalName, progress) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return { success: false, error: '组队码不存在' };
    if (camp.members.length >= (camp.max_members || 3)) return { success: false, error: '小组成员已满' };
    if (camp.members.find(m => m.nickname === nickname)) return { success: false, error: '该昵称已被使用，请换一个' };
    const memberId = genId();
    const now = new Date().toISOString().slice(0, 10);
    camp.members.push({ id: memberId, nickname, goal_name: goalName || null, progress: progress || 0, joined_at: now });
    saveData(data);
    const joined = getJoined();
    const idx = joined.findIndex(c => c.code === code);
    const record = { campId: camp.id, code, memberId, nickname, campName: camp.name };
    if (idx >= 0) { joined[idx] = record; } else { joined.push(record); }
    saveJoined(joined);
    return { success: true, campId: camp.id, campName: camp.name, memberId };
  },

  getCampByCode(code) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return null;
    return { camp, members: camp.members, messages: camp.messages };
  },

  updateProgress(code, memberId, progress, goalName) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return { success: false };
    const member = camp.members.find(m => m.id === memberId);
    if (!member) return { success: false };
    member.progress = progress || 0;
    member.goal_name = goalName || null;
    saveData(data);
    return { success: true };
  },

  sendMessage(code, memberId, nickname, text) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return { success: false };
    const msg = { id: genId(), member_id: memberId, nickname, text, created_at: Date.now() };
    camp.messages.push(msg);
    saveData(data);
    return { success: true, message: msg };
  },

  deleteMessage(code, msgId) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return { success: false };
    const idx = camp.messages.findIndex(m => m.id === msgId);
    if (idx >= 0) camp.messages.splice(idx, 1);
    saveData(data);
    return { success: true };
  },

  leaveCamp(code, memberId) {
    const data = getData();
    const camp = data.camps.find(c => c.code === code);
    if (!camp) return { success: false };
    camp.members = camp.members.filter(m => m.id !== memberId);
    camp.messages = camp.messages.filter(m => m.member_id !== memberId);
    saveData(data);
    saveJoined(getJoined().filter(c => c.code !== code));
    return { success: true };
  },

  disbandCamp(code) {
    const data = getData();
    data.camps = data.camps.filter(c => c.code !== code);
    saveData(data);
    saveJoined(getJoined().filter(c => c.code !== code));
    return { success: true };
  },

  getJoinedCamps() {
    const data = getData();
    const joined = getJoined();
    const valid = joined.filter(j => data.camps.find(c => c.code === j.code));
    if (valid.length !== joined.length) saveJoined(valid);
    return valid;
  },

  getJoinedByCode(code) {
    return getJoined().find(c => c.code === code);
  }
};
