import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { idUtils } from '../utils/idUtils.js';
import { today, format, daysBetween } from '../utils/dateUtils.js';

export const habitService = {
  checkIn(goalId) {
    const data = localStorageAdapter.getData();
    const goal = data.goals.find(g => g.id === goalId);
    if (!goal) {
      return { success: false, message: '目标不存在或已被删除' };
    }
    if (goal.status !== '进行中') {
      return { success: false, message: '仅可对进行中的目标打卡' };
    }
    const todayStr = today();
    const alreadyChecked = data.checkIns.some(
      c => c.goalId === goalId && c.checkInDate === todayStr
    );
    if (alreadyChecked) {
      return { success: false, message: '今日已打卡' };
    }
    const checkIn = {
      id: idUtils.generate(),
      goalId,
      checkInDate: todayStr,
      checkInTime: Date.now()
    };
    data.checkIns.push(checkIn);
    const ok = localStorageAdapter.saveData(data);
    if (!ok) {
      return { success: false, message: '本地存储空间不足，建议清理浏览器数据后重试' };
    }
    return { success: true, message: '打卡成功！' };
  },

  getStreakDays() {
    const data = localStorageAdapter.getData();
    if (data.records.length === 0) return 0;
    const dateSet = new Set(data.records.map(r => r.date));
    let streak = 0;
    const now = new Date();
    for (let i = 0; i < 365; i++) {
      const checkDate = new Date(now);
      checkDate.setDate(now.getDate() - i);
      const dateStr = format(checkDate);
      if (dateSet.has(dateStr)) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  },

  getMotivationText(streakDays) {
    if (streakDays === 0) return '开始你的第一笔储蓄吧！';
    if (streakDays >= 30) return '坚持一个月，你太厉害了！';
    if (streakDays >= 7) return '太棒了！已坚持一周，继续保持！';
    if (streakDays >= 3) return `已连续储蓄${streakDays}天，继续保持！`;
    return `已连续储蓄${streakDays}天，加油！`;
  },

  hasCheckedInToday(goalId) {
    const data = localStorageAdapter.getData();
    const todayStr = today();
    return data.checkIns.some(c => c.goalId === goalId && c.checkInDate === todayStr);
  }
};