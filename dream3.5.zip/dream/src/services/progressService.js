import { toYuan, sub } from '../utils/moneyUtils.js';
import { today, daysBetween } from '../utils/dateUtils.js';
import { VALIDATION_RULES } from '../constants.js';

export const progressService = {
  calcProgress(currentAmount, targetAmount) {
    if (!targetAmount || targetAmount === 0) return 0;
    const percent = Math.floor((currentAmount / targetAmount) * 100);
    return Math.min(Math.max(percent, 0), 100);
  },

  isCompleted(currentAmount, targetAmount) {
    return currentAmount >= targetAmount;
  },

  getRemaining(currentAmount, targetAmount) {
    return toYuan(sub(targetAmount, currentAmount));
  },

  getWarning(plannedDate, progress) {
    const days = daysBetween(today(), plannedDate);
    if (days < VALIDATION_RULES.WARNING_DAYS && progress < VALIDATION_RULES.WARNING_PROGRESS && days >= 0) {
      return `距离目标完成日期仅剩${days}天，当前进度${progress}%，加油！`;
    }
    return null;
  }
};