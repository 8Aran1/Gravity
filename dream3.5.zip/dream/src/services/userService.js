import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { USER_PROFILE_RULES, PRESET_AVATARS, DEFAULT_THEME_KEY, BACKGROUND_THEMES } from '../constants.js';

const CONTROL_CHAR_REGEX = /[\r\n\t\u0000-\u001F\u007F]/g;
const VALID_AVATAR_KEYS = new Set(PRESET_AVATARS.map(a => a.key));
const VALID_THEME_KEYS = new Set(BACKGROUND_THEMES.map(t => t.key));

function validate({ nickname, avatarKey }) {
  const errors = {};
  let cleaned = (nickname || '').replace(CONTROL_CHAR_REGEX, '').trim();
  const len = Array.from(cleaned).length;
  if (len < USER_PROFILE_RULES.NICKNAME_MIN) {
    errors.nickname = '昵称不能为空';
  } else if (len > USER_PROFILE_RULES.NICKNAME_MAX) {
    errors.nickname = '昵称最多 20 个字符';
  }
  if (!avatarKey || !VALID_AVATAR_KEYS.has(avatarKey)) {
    errors.avatar = '请选择头像';
  }
  return { cleanedNickname: cleaned, errors };
}

export const userService = {
  getDefaultProfile() {
    return {
      nickname: USER_PROFILE_RULES.DEFAULT_NICKNAME,
      avatarKey: USER_PROFILE_RULES.DEFAULT_AVATAR_KEY,
      updatedAt: null
    };
  },

  getAvatarSet() {
    return PRESET_AVATARS;
  },

  getAvatarEmojiByKey(key) {
    if (key && VALID_AVATAR_KEYS.has(key)) {
      const item = PRESET_AVATARS.find(a => a.key === key);
      if (item) return item.emoji;
    }
    const def = PRESET_AVATARS.find(a => a.isDefault);
    return def ? def.emoji : '⭐';
  },

  getProfile() {
    try {
      const data = localStorageAdapter.getData();
      const user = data.user;
      if (user && typeof user === 'object' && !Array.isArray(user) &&
          typeof user.nickname === 'string' && user.nickname.trim().length > 0 &&
          VALID_AVATAR_KEYS.has(user.avatarKey)) {
        return {
          nickname: user.nickname,
          avatarKey: user.avatarKey,
          updatedAt: user.updatedAt ?? null
        };
      }
      return this.getDefaultProfile();
    } catch (e) {
      return this.getDefaultProfile();
    }
  },

  saveProfile({ nickname, avatarKey, themeKey }) {
    const { cleanedNickname, errors } = validate({ nickname, avatarKey });
    if (Object.keys(errors).length > 0) {
      return { success: false, errors };
    }
    try {
      const data = localStorageAdapter.getData();
      const existingThemeKey = (data.user && data.user.themeKey) || DEFAULT_THEME_KEY;
      const finalThemeKey = (themeKey && VALID_THEME_KEYS.has(themeKey)) ? themeKey : existingThemeKey;
      data.user = {
        nickname: cleanedNickname,
        avatarKey,
        themeKey: finalThemeKey,
        updatedAt: Date.now()
      };
      const ok = localStorageAdapter.saveData(data);
      if (ok) {
        return { success: true, data: data.user };
      }
      return { success: false, error: '保存失败，请检查浏览器存储设置' };
    } catch (e) {
      return { success: false, error: '保存失败，请检查浏览器存储设置' };
    }
  }
};