import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { BACKGROUND_THEMES, DEFAULT_THEME_KEY } from '../constants.js';

const VALID_THEME_KEYS = new Set(BACKGROUND_THEMES.map(t => t.key));
const THEME_CLASSES = BACKGROUND_THEMES.map(t => 'theme-' + t.key);

export const themeService = {
  getThemeSet() {
    return BACKGROUND_THEMES;
  },

  getDefaultThemeKey() {
    return DEFAULT_THEME_KEY;
  },

  getCurrentThemeKey() {
    try {
      const data = localStorageAdapter.getData();
      const user = data.user;
      if (user && typeof user === 'object' && !Array.isArray(user) &&
          typeof user.themeKey === 'string' && VALID_THEME_KEYS.has(user.themeKey)) {
        return user.themeKey;
      }
      return DEFAULT_THEME_KEY;
    } catch (e) {
      return DEFAULT_THEME_KEY;
    }
  },

  applyTheme(themeKey) {
    try {
      if (!themeKey || !VALID_THEME_KEYS.has(themeKey)) {
        return false;
      }
      document.body.classList.remove(...THEME_CLASSES);
      document.body.classList.add('theme-' + themeKey);
      return true;
    } catch (e) {
      return false;
    }
  },

  saveTheme(themeKey) {
    try {
      if (!themeKey || !VALID_THEME_KEYS.has(themeKey)) {
        return { success: false, error: '主题标识非法' };
      }
      const data = localStorageAdapter.getData();
      if (!data.user || typeof data.user !== 'object') {
        data.user = { nickname: '', avatarKey: '' };
      }
      data.user.themeKey = themeKey;
      data.user.updatedAt = Date.now();
      const ok = localStorageAdapter.saveData(data);
      if (ok) {
        return { success: true };
      }
      return { success: false, error: '保存失败' };
    } catch (e) {
      return { success: false, error: '保存失败' };
    }
  },

  applySavedTheme() {
    try {
      const key = this.getCurrentThemeKey();
      if (!this.applyTheme(key)) {
        this.applyTheme(DEFAULT_THEME_KEY);
      }
    } catch (e) {
      try {
        this.applyTheme(DEFAULT_THEME_KEY);
      } catch (e2) {}
    }
  }
};