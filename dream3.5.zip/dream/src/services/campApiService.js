import { STORAGE_KEYS } from '../constants.js';

const API = window.location.origin + '/api/camp';

function getJoined() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.JOINED_KEY) || '[]');
  } catch (e) {
    return [];
  }
}

function saveJoined(list) {
  localStorage.setItem(STORAGE_KEYS.JOINED_KEY, JSON.stringify(list));
}

export const campApiService = {
  async create(name, nickname, goalName, progress, maxMembers) {
    const res = await fetch(`${API}/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, nickname, goalName, progress, maxMembers })
    });
    const data = await res.json();
    if (data.campId) {
      saveJoined([...getJoined(), {
        campId: data.campId,
        code: data.code,
        memberId: data.memberId,
        nickname,
        campName: name
      }]);
    }
    return data;
  },

  async join(code, nickname, goalName, progress) {
    const res = await fetch(`${API}/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, nickname, goalName, progress })
    });
    const data = await res.json();
    if (data.success) {
      const joined = getJoined();
      const idx = joined.findIndex(c => c.code === code);
      const record = { campId: data.campId, code, memberId: data.memberId, nickname, campName: data.campName };
      if (idx >= 0) { joined[idx] = record; } else { joined.push(record); }
      saveJoined(joined);
    }
    return data;
  },

  async getCamp(code) {
    const res = await fetch(`${API}/${code}`);
    if (!res.ok) return null;
    return await res.json();
  },

  async updateProgress(code, memberId, progress, goalName) {
    await fetch(`${API}/${code}/progress`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memberId, progress, goalName })
    });
  },

  async sendMessage(code, memberId, nickname, text) {
    const res = await fetch(`${API}/${code}/message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memberId, nickname, text })
    });
    return await res.json();
  },

  async deleteMessage(code, msgId) {
    await fetch(`${API}/${code}/message/${msgId}`, { method: 'DELETE' });
  },

  async leaveCamp(code, memberId) {
    await fetch(`${API}/${code}/leave`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memberId })
    });
    saveJoined(getJoined().filter(c => c.code !== code));
  },

  async disbandCamp(code) {
    await fetch(`${API}/${code}`, { method: 'DELETE' });
    saveJoined(getJoined().filter(c => c.code !== code));
  },

  getJoinedCamps() {
    return getJoined();
  },

  getJoinedByCode(code) {
    return getJoined().find(c => c.code === code);
  }
};