import { localStorageAdapter } from '../storage/localStorageAdapter.js';
import { idUtils } from '../utils/idUtils.js';
import { today, format } from '../utils/dateUtils.js';

const STEPS_RANGE = { min: 5000, max: 10000, fallback: 8000 };
const CHARITY_BADGE = { badgeId: 'charity_guardian', name: '公益守护者', unlockCondition: '完成一次公益赎回' };
const FALLBACK_QUESTION = {
  stem: '以下哪种理财方式最安全？',
  options: ['高收益保本', '银行存款', '陌生人推荐', '不明链接'],
  answerIndex: 1
};
const ANTI_FRAUD_QUESTIONS = [
  {
    stem: '以下哪种理财方式最安全？',
    options: ['高收益保本', '银行存款', '陌生人推荐', '不明链接'],
    answerIndex: 1
  },
  {
    stem: '收到"日赚千元"的理财广告，应该怎么做？',
    options: ['立即投资', '拉黑举报', '分享给朋友', '先投一点试试'],
    answerIndex: 1
  },
  {
    stem: '有人让你转账到"安全账户"验证，正确的做法是？',
    options: ['马上转账', '拒绝并报警', '先转小额', '确认对方身份后转'],
    answerIndex: 1
  },
  {
    stem: '以下哪个是良好的储蓄习惯？',
    options: ['月光不存', '定期存一点', '借钱投资', '只买不存'],
    answerIndex: 1
  }
];

export const charityService = {
  generateSteps() {
    try {
      const steps = Math.floor(Math.random() * (STEPS_RANGE.max - STEPS_RANGE.min + 1)) + STEPS_RANGE.min;
      return { steps, ok: true };
    } catch (e) {
      return { steps: STEPS_RANGE.fallback, ok: true };
    }
  },

  getAntiFraudQuestion() {
    try {
      const idx = Math.floor(Math.random() * ANTI_FRAUD_QUESTIONS.length);
      const q = ANTI_FRAUD_QUESTIONS[idx] || FALLBACK_QUESTION;
      return { stem: q.stem, options: [...q.options], answerIndex: q.answerIndex };
    } catch (e) {
      return { ...FALLBACK_QUESTION, options: [...FALLBACK_QUESTION.options] };
    }
  },

  isAnswerCorrect(question, selectedIndex) {
    try {
      if (!question || typeof selectedIndex !== 'number' || selectedIndex < 0 || selectedIndex > 3) {
        return { correct: false };
      }
      return { correct: selectedIndex === question.answerIndex };
    } catch (e) {
      return { correct: false };
    }
  },

  markHintClosed() {
    try {
      const key = 'charity_hint_closed_' + today();
      sessionStorage.setItem(key, '1');
    } catch (e) {}
  },

  isHintClosedToday() {
    try {
      const key = 'charity_hint_closed_' + today();
      return sessionStorage.getItem(key) === '1';
    } catch (e) {
      return false;
    }
  },

  detectYesterdayMiss() {
    try {
      const data = localStorageAdapter.getData();
      const yesterday = format(new Date(Date.now() - 86400000));
      const checkIns = Array.isArray(data.checkIns) ? data.checkIns : [];
      const activeGoals = Array.isArray(data.goals) ? data.goals.filter(g => g.status === '进行中') : [];
      for (const goal of activeGoals) {
        const hasYesterday = checkIns.some(c => c.checkInDate === yesterday && c.goalId === goal.id);
        if (!hasYesterday) {
          return { missed: true, goalId: goal.id, yesterday };
        }
      }
      return { missed: false, goalId: null, yesterday: null };
    } catch (e) {
      return { missed: false, goalId: null, yesterday: null };
    }
  },

  repairYesterdayCheckIn(goalId) {
    try {
      const data = localStorageAdapter.getData();
      const goal = data.goals.find(g => g.id === goalId && g.status === '进行中');
      if (!goal) {
        return { success: false, message: '这个梦想已启程远行，无需修复啦', alreadyRepaired: false };
      }
      const yesterday = format(new Date(Date.now() - 86400000));
      const checkIns = Array.isArray(data.checkIns) ? data.checkIns : [];
      const existing = checkIns.find(c => c.checkInDate === yesterday && c.goalId === goalId);
      if (existing) {
        return { success: true, message: '昨日已修复，感谢你的善意', alreadyRepaired: true };
      }
      if (!Array.isArray(data.checkIns)) data.checkIns = [];
      const backupLen = data.checkIns.length;
      data.checkIns.push({
        id: idUtils.generate(),
        goalId,
        checkInDate: yesterday,
        checkInTime: Date.now()
      });
      const ok = localStorageAdapter.saveData(data);
      if (!ok) {
        data.checkIns.length = backupLen;
        return { success: false, message: '存储空间不足，清理后稍后再试', alreadyRepaired: false };
      }
      return { success: true, message: '修复成功', alreadyRepaired: false };
    } catch (e) {
      return { success: false, message: '稍后再试', alreadyRepaired: false };
    }
  },

  unlockGuardianBadge() {
    try {
      const data = localStorageAdapter.getData();
      if (!Array.isArray(data.achievements)) data.achievements = [];
      const existing = data.achievements.find(a => a.badgeId === CHARITY_BADGE.badgeId);
      if (existing && existing.unlocked === true) {
        return { success: true, newlyUnlocked: false, badge: existing };
      }
      if (existing) {
        existing.unlocked = true;
        existing.unlockedDate = existing.unlockedDate || today();
        if (!existing.name) existing.name = CHARITY_BADGE.name;
        if (!existing.unlockCondition) existing.unlockCondition = CHARITY_BADGE.unlockCondition;
        const ok = localStorageAdapter.saveData(data);
        if (!ok) return { success: false, newlyUnlocked: false, badge: null };
        return { success: true, newlyUnlocked: true, badge: existing };
      }
      const badge = { ...CHARITY_BADGE, unlocked: true, unlockedDate: today() };
      data.achievements.push(badge);
      const ok = localStorageAdapter.saveData(data);
      if (!ok) return { success: false, newlyUnlocked: false, badge: null };
      return { success: true, newlyUnlocked: true, badge };
    } catch (e) {
      return { success: false, newlyUnlocked: false, badge: null };
    }
  }
};