import { STORAGE_KEYS, ACHIEVEMENTS, DATA_VERSION } from '../constants.js';

const API_URL = window.location.origin + '/api/data';

function getEmptyData() {
  return {
    _version: DATA_VERSION,
    goals: [],
    records: [],
    checkIns: [],
    camps: [],
    achievements: ACHIEVEMENTS.map(a => ({ ...a })),
    user: null
  };
}

let cache = null;

export const localStorageAdapter = {
  read(key) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (!data || typeof data !== 'object') return null;
      return data;
    } catch (e) {
      return null;
    }
  },

  write(key, data) {
    try {
      const payload = { ...data, _version: DATA_VERSION };
      localStorage.setItem(key, JSON.stringify(payload));
      return true;
    } catch (e) {
      return false;
    }
  },

  remove(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  },

  getVersion() {
    return DATA_VERSION;
  },

  async initData() {
    const localData = this.read(STORAGE_KEYS.DATA_KEY);
    if (localData) {
      try {
        await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...localData, _version: DATA_VERSION })
        });
        localStorage.removeItem(STORAGE_KEYS.DATA_KEY);
      } catch (e) {}
      cache = localData;
    } else {
      try {
        const res = await fetch(API_URL);
        const data = await res.json();
        cache = {
          _version: DATA_VERSION,
          goals: data.goals || [],
          records: data.records || [],
          checkIns: data.checkIns || [],
          camps: data.camps || [],
          achievements: (data.achievements && data.achievements.length > 0) ? data.achievements : ACHIEVEMENTS.map(a => ({ ...a }))
        };
      } catch (e) {
        cache = getEmptyData();
      }
    }
    if (!cache.achievements || cache.achievements.length === 0) {
      cache.achievements = ACHIEVEMENTS.map(a => ({ ...a }));
    }
    if (!cache.camps) cache.camps = [];
    if (!cache.user) cache.user = null;
    return cache;
  },

  saveData(data) {
    cache = data;
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, _version: DATA_VERSION })
    }).catch(() => {});
    return true;
  },

  getData() {
    return cache || getEmptyData();
  }
};
