import { tutorialSteps } from '../views/tutorialSteps.js';

const STORAGE_KEY = 'tutorialStep';

function _isValidForWrite(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || !Number.isInteger(value)) {
    return false;
  }
  return value >= 0 && value <= tutorialSteps.TOTAL;
}

export const tutorialStorage = {
  read() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw === null) return 0;
      const num = Number(raw);
      if (!Number.isFinite(num) || !Number.isInteger(num) || num < 0) return 0;
      if (num >= tutorialSteps.TOTAL) return tutorialSteps.TOTAL;
      return num;
    } catch (e) {
      return 0;
    }
  },

  write(step) {
    try {
      if (!_isValidForWrite(step)) return false;
      localStorage.setItem(STORAGE_KEY, String(step));
      return true;
    } catch (e) {
      return false;
    }
  },

  reset() {
    try {
      localStorage.setItem(STORAGE_KEY, '0');
      return true;
    } catch (e) {
      return false;
    }
  },

  complete() {
    try {
      localStorage.setItem(STORAGE_KEY, String(tutorialSteps.TOTAL));
      return true;
    } catch (e) {
      return false;
    }
  },

  remove() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      return true;
    } catch (e) {
      return false;
    }
  }
};
