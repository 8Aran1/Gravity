const GSAP_CDN_URL = 'https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js';
const GSAP_LOAD_TIMEOUT = 3000;
const SELECTORS = ['.home-identity-avatar', '.home-badge', '.home-create-btn', '.home-hero-camp'];
const DRAG_THRESHOLD = 5;
const MAX_STRETCH = 0.3;

function _shouldReduceMotion() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch (e) {
    return false;
  }
}

function _loadGSAP() {
  return new Promise((resolve) => {
    try {
      if (typeof window.gsap !== 'undefined') { resolve(window.gsap); return; }
      const script = document.createElement('script');
      script.src = GSAP_CDN_URL;
      script.async = true;
      let settled = false;
      const timer = setTimeout(() => { if (!settled) { settled = true; resolve(null); } }, GSAP_LOAD_TIMEOUT);
      script.onload = () => { if (!settled) { settled = true; clearTimeout(timer); resolve(window.gsap || null); } };
      script.onerror = () => { if (!settled) { settled = true; clearTimeout(timer); resolve(null); } };
      document.head.appendChild(script);
    } catch (e) { resolve(null); }
  });
}

function _getPoint(e) {
  if (e.touches && e.touches.length > 0) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
  if (e.changedTouches && e.changedTouches.length > 0) return { x: e.changedTouches[0].clientX, y: e.changedTouches[0].clientY };
  return { x: e.clientX, y: e.clientY };
}

function _bindElement(gsap, el) {
  let dragging = false;
  let startX = 0, startY = 0;
  let lastX = 0, lastY = 0;
  let lastTime = 0;
  let movedDistance = 0;
  let originalZIndex = '';

  const onDown = (e) => {
    const point = _getPoint(e);
    dragging = true;
    startX = point.x;
    startY = point.y;
    lastX = point.x;
    lastY = point.y;
    lastTime = Date.now();
    movedDistance = 0;
    originalZIndex = el.style.zIndex;
    el.style.zIndex = '99999';
    gsap.killTweensOf(el);
  };

  const onMove = (e) => {
    if (!dragging) return;
    const point = _getPoint(e);
    const dx = point.x - startX;
    const dy = point.y - startY;
    movedDistance = Math.sqrt(dx * dx + dy * dy);

    if (movedDistance > DRAG_THRESHOLD) {
      e.preventDefault();
      const now = Date.now();
      const dt = Math.max(1, now - lastTime);
      const vx = (point.x - lastX) / dt;
      const vy = (point.y - lastY) / dt;
      const stretchX = Math.min(MAX_STRETCH, Math.abs(vx) * 0.8);
      const stretchY = Math.min(MAX_STRETCH, Math.abs(vy) * 0.8);
      const scaleX = 1 + stretchX - stretchY * 0.5;
      const scaleY = 1 + stretchY - stretchX * 0.5;
      gsap.to(el, { scaleX, scaleY, x: dx, y: dy, duration: 0.1, ease: 'power2.out' });
      lastX = point.x;
      lastY = point.y;
      lastTime = now;
    }
  };

  const onUp = (e) => {
    if (!dragging) return;
    dragging = false;
    el.style.zIndex = originalZIndex;

    if (movedDistance > DRAG_THRESHOLD) {
      const blockClick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        el.removeEventListener('click', blockClick, true);
      };
      el.addEventListener('click', blockClick, true);
    }

    gsap.to(el, {
      scaleX: 1, scaleY: 1, x: 0, y: 0,
      duration: 1.2, ease: 'elastic.out(1, 0.3)'
    });
  };

  el.addEventListener('mousedown', onDown);
  el.addEventListener('touchstart', onDown, { passive: true });
  document.addEventListener('mousemove', onMove);
  document.addEventListener('touchmove', onMove, { passive: false });
  document.addEventListener('mouseup', onUp);
  document.addEventListener('touchend', onUp);
}

export const jellyInteraction = {
  async play() {
    try {
      if (_shouldReduceMotion()) return;
      const gsap = window.gsap || await _loadGSAP();
      if (!gsap) return;

      const bindAll = () => {
        for (const selector of SELECTORS) {
          document.querySelectorAll(selector).forEach(el => {
            if (!el._jellyBound) {
              _bindElement(gsap, el);
              el._jellyBound = true;
            }
          });
        }
      };

      bindAll();
      window.addEventListener('hashchange', bindAll);
    } catch (e) {}
  }
};