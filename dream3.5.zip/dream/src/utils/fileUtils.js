export const fileUtils = {
  downloadJson(filename, obj) {
    try {
      const jsonStr = JSON.stringify(obj, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return { success: true };
    } catch (e) {
      return { success: false, error: '导出失败，数据异常' };
    }
  },

  pickJsonFile() {
    return new Promise((resolve, reject) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/json,.json';
      input.style.display = 'none';
      document.body.appendChild(input);

      let settled = false;

      const cleanup = () => {
        if (input.parentNode) document.body.removeChild(input);
      };

      input.addEventListener('change', () => {
        if (settled) return;
        if (input.files.length === 0) {
          settled = true;
          cleanup();
          reject({ canceled: true });
          return;
        }
        const file = input.files[0];
        const reader = new FileReader();
        reader.onload = () => {
          if (settled) return;
          try {
            const parsed = JSON.parse(reader.result);
            settled = true;
            cleanup();
            resolve({ parsed, filename: file.name });
          } catch (e) {
            settled = true;
            cleanup();
            reject({ parseError: true });
          }
        };
        reader.onerror = () => {
          if (settled) return;
          settled = true;
          cleanup();
          reject({ parseError: true });
        };
        reader.readAsText(file);
      });

      window.addEventListener('focus', function onFocus() {
        window.removeEventListener('focus', onFocus);
        setTimeout(() => {
          if (!settled && input.files.length === 0) {
            settled = true;
            cleanup();
            reject({ canceled: true });
          }
        }, 300);
      });

      input.click();
    });
  }
};