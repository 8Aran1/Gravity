const GSAP_CDN_URL = 'https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js';
const SCROLLTRIGGER_CDN_URL = 'https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/ScrollTrigger.min.js';
const GSAP_LOAD_TIMEOUT = 3000;
const ST_LOAD_TIMEOUT = 3000;
const SPLASH_WAIT_TIMEOUT = 5000;
const TIMING = { heroFloat: 1.0, fade: 0.8, slide: 0.9, count: 1.2, stagger: 0.12, cardDelay: 0.08 };
const TRIGGER_START = 'top 85%';

const SELECTORS = {
  heroTitle: 'h1.home-hero-title',
  heroSlogan: '.home-hero-slogan',
  heroCamp: 'button.home-hero-camp',
  statValue: '.home-stat-value',
  motivation: '.home-motivation',
  badges: '.home-badge',
  goalCard: '.goal-card',
  createBtn: 'button.home-create-btn',
  settingsEntry: 'button.home-settings-entry',
  identityBar: '.home-identity-bar'
};

let _hashchangeHandler = null;

function _isHomePage() {
  return (window.location.hash || '#/') === '#/';
}

function _shouldReduceMotion() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch (e) {
    return false;
  }
}

function _loadGSAP() {
  return new Promise((resolve) => {
    try {
      if (typeof window.gsap !== 'undefined') {
        resolve(window.gsap);
        return;
      }
      const script = document.createElement('script');
      script.src = GSAP_CDN_URL;
      script.async = true;
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) { settled = true; resolve(null); }
      }, GSAP_LOAD_TIMEOUT);
      script.onload = () => {
        if (!settled) { settled = true; clearTimeout(timer); resolve(window.gsap || null); }
      };
      script.onerror = () => {
        if (!settled) { settled = true; clearTimeout(timer); resolve(null); }
      };
      document.head.appendChild(script);
    } catch (e) {
      resolve(null);
    }
  });
}

function _ensureScrollTrigger(gsap) {
  return new Promise((resolve) => {
    try {
      if (gsap.ScrollTrigger) {
        resolve(gsap.ScrollTrigger);
        return;
      }
      const script = document.createElement('script');
      script.src = SCROLLTRIGGER_CDN_URL;
      script.async = true;
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) { settled = true; resolve(null); }
      }, ST_LOAD_TIMEOUT);
      script.onload = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          try {
            if (window.ScrollTrigger) {
              gsap.registerPlugin(window.ScrollTrigger);
              resolve(gsap.ScrollTrigger || window.ScrollTrigger);
            } else {
              resolve(null);
            }
          } catch (e) {
            resolve(null);
          }
        }
      };
      script.onerror = () => {
        if (!settled) { settled = true; clearTimeout(timer); resolve(null); }
      };
      document.head.appendChild(script);
    } catch (e) {
      resolve(null);
    }
  });
}

function _waitForSplashDone() {
  return new Promise((resolve) => {
    try {
      const app = document.getElementById('app');
      if (!app || app.style.opacity !== '0') {
        resolve();
        return;
      }
      let observer = null;
      let timer = null;
      const cleanup = () => {
        if (observer) observer.disconnect();
        if (timer) clearTimeout(timer);
      };
      observer = new MutationObserver(() => {
        if (app.style.opacity !== '0') {
          cleanup();
          resolve();
        }
      });
      observer.observe(app, { attributes: true, attributeFilter: ['style'] });
      timer = setTimeout(() => {
        cleanup();
        resolve();
      }, SPLASH_WAIT_TIMEOUT);
    } catch (e) {
      resolve();
    }
  });
}

function _teardown() {
  try {
    if (window.gsap && window.gsap.ScrollTrigger) {
      window.gsap.ScrollTrigger.getAll().forEach(t => t.kill());
    }
  } catch (e) {}
  try {
    if (_hashchangeHandler) {
      window.removeEventListener('hashchange', _hashchangeHandler);
      _hashchangeHandler = null;
    }
  } catch (e) {}
}

function _setupHeroFloat(gsap) {
  const target = document.querySelector(SELECTORS.heroTitle);
  if (!target) return;
  gsap.from(target, {
    y: 30,
    opacity: 0,
    duration: TIMING.heroFloat,
    ease: 'power2.out',
    scrollTrigger: {
      trigger: target,
      start: TRIGGER_START,
      once: true
    }
  });
}

function _setupFadeIn(gsap, selector) {
  const targets = document.querySelectorAll(selector);
  if (!targets || targets.length === 0) return;
  gsap.from(targets, {
    opacity: 0,
    duration: TIMING.fade,
    ease: 'power2.out',
    stagger: TIMING.stagger,
    scrollTrigger: {
      trigger: targets[0],
      start: TRIGGER_START,
      once: true
    }
  });
}

function _setupCardSlide(gsap) {
  const cards = document.querySelectorAll(SELECTORS.goalCard);
  if (!cards || cards.length === 0) return;
  gsap.from(cards, {
    x: (i) => i % 2 === 0 ? -60 : 60,
    opacity: 0,
    duration: TIMING.slide,
    ease: 'power2.out',
    stagger: TIMING.cardDelay,
    scrollTrigger: {
      trigger: cards[0],
      start: TRIGGER_START,
      once: true
    }
  });
}

function _setupNumberCount(gsap) {
  const els = document.querySelectorAll(SELECTORS.statValue);
  if (!els || els.length === 0) return;
  els.forEach(el => {
    try {
      let textNode = null;
      for (const node of el.childNodes) {
        if (node.nodeType === 3) {
          textNode = node;
          break;
        }
      }
      if (!textNode) return;
      const text = textNode.textContent;
      const match = text.match(/^([^\d]*)(\d+(?:\.\d+)?)(.*)$/);
      if (!match) return;
      const prefix = match[1];
      const targetValue = parseFloat(match[2]);
      const suffix = match[3];
      const decimalPlaces = match[2].includes('.') ? match[2].split('.')[1].length : 0;
      const proxy = { val: 0 };
      gsap.to(proxy, {
        val: targetValue,
        duration: TIMING.count,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: el,
          start: TRIGGER_START,
          once: true
        },
        onUpdate: () => {
          const current = decimalPlaces > 0 ? proxy.val.toFixed(decimalPlaces) : Math.round(proxy.val);
          textNode.textContent = prefix + current + suffix;
        }
      });
    } catch (e) {}
  });
}

export const scrollAnimation = {
  async play() {
    try {
      if (!_isHomePage()) return;
      if (_shouldReduceMotion()) return;
      let gsap = window.gsap;
      if (!gsap) {
        gsap = await _loadGSAP();
      }
      if (!gsap) return;
      const st = await _ensureScrollTrigger(gsap);
      if (!st) return;
      await _waitForSplashDone();
      if (!_isHomePage()) return;
      _setupHeroFloat(gsap);
      _setupFadeIn(gsap, SELECTORS.identityBar);
      _setupFadeIn(gsap, SELECTORS.heroSlogan);
      _setupFadeIn(gsap, SELECTORS.heroCamp);
      _setupFadeIn(gsap, SELECTORS.motivation);
      _setupFadeIn(gsap, SELECTORS.badges);
      _setupFadeIn(gsap, SELECTORS.createBtn);
      _setupFadeIn(gsap, SELECTORS.settingsEntry);
      _setupCardSlide(gsap);
      _setupNumberCount(gsap);
      _hashchangeHandler = () => {
        if (!_isHomePage()) _teardown();
      };
      window.addEventListener('hashchange', _hashchangeHandler);
    } catch (e) {}
  }
};