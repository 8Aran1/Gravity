export function today() {
  return format(new Date());
}

export function format(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function isBeforeToday(dateStr) {
  return dateStr <= today();
}

export function daysBetween(dateStr1, dateStr2) {
  const d1 = new Date(dateStr1);
  const d2 = new Date(dateStr2);
  const diff = d2 - d1;
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}