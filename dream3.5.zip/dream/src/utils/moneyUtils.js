export function toFen(yuan) {
  return Math.round(yuan * 100);
}

export function toYuan(fen) {
  return (fen / 100).toFixed(2);
}

export function add(aFen, bFen) {
  return aFen + bFen;
}

export function sub(aFen, bFen) {
  return aFen - bFen;
}