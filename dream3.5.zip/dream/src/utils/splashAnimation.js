const GSAP_CDN_URL = 'https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js';
const GSAP_LOAD_TIMEOUT = 3000;
const PARTICLE_COUNT = 1000;
const TIMING = { gather: 1.2, hold: 0.5, scatter: 1.8 };
const PARTICLE_COLORS = ['#00E5FF', '#4D7FFF', '#B388FF'];

function _shouldReduceMotion() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch (e) {
    return false;
  }
}

function _showApp() {
  try {
    const app = document.getElementById('app');
    if (app) app.style.opacity = '1';
  } catch (e) {}
}

function _loadGSAP() {
  return new Promise((resolve) => {
    try {
      if (typeof window.gsap !== 'undefined') {
        resolve(window.gsap);
        return;
      }
      const script = document.createElement('script');
      script.src = GSAP_CDN_URL;
      script.async = true;
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) { settled = true; resolve(null); }
      }, GSAP_LOAD_TIMEOUT);
      script.onload = () => {
        if (!settled) { settled = true; clearTimeout(timer); resolve(window.gsap || null); }
      };
      script.onerror = () => {
        if (!settled) { settled = true; clearTimeout(timer); resolve(null); }
      };
      document.head.appendChild(script);
    } catch (e) {
      resolve(null);
    }
  });
}

function _sampleTextTargets(text, width, height) {
  try {
    const off = document.createElement('canvas');
    off.width = width;
    off.height = height;
    const ctx = off.getContext('2d');
    if (!ctx) return [];

    let fontSize = Math.min(width * 0.12, 80);
    ctx.font = 'bold ' + fontSize + 'px sans-serif';
    let textWidth = ctx.measureText(text).width;
    if (textWidth > width * 0.85) {
      fontSize = Math.floor(fontSize * (width * 0.85 / textWidth));
      ctx.font = 'bold ' + fontSize + 'px sans-serif';
    }
    if (fontSize * 1.3 > height * 0.8) {
      fontSize = Math.floor(height * 0.8 / 1.3);
      ctx.font = 'bold ' + fontSize + 'px sans-serif';
    }
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, width / 2, height / 2);

    const data = ctx.getImageData(0, 0, width, height).data;
    const candidates = [];
    for (let y = 0; y < height; y += 2) {
      for (let x = 0; x < width; x += 2) {
        if (data[(y * width + x) * 4 + 3] > 128) {
          candidates.push({ x: x, y: y });
        }
      }
    }
    if (candidates.length === 0) return [];

    for (let i = candidates.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = candidates[i];
      candidates[i] = candidates[j];
      candidates[j] = tmp;
    }

    const targets = [];
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      targets.push(candidates[i % candidates.length]);
    }
    return targets;
  } catch (e) {
    return [];
  }
}

function _createParticles(width, height, targets) {
  const particles = [];
  const count = targets.length > 0 ? Math.min(PARTICLE_COUNT, targets.length) : PARTICLE_COUNT;

  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = Math.max(width, height) * 0.7;
    const startX = width / 2 + Math.cos(angle) * dist;
    const startY = height / 2 + Math.sin(angle) * dist;
    const target = targets.length > 0 ? targets[i] : {
      x: width / 2 + (Math.random() - 0.5) * 200,
      y: height / 2 + (Math.random() - 0.5) * 100
    };
    particles.push({
      x: startX, y: startY,
      targetX: target.x, targetY: target.y,
      scatterX: width / 2 + Math.cos(angle) * dist * 1.5,
      scatterY: height / 2 + Math.sin(angle) * dist * 1.5,
      size: 1 + Math.random() * 2,
      color: PARTICLE_COLORS[Math.floor(Math.random() * PARTICLE_COLORS.length)],
      alpha: 0
    });
  }
  return particles;
}

function _createCanvas(width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  canvas.style.cssText = 'position:fixed;inset:0;z-index:9999;pointer-events:none;';
  document.body.appendChild(canvas);
  return canvas;
}

function _drawParticles(ctx, particles) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.shadowBlur = 10;
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i];
    if (p.alpha <= 0) continue;
    ctx.globalAlpha = p.alpha;
    ctx.fillStyle = p.color;
    ctx.shadowColor = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
}

export const splashAnimation = {
  play(options) {
    return new Promise((resolve) => {
      try {
        if (_shouldReduceMotion()) { _showApp(); resolve(); return; }

        const width = window.innerWidth;
        const height = window.innerHeight;
        const app = document.getElementById('app');
        if (app) {
          app.style.opacity = '0';
          app.style.transition = 'opacity 0.4s ease';
        }

        _loadGSAP().then((gsap) => {
          if (!gsap) { _showApp(); resolve(); return; }

          const testCtx = document.createElement('canvas').getContext('2d');
          if (!testCtx) { _showApp(); resolve(); return; }

          const targets = _sampleTextTargets('引力 Gravity', width, height);
          const particles = _createParticles(width, height, targets);
          const canvas = _createCanvas(width, height);
          const ctx = canvas.getContext('2d');
          if (!ctx) { _showApp(); resolve(); return; }

          const tl = gsap.timeline({
            onComplete: () => {
              try {
                if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
              } catch (e) {}
              _showApp();
              resolve();
            }
          });

          tl.to(particles, { alpha: 1, duration: 0.3, ease: 'power1.in' });
          tl.to(particles, {
            x: function (i, p) { return p.targetX; },
            y: function (i, p) { return p.targetY; },
            duration: TIMING.gather, ease: 'power2.inOut',
            onUpdate: function () { _drawParticles(ctx, particles); }
          }, '-=0.2');
          tl.to({}, {
            duration: TIMING.hold,
            onUpdate: function () { _drawParticles(ctx, particles); }
          });
          tl.to(particles, {
            x: function (i, p) { return p.scatterX; },
            y: function (i, p) { return p.scatterY; },
            alpha: 0, duration: TIMING.scatter, ease: 'power3.out',
            onUpdate: function () { _drawParticles(ctx, particles); }
          });
        });
      } catch (e) {
        _showApp();
        resolve();
      }
    });
  }
};