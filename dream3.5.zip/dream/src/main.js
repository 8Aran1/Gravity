import { localStorageAdapter } from './storage/localStorageAdapter.js';
import { homeView } from './views/homeView.js';
import { goalDetailView } from './views/goalDetailView.js';
import { goalFormView } from './views/goalFormView.js';
import { withdrawView } from './views/withdrawView.js';
import { campListView } from './views/campListView.js';
import { campFormView } from './views/campFormView.js';
import { campJoinView } from './views/campJoinView.js';
import { campDetailView } from './views/campDetailView.js';
import { advisorView } from './views/advisorView.js';
import { settingsView } from './views/settingsView.js';
import { profileView } from './views/profileView.js';
import { onboardingTutorial } from './views/onboardingTutorial.js';
import { splashAnimation } from './utils/splashAnimation.js';
import { scrollAnimation } from './utils/scrollAnimation.js';
import { jellyInteraction } from './utils/jellyInteraction.js';
import { themeService } from './services/themeService.js';
import { achievementService } from './services/achievementService.js';
import { knowledgeListView } from './views/knowledgeListView.js';
import { knowledgeDetailView } from './views/knowledgeDetailView.js';

function router() {
  const hash = window.location.hash || '#/';
  try {
    if (hash === '#/') {
      homeView.render();
    } else if (hash === '#/camps') {
      campListView.render();
    } else if (hash === '#/camp/new') {
      campFormView.render();
    } else if (hash === '#/camp/join') {
      campJoinView.render();
    } else if (hash === '#/settings') {
      settingsView.render();
    } else if (hash === '#/profile') {
      profileView.render();
    } else if (hash === '#/goal/new') {
      goalFormView.renderCreate();
    } else if (hash === '#/knowledge') {
      knowledgeListView.render();
    } else {
      const knowledgeDetailMatch = hash.match(/^#\/knowledge\/([^/]+)$/);
      const campMatch = hash.match(/^#\/camp\/([^/]+)$/);
      const withdrawMatch = hash.match(/^#\/goal\/([^/]+)\/withdraw$/);
      const editMatch = hash.match(/^#\/goal\/([^/]+)\/edit$/);
      const detailMatch = hash.match(/^#\/goal\/([^/]+)$/);

      if (knowledgeDetailMatch) {
        knowledgeDetailView.render(knowledgeDetailMatch[1]);
      } else if (campMatch) {
        campDetailView.render(campMatch[1]).catch(e => {
          console.error('camp详情渲染失败:', e);
          const app = document.getElementById('app');
          if (app && !app.innerHTML.trim()) {
            app.innerHTML = '<div class="page-container"><div class="empty-state"><p class="empty-text">页面加载出错</p><button class="btn btn-primary" onclick="location.hash=\'#/camps\'">返回引力场</button></div></div>';
          }
        });
      } else if (withdrawMatch) {
        withdrawView.render(withdrawMatch[1]);
      } else if (editMatch) {
        goalFormView.renderEdit(editMatch[1]);
      } else if (detailMatch) {
        goalDetailView.render(detailMatch[1]);
      } else {
        homeView.render();
      }
    }
  } catch (e) {
    console.error('路由渲染失败:', hash, e);
    const app = document.getElementById('app');
    if (app) app.innerHTML = '<div class="page-container"><div class="empty-state"><div class="empty-icon">⚠️</div><p class="empty-text">页面加载出错，请返回首页重试</p><button class="btn btn-primary" onclick="location.hash=\'#/\'">返回首页</button></div></div>';
  }
}

async function init() {
  try {
    await localStorageAdapter.initData();
    achievementService.checkAndUnlock();
  } catch (e) {
    console.error('初始化失败:', e);
    await localStorageAdapter.initData();
  }
  themeService.applySavedTheme();
  advisorView.mount();
  router();
  window.addEventListener('hashchange', router);
  try { await splashAnimation.play(); } catch (e) {}
  try { onboardingTutorial.start(); } catch (e) {}
  try { scrollAnimation.play(); } catch (e) {}
  try { jellyInteraction.play(); } catch (e) {}
}

init();