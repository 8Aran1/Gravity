# 公益赎回与柔性提醒 — 编码任务列表

> 特性：charity_redemption
> 项目：引力 · Gravity
> 技术栈：vanilla JS + ES Module + localStorage + 传统 CSS（毛玻璃拟态）
> 约束：不改 main.js 路由 / index.html 骨架 / localStorage 顶层结构；不破坏既有功能；不白屏；camelCase 命名

---

## 1. 常量与 charityService 基础搭建

### 1.1 新建 charityService 文件骨架
- [ ] 新建文件 `src/services/charityService.js`，使用 ES Module `export const charityService = {}` 形式，与既有 habitService/achievementService 风格一致
- [ ] 在文件顶部集中定义常量：`STEPS_RANGE = { min: 5000, max: 10000, fallback: 8000 }`、`CHARITY_BADGE = { badgeId: 'charity_guardian', name: '公益守护者', unlockCondition: '完成一次公益赎回' }`、`ANTI_FRAUD_QUESTIONS`（3-5 道金融反诈单选题，每题含 stem/options[4]/answerIndex，含兜底题"以下哪种理财方式最安全？/高收益保本/银行存款/陌生人推荐/不明链接，answerIndex=1"）、`FALLBACK_QUESTION` 兜底题常量
- [ ] 在文件顶部 import `localStorageAdapter`（from `'../storage/localStorageAdapter.js'`）、`idUtils`（from `'../utils/idUtils.js'`）、`dateUtils` 的 `today`/`format`/`daysBetween`（from `'../utils/dateUtils.js'`）
- [ ] 验收：文件存在且可被 `import` 不报错；常量未被外部修改；不依赖任何 DOM 对象

### 1.2 实现 generateSteps 模拟步数生成
- [ ] 在 `charityService` 上实现 `generateSteps()` 方法，返回 `{ steps: number, ok: boolean }`
- [ ] 逻辑：使用 `Math.random()` 生成 `STEPS_RANGE.min` 到 `STEPS_RANGE.max` 之间的整数（含端点），返回 `{ steps, ok: true }`
- [ ] 异常降级：用 try/catch 包裹，若 `Math.random` 不可用或返回异常值，返回 `{ steps: STEPS_RANGE.fallback, ok: true }` 并 `console.warn('generateSteps fallback')`
- [ ] 验收：连续调用 20 次返回值均在 [5000, 10000] 整数区间；不读取任何设备传感器；不产生任何 `fetch` 调用

### 1.3 实现 getAntiFraudQuestion 与 isAnswerCorrect
- [ ] 在 `charityService` 上实现 `getAntiFraudQuestion()`，返回 `{ stem, options, answerIndex }`
- [ ] 逻辑：从 `ANTI_FRAUD_QUESTIONS` 中随机取一题，返回其副本（深拷贝避免常量被改）
- [ ] 异常降级：try/catch 包裹，题库异常时返回 `FALLBACK_QUESTION`
- [ ] 在 `charityService` 上实现 `isAnswerCorrect(question, selectedIndex)`，返回 `{ correct: boolean }`
- [ ] 逻辑：比对 `selectedIndex === question.answerIndex`；question 异常或 selectedIndex 非 0-3 整数时返回 `{ correct: false }`
- [ ] 验收：`getAntiFraudQuestion()` 返回的 `options.length === 4`；`answerIndex` 为 0-3 整数；`isAnswerCorrect` 对正确索引返回 `correct: true`，错误索引返回 `correct: false`

### 1.4 实现 markHintClosed 与 isHintClosedToday
- [ ] 在 `charityService` 上实现 `markHintClosed()` 与 `isHintClosedToday()`，使用 `sessionStorage`
- [ ] 键名格式：`charity_hint_closed_<YYYY-MM-DD>`，值为 `'1'`，日期由 `dateUtils.today()` 生成
- [ ] `markHintClosed()`：try/catch 包裹 `sessionStorage.setItem`，异常静默降级
- [ ] `isHintClosedToday()`：try/catch 包裹 `sessionStorage.getItem`，异常或不可用时返回 `false`
- [ ] 验收：调用 `markHintClosed()` 后 `isHintClosedToday()` 返回 `true`；次日（手动改系统日期或键名日期不同）返回 `false`；sessionStorage 被禁用时不抛错

---

## 2. 漏签检测与柔性提示卡片

### 2.1 实现 charityService.detectYesterdayMiss
- [ ] 在 `src/services/charityService.js` 的 `charityService` 对象上实现 `detectYesterdayMiss()`，返回 `{ missed: boolean, goalId: string|null, yesterday: string|null }`
- [ ] 逻辑：读取 `data = localStorageAdapter.getData()`；计算 `yesterday = dateUtils.format(new Date(Date.now() - 86400000))`（YYYY-MM-DD）；从 `data.goals` 中筛选 `status === '进行中'` 的目标；对每个目标检查 `data.checkIns` 中是否存在 `checkInDate === yesterday && goalId === 目标.id` 的记录；返回首个漏签目标的 `{ missed: true, goalId, yesterday }`
- [ ] 异常降级：`data.checkIns` 缺失或非数组时按 `[]` 处理；`data.goals` 异常时返回 `{ missed: false, goalId: null, yesterday: null }`；无进行中目标时返回 `missed: false`
- [ ] 全方法 try/catch 包裹，异常时返回 `{ missed: false, goalId: null, yesterday: null }`
- [ ] 验收：有进行中目标且昨日无 checkIns 记录时返回 `missed: true` 与有效 goalId；昨日已打卡时返回 `missed: false`；无进行中目标时返回 `missed: false`；checkIns 为 undefined 时不抛错

### 2.2 新建 charityView 文件骨架与 renderHintCard
- [ ] 新建文件 `src/views/charityView.js`，使用 ES Module `export const charityView = {}` 形式
- [ ] 在文件顶部定义 `HINT_COPY` 文案常量对象，含 `title`（如"昨天没坚持住，没关系"）、`body`（如"来做点好事，把陪伴补回来吧"）、`cta`（如"来做点好事修复吧"）、`closeAria`（如"关闭提示"）；并定义 `FORBIDDEN_WORDS = ['惩罚', '断签', '失败', '扣款', '警告']` 常量用于自检（运行时不动态拼接文案）
- [ ] 在文件顶部 import `charityService`（from `'../services/charityService.js'`）、`modal` 的 `toast`（from `'./modal.js'`）
- [ ] 实现 `renderHintCard(container, onOpenModal)`：调用 `charityService.detectYesterdayMiss()`；若 `missed === false` 或 `charityService.isHintClosedToday() === true` 返回 `null`；否则构造 `.charity-hint-card` DOM（含标题、正文、"来做点好事修复吧"按钮、右上角关闭按钮），绑定按钮 click → `onOpenModal(goalId)`，关闭按钮 click → `charityService.markHintClosed()` 后移除卡片
- [ ] 全方法 try/catch 包裹，异常返回 `null`
- [ ] 验收：漏签且未关闭时返回含 `.charity-hint-card` 的 HTMLElement；未漏签或已关闭时返回 `null`；点击 CTA 触发 `onOpenModal` 回调；点击关闭后当日再调用返回 `null`；文案中不含 `FORBIDDEN_WORDS` 任一词汇

### 2.3 homeView 接入柔性提示卡片
- [ ] 修改文件 `src/views/homeView.js`：在文件顶部 import 区追加 `import { charityView } from './charityView.js';` 与 `import { charityService } from '../services/charityService.js';`
- [ ] 在 `render()` 方法中，于 `page.appendChild(this._renderMotivation(streak, motivation));`（第 27 行）之后、`page.appendChild(this._renderBadges());`（第 28 行）之前，插入 `page.appendChild(this._renderCharityHint());`
- [ ] 在 `homeView` 对象上新增私有方法 `_renderCharityHint()`：try 块内创建容器 `const wrapper = document.createElement('div');`，调用 `charityView.renderHintCard(wrapper, (goalId) => charityView.openRedemptionModal(goalId))`，若返回非 null 则 `wrapper.appendChild(card)`，返回 `wrapper`；catch 块返回 `document.createElement('span')`（空 span，保证不白屏）
- [ ] 不得修改 `_renderMotivation`、`_renderBadges`、`_renderGoalsSection` 等既有方法的任何代码
- [ ] 验收：首页渲染后，漏签用户在 motivation 区块下方、徽章墙上方可见柔性提示卡片；未漏签用户无卡片且页面布局不变；homeView 异常时返回空 span 不影响其他模块渲染

---

## 3. 公益赎回弹窗与任务面板

### 3.1 实现 charityView.openRedemptionModal 弹窗骨架
- [ ] 在 `src/views/charityView.js` 的 `charityView` 对象上实现 `openRedemptionModal(goalId)` 方法
- [ ] 逻辑：创建 `.charity-modal-overlay` 与 `.charity-modal-dialog` DOM 节点，dialog 内初始渲染任务选择面板（含标题"做点好事，修复昨天"与两个并列任务入口按钮"捐赠步数"、"反诈答题"，按钮类名 `.charity-task-entry`）
- [ ] 绑定"捐赠步数"click → 调用 `this._renderStepsPanel(dialog, goalId)`；绑定"反诈答题"click → 调用 `this._renderQuizPanel(dialog, goalId)`；绑定 overlay click（仅点击 overlay 自身非 dialog 内）→ `this._closeModal(overlay)`
- [ ] `document.body.appendChild(overlay)`；overlay 上挂载 `_charityGoalId = goalId` 便于调试
- [ ] 全方法 try/catch 包裹，异常时调用 `modal.toast('稍后再试')` 并清理半创建 DOM
- [ ] 验收：调用后 `document.body` 下出现 `.charity-modal-overlay` 子节点；弹窗内可见两个任务入口按钮；点击遮罩空白处弹窗关闭；异常时不白屏、不残留半创建 DOM

### 3.2 实现 _renderStepsPanel 捐步数面板
- [ ] 在 `charityView` 对象上实现 `_renderStepsPanel(dialog, goalId)`（以 `_` 前缀标记私有）
- [ ] 逻辑：清空 dialog 内容，渲染"模拟捐步数"标题、"生成步数"按钮（类名 `.charity-steps-trigger`）；绑定按钮 click → 调用 `charityService.generateSteps()`，展示步数（类名 `.charity-steps-display`，大字号）与"正在修复…"提示 → 调用 `charityService.repairYesterdayCheckIn(goalId)` → 若 `success` 调用 `charityService.unlockGuardianBadge()` 并 `this._renderSuccessPanel(dialog, badge)`；若 `repair` 失败调用 `modal.toast(message)` 并保持面板可重试
- [ ] 步数生成后禁用按钮 1 秒防止重复点击（按钮 disabled=true，1 秒后恢复）
- [ ] 全方法 try/catch 包裹，异常时 `modal.toast('稍后再试')`
- [ ] 验收：点击"生成步数"后 16ms 内展示 5000-10000 整数步数；修复成功后切换到成功结果页；修复失败时 toast 温柔提示且面板可重试；不出现 `fetch` 调用

### 3.3 实现 _renderQuizPanel 反诈答题面板
- [ ] 在 `charityView` 对象上实现 `_renderQuizPanel(dialog, goalId)`
- [ ] 逻辑：清空 dialog 内容，调用 `charityService.getAntiFraudQuestion()` 获取题目；渲染题干（`.charity-quiz-stem`）与 4 个选项按钮（`.charity-quiz-option`，按 index 顺序排列）；绑定每个选项 click → 调用 `charityService.isAnswerCorrect(question, index)`
- [ ] 答对：选项添加 `.charity-quiz-option--correct` 样式，1 秒后调用 `charityService.repairYesterdayCheckIn(goalId)` → 成功则 `charityService.unlockGuardianBadge()` 并 `this._renderSuccessPanel(dialog, badge)`
- [ ] 答错：选项添加 `.charity-quiz-option--wrong` 样式，`modal.toast('再想想看，答对即可修复')`，1 秒后移除错误样式允许重答
- [ ] 全方法 try/catch 包裹，异常时 `modal.toast('稍后再试')`
- [ ] 验收：面板展示 1 道题干与 4 个选项；答对进入修复流程；答错可重答且不进入修复流程；题库异常时仍展示兜底题可正常作答

### 3.4 实现 _closeModal 弹窗关闭
- [ ] 在 `charityView` 对象上实现 `_closeModal(overlay)`
- [ ] 逻辑：`overlay.remove()` 移除 DOM；解绑所有事件（通过移除节点自动解绑）
- [ ] 全方法 try/catch 包裹，异常静默
- [ ] 验收：调用后 `document.body` 下不再有对应 `.charity-modal-overlay`；多次调用不抛错

---

## 4. 打卡记录修复与公益徽章解锁

### 4.1 实现 charityService.repairYesterdayCheckIn
- [ ] 在 `src/services/charityService.js` 的 `charityService` 对象上实现 `repairYesterdayCheckIn(goalId)`，返回 `{ success: boolean, message: string, alreadyRepaired: boolean }`
- [ ] 逻辑：读取 `data = localStorageAdapter.getData()`；校验 `data.goals.find(g => g.id === goalId && g.status === '进行中')` 存在，否则返回 `{ success: false, message: '这个梦想已启程远行，无需修复啦', alreadyRepaired: false }`
- [ ] 计算 `yesterday = dateUtils.format(new Date(Date.now() - 86400000))`；查找 `data.checkIns` 中 `checkInDate === yesterday && goalId === goalId` 的记录；已存在则返回 `{ success: true, message: '昨日已修复，感谢你的善意', alreadyRepaired: true }`
- [ ] 不存在则备份 `backupLen = data.checkIns.length`，构造 `newCheckIn = { id: idUtils.generate(), goalId, checkInDate: yesterday, checkInTime: Date.now() }`，`data.checkIns.push(newCheckIn)`，调用 `localStorageAdapter.saveData(data)`
- [ ] saveData 成功返回 `{ success: true, message: '修复成功', alreadyRepaired: false }`；失败时回滚 `data.checkIns.length = backupLen` 并返回 `{ success: false, message: '存储空间不足，清理后稍后再试', alreadyRepaired: false }`
- [ ] 全方法 try/catch 包裹，异常返回 `{ success: false, message: '稍后再试', alreadyRepaired: false }`
- [ ] 验收：成功写入后 `data.checkIns` 新增一条符合 `{ id, goalId, checkInDate: 昨日, checkInTime }` 形状的记录；重复调用同一 goalId 第二次返回 `alreadyRepaired: true` 且不新增记录；目标不存在或不进行中时返回 `success: false`；saveData 失败时 `checkIns.length` 不变

### 4.2 实现 charityService.unlockGuardianBadge
- [ ] 在 `charityService` 对象上实现 `unlockGuardianBadge()`，返回 `{ success: boolean, newlyUnlocked: boolean, badge: object|null }`
- [ ] 逻辑：读取 `data = localStorageAdapter.getData()`；若 `data.achievements` 缺失或非数组则初始化为 `[]`
- [ ] 查找 `existing = data.achievements.find(a => a.badgeId === 'charity_guardian')`；不存在则构造 `{ ...CHARITY_BADGE, unlocked: true, unlockedDate: dateUtils.today() }` push 进数组，saveData，返回 `{ success: true, newlyUnlocked: true, badge }`
- [ ] 存在且 `existing.unlocked === true` 则返回 `{ success: true, newlyUnlocked: false, badge: existing }`（幂等）
- [ ] 存在但 `unlocked !== true`：补全缺失字段（badgeId/name/unlockCondition 缺失则填 `CHARITY_BADGE` 默认值），置 `existing.unlocked = true`，`existing.unlockedDate = existing.unlockedDate || dateUtils.today()`，saveData，返回 `{ success: true, newlyUnlocked: true, badge: existing }`
- [ ] saveData 失败返回 `{ success: false, newlyUnlocked: false, badge: null }`
- [ ] 全方法 try/catch 包裹，异常返回 `{ success: false, newlyUnlocked: false, badge: null }`
- [ ] 验收：首次调用后 `data.achievements` 含一条 `badgeId='charity_guardian' && unlocked===true` 记录；第二次调用返回 `newlyUnlocked: false` 且不新增、不覆盖 `unlockedDate`；既有三枚徽章（streak_7/streak_30/first_goal_done）记录不被修改

### 4.3 扩展 achievementService.getAll 合并公益徽章
- [ ] 修改文件 `src/services/achievementService.js` 的 `getAll()` 方法（第 7-24 行）
- [ ] 在 `return ACHIEVEMENTS.map(...)` 之后、`return` 之前，追加合并逻辑：读取 `data.achievements` 中 `badgeId === 'charity_guardian'` 的记录；若存在且 `unlocked === true`，将其加入返回数组末尾（形状 `{ badgeId, name, unlockCondition, unlocked: true, unlockedDate }`）
- [ ] 不得修改 `ACHIEVEMENTS.map` 内部对既有三枚徽章的判定逻辑；不得修改 `checkAndUnlock` 方法
- [ ] 验收：未解锁公益徽章时 `getAll()` 返回数组与修改前完全一致；解锁后返回数组长度 +1 且末项为 `charity_guardian`；既有三枚徽章的 `unlocked`/`unlockedDate` 值不变

### 4.4 实现 charityView._renderSuccessPanel 修复成功结果页
- [ ] 在 `src/views/charityView.js` 的 `charityView` 对象上实现 `_renderSuccessPanel(dialog, badge)`
- [ ] 逻辑：清空 dialog 内容，渲染温柔文案（"昨天的陪伴已经补回来啦"）、徽章预览（类名 `.charity-success-badge`，含图标 💝 或 🌈、徽章名称"公益守护者"、解锁条件文案）、"返回"按钮与"查看徽章"按钮
- [ ] 绑定"返回"click → `this._closeModal(overlay)`（overlay 为 dialog.parentElement）；绑定"查看徽章"click → `this._closeModal(overlay)` 并 `modal.toast('徽章已收藏到徽章墙')`
- [ ] 全方法 try/catch 包裹，异常时 `modal.toast('修复成功')` 并关闭弹窗
- [ ] 验收：修复成功后弹窗切换为结果页，可见徽章预览与两个按钮；点击"返回"弹窗关闭；点击"查看徽章"弹窗关闭并 toast 提示；文案不含禁用词

### 4.5 徽章墙图标按 badgeId 映射
- [ ] 修改文件 `src/views/homeView.js` 的 `_renderBadges()` 方法（第 142-146 行）：将硬编码的 `<span class="home-badge-icon">🏆</span>` 改为按 `badge.badgeId` 映射图标，`charity_guardian → 💝`，其余保持 `🏆`
- [ ] 不得修改 `_renderBadges` 的过滤逻辑（`achievements.filter(a => a.unlocked)`）与其他 DOM 结构
- [ ] 验收：既有三枚徽章仍显示 🏆；公益守护者徽章显示 💝；未解锁徽章不显示

---

## 5. 样式与降级

### 5.1 main.css 追加柔性提示卡片样式
- [ ] 修改文件 `src/styles/main.css`：在文件末尾追加 `.charity-hint-card` 样式段（玻璃拟态：`background: rgba(255,255,255,0.08); backdrop-filter: blur(12px); border-radius: 16px; padding: 16px 20px; margin: 12px 0;`，含标题、正文、CTA 按钮样式）
- [ ] 追加 `.charity-hint-close` 关闭按钮样式（绝对定位右上角、半透明、hover 高亮）
- [ ] 追加 `.charity-hint-cta` 按钮样式（复用既有 `.btn` 视觉语言，温柔色调）
- [ ] 验收：柔性提示卡片在深色星空背景下可读、有玻璃拟态效果；不与既有 `.home-motivation`/`.home-badges` 样式冲突

### 5.2 main.css 追加公益赎回弹窗样式
- [ ] 在 `src/styles/main.css` 末尾追加 `.charity-modal-overlay`（fixed 全屏、`background: rgba(20,25,45,0.55); backdrop-filter: blur(8px); z-index: 1500;` 居中 flex）、`.charity-modal-dialog`（玻璃拟态卡片、max-width 420px、圆角 20px、padding 24px）
- [ ] 追加 `.charity-task-entry` 任务入口按钮样式（并列两按钮、玻璃拟态、hover 微动 transform: translateY(-2px)）
- [ ] 追加 `.charity-steps-display` 步数展示样式（大字号 48px、居中、仪式感淡入动画 @keyframes）
- [ ] 追加 `.charity-quiz-option` 答题选项样式（单选按钮、选中态、`.charity-quiz-option--correct` 绿色边框、`.charity-quiz-option--wrong` 红色边框）
- [ ] 追加 `.charity-success-badge` 徽章预览样式（居中、发光效果 box-shadow、徽章图标大字号）
- [ ] 验收：弹窗在深色背景下居中显示、玻璃拟态；两个任务入口并列；步数大字号展示；答题选项对错态色彩分明；徽章预览有发光效果

### 5.3 backdrop-filter 不支持时的降级
- [ ] 在 `src/styles/main.css` 末尾追加 `@supports not (backdrop-filter: blur(1px)) { ... }` 降级段
- [ ] 降级段内将 `.charity-modal-overlay` 的 `background` 改为 `rgba(20,25,45,0.85)`（纯色半透明）、`.charity-modal-dialog` 与 `.charity-hint-card` 的 `background` 改为 `rgba(30,35,55,0.9)`，移除 blur 依赖
- [ ] 验收：在不支持 backdrop-filter 的浏览器（如旧版 Edge）上弹窗与卡片仍可读、不白屏；支持 backdrop-filter 的浏览器降级段不生效

---

## 6. 集成验证与回归测试

### 6.1 漏签检测与柔性提示端到端验证
- [ ] 手动构造测试数据：localStorage `dream_saving_camp_data` 中存在 1 个进行中目标，`checkIns` 数组中无昨日记录
- [ ] 刷新首页，验证 motivation 区块下方出现柔性提示卡片，文案温柔无禁用词
- [ ] 点击"来做点好事修复吧"，验证公益赎回弹窗弹出且含两个任务入口
- [ ] 点击柔性提示关闭按钮，刷新首页，验证当日不再出现柔性提示卡片
- [ ] 构造对比数据：昨日已正常打卡，验证首页不出现柔性提示卡片
- [ ] 验收：4 个场景全部符合预期；首页渲染耗时无明显增加（< 50ms）

### 6.2 公益赎回任务流程端到端验证
- [ ] 捐步数路径：打开弹窗 → 点击"捐赠步数" → 点击"生成步数" → 验证展示 5000-10000 整数 → 验证切换到修复成功结果页 → 验证 `data.checkIns` 新增昨日记录 → 验证 `data.achievements` 含 `charity_guardian` 解锁记录
- [ ] 反诈答题路径：打开弹窗 → 点击"反诈答题" → 选择错误选项 → 验证温柔重答提示 → 选择正确选项 → 验证切换到修复成功结果页 → 验证 checkIns 与 achievements 写入
- [ ] 幂等验证：对同一目标第二次发起公益赎回并完成，验证 `checkIns` 不新增重复昨日记录、`achievements` 中 `charity_guardian` 的 `unlockedDate` 不被覆盖
- [ ] 验收：三条路径全部符合预期；全流程无 `fetch` 调用、无传感器读取、无真实金额字段

### 6.3 异常降级与不白屏验证
- [ ] 清空 localStorage 后刷新首页，验证不白屏、无柔性提示卡片、控制台无未捕获异常
- [ ] 手动破坏 `data.checkIns` 为 `undefined`，刷新首页，验证不白屏、柔性提示不出现
- [ ] 手动破坏 `data.achievements` 为 `undefined`，完成一次公益赎回，验证徽章正常解锁且不抛错
- [ ] 在公益赎回弹窗中点击选项时手动 throw 异常，验证 `modal.toast('稍后再试')` 触发且主页不白屏
- [ ] 验收：4 个异常场景全部降级处理，无白屏、无未捕获异常、主页其他模块正常可用

### 6.4 既有功能回归验证
- [ ] 验证粒子动画在首页正常播放
- [ ] 验证组队留言、引力场列表功能正常
- [ ] 验证储蓄打卡（今日 checkIn）正常工作
- [ ] 验证既有三枚徽章（streak_7/streak_30/first_goal_done）的解锁条件与展示不变
- [ ] 验证 main.js 路由表、index.html 骨架未被修改
- [ ] 验证 localStorage `dream_saving_camp_data` 顶层字段结构（goals/records/checkIns/camps/achievements/user）不变
- [ ] 验收：6 项既有功能全部正常；diff 范围仅限 `charityService.js`/`charityView.js` 新建 + `homeView.js`/`achievementService.js`/`main.css` 局部修改

### 6.5 性能与文案合规验证
- [ ] 验证漏签检测 + 柔性卡片渲染合耗时 < 50ms（Performance.now 包测）
- [ ] 验证弹窗从点击到可交互 < 100ms
- [ ] 验证步数生成 < 16ms
- [ ] 验证单次修复全流程（repair + unlock）< 80ms
- [ ] 全量审查 charityView 所有文案字符串，确认不含 `['惩罚', '断签', '失败', '扣款', '警告']` 任一词汇
- [ ] 验收：4 项性能指标达标；文案零禁用词

---

## 7. 代码审查与交付确认

### 7.1 代码审查
- [ ] 审查 `src/services/charityService.js`：确认所有方法同步、无 DOM 依赖、所有异常 try/catch 包裹、常量集中于文件顶部
- [ ] 审查 `src/views/charityView.js`：确认所有 DOM 操作 try/catch 包裹、文案集中于 `HINT_COPY` 常量、私有方法以 `_` 前缀标记
- [ ] 审查 `src/views/homeView.js` diff：确认仅新增 import + 1 行 appendChild + 1 个 `_renderCharityHint` 方法 + `_renderBadges` 图标映射修改，其余行不变
- [ ] 审查 `src/services/achievementService.js` diff：确认仅 `getAll()` 末尾追加合并逻辑，`checkAndUnlock` 与既有三枚徽章判定不变
- [ ] 审查 `src/styles/main.css` diff：确认仅末尾追加 `.charity-*` 段与 `@supports` 降级段，既有样式不变
- [ ] 验收：5 个文件审查通过，diff 范围与设计文档 2.4.4 节文件修改清单一致

### 7.2 设计一致性核对
- [ ] 核对 design.md 2.2.2 节接口清单中 8 个接口签名与实现一致
- [ ] 核对 design.md 2.1.3.1 节状态机所有状态转移已实现（HintHidden/HintVisible/ModalTaskSelect/StepsPanel/QuizPanel/SuccessPanel）
- [ ] 核对 design.md 2.4.1 节不白屏降级策略 5 项全部落地
- [ ] 核对 design.md 2.4.2 节既有功能保护措施 6 项全部落地
- [ ] 验收：4 项核对全部一致

### 7.3 变更范围最终确认
- [ ] 确认新建文件仅 `src/services/charityService.js` 与 `src/views/charityView.js` 两个
- [ ] 确认修改文件仅 `src/views/homeView.js`、`src/services/achievementService.js`、`src/styles/main.css` 三个
- [ ] 确认未修改 `src/main.js`、`index.html`、`src/constants.js`、`src/storage/localStorageAdapter.js` 及其他既有文件
- [ ] 确认未引入新的 npm 依赖、未引入 Tailwind 等原子类框架、未引入 TypeScript
- [ ] 验收：变更范围严格限定，可安全合入主分支