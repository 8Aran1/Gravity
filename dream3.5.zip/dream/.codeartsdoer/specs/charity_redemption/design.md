# 公益赎回与柔性提醒 — 技术设计文档

> 项目：引力 · Gravity
> 范围：charity_redemption 特性
> 技术栈：vanilla JS + ES Module + localStorage + 传统 CSS（毛玻璃拟态）
> 约束：不改 main.js 路由 / index.html 骨架 / localStorage 顶层结构；不破坏既有功能；不白屏

---

# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 写入 checkIns 记录（id/goalId/checkInDate/checkInTime 四字段） | habitService.checkIn(goalId) 已实现同形状记录写入 | src/services/habitService.js:22-28 | 100% |
| 计算连签天数（修复后重新连续计数） | habitService.getStreakDays() 基于日期集合连续计数 | src/services/habitService.js:36-53 | 75% |
| 判断今日是否已打卡 | habitService.hasCheckedInToday(goalId) | src/services/habitService.js:63-67 | 100% |
| 徽章解锁机制（badgeId/name/unlockCondition/unlocked/unlockedDate） | achievementService.checkAndUnlock() 遍历 ACHIEVEMENTS 写入 data.achievements | src/services/achievementService.js:26-51 | 75% |
| 徽章查询展示（按 unlocked 过滤） | achievementService.getAll() 动态计算 + homeView._renderBadges() 渲染 | src/services/achievementService.js:7-24；src/views/homeView.js:133-150 | 50% |
| 温柔文案提示（toast） | modal.toast(message) 玻璃拟态底部提示 | src/views/modal.js:53-67 | 100% |
| 玻璃拟态弹窗样式（backdrop-filter） | .modal-overlay / .modal-dialog 已有 blur 与半透明背景 | src/styles/main.css:606-629 | 100% |
| 唯一 id 生成 | idUtils.generate() 时间戳+随机 base36 | src/utils/idUtils.js:1-5 | 100% |
| 日期工具（today/format/daysBetween） | dateUtils 提供 YYYY-MM-DD 格式与差值计算 | src/utils/dateUtils.js:1-21 | 100% |
| localStorage 读写适配 | localStorageAdapter.getData()/saveData() 带缓存与异常兜底 | src/storage/localStorageAdapter.js:91-103 | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 首页柔性提示卡片渲染 | homeView.render() 已有分模块渲染骨架（identityBar/hero/stats/motivation/badges/goalsSection） | 现有首页无漏签提示入口；motivation 区块仅展示连签正向反馈，不含漏签柔性引导 | 在 homeView 中新增 _renderCharityHint() 私有方法，插入位置为 motivation 之后、badges 之前；由 charityService.detectYesterdayMiss() 决策是否渲染 |
| 徽章墙展示公益守护者 | homeView._renderBadges() 调用 achievementService.getAll() 过滤 unlocked | getAll() 仅遍历 ACHIEVEMENTS 常量三枚徽章，不识别 charity_guardian；徽章墙图标硬编码为 🏆 | achievementService.getAll() 增加对 data.achievements 中 charity_guardian 记录的合并返回；徽章墙图标改为按 badgeId 映射（charity_guardian → 🌈 或 💝） |
| 徽章解锁幂等写入 | achievementService.checkAndUnlock() 仅处理 ACHIEVEMENTS 常量三枚 | checkAndUnlock 不识别 charity_guardian，且其触发条件是连签/达成，不是公益行为 | 新增 charityService.unlockGuardianBadge() 独立处理公益徽章幂等写入，不修改既有 checkAndUnlock 逻辑 |
| 弹窗多步流程承载 | modal.show(message, onConfirm, onCancel) 仅支持确认/取消两按钮单步弹窗 | 公益赎回需任务选择 → 任务执行 → 修复成功结果页三段式弹窗，modal.show 无法承载 | charityView 自建 charityModal DOM 容器（沿用 .modal-overlay/.modal-dialog 样式），内部多面板切换；不复用 modal.show 但复用 modal.toast |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**A. charityService（src/services/charityService.js）— 全新服务模块**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 漏签检测 detectYesterdayMiss | 无 | { missed: boolean, goalId: string\|null, yesterday: string\|null } | 取进行中目标，判断 checkIns 中是否存在昨日记录，返回首个漏签目标 | localStorageAdapter、dateUtils |
| 生成模拟步数 generateSteps | 无 | { steps: number, ok: boolean } | Math.random 生成 5000-10000 整数；异常降级返回 8000 | 无 |
| 获取反诈题目 getAntiFraudQuestion | 无 | { stem: string, options: string[4], answerIndex: number } | 从内置题库常量随机取一题；异常降级返回兜底题 | 无 |
| 判定答题 isAnswerCorrect | (question, selectedIndex) | { correct: boolean } | 比对 selectedIndex 与 question.answerIndex | 无 |
| 修复昨日打卡 repairYesterdayCheckIn | (goalId) | { success: boolean, message: string, alreadyRepaired: boolean } | 校验目标存在与进行中、校验昨日记录幂等、构造 checkIn 记录追加写入、saveData 失败回滚 | localStorageAdapter、idUtils、dateUtils |
| 解锁公益徽章 unlockGuardianBadge | 无 | { success: boolean, newlyUnlocked: boolean, badge: object\|null } | 查找 data.achievements 中 charity_guardian，不存在则追加，已存在且 unlocked 则幂等跳过，存在但字段不全则补全 | localStorageAdapter、dateUtils |
| 标记柔性提示已关闭 markHintClosed | 无 | void | 在 sessionStorage 写入当日关闭标记 | sessionStorage、dateUtils |
| 判断柔性提示当日是否已关闭 isHintClosedToday | 无 | boolean | 读取 sessionStorage 当日标记 | sessionStorage、dateUtils |

**B. charityView（src/views/charityView.js）— 全新视图模块**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 渲染柔性提示卡片 renderHintCard | (container, onOpenModal) | HTMLElement\|null | 调用 charityService.detectYesterdayMiss，漏签则构造卡片 DOM（含温柔文案 + "来做点好事修复吧"按钮 + 关闭按钮），未漏签返回 null | charityService、dateUtils |
| 打开公益赎回弹窗 openRedemptionModal | (goalId) | void | 创建 overlay/dialog DOM，渲染任务选择面板，绑定任务切换与完成回调 | charityService、modal（toast） |
| 渲染捐步数面板 _renderStepsPanel | (dialog, goalId) | void | 渲染"生成步数"按钮，点击后调用 generateSteps 并展示步数与修复成功，触发 repairYesterdayCheckIn + unlockGuardianBadge | charityService |
| 渲染反诈答题面板 _renderQuizPanel | (dialog, goalId) | void | 渲染题干与 4 选项，作答后判定对错，对则修复，错则温柔提示重答 | charityService |
| 渲染修复成功结果页 _renderSuccessPanel | (dialog, badge) | void | 渲染温柔文案 + 徽章预览 + "返回"按钮，关闭弹窗 | 无 |
| 关闭弹窗 _closeModal | (overlay) | void | 移除 DOM，解绑事件 | 无 |

**C. main.css 追加样式段**

| 功能点 | 核心逻辑 |
|--------|---------|
| .charity-hint-card 柔性提示卡片 | 玻璃拟态背景、圆角、内边距、温柔色调 |
| .charity-hint-close 关闭按钮 | 绝对定位右上角、半透明 |
| .charity-modal-overlay / .charity-modal-dialog | 复用 .modal-overlay 视觉，独立类名避免与 modal.js 冲突 |
| .charity-task-entry 任务入口按钮 | 并列两按钮、玻璃拟态、hover 微动 |
| .charity-steps-display 步数展示 | 大字号步数、仪式感动画 |
| .charity-quiz-option 答题选项 | 单选按钮样式、选中态、对错态色彩 |
| .charity-success-badge 徽章预览 | 居中、发光效果 |
| backdrop-filter 不支持时的降级 | @supports not (backdrop-filter: blur(1px)) 下改为纯色半透明背景 |

## 1.2 存量功能详细分析

### 1.2.1 habitService.checkIn 接口契约

- **入参**：goalId: string
- **出参**：{ success: boolean, message: string }
- **业务规则**：校验目标存在 → 校验状态为"进行中" → 校验今日未打卡 → 构造 { id, goalId, checkInDate: today(), checkInTime: Date.now() } → push 到 data.checkIns → saveData
- **副作用**：写入 localStorage，更新 localStorageAdapter.cache
- **约束**：仅限今日打卡；不修复历史漏签；不返回新记录 id
- **对本组件启示**：repairYesterdayCheckIn 不能复用 checkIn（其硬编码 today()），需独立实现但复用其记录形状与校验模式

### 1.2.2 habitService.getStreakDays 接口契约

- **入参**：无
- **出参**：number（连签天数）
- **业务规则**：基于 data.records 的 date 字段构建日期集合，从今日向前连续计数
- **关键约束**：实际使用 records.date 而非 checkIns.checkInDate 作为连签依据
- **对本组件启示**：修复写入 checkIns 后，连签天数计算依赖 records 而非 checkIns。需在 design 中明确：公益修复仅补 checkIns 记录（满足 spec 6.1 约束），连签恢复的视觉反馈通过 checkIns 数组本身的连续性体现；若项目实际连签展示以 records 为准，则修复后连签数字可能不变，需在 charityView 文案中避免承诺"连签恢复 +1"

### 1.2.3 achievementService.checkAndUnlock 接口契约

- **入参**：无
- **出参**：newBadge: object\|null（新解锁徽章）
- **业务规则**：遍历 ACHIEVEMENTS 常量三枚徽章，按 streak/hasCompletedGoal 判定 shouldUnlock，写入 data.achievements 中对应记录的 unlocked/unlockedDate
- **关键约束**：仅识别 ACHIEVEMENTS 常量中定义的 badgeId，不处理 charity_guardian
- **对本组件启示**：unlockGuardianBadge 必须独立实现，不能扩展 ACHIEVEMENTS 常量（spec 4.5.1 禁止修改既有徽章定义）。但可在 data.achievements 数组中追加 charity_guardian 记录，因为 localStorageAdapter.initData 已保证 achievements 数组存在且可追加

### 1.2.4 achievementService.getAll 接口契约

- **入参**：无
- **出参**：ACHIEVEMENTS.map 增强后的数组（含 unlocked/unlockedDate）
- **业务规则**：仅遍历 ACHIEVEMENTS 常量，从 data.achievements 读取 stored.unlockedDate
- **对本组件启示**：徽章墙若要展示 charity_guardian，需扩展 getAll() 使其合并 data.achievements 中的 charity_guardian 记录。此为对既有功能的局部扩展，需保证不破坏既有三枚徽章的返回

### 1.2.5 modal.toast 接口契约

- **入参**：message: string
- **出参**：void
- **业务规则**：创建 .toast DOM，2 秒后自动移除
- **约束**：仅文本，不支持 HTML；z-index 2000
- **对本组件启示**：可直接复用作为温柔文案提示通道（如"昨日已修复，感谢你的善意"）。公益赎回弹窗内的小幅反馈亦可用 toast

### 1.2.6 homeView.render 渲染管线

- **渲染顺序**：identityBar → hero → stats → motivation → badges → goalsSection → disclaimer → settingsEntry
- **异常处理**：_renderIdentityBar 已有 try/catch 降级返回空 span
- **对本组件启示**：柔性提示卡片插入点选在 motivation 之后、badges 之前（语义上属于"状态引导"层），需用 try/catch 包裹保证不白屏

### 1.2.7 localStorageAdapter 数据形状约束

- **顶层字段**：{ _version, goals, records, checkIns, camps, achievements, user }
- **initData 兜底**：achievements 为空时回填 ACHIEVEMENTS.map(a => ({...a}))
- **saveData 行为**：同步写 cache + 异步 fetch API（失败静默）
- **对本组件启示**：charityService 所有写入必须通过 localStorageAdapter.saveData，不能直接 localStorage.setItem；读取通过 getData() 拿 cache 引用，修改后整体 saveData

---

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "引力场使用者" as user
rectangle "公益赎回与柔性提醒" as comp {
  rectangle "charityService" as svc
  rectangle "charityView" as view
}
storage "localStorage\ndream_saving_camp_data" as ls
storage "sessionStorage\ncharity_hint_closed_<date>" as ss
rectangle "homeView" as home
rectangle "achievementService" as ach
rectangle "habitService" as habit
rectangle "modal" as modalLib

user --> view : 点击柔性按钮/选择任务/作答/关闭
home --> view : 调用 renderHintCard(container, onOpenModal)
view --> svc : detectYesterdayMiss/generateSteps/getAntiFraudQuestion/repairYesterdayCheckIn/unlockGuardianBadge
svc --> ls : getData/saveData（读写 checkIns/achievements）
svc --> ss : 标记/读取当日柔性提示关闭状态
svc --> habit : 复用 checkIns 记录形状约定
svc --> ach : 合并 charity_guardian 到 achievements 查询
view --> modalLib : 复用 toast 温柔提示
@enduml
```

**通信协议与频率**：
- homeView → charityView：每次首页渲染调用 1 次 renderHintCard
- charityView → charityService：用户交互触发，低频（单次会话 ≤ 数次）
- charityService → localStorageAdapter：同步调用，单次修复 ≤ 2 次 getData + 1 次 saveData
- charityService → sessionStorage：单次标记/读取，O(1)

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
rectangle "charityService" as svc {
  rectangle "detectYesterdayMiss()" as d1
  rectangle "generateSteps()" as d2
  rectangle "getAntiFraudQuestion()" as d3
  rectangle "isAnswerCorrect(q, idx)" as d4
  rectangle "repairYesterdayCheckIn(goalId)" as d5
  rectangle "unlockGuardianBadge()" as d6
  rectangle "markHintClosed() / isHintClosedToday()" as d7
}
rectangle "charityView" as view {
  rectangle "renderHintCard(container, cb)" as v1
  rectangle "openRedemptionModal(goalId)" as v2
  rectangle "_renderStepsPanel" as v3
  rectangle "_renderQuizPanel" as v4
  rectangle "_renderSuccessPanel" as v5
  rectangle "_closeModal" as v6
}
rectangle "常量" as consts {
  rectangle "ANTI_FRAUD_QUESTIONS 题库"
  rectangle "CHARITY_BADGE 徽章定义"
  rectangle "STEPS_RANGE 步数范围"
  rectangle "HINT_COPY 柔性文案"
}

v1 --> d1
v1 --> d7
v2 --> v3
v2 --> v4
v3 --> d2
v3 --> d5
v3 --> d6
v4 --> d3
v4 --> d4
v4 --> d5
v4 --> d6
v5 --> d6
svc --> consts
@enduml
```

**模块职责**：
- **charityService**：纯逻辑层，无 DOM 依赖，所有方法同步且幂等可重入，所有异常内部捕获返回降级结果
- **charityView**：纯渲染层，不直接读写 localStorage，所有 DOM 操作 try/catch 包裹，失败静默降级
- **常量集中管理**：题库、徽章定义、步数范围、柔性文案集中于 charityService 顶部与 charityView 顶部，便于后续扩展

**配置项及取值策略**：
- STEPS_RANGE = { min: 5000, max: 10000, fallback: 8000 }
- CHARITY_BADGE = { badgeId: 'charity_guardian', name: '公益守护者', unlockCondition: '完成一次公益赎回' }
- ANTI_FRAUD_QUESTIONS：3-5 道题，含兜底题
- HINT_COPY：柔性文案常量，禁用词列表校验

### 2.1.3 实现设计文档

#### 2.1.3.1 公益赎回状态机

```plantuml
@startuml
[*] --> HintHidden : 无漏签或已关闭
[*] --> HintVisible : 检测到昨日漏签且当日未关闭

HintVisible --> ModalTaskSelect : 点击"来做点好事修复吧"
HintVisible --> HintHidden : 点击关闭按钮（标记当日已关闭）

ModalTaskSelect --> StepsPanel : 点击"捐赠步数"
ModalTaskSelect --> QuizPanel : 点击"反诈答题"
ModalTaskSelect --> HintVisible : 点击弹窗遮罩/关闭

StepsPanel --> SuccessPanel : 生成步数成功 + 修复写入成功
StepsPanel --> StepsPanel : 修复失败（温柔提示重试）

QuizPanel --> QuizPanel : 答错（温柔提示重答）
QuizPanel --> SuccessPanel : 答对 + 修复写入成功

SuccessPanel --> [*] : 点击"返回"
SuccessPanel --> [*] : 点击"查看徽章"（关闭弹窗 + toast 提示）
@enduml
```

**触发条件与处理策略**：
- HintHidden → HintVisible：仅首页/目标详情页渲染时触发，由 detectYesterdayMiss 返回 missed=true 且 isHintClosedToday=false 共同决定
- 任意面板 → SuccessPanel：修复写入成功且徽章解锁完成（含幂等已解锁场景）
- 任意异常态：捕获后 toast 温柔提示，弹窗保持当前面板不跳转，不白屏

#### 2.1.3.2 修复写入事务设计

```plantuml
@startuml
start
:读取 data = localStorageAdapter.getData();
:校验 goal 存在且 status=进行中;
if (校验失败) then (是)
  :返回 {success:false, message:温柔文案};
  stop
else (否)
endif
:计算 yesterday = format(today - 1);
:查找 data.checkIns 中 goalId+checkInDate=yesterday 记录;
if (已存在) then (是)
  :返回 {success:true, alreadyRepaired:true, message:"昨日已修复"};
  stop
else (否)
endif
:备份 checkIns 引用长度 backupLen;
:构造 newCheckIn = {id:idUtils.generate(), goalId, checkInDate:yesterday, checkInTime:Date.now()};
:data.checkIns.push(newCheckIn);
:ok = localStorageAdapter.saveData(data);
if (ok) then (是)
  :返回 {success:true, alreadyRepaired:false};
  stop
else (否)
  :回滚 data.checkIns.length = backupLen;
  :返回 {success:false, message:"存储空间不足，清理后稍后再试"};
  stop
endif
@enduml
```

**事务边界**：单次 saveData 调用为原子边界；失败时通过截断数组长度回滚内存 cache，避免半写入

#### 2.1.3.3 徽章解锁幂等流程

```plantuml
@startuml
start
:读取 data = localStorageAdapter.getData();
:确保 data.achievements 为数组（缺失则初始化为 []）;
:查找 existing = data.achievements.find(badgeId=charity_guardian);
if (existing 不存在) then (是)
  :构造 badge = {...CHARITY_BADGE, unlocked:true, unlockedDate:today()};
  :data.achievements.push(badge);
  :saveData(data);
  :返回 {success:true, newlyUnlocked:true, badge};
  stop
else (否)
endif
if (existing.unlocked === true) then (是)
  :返回 {success:true, newlyUnlocked:false, badge:existing};
  stop
else (否)
endif
:补全 existing 字段（badgeId/name/unlockCondition 缺失则填默认）;
:existing.unlocked = true;
:existing.unlockedDate = existing.unlockedDate || today();
:saveData(data);
:返回 {success:true, newlyUnlocked:true, badge:existing};
stop
@enduml
```

**幂等保证**：通过 badgeId 唯一查找 + unlocked 状态判断，重复触发不产生重复记录、不覆盖既有 unlockedDate

## 2.2 接口设计

### 2.2.1 总体设计

**接口分类依据**：
- charityService 对外暴露纯函数式同步接口，无 DOM 依赖，可被任意视图或服务调用
- charityView 对外暴露渲染入口（renderHintCard / openRedemptionModal），内部方法以 _ 前缀标记私有
- 不新增全局对象，全部通过 ES Module import/export 通信

**接口变更策略**：
- charityService / charityView 为全新模块，无既有调用方，无兼容负担
- achievementService.getAll() 局部扩展：在返回数组末尾合并 data.achievements 中的 charity_guardian 记录（若存在），既有三枚徽章返回不变
- homeView.render() 局部扩展：在渲染管线中插入 _renderCharityHint() 调用，既有模块不变

**稳定性等级**：
- charityService 全部接口：稳定（本特性范围内）
- achievementService.getAll 扩展行为：稳定（向后兼容）
- homeView._renderCharityHint：实验（内部私有方法）

### 2.2.2 接口清单

#### charityService.detectYesterdayMiss()

```js
// 接口签名
detectYesterdayMiss(): { missed: boolean, goalId: string|null, yesterday: string|null }
```

- **业务说明**：检测当前用户是否存在昨日漏签，返回首个漏签的目标 id
- **前置条件**：localStorageAdapter 已 initData
- **后置条件**：无副作用，纯读取
- **异常映射**：checkIns 缺失 → 按 [] 处理返回 missed=false；goals 异常 → 返回 missed=false
- **调用示例**：
```js
import { charityService } from '../services/charityService.js';
const { missed, goalId, yesterday } = charityService.detectYesterdayMiss();
if (missed) { charityView.openRedemptionModal(goalId); }
```

#### charityService.generateSteps()

```js
generateSteps(): { steps: number, ok: boolean }
```

- **业务说明**：随机生成 5000-10000 整数步数
- **前置条件**：无
- **后置条件**：无副作用
- **异常映射**：Math.random 异常 → 返回 { steps: 8000, ok: true } 并 console.warn
- **调用示例**：
```js
const { steps } = charityService.generateSteps();
```

#### charityService.getAntiFraudQuestion()

```js
getAntiFraudQuestion(): { stem: string, options: string[], answerIndex: number }
```

- **业务说明**：从内置题库随机返回一道反诈单选题
- **前置条件**：无
- **后置条件**：无副作用
- **异常映射**：题库常量异常 → 返回兜底题 { stem: '以下哪种理财方式最安全？', options: ['高收益保本', '银行存款', '陌生人推荐', '不明链接'], answerIndex: 1 }
- **调用示例**：
```js
const q = charityService.getAntiFraudQuestion();
```

#### charityService.isAnswerCorrect(question, selectedIndex)

```js
isAnswerCorrect(question: object, selectedIndex: number): { correct: boolean }
```

- **业务说明**：判定用户作答是否正确
- **前置条件**：question 含 answerIndex 字段，selectedIndex 为 0-3 整数
- **后置条件**：无副作用
- **异常映射**：question 异常 → 返回 { correct: false }
- **调用示例**：
```js
const { correct } = charityService.isAnswerCorrect(q, 1);
```

#### charityService.repairYesterdayCheckIn(goalId)

```js
repairYesterdayCheckIn(goalId: string): { success: boolean, message: string, alreadyRepaired: boolean }
```

- **业务说明**：向 checkIns 数组追加昨日打卡记录，幂等
- **前置条件**：goalId 非空字符串
- **后置条件**：成功时 data.checkIns 新增一条记录（或幂等不新增）；失败时 data 不变
- **异常映射**：目标不存在 → { success:false, message:'这个梦想已启程远行，无需修复啦' }；目标非进行中 → { success:false, message:'这个梦想已启程远行，无需修复啦' }；saveData 失败 → { success:false, message:'存储空间不足，清理后稍后再试' }；已存在昨日记录 → { success:true, alreadyRepaired:true, message:'昨日已修复，感谢你的善意' }
- **调用示例**：
```js
const result = charityService.repairYesterdayCheckIn(goalId);
if (result.success) { charityService.unlockGuardianBadge(); }
```

#### charityService.unlockGuardianBadge()

```js
unlockGuardianBadge(): { success: boolean, newlyUnlocked: boolean, badge: object|null }
```

- **业务说明**：解锁公益守护者徽章，幂等
- **前置条件**：无
- **后置条件**：成功时 data.achievements 包含一条 badgeId=charity_guardian 且 unlocked=true 的记录；幂等时不覆盖既有 unlockedDate
- **异常映射**：achievements 缺失 → 初始化为 [] 后写入；saveData 失败 → { success:false, newlyUnlocked:false, badge:null }
- **调用示例**：
```js
const { newlyUnlocked, badge } = charityService.unlockGuardianBadge();
if (newlyUnlocked) { charityView._renderSuccessPanel(dialog, badge); }
```

#### charityService.markHintClosed() / isHintClosedToday()

```js
markHintClosed(): void
isHintClosedToday(): boolean
```

- **业务说明**：标记柔性提示当日已关闭 / 查询当日是否已关闭
- **前置条件**：无
- **后置条件**：markHintClosed 在 sessionStorage 写入键 `charity_hint_closed_<YYYY-MM-DD>` 值 '1'
- **异常映射**：sessionStorage 不可用 → 静默降级，isHintClosedToday 返回 false
- **调用示例**：
```js
if (!charityService.isHintClosedToday()) { charityView.renderHintCard(container, onOpen); }
```

#### charityView.renderHintCard(container, onOpenModal)

```js
renderHintCard(container: HTMLElement, onOpenModal: (goalId: string) => void): HTMLElement|null
```

- **业务说明**：在指定容器内渲染柔性提示卡片，返回卡片 DOM 或 null（未漏签/已关闭/异常）
- **前置条件**：container 为有效 DOM 节点
- **后置条件**：返回非 null 时 container 内新增 .charity-hint-card 子节点
- **异常映射**：任意异常 → 返回 null，不影响 container 内其他内容
- **调用示例**：
```js
const card = charityView.renderHintCard(page, (goalId) => charityView.openRedemptionModal(goalId));
if (card) page.appendChild(card);
```

#### charityView.openRedemptionModal(goalId)

```js
openRedemptionModal(goalId: string): void
```

- **业务说明**：打开公益赎回弹窗，承载任务选择 → 任务执行 → 修复成功结果页全流程
- **前置条件**：goalId 非空
- **后置条件**：document.body 新增 .charity-modal-overlay 子节点；关闭时移除
- **异常映射**：DOM 创建失败 → toast '稍后再试'，不影响主页
- **调用示例**：
```js
charityView.openRedemptionModal(goalId);
```

## 2.3 数据模型

### 2.3.1 设计目标

**需支持的业务场景**：
- 检测昨日漏签并修复（单目标单日）
- 公益徽章解锁与徽章墙展示
- 柔性提示当日关闭状态记忆

**性能/容量/扩展性目标**：
- checkIns 数组追加单条记录，O(1) push
- achievements 数组追加单条记录，O(n) 查找 + O(1) push
- sessionStorage 单键值对，O(1)
- 题库与徽章定义集中于常量，扩展只需追加常量项

**与存量数据兼容策略**：
- 不新增 localStorage 顶层键
- checkIns 新增记录严格符合既有 { id, goalId, checkInDate, checkInTime } 形状
- achievements 新增 charity_guardian 记录符合既有 { badgeId, name, unlockCondition, unlocked, unlockedDate } 形状
- sessionStorage 为本特性新增的临时存储，键名带日期后缀，次日自动失效（不读取即不影响）

### 2.3.2 模型实现

```plantuml
@startuml
class CheckIn {
  +id : string
  +goalId : string
  +checkInDate : string
  +checkInTime : number
}

class Achievement {
  +badgeId : string
  +name : string
  +unlockCondition : string
  +unlocked : boolean
  +unlockedDate : string|null
}

class CharityBadge {
  +badgeId : string = "charity_guardian"
  +name : string = "公益守护者"
  +unlockCondition : string = "完成一次公益赎回"
}

class AntiFraudQuestion {
  +stem : string
  +options : string[4]
  +answerIndex : number
}

class StepsRange {
  +min : number = 5000
  +max : number = 10000
  +fallback : number = 8000
}

class HintClosedMarker {
  +key : string = "charity_hint_closed_<YYYY-MM-DD>"
  +value : string = "1"
  +storage : sessionStorage
}

CheckIn "1" -- "1" Goal : goalId >
Achievement "1" -- "1" CharityBadge : badgeId = charity_guardian >
@enduml
```

**对象关系与生命周期**：
- **CheckIn**：由 charityService.repairYesterdayCheckIn 创建，生命周期与 goals 同步（goalService.remove 会级联清理 checkIns）
- **Achievement（charity_guardian 实例）**：由 charityService.unlockGuardianBadge 创建，unlocked 一旦置 true 不可回退；unlockedDate 首次写入后不被覆盖
- **AntiFraudQuestion**：常量对象，无生命周期，每次 getAntiFraudQuestion 返回其副本
- **HintClosedMarker**：sessionStorage 键值对，当日有效，次日因键名不同自动失效

**持久化策略**：
- CheckIn 与 Achievement 通过 localStorageAdapter.saveData 持久化到 localStorage 键 `dream_saving_camp_data`
- HintClosedMarker 通过 sessionStorage.setItem 持久化（浏览器会话级，关闭标签页即清空，满足"当日不再展示"语义）
- AntiFraudQuestion 与 StepsRange 为内存常量，不持久化

**禁用词校验模型**（内置于 charityView 文案常量）：
- 禁用词列表：['惩罚', '断签', '失败', '扣款', '警告']
- 所有 HINT_COPY 文案在写入常量前已人工校验不含禁用词
- 运行时不做动态文案拼接，避免禁用词注入

---

## 2.4 关键实现约束与降级策略

### 2.4.1 不白屏保证

| 场景 | 降级策略 |
|------|---------|
| charityService 任意方法异常 | try/catch 返回安全默认值（missed=false / steps=8000 / success=false 等） |
| charityView.renderHintCard 异常 | try/catch 返回 null，homeView 不 appendChild |
| charityView.openRedemptionModal DOM 创建异常 | try/catch 调用 modal.toast('稍后再试') 并清理半创建 DOM |
| localStorageAdapter.saveData 失败 | charityService 回滚内存 cache 并返回 success=false |
| sessionStorage 不可用 | markHintClosed/isHintClosedToday 静默降级，不影响主流程 |

### 2.4.2 既有功能不受影响

| 既有功能 | 保护措施 |
|---------|---------|
| main.js 路由 | 不修改 router()，公益赎回以弹窗承载，不新增 hash 路由 |
| index.html 骨架 | 不修改，所有 DOM 由 JS 动态创建 |
| localStorage 顶层结构 | 仅在 checkIns/achievements 数组内追加符合形状的条目 |
| 粒子动画/组队留言/引力场/储蓄打卡 | 不修改其代码文件，charityService/charityView 与其无依赖关系 |
| 既有三枚徽章 | 不修改 ACHIEVEMENTS 常量、不修改 achievementService.checkAndUnlock 逻辑；仅扩展 getAll() 合并返回 charity_guardian |
| backdrop-filter 不支持 | @supports not (backdrop-filter: blur(1px)) 下 .charity-modal-overlay 改为 rgba(20,25,45,0.85) 纯色半透明 |

### 2.4.3 性能保证

| 性能指标 | 实现策略 |
|---------|---------|
| 漏签检测 + 柔性卡片渲染 < 50ms | detectYesterdayMiss 单次 getData + 数组 some 查找 O(n)；renderHintCard 单次 DOM 创建 < 5 节点 |
| 弹窗可交互 < 100ms | openRedemptionModal 同步创建 DOM，无异步等待 |
| 步数生成 < 16ms | Math.random 单次调用 + 取整 |
| 单次修复全流程 < 80ms | repairYesterdayCheckIn + unlockGuardianBadge 各 1 次 getData + 1 次 saveData，同步 |

### 2.4.4 文件修改清单

| 文件 | 操作 | 修改范围 |
|------|------|---------|
| src/services/charityService.js | 新建 | 全新文件，约 150 行 |
| src/views/charityView.js | 新建 | 全新文件，约 250 行 |
| src/views/homeView.js | 局部修改 | render() 中插入 _renderCharityHint() 调用 + 新增 _renderCharityHint() 私有方法；import charityView |
| src/services/achievementService.js | 局部修改 | getAll() 末尾合并 data.achievements 中 charity_guardian 记录（若存在） |
| src/styles/main.css | 局部追加 | 末尾追加 .charity-* 样式段 + @supports 降级段，约 120 行 |

### 2.4.5 homeView 局部修改示意（仅描述，不含代码）

在 homeView.js render() 方法的 `page.appendChild(this._renderMotivation(streak, motivation));` 之后、`page.appendChild(this._renderBadges());` 之前，插入：

```
page.appendChild(this._renderCharityHint());
```

新增 _renderCharityHint() 方法：
- try 块内：调用 charityService.detectYesterdayMiss() 与 isHintClosedToday()
- 若 missed=true 且 未关闭：调用 charityView.renderHintCard(document.createElement('div'), (goalId) => charityView.openRedemptionModal(goalId))，返回含卡片的容器
- 否则返回空 span
- catch 块返回空 span，保证不白屏

### 2.4.6 achievementService.getAll 局部修改示意（仅描述，不含代码）

在 getAll() 方法返回数组前，追加合并逻辑：
- 读取 data.achievements 中 badgeId=charity_guardian 的记录
- 若存在且 unlocked=true：将其加入返回数组末尾
- 若不存在或 unlocked=false：不加入（徽章墙仅展示已解锁徽章，与既有 _renderBadges 过滤逻辑一致）
- 既有三枚徽章返回逻辑完全不变

---

## 2.5 验收对齐

本设计与 spec.md 核心能力的对齐映射：

| spec 章节 | 设计落点 |
|----------|---------|
| 5.1 漏签检测与柔性提示 | charityService.detectYesterdayMiss + charityView.renderHintCard + homeView._renderCharityHint |
| 5.2 公益赎回任务 | charityService.generateSteps/getAntiFraudQuestion/isAnswerCorrect + charityView.openRedemptionModal/_renderStepsPanel/_renderQuizPanel |
| 5.3 打卡记录修复 | charityService.repairYesterdayCheckIn（含幂等、回滚、字段形状约束） |
| 5.4 公益徽章奖励 | charityService.unlockGuardianBadge + achievementService.getAll 扩展 + charityView._renderSuccessPanel |
| 6.1-6.4 数据约束 | 2.3.2 模型实现中字段定义与常量约束 |
| 4.1-4.5 DFX 约束 | 2.4 关键实现约束与降级策略 |