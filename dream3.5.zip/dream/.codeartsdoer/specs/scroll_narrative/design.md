# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 通过 CDN 异步加载 GSAP 并设置 3 秒超时降级 | `_loadGSAP()` 已实现 CDN 异步加载、`GSAP_LOAD_TIMEOUT=3000` 超时、onload/onerror/timeout 三路兜底 resolve | `src/utils/splashAnimation.js:21-46` | 100% |
| 检测 `prefers-reduced-motion` 偏好并跳过动画 | `_shouldReduceMotion()` 通过 `window.matchMedia('(prefers-reduced-motion: reduce)')` 检测，命中则直接 `_showApp()` 返回 | `src/utils/splashAnimation.js:6-12` | 100% |
| 动画失败/降级时显示完全可用的首页不白屏 | splashAnimation 全程 try/catch，失败统一调用 `_showApp()` 将 `#app` 透明度恢复为 1 | `src/utils/splashAnimation.js:14-19, 136-187` | 100% |
| 粒子入场动画播放结束后让位给后续动画 | `gsap.timeline({ onComplete })` 中移除 canvas 并调用 `_showApp()` 恢复 `#app` 透明度 | `src/utils/splashAnimation.js:158-165` | 100% |
| 首页元素由 `homeView` 渲染并提供稳定选择器 | `homeView._renderHero/_renderStats/_renderGoalsSection` 等已产出 `.home-hero-title`、`.home-hero-slogan`、`.home-hero-camp`、`.home-stat-value`、`.goal-card`、`.home-create-btn` 等稳定 class | `src/views/homeView.js:72-184` | 100% |
| 主初始化流程末尾串联既有动画模块 | `init()` 末尾 `try { splashAnimation.play(); } catch (e) {}` 已采用"可选串联 + 容错"模式，新增模块可同模式接入 | `src/main.js:78-79` | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 在主初始化流程中接入滚动叙事动画 | `init()` 末尾已串联 `splashAnimation.play()` | 现有串联点仅覆盖粒子入场，缺少滚动叙事接入点；`splashAnimation.play()` 为 async 但内部未 await timeline，无法用 `await` 等到粒子动画真正结束 | 在 `init()` 中 `splashAnimation.play()` 之后新增 `scrollAnimation.play()` 调用，由 `scrollAnimation` 内部自行感知 splash 结束时机（监听 `#app` 透明度恢复），不修改 `splashAnimation.js` |
| 复用已加载的 GSAP 实例 | `splashAnimation._loadGSAP()` 加载成功后挂载到 `window.gsap` | 滚动叙事需额外加载 ScrollTrigger 插件；若重新加载 GSAP 会浪费请求，应优先复用 `window.gsap` | `scrollAnimation` 优先取 `window.gsap`，未命中时再走 CDN 加载；ScrollTrigger 通过独立 CDN 脚本加载并 `gsap.registerPlugin()` |

### 1.1.3 需要新增的功能或接口

按业务模块分组如下：

**模块：`src/utils/scrollAnimation.js`（新建）**
- `scrollAnimation.play()`：滚动叙事动画总入口。输入：无；输出：Promise<void>。核心逻辑：路由判定 → 偏好判定 → 加载 GSAP+ScrollTrigger → 等待 splash 结束 → 注册各元素 ScrollTrigger → 失败统一降级。
- 内部辅助：`_isHomePage()`、`_shouldReduceMotion()`、`_ensureScrollTrigger(gsap)`、`_waitForSplashDone()`、`_setupHeroFloat()`、`_setupFadeIn()`、`_setupCardSlide()`、`_setupNumberCount()`、`_teardown()`。

**模块：`src/main.js`（修改）**
- 在 `init()` 末尾新增一行 `try { scrollAnimation.play(); } catch (e) {}`，并在文件头部新增 `import { scrollAnimation } from './utils/scrollAnimation.js';`。

依赖关系：`scrollAnimation` 依赖 `window.gsap` 与 ScrollTrigger（CDN），依赖 `homeView` 已渲染的 DOM 元素（通过选择器查询，无代码级依赖），依赖 `#app` 元素的透明度状态作为 splash 结束信号。

## 1.2 存量功能详细分析

### 1.2.1 `splashAnimation.play()` 接口契约与约束

- **入参**：`options`（未使用，预留）。
- **出参**：`Promise<void>`，但实际 resolve 时机为 GSAP 加载完成或降级分支返回，**并非**粒子动画 timeline 播放结束。timeline 结束由 `onComplete` 回调异步触发 `_showApp()`。
- **副作用**：
  1. 命中 `prefers-reduced-motion` → 立即 `_showApp()` 返回。
  2. 正常路径 → 将 `#app.style.opacity` 置为 `'0'` 并加 0.4s 过渡；创建全屏 `canvas`（`z-index:9999; pointer-events:none`）绘制粒子；timeline `onComplete` 移除 canvas 并将 `#app.style.opacity` 置为 `'1'`。
  3. 任意异常或加载失败 → `_showApp()` 恢复 `#app` 透明度。
- **关键约束**：
  1. 粒子 canvas 设置 `pointer-events:none`，不遮挡点击层——滚动叙事动画须同样遵守。
  2. `#app.style.opacity` 在 splash 期间为 `'0'`，结束恢复为 `'1'`——这是滚动叙事感知 splash 结束的唯一可用信号（不修改 splashAnimation 源码的前提下）。
  3. `_loadGSAP()` 成功后 `window.gsap` 全局可用，可被滚动叙事复用。

### 1.2.2 `homeView.render()` 渲染结构与选择器稳定性

- **调用时机**：由 `router()` 在 `hash === '#/'` 时调用，同步完成 DOM 构建。
- **产出的目标元素与选择器**（均为 class，稳定）：
  - `.home-identity-bar`：身份栏（头像+昵称，可点击进入个人资料）。
  - `h1.home-hero-title`：大标题"引力"——滚动叙事浮动显现目标。
  - `p.home-hero-slogan`：副标题——淡入目标。
  - `button.home-hero-camp`：引力场入口按钮——淡入目标，且必须保持可点击。
  - `.home-stats > .home-stat > .home-stat-value`：三个统计数字（累计储蓄 `¥xxx.xx`、进行中 `n<span.home-stat-sub>/m</span>`、连续天数 `n`）——数字滚动计数目标。
  - `.home-motivation`：激励语——淡入目标。
  - `.home-badges` / `.home-badge`：徽章——淡入目标。
  - `.goal-card`：目标卡片（由 `goalCard.render` 产出，0 至多个）——多米诺错落滑入目标。
  - `button.home-create-btn`：新建引力源按钮——淡入目标，必须保持可点击。
  - `button.home-settings-entry`：数据管理入口——淡入目标，必须保持可点击。
- **约束**：
  1. 上述元素在 `homeView.render()` 返回时已挂载到 `#app`，滚动叙事可在 splash 结束后安全查询。
  2. `.home-stat-value` 的内容形态有三种（纯数字、`¥` 前缀 + 小数、数字 + 子 span 后缀），数字计数需按形态分别解析，不能简单 `textContent` 覆盖（会破坏 `.home-stat-sub` 子结构）。
  3. `.goal-card` 数量动态（可能为 0），为 0 时滑入逻辑应安全跳过。

### 1.2.3 `onboardingTutorial` 与滚动叙事的协调关系

- **行为模式**：非阻塞气泡引导，通过 `tutorialStorage` 判定是否首次访问；气泡挂载到 `document.body`，定位为 `position:fixed/absolute`，不抢占 `#app` 内容流。
- **约束结论**：新手引导为异步用户驱动流程，不会"自动结束"，若滚动叙事硬等其结束将导致新用户永远看不到滚动动画。spec 5.1.1 规则 2 中"新手引导已结束"应解读为"新手引导已启动并进入稳定展示态、不与滚动叙事争夺同一视觉层"。因此滚动叙事**仅需等待 splash 结束**，与新手引导气泡并存即可，二者作用层不重叠（气泡在 body 顶层，滚动动画作用于 `#app` 内元素）。

### 1.2.4 `init()` 流程约束

- **执行顺序**：`initData → checkAndUnlock → applySavedTheme → advisorView.mount → router → hashchange 监听 → onboardingTutorial.start → splashAnimation.play`。
- **接入点约束**：滚动叙事必须在 `router()` 已渲染首页（即 `homeView.render()` 已执行）之后接入，否则查询不到目标元素。`init()` 末尾 `splashAnimation.play()` 之后满足该前提。
- **容错模式约束**：既有动画接入采用 `try { xxx.play(); } catch (e) {}` 静默容错，滚动叙事须沿用同一模式，保证任何异常都不影响核心功能。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用用户" as User
rectangle "scroll_narrative\n(scrollAnimation.js)" as SA {
  usecase "play()" as Play
}
rectangle "main.js init()" as Init
rectangle "window.gsap\n(splashAnimation 已挂载)" as GSAP
rectangle "ScrollTrigger\n(CDN 插件)" as ST
rectangle "homeView 已渲染 DOM\n(#app 内)" as DOM
rectangle "#app.style.opacity\n(splash 结束信号)" as Signal
rectangle "浏览器滚动事件" as Scroll

User --> Scroll : 向下滚动首页
Init --> Play : init() 末尾调用
Play --> GSAP : 复用 / 兜底加载
Play --> ST : CDN 加载 + registerPlugin
Play --> Signal : MutationObserver 等待 opacity='1'
Play --> DOM : 查询目标元素\n注册 ScrollTrigger
Scroll --> SA : 触发各元素入场动画
@enduml
```

**通信协议与频率**：
- `init() → play()`：单次同步调用（内部 async）。
- `play() → window.gsap`：单次读取。
- `play() → ScrollTrigger CDN`：单次脚本加载（3 秒超时降级）。
- `play() → #app MutationObserver`：监听 style 属性变化，splash 结束后立即 disconnect。
- `ScrollTrigger → DOM 元素`：随用户滚动按需触发，每元素最多触发一次（`once: true`）。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
package "scrollAnimation.js" {
  component "play()\n[总入口]" as Play
  component "_isHomePage()\n[路由判定]" as IsHome
  component "_shouldReduceMotion()\n[偏好判定]" as Reduce
  component "_ensureScrollTrigger()\n[加载插件]" as EnsureST
  component "_waitForSplashDone()\n[等待 splash 结束]" as WaitSplash
  component "_setupHeroFloat()\n[大标题浮动]" as HeroFloat
  component "_setupFadeIn()\n[淡入组]" as FadeIn
  component "_setupCardSlide()\n[卡片错落滑入]" as CardSlide
  component "_setupNumberCount()\n[数字滚动计数]" as NumCount
  component "_teardown()\n[清理 ScrollTrigger]" as Teardown
}

Play --> IsHome
Play --> Reduce
Play --> EnsureST
Play --> WaitSplash
Play --> HeroFloat
Play --> FadeIn
Play --> CardSlide
Play --> NumCount
Play --> Teardown : hashchange 离开首页时调用
@enduml
```

**模块职责**：
- `play()`：编排总流程，所有失败分支统一静默返回（降级）。
- `_isHomePage()`：判定 `(window.location.hash || '#/') === '#/'`，非首页直接返回不注册任何触发器。
- `_shouldReduceMotion()`：复用 splashAnimation 同名逻辑，命中则直接返回。
- `_ensureScrollTrigger(gsap)`：优先取 `gsap.ScrollTrigger`，未命中则 CDN 加载 `ScrollTrigger.min.js` 并 `gsap.registerPlugin(ScrollTrigger)`，3 秒超时降级。
- `_waitForSplashDone()`：若 `#app.style.opacity !== '0'` 视为 splash 已结束或未启动，立即 resolve；否则 `MutationObserver` 监听 `#app` 的 style 属性，opacity 恢复非 `'0'` 时 resolve；5 秒兜底超时强制 resolve 防止永久阻塞。
- `_setupHeroFloat / _setupFadeIn / _setupCardSlide / _setupNumberCount`：四类入场动画注册，均使用 `gsap.from()` + ScrollTrigger `once: true`，保证动画结束后元素自动归位至完全显现状态。
- `_teardown()`：`ScrollTrigger.getAll().forEach(t => t.kill())`，在用户离开首页路由时清理触发器，避免内存泄漏与跨页污染。

**配置项及取值策略**：
- `SCROLLTRIGGER_CDN_URL`：`https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/ScrollTrigger.min.js`（与 splashAnimation 的 GSAP 版本对齐）。
- `ST_LOAD_TIMEOUT = 3000`：与 `GSAP_LOAD_TIMEOUT` 一致。
- `SPLASH_WAIT_TIMEOUT = 5000`：等待 splash 结束的兜底上限。
- `TIMING`：`{ heroFloat: 1.0, fade: 0.8, slide: 0.9, count: 1.2, stagger: 0.12, cardDelay: 0.08 }`，单元素时长均 ≤ 1.2s 满足 spec 6.1 约束。
- 触发位置统一 `start: 'top 85%'`，即元素顶部进入视口 85% 高度时触发。

### 2.1.3 实现设计文档

**滚动叙事动画状态流转**：

```plantuml
@startuml
[*] --> Pending : play() 被调用
Pending --> Skipped : 非首页路由 / 命中 reduced-motion
Pending --> Loading : 首页且允许动画
Loading --> Degraded : GSAP 或 ScrollTrigger 加载失败/超时
Loading --> WaitingSplash : 插件就绪
WaitingSplash --> Degraded : 等待期间用户离开首页
WaitingSplash --> Registering : splash 结束且仍在首页
Registering --> Active : 所有触发器注册完成
Active --> Done : 用户滚动触发各元素依次入场\n(once: true 全部触发后)
Active --> TornDown : 用户 hashchange 离开首页\n(_teardown 清理)
Done --> [*]
Skipped --> [*]
Degraded --> [*]
TornDown --> [*]
@enduml
```

**关键分支与触发条件**：
- **Skipped 分支**：`_isHomePage()` 返回 false 或 `_shouldReduceMotion()` 返回 true → 直接 return，元素保持 homeView 渲染后的自然显现态，不白屏。
- **Degraded 分支（加载失败）**：`_ensureScrollTrigger` 返回 null → 直接 return，因未对元素做任何 `gsap.set` 初始隐藏，元素保持自然显现，不白屏。
- **Degraded 分支（等待期间离开首页）**：`_waitForSplashDone` resolve 后再次检查 `_isHomePage()` 返回 false → return，不注册触发器。
- **Registering 分支**：使用 `gsap.from()` 设置初始隐藏态（opacity:0 / 位移），由 ScrollTrigger `once: true` 在元素进入触发位置时播放；`gsap.from` 的 `immediateRender` 默认为 true，注册瞬间即应用初始态，触发后自动恢复至原态。
- **TornDown 分支**：监听 `hashchange`，离开 `#/` 时调用 `_teardown()` 杀死所有 ScrollTrigger 实例并移除监听，防止切回首页时残留触发器重复注册。

**扩展点设计**：
- 元素选择器与动画参数集中定义为模块顶部常量（如 `SELECTORS`、`TIMING`），后续调整动画节奏或扩展目标元素只需修改常量，无需改动 `play()` 主流程。
- `_setupNumberCount` 对 `.home-stat-value` 的三种内容形态（`¥小数`、`n<span>/m</span>`、`纯整数`）采用正则 `^([^\d]*)(\d+(?:\.\d+)?)(.*)$` 拆分为前缀/数字/后缀三段，动画时仅替换数字段、保留前缀与后缀（含子 span 结构），保证 DOM 结构不被破坏。

**事务/一致性设计**：本组件为纯展示动画，无数据写入，无事务需求。唯一一致性约束为"动画结束后元素完全显现"——通过 `gsap.from()` 的语义（from 状态 → 原状态）+ `once: true` + 异常降级时不应用初始隐藏态，三重保证元素最终必然可见。

## 2.2 接口设计

### 2.2.1 总体设计

| 接口 | 类型 | 暴露形式 | 稳定性 | 调用方 |
|------|------|---------|--------|--------|
| `scrollAnimation.play()` | 异步方法 | ES Module 命名导出 | 稳定 | `main.js init()` |
| `scrollAnimation._teardown()` | 内部方法 | 模块私有（下划线前缀） | 实验性（不应外部调用） | `play()` 内部 hashchange 监听 |

**接口分类依据**：仅 `play()` 为对外契约，其余均为内部实现细节，遵循项目既有下划线前缀私有约定（与 `splashAnimation._loadGSAP` 等一致）。

**接口变更策略**：`play()` 签名固定为无参 `Promise<void>`，未来扩展通过内部常量配置，不破坏调用方。

### 2.2.2 接口清单

#### `scrollAnimation.play()`

**接口签名**：
```js
async play() -> Promise<void>
```

**业务说明**：启动首页滚动叙事动画的总入口。在应用主初始化流程末尾、首页已渲染、粒子入场动画已启动后调用。内部完成路由判定、偏好判定、GSAP+ScrollTrigger 加载、等待 splash 结束、注册四类入场动画触发器全流程。

**前置条件**：
1. 调用时 `#app` 元素已存在且首页（`#/` 路由）已由 `homeView.render()` 渲染完成（即 `init()` 中 `router()` 已执行）。
2. `window.gsap` 可选——若 `splashAnimation` 已加载则复用，否则由本模块自行兜底加载。
3. 调用方须采用 `try { scrollAnimation.play(); } catch (e) {}` 容错模式，与本模块内部降级形成双层保护。

**后置条件**：
- 正常路径：首页各元素随用户滚动依次触发入场动画，结束后元素完全显现、位置归位、透明度为 1，所有按钮可正常点击。
- 降级路径（任一前置失败）：未对任何元素应用初始隐藏态，首页保持 `homeView.render()` 产出的自然显现态，无白屏、无功能损坏。
- 离开首页路由：`_teardown()` 清理所有 ScrollTrigger 实例与 hashchange 监听，无内存泄漏。

**异常映射**：所有异常（CDN 加载失败、超时、元素查询失败、gsap 调用异常）均被 `try/catch` 捕获并静默 return，不向外抛出。调用方 `catch` 块为二道防线，实际不会进入。

**调用示例**（`src/main.js`）：
```js
import { scrollAnimation } from './utils/scrollAnimation.js';
// ... 既有 imports

async function init() {
  try {
    await localStorageAdapter.initData();
    achievementService.checkAndUnlock();
  } catch (e) {
    console.error('初始化失败:', e);
    await localStorageAdapter.initData();
  }
  themeService.applySavedTheme();
  advisorView.mount();
  router();
  window.addEventListener('hashchange', router);
  try { onboardingTutorial.start(); } catch (e) {}
  try { splashAnimation.play(); } catch (e) {}
  try { scrollAnimation.play(); } catch (e) {}
}

init();
```

**改动说明**：仅新增 1 行 import + 1 行调用，`init()` 其余顺序完全不变，满足 spec"主初始化流程不受影响"约束。

## 2.3 数据模型

### 2.3.1 设计目标

1. **支持的业务场景**：首页（`#/` 路由）向下滚动时，大标题向上浮动淡入、副标题与引力场入口依次淡入、目标卡片从左/右错落滑入、数据统计数字由 0 滚动计数至目标值、激励语/徽章/按钮等其余元素依次淡入。
2. **性能目标**：单元素动画时长 ≤ 1.2s；ScrollTrigger 按需触发不一次性执行；动画全程不阻塞主线程；移动端与桌面端均不卡顿。
3. **容量目标**：目标元素数量有限（首页固定结构 + 动态目标卡片），ScrollTrigger 实例数 = 元素数，离开首页时全部 kill，无累积。
4. **兼容策略**：不依赖任何 localStorage 键或应用数据状态；首次访问（无本地数据）同样可播放或安全降级；尊重 `prefers-reduced-motion`；CDN 不可达时降级为自然显现。
5. **与存量数据兼容**：本组件不读写任何数据，与 `dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps` 等键零接触。

### 2.3.2 模型实现

**核心领域对象类图**：

```plantuml
@startuml
class scrollAnimation {
  +play(): Promise<void>
  -_isHomePage(): boolean
  -_shouldReduceMotion(): boolean
  -_ensureScrollTrigger(gsap): Promise<ScrollTrigger|null>
  -_waitForSplashDone(): Promise<void>
  -_setupHeroFloat(gsap, st): void
  -_setupFadeIn(gsap, st, selector): void
  -_setupCardSlide(gsap, st): void
  -_setupNumberCount(gsap, st): void
  -_teardown(): void
}

class ScrollTriggerConfig {
  +trigger: Element
  +start: String
  +once: boolean
}

class NumberSegments {
  +prefix: String
  +value: number
  +suffix: String
}

scrollAnimation ..> ScrollTriggerConfig : 创建
scrollAnimation ..> NumberSegments : 解析 .home-stat-value
@enduml
```

**对象关系与生命周期**：
- `scrollAnimation` 为单例对象字面量（与 `splashAnimation` 同模式），整个应用生命周期内仅一个实例。
- `ScrollTriggerConfig` 为每次注册触发器时构造的配置对象，生命周期与对应 ScrollTrigger 实例绑定，触发后（`once: true`）由 GSAP 内部管理，离开首页时由 `_teardown()` 显式 kill。
- `NumberSegments` 为 `_setupNumberCount` 内部对每个 `.home-stat-value` 解析出的临时值对象（前缀/数字/后缀三段），仅在动画期间存在于闭包中，动画结束随闭包释放。

**创建与销毁策略**：
- 创建：`play()` 内部按需查询 DOM 元素并构造触发器，不预创建。
- 销毁：`_teardown()` 调用 `ScrollTrigger.getAll().forEach(t => t.kill())` 销毁全部实例；`hashchange` 监听器在 `_teardown` 中一并移除。

**持久化策略**：无持久化。本组件为纯运行时展示动画，不涉及任何存储模型，不触碰 localStorage 任何键，不触碰 index.html 结构。所有初始隐藏态由 `gsap.from()` 的 `immediateRender` 在运行时动态应用，动画结束后由 GSAP 自动恢复至 `homeView.render()` 产出的原始内联/样式表状态，不残留任何 inline style 污染。
