# 滚动叙事动画（scroll_narrative）编码任务列表

> 变更范围：新建 `src/utils/scrollAnimation.js` + 修改 `src/main.js`（仅 +1 import、+1 调用）
> 依赖前置：spec.md、design.md 已确认；`homeView` 已产出稳定选择器；`splashAnimation` 已挂载 `window.gsap` 并通过 `#app.style.opacity` 暴露结束信号

## 1. 滚动叙事模块骨架与降级基础设施

### 1.1 创建 scrollAnimation.js 模块骨架与配置常量
- [ ] 新建 `src/utils/scrollAnimation.js`，在文件顶部定义模块级常量：`SCROLLTRIGGER_CDN_URL`（`https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/ScrollTrigger.min.js`，与 splashAnimation GSAP 版本对齐）、`ST_LOAD_TIMEOUT=3000`、`SPLASH_WAIT_TIMEOUT=5000`、`TIMING={ heroFloat:1.0, fade:0.8, slide:0.9, count:1.2, stagger:0.12, cardDelay:0.08 }`、`SELECTORS` 集中定义各目标元素选择器（heroTitle、heroSlogan、heroCamp、statValue、motivation、badges、badge、goalCard、createBtn、settingsEntry）、触发位置常量 `TRIGGER_START='top 85%'`
- [ ] 定义 `scrollAnimation` 对象字面量骨架（与 `splashAnimation` 同模式），声明 `play()` 及所有下划线前缀内部方法占位，统一采用 ES Module 命名导出 `export const scrollAnimation = {...}`
- [ ] 验收：文件创建成功，常量与选择器集中可维护，单元素动画时长均 ≤ 1.2s 满足 spec 6.1 约束

### 1.2 实现路由判定 _isHomePage()
- [ ] 在 `scrollAnimation.js` 中实现 `_isHomePage()`：返回 `(window.location.hash || '#/') === '#/'`，非首页直接返回 false
- [ ] 验收：首页 `#/` 返回 true；`#/camps`、`#/settings` 等非首页返回 false；空 hash 视为首页

### 1.3 实现减少动态偏好判定 _shouldReduceMotion()
- [ ] 在 `scrollAnimation.js` 中实现 `_shouldReduceMotion()`：复用 splashAnimation 同名逻辑，通过 `window.matchMedia('(prefers-reduced-motion: reduce)')` 检测，try/catch 兜底返回 false
- [ ] 验收：用户开启 prefers-reduced-motion 时返回 true；不支持 matchMedia 时安全返回 false 不抛错

### 1.4 实现 ScrollTrigger 插件加载 _ensureScrollTrigger(gsap)
- [ ] 在 `scrollAnimation.js` 中实现 `_ensureScrollTrigger(gsap)`：优先取 `gsap.ScrollTrigger`（已注册则直接 resolve）；未命中则动态创建 `<script>` 加载 `SCROLLTRIGGER_CDN_URL`，`async=true`，onload 后调用 `gsap.registerPlugin(window.ScrollTrigger)` 并 resolve；onerror 与 `ST_LOAD_TIMEOUT` 超时均 resolve(null) 降级；全程 try/catch 兜底 resolve(null)
- [ ] 验收：插件已注册时零网络请求复用；CDN 不可达或 3s 超时返回 null 触发降级；加载成功返回 ScrollTrigger 类

## 2. splash 结束感知与生命周期管理

### 2.1 实现 _waitForSplashDone() 等待 splash 结束
- [ ] 在 `scrollAnimation.js` 中实现 `_waitForSplashDone()`：先读取 `#app.style.opacity`，若不为 `'0'` 视为 splash 已结束或未启动，立即 resolve；否则用 `MutationObserver` 监听 `#app` 的 `attributes`（`attributeFilter:['style']`），回调中检查 `opacity` 恢复非 `'0'` 时 disconnect 并 resolve；同时设置 `SPLASH_WAIT_TIMEOUT=5000` 兜底超时强制 disconnect 并 resolve，防止永久阻塞
- [ ] 验收：splash 进行中时能感知 opacity 恢复并 resolve；splash 未启动时立即 resolve；5s 兜底超时保证不永久挂起

### 2.2 实现 _teardown() 清理 ScrollTrigger 与监听
- [ ] 在 `scrollAnimation.js` 中实现 `_teardown()`：try/catch 内调用 `ScrollTrigger.getAll().forEach(t => t.kill())` 销毁全部实例；移除 `hashchange` 监听器（监听器引用需在模块作用域保存）；不抛错
- [ ] 验收：调用后所有 ScrollTrigger 实例被 kill；hashchange 监听被移除；无内存泄漏与跨页污染

### 2.3 实现 hashchange 离开首页时自动清理
- [ ] 在 `play()` 注册触发器后，于模块作用域保存 hashchange 监听器引用，监听器内判定离开 `#/` 时调用 `_teardown()`；切回首页时不残留旧触发器重复注册
- [ ] 验收：首页 → 非首页时触发器全部清理；再次切回首页时无重复触发器

## 3. 四类入场动画注册

### 3.1 实现 _setupHeroFloat(gsap, st) 大标题向上浮动淡入
- [ ] 在 `scrollAnimation.js` 中实现 `_setupHeroFloat(gsap, st)`：查询 `h1.home-hero-title`，未命中安全跳过；使用 `gsap.from(target, { y:30, opacity:0, duration:TIMING.heroFloat, ease:'power2.out', scrollTrigger:{ trigger:target, start:TRIGGER_START, once:true } })`，由 `immediateRender` 默认 true 应用初始隐藏态，触发后自动恢复至原态
- [ ] 验收：大标题由下方位置向上浮动且透明度 0→1；动画时长 1.0s；元素查询失败时不抛错不白屏

### 3.2 实现 _setupFadeIn(gsap, st, selector) 淡入组
- [ ] 在 `scrollAnimation.js` 中实现 `_setupFadeIn(gsap, st, selector)`：对传入选择器查询到的元素组使用 `gsap.from(targets, { opacity:0, duration:TIMING.fade, ease:'power2.out', stagger:TIMING.stagger, scrollTrigger:{ trigger:targets[0] 或容器, start:TRIGGER_START, once:true } })`；分别应用于副标题 `.home-hero-slogan`、引力场入口 `button.home-hero-camp`、激励语 `.home-motivation`、徽章 `.home-badge` 组、新建引力源按钮 `button.home-create-btn`、数据管理入口 `button.home-settings-entry`、身份栏 `.home-identity-bar`
- [ ] 验收：各元素依次淡入显现，相邻元素错落有间隔；按钮类元素动画结束后透明度为 1 且可正常点击

### 3.3 实现 _setupCardSlide(gsap, st) 目标卡片错落滑入
- [ ] 在 `scrollAnimation.js` 中实现 `_setupCardSlide(gsap, st)`：查询所有 `.goal-card`，数量为 0 时安全跳过；按索引奇偶交替从左/右滑入（偶数索引 `x:-60`，奇数索引 `x:60`），使用 `gsap.from(cards, { x:(i)=> i%2===0 ? -60 : 60, opacity:0, duration:TIMING.slide, ease:'power2.out', stagger:TIMING.cardDelay, scrollTrigger:{ trigger:cards[0], start:TRIGGER_START, once:true } })` 形成多米诺错落节奏
- [ ] 验收：目标卡片依次从左/右侧滑入，相邻卡片错落有间隔；0 张卡片时安全跳过不报错；动画结束后位置归位

### 3.4 实现 _setupNumberCount(gsap, st) 数据统计数字滚动计数
- [ ] 在 `scrollAnimation.js` 中实现 `_setupNumberCount(gsap, st)`：查询所有 `.home-stat-value`，对每个元素用正则 `^([^\d]*)(\d+(?:\.\d+)?)(.*)$` 将 `textContent` 拆分为前缀/数字/后缀三段（保留 `.home-stat-sub` 子 span 结构，不破坏 DOM）；使用 `gsap.fromTo` 或闭包变量从 0 计数至目标数值，`onUpdate` 时仅替换数字段、前缀与后缀（含子 span）保持不变；`duration:TIMING.count`，`scrollTrigger:{ trigger:元素, start:TRIGGER_START, once:true }`；解析失败（无数字）时安全跳过该元素
- [ ] 验收：累计储蓄 `¥xxx.xx`、进行中 `n/m`、连续天数 `n` 三种形态均由 0 计数至目标值；`.home-stat-sub` 子 span 结构不被破坏；动画结束后显示目标数值

## 4. 总入口编排与主初始化流程接入

### 4.1 实现 play() 总入口编排
- [ ] 在 `scrollAnimation.js` 中实现 `async play()`：全程 try/catch 静默降级。流程顺序：① `_isHomePage()` 返回 false 直接 return；② `_shouldReduceMotion()` 返回 true 直接 return；③ 取 `window.gsap`，未命中则 CDN 兜底加载（复用 splashAnimation `_loadGSAP` 模式，3s 超时降级），失败 return；④ `_ensureScrollTrigger(gsap)` 返回 null 直接 return；⑤ `_waitForSplashDone()` 等待 splash 结束；⑥ 等待结束后再次 `_isHomePage()` 判定，离开首页则 return；⑦ 依次调用 `_setupHeroFloat`、`_setupFadeIn`（各组）、`_setupCardSlide`、`_setupNumberCount`；⑧ 注册 hashchange 监听器（任务 2.3）
- [ ] 验收：正常路径四类动画均注册；任一前置失败均静默 return 且未对元素应用初始隐藏态（不白屏）；等待期间离开首页不注册触发器

### 4.2 修改 main.js 接入滚动叙事动画
- [ ] 在 `src/main.js` 文件头部新增 `import { scrollAnimation } from './utils/scrollAnimation.js';`（紧随 `splashAnimation` import 之后，保持导入顺序整洁）
- [ ] 在 `init()` 末尾 `try { splashAnimation.play(); } catch (e) {}` 之后新增一行 `try { scrollAnimation.play(); } catch (e) {}`，`init()` 其余执行顺序完全不变
- [ ] 验收：`main.js` 仅新增 1 行 import + 1 行调用；既有 `initData → checkAndUnlock → applySavedTheme → advisorView.mount → router → hashchange → onboardingTutorial → splashAnimation` 顺序不变；双层 try/catch 容错

## 5. 验证与测试

### 5.1 首页滚动叙事动画正常路径验证
- [ ] 验证首页向下滚动时大标题"引力"由下向上浮动且透明度 0→1
- [ ] 验证副标题、引力场入口依次淡入显现，形成由上至下叙事节奏
- [ ] 验证目标卡片依次从左/右侧错落滑入，相邻卡片有明显间隔
- [ ] 验证数据统计数字由 0 递增至目标数值，`.home-stat-sub` 子 span 结构完好
- [ ] 验证激励语、徽章、新建引力源按钮、数据管理入口依次淡入
- [ ] 验证所有元素动画结束后处于完全显现状态（透明度 1、位置归位）

### 5.2 降级与边界场景验证
- [ ] 模拟 ScrollTrigger CDN 加载失败：直接显示完全可用首页，无白屏
- [ ] 模拟加载超时（>3s）：触发降级，首页自然显现
- [ ] 开启浏览器 prefers-reduced-motion：不播放滚动叙事动画，首页直接可用
- [ ] 进入非首页路由（`#/camps`、`#/settings` 等）滚动：不触发滚动叙事动画
- [ ] 首页等待 splash 期间切到非首页：不注册触发器，无残留
- [ ] 首页 → 非首页 → 再次切回首页：无重复触发器，无动画异常

### 5.3 核心功能完好性验证
- [ ] 动画结束后点击"新建引力源"按钮：正常跳转 `#/goal/new`
- [ ] 动画结束后点击引力场入口按钮：正常跳转 `#/camps`
- [ ] 动画结束后点击目标卡片：正常进入目标详情
- [ ] 动画结束后点击数据管理入口：正常跳转 `#/settings`
- [ ] 动画期间点击上述按钮：点击事件正常透传生效，不被动画遮挡
- [ ] 动画结束后打卡、引力小助手、逃逸速度功能交互与数据行为与动画前完全一致
- [ ] 验证 localStorage 键 `dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps` 未被触碰

### 5.4 性能与兼容性验证
- [ ] 桌面端浏览器验证：滚动叙事流畅无卡顿、无掉帧、无白屏
- [ ] 移动端窄屏验证：动画正常播放，无溢出、无卡顿、无点击失效
- [ ] 首次访问（无任何 localStorage 数据）：动画正常播放或安全降级
- [ ] 无网络/CDN 不可达环境：降级直接显示可用首页
- [ ] 验证 `index.html` 结构对比动画前后完全不变（仅 JS 动态控制既有元素）
- [ ] 出现卡顿或白屏征兆时：能立即回退至无动画状态，核心功能完好

## 6. 审查与确认

### 6.1 代码审查
- [ ] 审查 `scrollAnimation.js` 命名风格：全部 camelCase，下划线前缀私有方法与 `splashAnimation` 一致
- [ ] 审查模块组织：动画逻辑集中封装于独立模块，未散落到业务视图代码
- [ ] 审查 `index.html`：既有结构零修改，仅通过 JS 动态控制既有元素
- [ ] 审查 localStorage：本组件零读写，不触碰任何数据键
- [ ] 审查接入方式：`main.js` 仅 +1 import +1 调用，简洁可移除便于回滚
- [ ] 审查 GSAP/ScrollTrigger：均通过 CDN 引入，无 npm 安装，保证纯前端静态运行

### 6.2 变更范围最终确认
- [ ] 确认变更文件清单：新建 `src/utils/scrollAnimation.js`、修改 `src/main.js`，无其他文件变更
- [ ] 确认 `main.js` diff：仅新增 1 行 import + 1 行 `try { scrollAnimation.play(); } catch (e) {}` 调用
- [ ] 确认既有 `init()` 流程顺序、router、homeView、splashAnimation、onboardingTutorial 均未改动