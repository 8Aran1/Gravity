# 背景主题功能 - 编码任务清单

> 本任务清单基于 `.codeartsdoer/specs/background_theme/spec.md`（需求规格）与 `design.md`（实现方案）生成。
>
> **全局约束（适用于所有任务）**：
> 1. 数据必须通过 `src/storage/localStorageAdapter.js` 的 `getData()/saveData()` 存取，禁止在视图层直接操作 `localStorage`。
> 2. 不修改 `index.html`；不修改 `main.js` 既有路由分支的匹配逻辑与顺序（`init()` 中插入一行 `applySavedTheme()` 调用不属于路由分支修改）。
> 3. 不引入任何图片文件、外部图片 URL、base64 数据；所有背景由纯 CSS 渐变实现。
> 4. 不引入任何付费/商业授权组件或第三方样式库。
> 5. 不白屏：所有新增渲染与启动逻辑须有 `try/catch` 兜底，异常回退默认主题或跳过区域。
> 6. 命名采用 camelCase，文件名如 `themeService.js`。
> 7. 不新增任何 localStorage 键，主题选择挂载于主数据 `user.themeKey`。
> 8. 完成每个任务后须用 `node --check` 对涉及的 JS 文件做语法检查（Node.js v24 可用）。

---

## 1. 定义预设主题常量

**写作指导**：本组为基础数据层任务，无外部依赖，是后续所有任务的基石，须最先完成。

### 1.1 在 constants.js 中新增 BACKGROUND_THEMES 预设主题集合
- [ ] 在 `src/constants.js` 末尾追加 `BACKGROUND_THEMES` 常量，定义为固定 3 套主题的数组，每套含 `key`（string）、`name`（中文展示名）、`gradient`（CSS 渐变表达式）、`type`（'linear'|'radial'）、`isDefault`（boolean）五个字段
- [ ] 三套主题取值严格按 design.md 2.4 节定义：
  - 星云紫：`key:'nebula'`, `name:'星云紫'`, `gradient:'linear-gradient(135deg, #4B0082 0%, #2D0A4E 45%, #0A0A1A 100%)'`, `type:'linear'`, `isDefault:true`
  - 晨曦黄：`key:'dawn'`, `name:'晨曦黄'`, `gradient:'radial-gradient(circle at 30% 25%, #FFF8DC 0%, #FFD580 45%, #FF8C42 100%)'`, `type:'radial'`, `isDefault:false`
  - 赛博蓝：`key:'cyber'`, `name:'赛博蓝'`, `gradient:'linear-gradient(135deg, #0B1E3F 0%, #0A4D8C 50%, #00E5FF 100%)'`, `type:'linear'`, `isDefault:false`
- [ ] 验收标准：`BACKGROUND_THEMES.length === 3`；三个 `key` 互不相同（`nebula`/`dawn`/`cyber`）；有且仅有一项 `isDefault:true`（为 `nebula`）；`gradient` 字段均为 CSS 渐变表达式，不含 `url()`
- [ ] 验收标准：`node --check src/constants.js` 通过

### 1.2 在 constants.js 中新增 DEFAULT_THEME_KEY 默认主题标识
- [ ] 在 `src/constants.js` 中追加 `DEFAULT_THEME_KEY` 常量，取值为 `BACKGROUND_THEMES` 中 `isDefault:true` 项的 `key`（即 `'nebula'`）
- [ ] 验收标准：`DEFAULT_THEME_KEY === 'nebula'`；该值与 `BACKGROUND_THEMES` 中某项的 `key` 严格相等（交叉校验一致）
- [ ] 验收标准：`node --check src/constants.js` 通过

---

## 2. 实现主题服务核心能力

**写作指导**：本组为新增服务层，依赖任务组 1（常量）与既有 `localStorageAdapter`。是主题读/写/应用的核心，须在视图与启动接入前完成。

### 2.1 新建 themeService.js 并实现 getThemeSet / getDefaultThemeKey
- [ ] 新建文件 `src/services/themeService.js`，导出 `themeService` 对象（或具名导出方法，与既有 `userService` 风格一致）
- [ ] 实现 `getThemeSet()`：返回 `BACKGROUND_THEMES` 数组（纯读常量，不抛异常）
- [ ] 实现 `getDefaultThemeKey()`：返回 `DEFAULT_THEME_KEY`（不抛异常）
- [ ] 验收标准：`themeService.getThemeSet()` 返回长度为 3 的数组；`themeService.getDefaultThemeKey()` 返回 `'nebula'`
- [ ] 验收标准：`node --check src/services/themeService.js` 通过

### 2.2 实现 getCurrentThemeKey 读取当前主题（含合法性兜底）
- [ ] 在 `themeService.js` 中实现 `getCurrentThemeKey()`：通过 `localStorageAdapter.getData()` 读取主数据，取 `data.user?.themeKey`
- [ ] 兜底逻辑：当 `user` 为 `null`、`themeKey` 缺失、非字符串、或不在 `BACKGROUND_THEMES` 的 `key` 集合内时，回退返回 `DEFAULT_THEME_KEY`
- [ ] 整个方法体外层 `try/catch`，任何异常均回退 `DEFAULT_THEME_KEY`，不外抛
- [ ] 验收标准：主数据 `user` 为 `null` 时返回 `'nebula'`；`user.themeKey` 为 `'dawn'` 时返回 `'dawn'`；`user.themeKey` 为 `'invalidXxx'` 时返回 `'nebula'`；`user.themeKey` 为 `undefined`/`123`/`''` 时返回 `'nebula'`
- [ ] 验收标准：方法无副作用，不写存储、不改 DOM

### 2.3 实现 applyTheme 切换 body class（含防注入校验）
- [ ] 在 `themeService.js` 中实现 `applyTheme(themeKey)`：先校验 `themeKey` 是否属于 `BACKGROUND_THEMES` 的 `key` 集合
- [ ] 合法时：`document.body.classList.remove('theme-nebula','theme-dawn','theme-cyber')`，再 `document.body.classList.add('theme-' + themeKey)`，返回 `true`
- [ ] 非法时：保持现状不动，返回 `false`
- [ ] 外层 `try/catch`，异常返回 `false`，不外抛
- [ ] 验收标准：调用 `applyTheme('dawn')` 后 `document.body.classList` 含 `theme-dawn` 且不含 `theme-nebula`/`theme-cyber`；调用 `applyTheme('hack<>')` 后 body class 不变且返回 `false`
- [ ] 验收标准：JS 永不拼接用户输入为 CSS 字符串，仅切换预定义 class token，从源头杜绝 CSS 注入

### 2.4 实现 saveTheme 持久化主题选择
- [ ] 在 `themeService.js` 中实现 `saveTheme(themeKey)`：返回 `{ success: boolean, error?: string }`
- [ ] 校验 `themeKey` 合法性，非法直接返回 `{success:false, error:'主题标识非法'}`
- [ ] 合法时：`localStorageAdapter.getData()` 读主数据；若 `data.user` 为 `null` 则初始化为默认资料对象 `{nickname:'', avatarKey:''}` 再写；将 `data.user.themeKey = themeKey`、`data.user.updatedAt = Date.now()`；调用 `localStorageAdapter.saveData(data)`
- [ ] 外层 `try/catch`，写入失败（如配额超限）返回 `{success:false, error:'保存失败'}`，不外抛
- [ ] 验收标准：调用 `saveTheme('cyber')` 后主数据 `user.themeKey === 'cyber'`；调用 `saveTheme('bad')` 返回 `{success:false}` 且主数据不变
- [ ] 验收标准：保存成功后既有 `goals/records/checkIns/camps/achievements` 字段保持原值不变（读取对比）

### 2.5 实现 applySavedTheme 启动恢复主题（含全量兜底）
- [ ] 在 `themeService.js` 中实现 `applySavedTheme()`：等价于 `applyTheme(getCurrentThemeKey())`，外层再包一层 `try/catch`，任何异常回退 `applyTheme(DEFAULT_THEME_KEY)`
- [ ] 验收标准：主数据 `user.themeKey='dawn'` 时调用后 body 含 `theme-dawn`；`user` 为 `null` 时 body 含 `theme-nebula`；模拟 `getCurrentThemeKey` 抛异常时 body 仍含 `theme-nebula` 且不外抛
- [ ] 验收标准：方法不修改任何业务数据字段（`goals/records/checkIns/camps/achievements`），无业务副作用
- [ ] 验收标准：`node --check src/services/themeService.js` 通过

---

## 3. 实现三套主题背景渐变样式

**写作指导**：本组为 body 主题渐变 CSS，独立于 JS 逻辑，被 `themeService.applyTheme` 切换的 class 依赖。可与任务组 2 并行，但须在任务组 5（启动接入）前完成。

### 3.1 在 main.css 中新增 body 主题渐变规则
- [ ] 在 `src/styles/main.css` 中 `body` 规则附近追加三条规则：`body.theme-nebula`、`body.theme-dawn`、`body.theme-cyber`
- [ ] 每条规则设置 `background` 为对应渐变表达式（与 `constants.js` 中 `gradient` 一致）、`background-image: none`（覆盖默认 body 的 radial-gradient 装饰层避免叠加）、`background-attachment: fixed`
- [ ] 具体取值：
  - `body.theme-nebula { background: linear-gradient(135deg, #4B0082 0%, #2D0A4E 45%, #0A0A1A 100%); background-image: none; background-attachment: fixed; }`
  - `body.theme-dawn { background: radial-gradient(circle at 30% 25%, #FFF8DC 0%, #FFD580 45%, #FF8C42 100%); background-image: none; background-attachment: fixed; }`
  - `body.theme-cyber { background: linear-gradient(135deg, #0B1E3F 0%, #0A4D8C 50%, #00E5FF 100%); background-image: none; background-attachment: fixed; }`
- [ ] 验收标准：浏览器中给 `body` 添加 `theme-nebula`/`theme-dawn`/`theme-cyber` class 后背景分别呈现深紫到黑对角渐变、淡黄到橙径向渐变、深蓝到青对角渐变
- [ ] 验收标准：三条规则均不含 `url()` 引用；网络面板无任何图片资源请求
- [ ] 验收标准：仅重写 `background`/`background-image`/`background-attachment`，不触碰 `color`/`font`/`margin` 等其他属性

---

## 4. 修改用户资料保存以保留主题选择

**写作指导**：本组修改既有 `userService.saveProfile`，防止保存昵称/头像时整体覆盖 `user` 导致 `themeKey` 丢失。依赖任务组 1（常量）概念，可与任务组 2、3 并行。

### 4.1 修改 saveProfile 重建 user 时保留既有 themeKey
- [ ] 定位 `src/services/userService.js` 中 `saveProfile` 方法（约 63-83 行），找到重建 `data.user = {nickname, avatarKey, updatedAt: Date.now()}` 的整体赋值语句
- [ ] 修改为：重建前读取旧 `data.user?.themeKey`，重建时写入 `{nickname, avatarKey, themeKey: 旧themeKey || DEFAULT_THEME_KEY, updatedAt: Date.now()}`，保留既有主题选择
- [ ] 在文件顶部引入 `DEFAULT_THEME_KEY`（从 `constants.js`）
- [ ] 验收标准：先调用 `themeService.saveTheme('cyber')` 设主题，再调用 `userService.saveProfile({nickname:'小明', avatarKey:'smile'})`，读取主数据 `user.themeKey` 仍为 `'cyber'`（未被清空）
- [ ] 验收标准：`saveProfile` 在 `user` 原本无 `themeKey` 时写入 `DEFAULT_THEME_KEY`（即 `'nebula'`），不写入 `undefined`/`null`
- [ ] 验收标准：`saveProfile` 既有校验逻辑（昵称长度、头像 key 合法性）与返回结构（`{success,data}`/`{success:false,errors}`）不变
- [ ] 验收标准：`node --check src/services/userService.js` 通过

---

## 5. 实现个人主页"更换背景"区域

**写作指导**：本组为视图层集成，依赖任务组 1（常量）、2（themeService）、3（body 样式）。包含预览区域样式与渲染交互两部分。须保证不影响既有昵称/头像区域。

### 5.1 在 main.css 中新增主题预览区域样式
- [ ] 在 `src/styles/main.css` 末尾追加预览区域样式：`.profile-theme-grid`、`.profile-theme-item`、`.profile-theme-preview`、`.profile-theme-name`、`.profile-theme-item:hover`、`.profile-theme-item.selected`
- [ ] 样式取值按 design.md 2.8 节：
  - `.profile-theme-grid`：`display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-top:8px;`
  - `.profile-theme-item`：圆角 `var(--radius-md)`、边框 `2px solid var(--color-border)`、`cursor:pointer`、`transition:all 0.2s ease`、`user-select:none`，复用 `.profile-avatar-item` 范式
  - `.profile-theme-preview`：`aspect-ratio:1; border-radius:var(--radius-sm);`（背景由 JS 内联 style 赋值，此处仅控制几何）
  - `.profile-theme-name`：`font-size:0.8rem; color:var(--color-text-light); text-align:center; margin-top:6px;`
  - `.profile-theme-item:hover`：`border-color:var(--color-primary); transform:translateY(-2px);`
  - `.profile-theme-item.selected`：`border-color:var(--color-primary); box-shadow:0 4px 12px rgba(76,175,80,0.2); transform:scale(1.03);`（与头像选中态一致）
- [ ] 追加响应式 `@media (max-width:768px)`：`.profile-theme-grid { grid-template-columns:repeat(3,1fr); gap:10px; }`
- [ ] 验收标准：预览区域呈三列等宽网格，每项含圆角预览块与居中名称；选中项有边框高亮与微缩放；hover 有上移反馈
- [ ] 验收标准：沿用既有 CSS 变量（`--radius-*`/`--color-*`），不引入新依赖

### 5.2 在 profileView.js 中新增 _renderThemeSection 渲染方法
- [ ] 在 `src/views/profileView.js` 中新增 `_renderThemeSection(formCard)` 方法（或挂到 view 对象上），入参为 `form-card` 容器
- [ ] 方法整体外层 `try/catch`，异常时跳过该区域（不 append），不影响昵称/头像区域渲染
- [ ] 渲染 DOM 结构：更换背景 label（沿用 `.form-label`，`marginTop:16px`）+ `.profile-theme-grid`；grid 内遍历 `themeService.getThemeSet()` 生成 `.profile-theme-item[data-key]`，每项含 `.profile-theme-preview`（`el.style.background = theme.gradient` 内联赋值）与 `.profile-theme-name`（中文名）
- [ ] 初始选中态：`themeService.getCurrentThemeKey()` 取当前主题，对应项加 `selected` class
- [ ] 每项绑定 click 事件调用 `_handleThemeSelect`
- [ ] 验收标准：调用后 `form-card` 内出现"更换背景"标题 + 三套预览（星云紫/晨曦黄/赛博蓝名称可见）+ 当前主题预览高亮选中
- [ ] 验收标准：预览背景为纯 CSS 渐变（内联 style），无图片资源加载
- [ ] 验收标准：渲染异常时昵称/头像区域仍正常可见，不白屏

### 5.3 在 profileView.js 中新增 _handleThemeSelect 点击切换处理
- [ ] 在 `src/views/profileView.js` 中新增 `_handleThemeSelect(themeKey, gridEl)` 方法
- [ ] 处理流程：读取 `themeKey` → `themeService.applyTheme(themeKey)` 立即切换 body 背景（点击即生效，无需点保存）→ `themeService.saveTheme(themeKey)` 持久化 → 选中态转移（`gridEl.querySelectorAll('.profile-theme-item').forEach(el=>el.classList.remove('selected'))`，当前项 `add('selected')`）→ `modal.toast('背景已切换')`
- [ ] 保存失败时：`modal.toast('保存失败，重启后可能无法恢复')`，但**不回滚** body 背景（保持已应用视觉，满足 spec 4.2.2）
- [ ] 验收标准：点击未选中主题预览后 body 背景立即变为该主题，选中高亮转移到该项，弹出"背景已切换"toast
- [ ] 验收标准：模拟 `saveTheme` 返回 `{success:false}` 时 toast 提示保存失败但 body 背景保持已切换状态不回滚
- [ ] 验收标准：点击切换后既有昵称、头像区域不受影响，打卡/储蓄营数据不变

### 5.4 在 profileView.render 中插入"更换背景"区域
- [ ] 定位 `src/views/profileView.js` 的 `render()` 方法，找到 `form-card` 内头像网格 `grid` 与保存按钮 `saveBtn` 的构建位置
- [ ] 在头像网格 append 之后、保存按钮 append 之前，调用 `_renderThemeSection(formCard)` 插入主题区域
- [ ] 不改动既有昵称 input、头像 grid、保存按钮的构建与 append 顺序
- [ ] 验收标准：打开 `#/profile` 后页面同时可见昵称输入、头像网格、"更换背景"区域、保存按钮，纵向排列互不遮挡
- [ ] 验收标准：既有 `_handleSave` 方法与保存按钮行为不变（保存昵称/头像仍正常）
- [ ] 验收标准：`node --check src/views/profileView.js` 通过

---

## 6. 接入应用启动自动应用主题

**写作指导**：本组修改 `main.js init()`，依赖任务组 2（themeService.applySavedTheme）与 3（body 样式）。须确保首屏背景先于路由渲染就绪，且不修改路由分支。

### 6.1 在 main.js init() 中插入 applySavedTheme 调用
- [ ] 定位 `src/main.js` 的 `init()` 方法（约 63-74 行），找到 `await localStorageAdapter.initData()` 之后、`achievementService.checkAndUnlock()` 与 `router()` 之前的位置
- [ ] 在 `initData()` 之后、`router()` 之前插入一行 `themeService.applySavedTheme();`
- [ ] 在文件顶部引入 `themeService`（从 `./services/themeService.js`）
- [ ] 验收标准：此前选择"星云紫"后重启应用，首屏加载完成后 body 背景即为星云紫主题（无白屏闪烁）
- [ ] 验收标准：未设置过主题时启动应用，首屏背景为默认主题（星云紫）
- [ ] 验收标准：主题数据损坏时启动应用，应用正常启动、背景为默认主题、首页内容完整可见、不白屏
- [ ] 验收标准：`router()` 函数体内所有 `if/else if` 路由分支匹配逻辑与顺序保持不变；`#/`、`#/camps`、`#/camp/new`、`#/settings`、`#/profile` 等既有路由均能正常渲染
- [ ] 验收标准：`node --check src/main.js` 通过

---

## 7. 集成验证与现有功能回归测试

**写作指导**：本组为集成与回归验证，依赖任务组 1-6 全部完成。重点验证不影响现有打卡、储蓄营、储蓄目标、存钱顾问、数据备份等功能。

### 7.1 验证主题切换不影响业务数据完整性
- [ ] 测试步骤：先准备含 goals/records/checkIns/camps/achievements 的主数据 → 进入 `#/profile` 点击切换主题为"赛博蓝" → 读取主数据对比
- [ ] 验收标准：切换后 `goals/records/checkIns/camps/achievements` 各字段值与切换前完全一致，仅 `user.themeKey` 变为 `'cyber'`、`user.updatedAt` 更新
- [ ] 验收标准：切换主题后打卡功能正常（能新增/查看打卡），储蓄营功能正常（能查看/加入/创建营），储蓄目标功能正常（能查看/新增目标）

### 7.2 验证启动应用主题不影响业务启动
- [ ] 测试步骤：设置 `user.themeKey='dawn'` → 刷新应用 → 观察首屏
- [ ] 验收标准：首屏背景为晨曦黄主题，首页内容（hero/stats/motivation 等）完整可见且可读性良好
- [ ] 验收标准：`achievementService.checkAndUnlock()`、`advisorView.mount()` 仍正常执行（成就解锁、存钱顾问挂载不受影响）
- [ ] 验收标准：启动到首屏可见时间增量不超过 50ms（仅一次内存读 + 一次 classList 切换）

### 7.3 验证用户资料保存不丢失主题
- [ ] 测试步骤：选择主题"赛博蓝" → 修改昵称为"测试用户" → 点击保存 → 刷新应用
- [ ] 验收标准：刷新后背景仍为赛博蓝主题，`user.themeKey==='cyber'`，`user.nickname==='测试用户'`（主题与昵称均保留）
- [ ] 验收标准：修改头像后保存，主题同样不丢失

### 7.4 验证数据备份导出导入兼容主题字段
- [ ] 测试步骤：选择主题"晨曦黄" → 调用 `backupService.exportData()` 导出 → 清空数据 → 调用 `backupService.applyImport(导出数据)` 导入 → 刷新
- [ ] 验收标准：导入后 `user.themeKey==='dawn'`，背景恢复为晨曦黄主题
- [ ] 验收标准：备份文件结构未被破坏（既有字段齐全）

### 7.5 验证数据清空一并清除主题
- [ ] 测试步骤：选择主题"赛博蓝" → 调用 `clearAllData()` 清空 → 观察 `location.reload()` 后状态
- [ ] 验收标准：清空后主数据被移除，重新初始化后 `user` 为 `null`，`applySavedTheme` 回退默认主题（星云紫），背景为星云紫

### 7.6 验证异常兜底不白屏
- [ ] 测试步骤：手动篡改 localStorage `dream_saving_camp_data` 中 `user.themeKey` 为 `'invalidTheme'` → 刷新应用
- [ ] 验收标准：应用正常启动，背景回退为默认主题（星云紫），不报错不白屏，个人主页默认主题预览高亮
- [ ] 测试步骤：篡改 `user.themeKey` 为数字 `123` 或 `null` → 刷新
- [ ] 验收标准：同上，回退默认主题不白屏
- [ ] 测试步骤：模拟个人主页"更换背景"区域渲染抛异常
- [ ] 验收标准：昵称/头像区域正常可见，"更换背景"区域缺失或显示兜底提示，不白屏

### 7.7 验证可读性与排版美观
- [ ] 测试步骤：分别在星云紫/晨曦黄/赛博蓝主题下查看首页、储蓄营、打卡、存钱顾问、个人主页、设置等所有页面
- [ ] 验收标准：各页面文字与控件清晰可读，无内容溢出、遮挡或白屏；个人主页"更换背景"区域与昵称/头像区域间距协调，沿用 Minimalist Modern 视觉
- [ ] 验收标准：切换主题延迟 < 100ms（点击即生效，无明显卡顿）

---

## 8. 部署配置与数据兼容确认

**写作指导**：本应用为纯前端 vanilla JS + localStorage，无后端部署。本组确认数据兼容性与配置项，确保历史数据平滑升级。

### 8.1 确认历史数据兼容性
- [ ] 测试步骤：构造旧版主数据（`user` 为 `{nickname, avatarKey, updatedAt}`，无 `themeKey` 字段）写入 localStorage → 刷新应用
- [ ] 验收标准：应用正常启动，背景为默认主题（星云紫），不报错不要求手动迁移；个人主页默认主题预览高亮
- [ ] 验收标准：旧数据中 `goals/records/checkIns/camps/achievements` 等业务字段正常读取，功能可用

### 8.2 确认不新增 localStorage 键与存储体系一致
- [ ] 检查 `src/constants.js` 的 `STORAGE_KEYS` 与 `APP_DATA_KEYS` 未新增任何键
- [ ] 验收标准：主题选择仅存于 `dream_saving_camp_data` 的 `user.themeKey`，不独立使用新键；与既有数据备份/清空机制一致

### 8.3 确认不修改 index.html 与路由
- [ ] 对比 `index.html` 修改前后无差异（git diff 为空）
- [ ] 验收标准：`index.html` 未被修改；`main.js router()` 路由分支匹配逻辑与顺序不变，仅 `init()` 内新增一行 `applySavedTheme()` 调用

---

## 9. 审查与最终验证

**写作指导**：本组为交付前最终核对，确保设计与实现一致、约束全部满足。

### 9.1 代码审查
- [ ] 审查 `src/services/themeService.js`：所有方法均有 `try/catch` 兜底，不外抛导致白屏；`applyTheme` 不拼接用户输入为 CSS 字符串
- [ ] 审查 `src/services/userService.js`：`saveProfile` 保留 `themeKey` 逻辑正确，既有校验与返回结构不变
- [ ] 审查 `src/views/profileView.js`：`_renderThemeSection` 独立 `try/catch`，异常不影响既有区域；`_handleThemeSelect` 先 apply 再 save，失败不回滚
- [ ] 审查 `src/main.js`：仅 `init()` 插入一行，`router()` 不变
- [ ] 审查 `src/styles/main.css`：三套 body 主题渐变与预览区域样式均用纯 CSS 渐变，无 `url()`
- [ ] 验收标准：所有新增/修改文件通过 `node --check` 语法检查

### 9.2 设计与实现一致性核对
- [ ] 核对 design.md 2.10 节"新增/修改文件清单"中 6 个文件均已按设计修改/新增
- [ ] 核对 design.md 2.4 节三套主题渐变表达式与 `constants.js`/`main.css` 中定义一致
- [ ] 核对 design.md 2.2.2 节 6 个接口签名与 `themeService.js` 实现一致
- [ ] 验收标准：设计文档与代码实现完全对应，无遗漏

### 9.3 约束条件最终确认
- [ ] 确认数据均通过 `localStorageAdapter.js` 存取（grep 检查新增代码无直接 `localStorage.setItem/getItem` 调用）
- [ ] 确认未修改 `index.html`、未修改 `main.js` 路由分支
- [ ] 确认未引入图片文件、未引入第三方依赖
- [ ] 确认所有新增逻辑有异常兜底，不白屏
- [ ] 验收标准：全局约束 8 条全部满足

### 9.4 变更范围确认
- [ ] 确认变更文件清单：`src/constants.js`（追加常量）、`src/services/themeService.js`（新增）、`src/services/userService.js`（修改 1 处）、`src/views/profileView.js`（追加方法 + render 内插入）、`src/main.js`（插入 1 行）、`src/styles/main.css`（追加规则）
- [ ] 确认未变更：`index.html`、`src/storage/localStorageAdapter.js`、`src/services/backupService.js`、其他业务 service/view
- [ ] 验收标准：变更范围与 design.md 2.10 节一致，无越界修改