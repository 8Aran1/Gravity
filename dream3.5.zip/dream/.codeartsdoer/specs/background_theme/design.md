# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 复用 `#/profile` 路由进入个人主页 | `main.js` 已存在 `#/profile` 分支并调用 `profileView.render()` | `src/main.js:28-29` | 100% |
| 个人主页既有昵称/头像区域不被破坏 | `profileView.render()` 已渲染昵称输入 + 12 项 Emoji 头像网格 + 保存按钮，外层 `try/catch` 兜底 | `src/views/profileView.js:6-85` | 100% |
| 主题数据存于主数据 `user` 字段并与既有资料共存 | `localStorageAdapter` 统一管理主数据 `dream_saving_camp_data`，`user` 字段已用于 `{nickname, avatarKey, updatedAt}` | `src/storage/localStorageAdapter.js:5-15, 87` | 75% |
| 切换主题时弹出轻量提示 | `modal.toast(message)` 已实现 toast 提示 | `src/views/modal.js:53-67` | 100% |
| 主题随数据备份导出/导入、随清空一并清除 | `backupService.exportData()` 直接读取整个主数据（含 `user`），`clearAllData()` 移除全部 `APP_DATA_KEYS` | `src/services/backupService.js:37-50, 87-96` | 100% |
| 沿用 Minimalist Modern 视觉与 CSS 变量 | `main.css` `:root` 已定义 `--color-*`、`--radius-*`、`--shadow-*`、`--ease-out` 等变量，`.form-card`/`.profile-avatar-*` 已有圆角卡片与网格选中态范式 | `src/styles/main.css:1-27, 524-532, 2039-2064` | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 在 `user` 对象中新增 `themeKey` 字段并持久化 | `userService.saveProfile()` 写入 `data.user = {nickname, avatarKey, updatedAt}`，整体覆盖 `user` | `saveProfile` 用整体赋值重建 `user`，未保留任何额外字段；若直接在 `user` 上加 `themeKey`，下次保存资料时会被清空 | 修改 `saveProfile`：重建 `user` 时保留既有 `themeKey`（与 `updatedAt` 一并写入），不引入新 localStorage 键 |
| `localStorageAdapter` 兜底历史数据时兼容 `user.themeKey` | `initData()` 末尾 `if(!cache.user) cache.user=null` | 仅保证 `user` 字段存在，不感知 `themeKey` | 无需改 `initData`：`user` 为 `null` 或不含 `themeKey` 时由 `themeService` 读取层兜底默认主题，存储层保持中立 |
| 应用启动时自动应用已保存主题 | `main.js` `init()` 在 `initData()` 后依次执行 `achievementService.checkAndUnlock()` → `advisorView.mount()` → `router()` | 启动流程无主题应用环节；`router()` 渲染首屏前 body 仍为 CSS 默认背景 | 在 `init()` 中 `initData()` 之后、`router()` 之前插入一次 `themeService.applySavedTheme()`，使首屏背景先就绪 |
| 个人主页新增"更换背景"区域 | `profileView.render()` 仅渲染昵称 + 头像 + 保存按钮 | 无主题预览区域 | 在头像网格之后、保存按钮之前插入"更换背景"区块（标题 + 三预览 + 选中态 + 点击即生效） |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**A. 常量层（`src/constants.js`）**
- `BACKGROUND_THEMES`：预设主题集合常量，固定 3 套（星云紫 / 晨曦黄 / 赛博蓝），每套含 `key`、`name`、`gradient`（CSS 渐变表达式）、`type`（linear/radial）、`isDefault`。
- `DEFAULT_THEME_KEY`：默认主题标识，指向集合中 `isDefault:true` 的项。
- 依赖：无外部模块，仅被 `themeService` 与 `profileView` 引用。

**B. 主题服务层（`src/services/themeService.js`，新增文件）**
- `getThemeSet()`：返回预设主题集合（用于视图渲染预览）。
- `getDefaultThemeKey()`：返回默认主题标识。
- `getCurrentThemeKey()`：从主数据 `user.themeKey` 读取当前主题，非法或缺失时回退默认。
- `applyTheme(themeKey)`：校验合法性后，将对应主题 class 切换到 `document.body`，立即生效。
- `applySavedTheme()`：读取已持久化主题并应用，供启动调用；内部全量 `try/catch`，异常回退默认。
- `saveTheme(themeKey)`：将合法 `themeKey` 写入主数据 `user.themeKey` 并持久化，返回 `{success}`。
- 依赖：`localStorageAdapter`、`constants`（`BACKGROUND_THEMES`、`DEFAULT_THEME_KEY`）。

**C. 视图层（`src/views/profileView.js`，扩展）**
- `_renderThemeSection()`：渲染"更换背景"区域（标题 + 三预览卡片 + 选中高亮 + 点击切换）。
- `_handleThemeSelect(themeKey)`：点击预览的处理逻辑（校验 → 应用 → 持久化 → 选中态转移 → toast）。

**D. 样式层（`src/styles/main.css`，扩展）**
- `.profile-theme-grid` / `.profile-theme-item` / `.profile-theme-preview` / `.profile-theme-name` / `.profile-theme-item.selected`：主题预览区域样式。
- `body.theme-nebula` / `body.theme-dawn` / `body.theme-cyber`：三套主题的 body 背景渐变规则。

## 1.2 存量功能详细分析

### 1.2.1 `userService.saveProfile`（`src/services/userService.js:63-83`）

- **接口契约**：入参 `{nickname, avatarKey}`；出参 `{success, data}` 或 `{success:false, errors}` 或 `{success:false, error}`。副作用：整体覆盖 `data.user` 为 `{nickname, avatarKey, updatedAt: Date.now()}` 后调用 `localStorageAdapter.saveData(data)`。
- **业务规则**：先 `validate` 校验昵称长度与头像 key 合法性，任一不通过即返回 `errors` 不写存储；通过后整体重建 `user` 对象。
- **扩展点**：无显式扩展点，但重建 `user` 时可通过读取旧 `data.user` 携带额外字段。
- **约束**：**整体覆盖语义**是本设计的关键约束——任何挂在 `user` 上的新字段（如 `themeKey`）必须在 `saveProfile` 重建时显式保留，否则会被清空。本设计选择在 `saveProfile` 内保留 `themeKey`（读取旧值或当前已应用值），保证用户保存昵称/头像时不丢失主题选择。

### 1.2.2 `localStorageAdapter`（`src/storage/localStorageAdapter.js`）

- **接口契约**：`initData()`（async，返回 cache）、`getData()`（同步返回 cache 或空数据）、`saveData(data)`（同步，写 cache 并异步 fetch 同步，返回 true）、`read/write/remove`（底层 localStorage 操作）。
- **业务规则**：`initData()` 优先读本地 `dream_saving_camp_data`，无则 fetch API 兜底，再无则 `getEmptyData()`；末尾 `if(!cache.user) cache.user=null` 保证 `user` 字段存在。`saveData` 写入时统一带 `_version`。
- **约束**：`saveData` 的 `fetch(API_URL).catch(()=>{})` 在纯前端无后端环境下会失败被吞掉，但 `localStorage.setItem` 在 `write` 中已先行执行——实际持久化以本地为准，符合"纯前端 vanilla JS + localStorage"技术栈。
- **对本设计的影响**：主题字段挂在 `user` 上即可随主数据被 `getData/saveData` 统一管理，无需新增存储键，天然满足"与既有数据共存于同一存储体系"。

### 1.2.3 `profileView.render`（`src/views/profileView.js:6-85`）

- **接口契约**：无入参，副作用为清空 `#app` 并挂载个人主页 DOM。外层 `try/catch`，异常时渲染兜底错误页（含"返回首页"按钮）。
- **业务规则**：DOM 结构为 `page.page-container.profile-page > backLink + form-title + form-card`；`form-card` 内依次为昵称 label/input、头像 label/grid、保存按钮。`selectedAvatarKey` 为闭包内可变状态，点击头像项即时更新选中态，但**不立即持久化**，需点击"保存"才写存储。
- **扩展点**：`form-card` 内子节点按追加顺序渲染，可在头像网格与保存按钮之间插入新区域。`_handleSave` 为独立方法，可继续保留。
- **约束**：主题切换的"点击即生效"语义（spec 5.1.1.6）与既有头像"点击仅改选中态、保存才生效"不同——主题预览点击需立即应用并持久化，不复用 `_handleSave` 流程，需独立处理函数。

### 1.2.4 `main.js init()`（`src/main.js:63-74`）

- **接口契约**：无入参，应用入口。`await initData()` → `achievementService.checkAndUnlock()` → `advisorView.mount()` → `router()` → 监听 `hashchange`。
- **约束**：spec 4.4.3 / 5.1.1.12 明确"禁止修改 `index.html` 与 `main.js` 既有路由分支的匹配逻辑与顺序"。`init()` 内的初始化语句**不属于路由分支**，可在其中插入主题应用调用而不违反约束。插入点选在 `initData()` 之后、`router()` 之前，使首屏背景先于路由渲染就绪，满足 spec 5.2.1.3"主题应用须在路由渲染前或同时完成"。

### 1.2.5 `main.css` body 背景（`src/styles/main.css:35-44`）

- **现状**：`body` 当前 `background: var(--color-bg); background-image: radial-gradient(...)` + `background-attachment: fixed`，为浅色默认氛围。
- **约束**：spec 1.4.2 限定"仅作用于 body 的背景属性"。本设计采用 `body.theme-<key>` class 切换方案：class 规则中重写 `background` 与 `background-image`（覆盖默认），不触碰 `color`/`font` 等其他属性。页面内容均位于 `.page-container`/`.form-card`/`.home-*` 等自带 `--color-card` 白底或半透明底的容器内，body 背景仅作为氛围透出，文字可读性由容器自身底色保证，满足 spec 5.3.1.6。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用使用者" as User
rectangle "dream 应用" {
  rectangle "main.js\n(init 启动流程)" as Main
  rectangle "profileView.js\n(个人主页)" as Profile
  rectangle "themeService.js\n(主题服务)" as Theme
  rectangle "userService.js\n(用户资料)" as UserSvc
}
storage "localStorageAdapter\n(主数据 user 字段)" as Storage

User --> Profile : 进入 #/profile\n点击主题预览
User --> Main : 打开应用
Main --> Theme : applySavedTheme()\n(启动时一次)
Profile --> Theme : applyTheme()\nsaveTheme()
Theme --> Storage : getData/saveData\n(读写 user.themeKey)
UserSvc --> Storage : saveProfile\n(保留 themeKey)
Storage --> Theme : user.themeKey 或空
Theme --> Main : body.classList 切换\n(返回 void)
@enduml
```

- 上游调用方：`main.js init()`（启动时一次）、`profileView`（用户点击切换时）。
- 下游依赖：`localStorageAdapter`（读写主数据 `user.themeKey`）、`constants`（主题集合与默认 key）。
- 调用频率：启动 1 次 + 用户每次点击预览 1 次；纯本地 DOM 与 localStorage 操作，无网络、无中间件。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
package "constants.js" {
  object "BACKGROUND_THEMES\n(3 套预设)" as ConstThemes
  object "DEFAULT_THEME_KEY" as ConstDefault
}
package "themeService.js (新增)" {
  object "getThemeSet()" as TS_getSet
  object "getDefaultThemeKey()" as TS_getDef
  object "getCurrentThemeKey()" as TS_getCur
  object "applyTheme(key)" as TS_apply
  object "applySavedTheme()" as TS_applySaved
  object "saveTheme(key)" as TS_save
}
package "userService.js (扩展)" {
  object "saveProfile()\n保留 themeKey" as US_save
}
package "profileView.js (扩展)" {
  object "_renderThemeSection()" as PV_section
  object "_handleThemeSelect(key)" as PV_handle
}
package "main.js (扩展 init)" {
  object "init()\n插入 applySavedTheme()" as M_init
}
package "main.css (扩展)" {
  object "body.theme-*\n(3 套渐变)" as CSS_body
  object ".profile-theme-*\n(预览区域)" as CSS_preview
}

ConstThemes --> TS_getSet
ConstDefault --> TS_getDef
TS_getCur --> Storage
TS_apply --> CSS_body
TS_save --> Storage
PV_section --> TS_getSet
PV_section --> TS_getCur
PV_handle --> TS_apply
PV_handle --> TS_save
M_init --> TS_applySaved
US_save --> Storage
@enduml
```

模块划分与职责：

| 模块 | 职责 | 新增/修改 |
|------|------|----------|
| `constants.js` | 集中定义预设主题集合与默认主题 key | 修改（追加常量） |
| `themeService.js` | 主题合法性校验、读取、应用（切换 body class）、持久化 | 新增 |
| `userService.js` | `saveProfile` 重建 `user` 时保留 `themeKey` | 修改（1 处） |
| `profileView.js` | 渲染"更换背景"区域 + 点击切换处理 | 修改（追加方法 + render 内插入） |
| `main.js` | `init` 中启动时应用已保存主题 | 修改（插入 1 行调用） |
| `main.css` | 三套 body 主题渐变 + 预览区域样式 | 修改（追加规则） |

配置项及取值策略：预设主题集合为编译期常量，运行期不可变；默认主题取 `BACKGROUND_THEMES` 中 `isDefault:true` 项的 `key`，由 `DEFAULT_THEME_KEY` 显式声明并与之交叉校验。

### 2.1.3 实现设计文档

**主题状态机（无持久业务状态，仅 body class 与 user.themeKey 两态同步）**

```plantuml
@startuml
hide empty description
state "未应用" as Unapplied
state "已应用 themeKey" as Applied

[*] --> Unapplied : 启动 init()
Unapplied --> Applied : applySavedTheme()\n读取 user.themeKey\n(合法) 或回退默认
Applied --> Applied : applyTheme(newKey)\n(点击切换)\n校验合法 → 切 class + 写 user.themeKey
Applied --> Applied : applyTheme(非法)\n忽略，保持当前
Unapplied --> Applied : applyTheme(key)\n(直接调用，兜底)
@enduml
```

**点击切换流程分支（`_handleThemeSelect`）**

```plantuml
@startuml
start
:用户点击某主题预览;
:读取 themeKey = dataset.key;
if (themeKey 属于预设集合?) then (yes)
  :applyTheme(themeKey)\n切换 body class;
  :saveTheme(themeKey)\n写 user.themeKey;
  if (保存成功?) then (yes)
    :选中态转移到该项;
    :modal.toast("背景已切换");
  else (no)
    :保持已应用背景不回滚;
    :modal.toast("保存失败，重启后可能无法恢复");
  endif
else (no)
  :忽略点击\n(理论上不会触发，因预览仅渲染合法项);
endif
stop
@enduml
```

**启动应用主题异常兜底（`applySavedTheme`）**

```plantuml
@startuml
start
:applySavedTheme() 被调用;
try
  :key = getCurrentThemeKey()\n(内部已 try/catch 回退默认);
  :applyTheme(key);
catch (任意异常)
  :applyTheme(DEFAULT_THEME_KEY);
endtry
stop
@enduml
```

- 扩展点：`BACKGROUND_THEMES` 为常量数组，未来新增主题只需追加一项（新 `key`，不复用废弃 `key`），`themeService` 与 `profileView` 自动适配，满足 spec 6.2.6 稳定性要求。
- 事务设计：主题应用（DOM class 切换）与持久化（写 localStorage）为两次独立操作。spec 4.2.2 要求"写入失败时已应用背景不回滚"——故先 `applyTheme`（DOM 已变）再 `saveTheme`，`saveTheme` 失败仅 toast 提示，不调用 `applyTheme` 回退，保证视觉一致性。

## 2.2 接口设计

### 2.2.1 总体设计

接口分类依据：按"读 / 写 / 应用"三类职责划分。所有接口均为同步（除底层 `saveData` 内部异步 fetch 被吞掉外，localStorage 写入同步完成）。无接口继承体系。接口变更策略：`themeService` 为新增模块，首版即稳定；后续只允许向 `BACKGROUND_THEMES` 追加主题，不修改既有方法签名。

| 接口 | 所属模块 | 稳定性 | 调用方 |
|------|---------|--------|--------|
| `getThemeSet()` | themeService | 稳定 | profileView |
| `getDefaultThemeKey()` | themeService | 稳定 | themeService 内部 |
| `getCurrentThemeKey()` | themeService | 稳定 | profileView、themeService |
| `applyTheme(key)` | themeService | 稳定 | profileView、themeService |
| `applySavedTheme()` | themeService | 稳定 | main.js |
| `saveTheme(key)` | themeService | 稳定 | profileView |

### 2.2.2 接口清单

#### themeService.getThemeSet()

- **接口签名**：`getThemeSet(): BackgroundTheme[]`，其中 `BackgroundTheme = { key: string, name: string, gradient: string, type: 'linear'|'radial', isDefault: boolean }`
- **业务说明**：返回预设主题集合（3 套），供视图渲染预览卡片。
- **前置条件**：无。
- **后置条件**：无副作用，纯读常量。
- **异常映射**：不抛异常。
- **调用示例**：
```js
import { themeService } from '../services/themeService.js';
const themes = themeService.getThemeSet();
for (const t of themes) { /* 渲染预览，使用 t.gradient 作为预览背景 */ }
```

#### themeService.getDefaultThemeKey()

- **接口签名**：`getDefaultThemeKey(): string`
- **业务说明**：返回默认主题标识（`DEFAULT_THEME_KEY`）。
- **前置条件**：无。
- **后置条件**：无副作用。
- **异常映射**：不抛异常。

#### themeService.getCurrentThemeKey()

- **接口签名**：`getCurrentThemeKey(): string`
- **业务说明**：从主数据 `user.themeKey` 读取当前主题；`user` 为 `null`、`themeKey` 缺失、非字符串、不在预设集合内时，回退默认主题 key。
- **前置条件**：`localStorageAdapter.initData()` 已执行（`getData()` 可用）。
- **后置条件**：无副作用（不写存储、不改 DOM）。
- **异常映射**：内部全量 `try/catch`，任何异常回退默认 key，不外抛。
- **调用示例**：
```js
const current = themeService.getCurrentThemeKey(); // 'nebula' | 'dawn' | 'cyber'
```

#### themeService.applyTheme(themeKey)

- **接口签名**：`applyTheme(themeKey: string): boolean`
- **业务说明**：校验 `themeKey` 合法性；合法则移除 `body` 上所有 `theme-*` class 并添加 `theme-<key>`，返回 `true`；非法则保持现状返回 `false`。
- **前置条件**：`document.body` 存在（DOM 就绪）。
- **后置条件**：`body.classList` 仅含一个 `theme-*` class（对应已应用主题）；不写存储。
- **异常映射**：内部 `try/catch`，异常返回 `false`，不外抛。
- **调用示例**：
```js
themeService.applyTheme('nebula'); // body 获得 class "theme-nebula"
```

#### themeService.applySavedTheme()

- **接口签名**：`applySavedTheme(): void`
- **业务说明**：读取已持久化主题并应用，供启动调用。等价于 `applyTheme(getCurrentThemeKey())`，外层再包一层 `try/catch` 兜底默认。
- **前置条件**：`localStorageAdapter.initData()` 已执行；DOM 就绪。
- **后置条件**：`body` 必定含一个 `theme-*` class（要么已保存主题，要么默认）。
- **异常映射**：不外抛，任何异常均回退默认主题并应用。
- **调用示例**：
```js
await localStorageAdapter.initData();
themeService.applySavedTheme(); // 首屏背景就绪
router();
```

#### themeService.saveTheme(themeKey)

- **接口签名**：`saveTheme(themeKey: string): { success: boolean, error?: string }`
- **业务说明**：校验 `themeKey` 合法；合法则读取主数据，将 `user.themeKey` 与 `user.updatedAt` 写入（`user` 为 `null` 时初始化为默认资料对象再写 `themeKey`），调用 `localStorageAdapter.saveData` 持久化。非法或写入失败返回 `{success:false}`。
- **前置条件**：`localStorageAdapter.initData()` 已执行。
- **后置条件**：成功时主数据 `user.themeKey` 等于入参；失败时主数据不变。
- **异常映射**：内部 `try/catch`，返回 `{success:false, error}`，不外抛。
- **调用示例**：
```js
const r = themeService.saveTheme('cyber');
if (!r.success) modal.toast(r.error || '保存失败');
```

## 2.3 数据模型

### 2.3.1 设计目标

- 支持业务场景：三套预设主题的选择、持久化、启动恢复、合法性兜底。
- 性能/容量：主题选择仅一个字符串字段（`themeKey`）+ 一个时间戳（`updatedAt`），增量 < 100 字节，对 localStorage 容量无感。
- 扩展性：新增主题只需追加常量项，数据模型不变。
- 与存量数据兼容：`user` 对象新增 `themeKey` 字段，旧数据无该字段时读取层回退默认，不要求迁移；`saveProfile` 重建 `user` 时保留已有 `themeKey`，保证保存昵称/头像不丢失主题。

### 2.3.2 模型实现

```plantuml
@startuml
class BackgroundTheme <<常量>> {
  + key : string
  + name : string
  + gradient : string
  + type : "linear" | "radial"
  + isDefault : boolean
}

class User "主数据 user 字段" {
  + nickname : string
  + avatarKey : string
  + themeKey : string
  + updatedAt : number
}

class BackgroundThemeChoice "逻辑视图" {
  + themeKey : string
  + updatedAt : number
}

BackgroundThemeChoice --> BackgroundTheme : themeKey ∈ {key}
User ..> BackgroundThemeChoice : user.themeKey 投影

note right of User
  旧数据: {nickname, avatarKey, updatedAt}
  新数据: {nickname, avatarKey, themeKey, updatedAt}
  读取层对缺失 themeKey 回退默认，不报错
end note
@enduml
```

- **核心领域对象**：
  - `BackgroundTheme`（常量）：预设主题定义，含 `key`/`name`/`gradient`/`type`/`isDefault`，集合固定 3 项。
  - `User`（主数据 `user` 字段）：既有 `{nickname, avatarKey, updatedAt}` 扩展为 `{nickname, avatarKey, themeKey, updatedAt}`。`themeKey` 为可选字段（旧数据缺失），读取层兜底。
  - `BackgroundThemeChoice`（逻辑视图）：`{themeKey, updatedAt}`，由 `themeService` 读写，不单独建表，投影自 `User`。
- **对象关系**：`BackgroundThemeChoice.themeKey` 取值约束于 `BackgroundTheme.key` 集合（外键式约束，由 `themeService` 校验保证）。
- **创建/销毁策略**：`themeKey` 在用户首次点击主题预览时创建；`clearAllData` 移除整个主数据（含 `user`），主题随之清除，由 `location.reload()` 触发重新初始化回退默认。
- **持久化策略**：挂在主数据 `user` 字段上，随 `localStorageAdapter.saveData` 一并写入 `dream_saving_camp_data`；不新增 localStorage 键；随 `backupService.exportData/applyImport` 自动导出导入（因备份读写整个主数据）。

## 2.4 三套主题 CSS 渐变定义

| 主题 | key | 中文名 | 渐变类型 | CSS 渐变表达式 | 氛围 |
|------|-----|--------|---------|--------------|------|
| 星云紫 | `nebula` | 星云紫 | 对角线性渐变 | `linear-gradient(135deg, #4B0082 0%, #2D0A4E 45%, #0A0A1A 100%)` | 深紫到黑，深邃神秘宇宙感 |
| 晨曦黄 | `dawn` | 晨曦黄 | 径向渐变 | `radial-gradient(circle at 30% 25%, #FFF8DC 0%, #FFD580 45%, #FF8C42 100%)` | 淡黄到橙，温暖清晨感 |
| 赛博蓝 | `cyber` | 赛博蓝 | 对角线性渐变 | `linear-gradient(135deg, #0B1E3F 0%, #0A4D8C 50%, #00E5FF 100%)` | 深蓝到青，冷峻科技感 |

- **默认主题**：`nebula`（星云紫，`isDefault: true`），与"梦想储蓄"的深邃宇宙意象契合。
- **纯 CSS 实现**：三套均为 CSS 原生渐变表达式，无 `url()`、无图片、无 base64，满足 spec 5.1.1.5 与 4.3.4。
- **可读性保障**：三套渐变仅作用于 `body` 背景；页面内容容器（`.form-card` 白底、`.home-hero` 自带渐变、`.home-stats`/`.home-motivation` 等均自带底色）覆盖在 body 之上，文字色 `--color-text` 在容器底色上保持原有对比度，不因 body 背景变化而不可读。`background-attachment: fixed` 保持氛围稳定不随滚动。

## 2.5 动态修改 body 背景的实现方案

**方案选择：切换 `body` class（`document.body.classList`），不直接 `style.background`。**

- **理由**：
  1. class 方案将渐变定义集中在 CSS（`body.theme-nebula` 等规则），JS 只负责切换 token，符合 spec 4.4.2"渐变样式集中定义"与 4.3.2"禁止将用户输入作为 CSS 原样注入"——JS 永不拼接 CSS 字符串，仅切换预定义 class，从源头杜绝 CSS 注入。
  2. 预览卡片可复用同一渐变表达式（通过 CSS 变量或直接引用同款 gradient），保证"预览即所用"。
  3. 主题切换为 class 增删，浏览器样式重算开销极小，满足 spec 4.1.1"延迟 < 100ms"。
- **实现要点**：
  - `applyTheme(key)` 中：先 `body.classList.remove('theme-nebula','theme-dawn','theme-cyber')`，再 `body.classList.add('theme-' + key)`。
  - CSS 中 `body.theme-nebula { background: <渐变>; background-image: none; background-attachment: fixed; }`（`background-image:none` 覆盖默认 `body` 的 radial-gradient 装饰，避免叠加）。
  - `key` 在拼入 class 前必须通过 `BACKGROUND_THEMES` 集合校验，非法 key 不执行拼接，双重防注入。

## 2.6 在 profileView.js 中集成"更换背景"区域

- **位置**：在 `profileView.render()` 的 `form-card` 内，头像网格 `grid` 之后、保存按钮 `saveBtn` 之前插入。即与昵称、头像同属一张卡片，纵向排列，互不遮挡（满足 spec 5.3.1.1）。
- **DOM 结构**：
```
form-card
  ├─ 昵称 label + input（既有）
  ├─ 头像 label + profile-avatar-grid（既有）
  ├─ 更换背景 label（新增，marginTop:16px，沿用 .form-label）
  ├─ profile-theme-grid（新增）
  │    ├─ profile-theme-item[data-key="nebula"]
  │    │    ├─ profile-theme-preview（背景=星云紫渐变）
  │    │    └─ profile-theme-name "星云紫"
  │    ├─ profile-theme-item[data-key="dawn"] ...
  │    └─ profile-theme-item[data-key="cyber"] ...
  └─ 保存按钮（既有）
```
- **预览卡片**：每项 `.profile-theme-item` 内含一个 `.profile-theme-preview`（aspect-ratio:1，圆角，背景设为该主题 `gradient`，直观呈现"预览即所用"）与 `.profile-theme-name`（中文名）。选中态复用既有 `.selected` 范式（边框高亮 + 轻微缩放），与头像选中态视觉一致，沿用 Minimalist Modern。
- **点击切换逻辑**（`_handleThemeSelect`）：
  1. 读取 `dataset.key`。
  2. `themeService.applyTheme(key)` 立即切换 body 背景（spec 5.1.1.6 点击即生效，无需点保存）。
  3. `themeService.saveTheme(key)` 持久化；失败时 toast 提示但**不回滚** body 背景（spec 4.2.2）。
  4. 选中态转移：`grid.querySelectorAll('.profile-theme-item').forEach(el => el.classList.remove('selected'))`，当前项 `add('selected')`。
  5. `modal.toast('背景已切换')` 轻量反馈。
- **初始选中态**：渲染时 `themeService.getCurrentThemeKey()` 取当前主题，对应项加 `.selected`。
- **异常兜底**：`_renderThemeSection` 整体 `try/catch`，异常时跳过该区域（不 append），不影响昵称/头像区域渲染（spec 5.3.3.1）。

## 2.7 应用启动时自动应用已保存主题

- **文件**：`src/main.js`。
- **时机**：`init()` 中 `await localStorageAdapter.initData()` 之后、`achievementService.checkAndUnlock()` 与 `router()` 之前。插入 `themeService.applySavedTheme()` 一行调用。
- **理由**：
  1. `initData()` 已完成，`getData()` 可用，`themeService` 能读到 `user.themeKey`。
  2. 在 `router()` 之前应用，body 背景先于首屏内容就绪，避免"先白屏后背景闪烁"（spec 5.2.1.3）。
  3. 在 `achievementService.checkAndUnlock()` 之前不影响其逻辑（主题应用无副作用，spec 5.2.1.4）。
- **异常兜底**：`applySavedTheme` 内部全量 `try/catch`，任何异常回退默认主题并应用，不外抛、不阻塞后续 `router()`（spec 5.2.3.1）。
- **不修改路由分支**：仅 `init()` 内插入一行初始化调用，`router()` 函数内所有 `if/else if` 路由分支匹配逻辑与顺序保持不变（spec 4.4.3 / 5.1.1.12）。

## 2.8 样式方案（沿用 Minimalist Modern 与 CSS 变量）

- **预览区域样式**（追加到 `main.css` 末尾）：
  - `.profile-theme-grid`：`display:grid; grid-template-columns:repeat(3, 1fr); gap:12px; margin-top:8px;`（三列等宽，与头像网格风格统一）。
  - `.profile-theme-item`：圆角 `--radius-md`、边框 `2px solid var(--color-border)`、`cursor:pointer`、`transition:all 0.2s ease`、`user-select:none`，复用 `.profile-avatar-item` 范式。
  - `.profile-theme-preview`：`aspect-ratio:1; border-radius:var(--radius-sm);` 背景由内联 style 设为对应 `gradient`（因渐变表达式在常量中，JS 渲染时赋值 `el.style.background = theme.gradient`，此处仅控制几何）。
  - `.profile-theme-name`：`font-size:0.8rem; color:var(--color-text-light); text-align:center; margin-top:6px;`。
  - `.profile-theme-item:hover`：`border-color:var(--color-primary); transform:translateY(-2px);`。
  - `.profile-theme-item.selected`：`border-color:var(--color-primary); box-shadow:0 4px 12px rgba(76,175,80,0.2); transform:scale(1.03);`（与头像选中态一致）。
  - 响应式 `@media (max-width:768px)`：`grid-template-columns:repeat(3,1fr); gap:10px;`（三列保持，预览缩小）。
- **body 主题渐变**（追加到 `main.css`，位于 `body` 规则附近）：
  - `body.theme-nebula { background: linear-gradient(135deg, #4B0082 0%, #2D0A4E 45%, #0A0A1A 100%); background-image: none; background-attachment: fixed; }`
  - `body.theme-dawn { background: radial-gradient(circle at 30% 25%, #FFF8DC 0%, #FFD580 45%, #FF8C42 100%); background-image: none; background-attachment: fixed; }`
  - `body.theme-cyber { background: linear-gradient(135deg, #0B1E3F 0%, #0A4D8C 50%, #00E5FF 100%); background-image: none; background-attachment: fixed; }`
  - `background-image:none` 覆盖默认 `body` 的 radial-gradient 装饰层，避免与主题渐变叠加；`background-attachment:fixed` 保持氛围稳定。
- **不引入新依赖**：纯 CSS，无预处理器、无原子 CSS 框架、无第三方组件，满足 spec 1.4.6 与用户偏好。

## 2.9 如何确保不影响现有功能

| 现有功能 | 潜在影响点 | 隔离措施 |
|---------|-----------|---------|
| 打卡 / 储蓄营 / 储蓄目标 / 存钱顾问 | 主题切换仅改 `body.classList`，不触碰业务 DOM 与数据 | `themeService` 只读写 `user.themeKey`，不读不改 `goals/records/checkIns/camps/achievements`；`applyTheme` 仅操作 `body` class |
| 用户资料保存（昵称/头像） | `userService.saveProfile` 整体覆盖 `user` 可能清掉 `themeKey` | 修改 `saveProfile`：重建 `user` 时读取旧 `data.user?.themeKey` 并保留，写入 `{nickname, avatarKey, themeKey, updatedAt}` |
| 数据备份导出/导入 | `backupService.exportData` 读整个主数据，自动含 `user.themeKey` | 无需改 `backupService`；导入时 `user.themeKey` 随主数据恢复，`themeService.getCurrentThemeKey` 读取时合法性校验，非法回退默认 |
| 数据清空 | `clearAllData` 移除 `dream_saving_camp_data`，`user` 连同 `themeKey` 清除 | 无需改 `clearAllData`；`location.reload()` 后 `initData` 重建空数据，`applySavedTheme` 回退默认主题 |
| 既有路由 | `main.js router()` 路由分支 | 仅在 `init()` 插入一行 `themeService.applySavedTheme()`，`router()` 函数体不变；`#/profile` 分支仍调用 `profileView.render()`，分支顺序不变 |
| 首页 hero/stats 等区域可读性 | body 背景变深可能透出影响 | 这些区域自带底色（`.home-hero` 渐变、`.home-stats`/`.home-motivation` 等容器底色），body 背景仅在其间隙透出，文字可读性由容器底色保证 |
| 个人主页昵称/头像区域 | 新增"更换背景"区域挤占布局 | 新区域插在头像网格与保存按钮之间，纵向流式排列，`.form-card` 自适应高度，不遮挡既有区域；`_renderThemeSection` 独立 `try/catch`，异常时跳过不影响既有区域 |
| 启动性能 | 新增 `applySavedTheme` 调用 | 仅一次 `getData`（内存读）+ 一次 `classList` 切换，无 IO 阻塞，增量 < 50ms（spec 4.1.2） |

## 2.10 新增/修改文件清单

| 文件 | 操作 | 职责 |
|------|------|------|
| `src/constants.js` | 修改（追加） | 新增 `BACKGROUND_THEMES`（3 套预设主题定义）、`DEFAULT_THEME_KEY`（默认主题标识） |
| `src/services/themeService.js` | 新增 | 主题合法性校验、读取当前主题、应用（切换 body class）、持久化、启动恢复 |
| `src/services/userService.js` | 修改（1 处） | `saveProfile` 重建 `user` 时保留既有 `themeKey`，避免保存资料清空主题 |
| `src/views/profileView.js` | 修改（追加方法 + render 内插入） | 新增 `_renderThemeSection` 渲染"更换背景"区域、`_handleThemeSelect` 处理点击切换；`render` 内在头像网格后插入该区域 |
| `src/main.js` | 修改（插入 1 行） | `init()` 中 `initData()` 之后、`router()` 之前调用 `themeService.applySavedTheme()`；路由分支不变 |
| `src/styles/main.css` | 修改（追加规则） | 新增 `body.theme-nebula/dawn/cyber` 三套渐变规则 + `.profile-theme-*` 预览区域样式 |

不新增任何图片文件、不引入任何第三方依赖、不修改 `index.html`、不新增 localStorage 键。