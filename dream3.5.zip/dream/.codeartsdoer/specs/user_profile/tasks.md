# 个人资料模块 - 编码任务清单

> 本清单基于 `.codeartsdoer/specs/user_profile/spec.md`（需求规格）与 `design.md`（增量设计方案）生成，按业务功能垂直切割，任务按依赖关系排序。
>
> **全局约束（适用于所有任务）**：
> 1. 数据必须经 `src/storage/localStorageAdapter.js` 的 `getData()/saveData()` 读写，禁止视图层直接操作 `localStorage`。
> 2. 禁止修改 `index.html`；禁止修改 `src/main.js` 既有路由分支的匹配逻辑与顺序（仅新增 `#/profile` 分支与一个 import）。
> 3. 禁止白屏：所有新增视图入口须 try/catch 兜底，异常时展示错误兜底页与返回首页入口。
> 4. 命名采用 camelCase，文件名与变量名一致（如 `userService.js`、`profileView.js`）。
> 5. 样式使用既有 CSS 变量（`--color-*`、`--radius-*`、`--shadow-*`），禁止硬编码颜色；纯 CSS，不引入预处理器。
> 6. 昵称一律用 `element.textContent` 渲染，禁止 `innerHTML` 拼接昵称（防 XSS）。
> 7. 不引入任何付费/商业授权组件，不新增外部依赖。

---

## 1. 定义用户资料规则与预设头像集合

**依赖**：无（基础任务，可与任务 2 并行）
**目标**：在常量层集中定义用户资料校验规则与预设头像集合，供后续服务与视图引用。

### 1.1 追加 USER_PROFILE_RULES 常量
- [ ] 在 `src/constants.js` 末尾追加 `USER_PROFILE_RULES` 常量对象，包含 `NICKNAME_MIN: 1`、`NICKNAME_MAX: 20`、`DEFAULT_NICKNAME: '梦想家'`、`DEFAULT_AVATAR_KEY: 'star'`，并 `export` 导出。
- **验收**：`import { USER_PROFILE_RULES } from './constants.js'` 可读到 4 个字段；值与上述一致；既有常量（STORAGE_KEYS/VALIDATION_RULES/CAMP_RULES 等）值与引用不受影响。

### 1.2 追加 PRESET_AVATARS 预设头像集合
- [ ] 在 `src/constants.js` 追加 `PRESET_AVATARS` 数组并 `export`，共 12 项，每项为 `{ key, emoji, isDefault }`，依次为：star⭐(isDefault:true)、rocket🚀、fire🔥、sun☀️、moon🌙、rainbow🌈、gem💎、crown👑、cat🐱、dog🐶、panda🐼、fox🦊。
- **验收**：数组长度为 12（满足 spec 6.2 数量 8-16）；所有 `key` 唯一；有且仅有一项 `isDefault: true` 且其 key 为 `'star'`；默认头像 key 与 `USER_PROFILE_RULES.DEFAULT_AVATAR_KEY` 一致。

---

## 2. 扩展存储适配器支持 user 字段兜底

**依赖**：无（基础任务，可与任务 1 并行）
**目标**：在主数据对象中为 user 字段提供挂载点与历史数据兜底，不改动既有读写逻辑。

### 2.1 在 getEmptyData() 返回对象中追加 user 字段
- [ ] 在 `src/storage/localStorageAdapter.js` 的 `getEmptyData()` 返回对象末尾追加 `user: null` 字段（位于 `achievements` 之后），不改动既有字段顺序。
- **验收**：`getEmptyData()` 返回对象包含 `_version/goals/records/checkIns/camps/achievements/user` 七个字段，`user` 为 `null`，其余字段值与改动前一致。

### 2.2 在 initData() 末尾追加 user 字段兜底
- [ ] 在 `src/storage/localStorageAdapter.js` 的 `initData()` 方法末尾（`if (!cache.camps) cache.camps = [];` 之后、`return cache;` 之前）追加 `if (!cache.user) cache.user = null;`，不改动既有兜底与读写逻辑。
- **验收**：历史数据（无 user 字段）经 `initData()` 后 `cache.user === null`；已含合法 user 字段的数据经 `initData()` 后 `cache.user` 保持原值；既有 `achievements/camps` 兜底逻辑与 `getData()/saveData()/read()/write()` 行为不变。

---

## 3. 实现用户资料领域服务

**依赖**：任务 1（常量）、任务 2（存储兜底）
**目标**：新建 `src/services/userService.js`，提供用户资料的读取、校验、保存与头像集合查询能力，作为视图访问资料的唯一入口。

### 3.1 创建 userService.js 文件骨架与依赖引入
- [ ] 新建 `src/services/userService.js`，从 `../storage/localStorageAdapter.js` 引入 `localStorageAdapter`，从 `../constants.js` 引入 `USER_PROFILE_RULES` 与 `PRESET_AVATARS`；导出 `export const userService = { ... }` 对象。
- **验收**：文件存在；`import { userService } from '../services/userService.js'` 不报错；`userService` 为对象。

### 3.2 实现 getDefaultProfile() 方法
- [ ] 在 `userService` 中实现 `getDefaultProfile()`，返回 `{ nickname: USER_PROFILE_RULES.DEFAULT_NICKNAME, avatarKey: USER_PROFILE_RULES.DEFAULT_AVATAR_KEY, updatedAt: null }`。
- **验收**：调用返回 `{ nickname: '梦想家', avatarKey: 'star', updatedAt: null }`；纯函数无副作用。

### 3.3 实现 getAvatarSet() 与 getAvatarEmojiByKey(key) 方法
- [ ] 实现 `getAvatarSet()`：返回 `PRESET_AVATARS` 数组（每项含 key/emoji/isDefault）。
- [ ] 实现 `getAvatarEmojiByKey(key)`：在 `PRESET_AVATARS` 中查找 `key` 匹配项的 `emoji`；未找到或入参非法时回退默认头像（`isDefault: true` 项）的 emoji。
- **验收**：`getAvatarSet().length === 12`；`getAvatarEmojiByKey('rocket')` 返回 `'🚀'`；`getAvatarEmojiByKey('unknown')` 与 `getAvatarEmojiByKey(null)` 均返回 `'⭐'`（默认）。

### 3.4 实现内部 _validate({ nickname, avatarKey }) 校验方法
- [ ] 在 `userService` 中实现私有 `_validate`（作为对象内部方法或模块函数）：先去除昵称中换行符与不可见控制字符（正则 `/[\r\n\t\u0000-\u001F\u007F]/g` 替换为空），再 `trim`；按 `Array.from(str).length` 计算用户感知字符长度；长度 < `NICKNAME_MIN` 时 `errors.nickname = '昵称不能为空'`，长度 > `NICKNAME_MAX` 时 `errors.nickname = '昵称最多 20 个字符'`；`avatarKey` 不在 `PRESET_AVATARS` 的 key 集合内时 `errors.avatar = '请选择头像'`；返回 `{ cleanedNickname, errors }`，`errors` 为空对象时表示校验通过。
- **验收**：空昵称 → `errors.nickname === '昵称不能为空'`；21 字昵称 → `errors.nickname === '昵称最多 20 个字符'`；含 `\n` 的昵称被去除换行后通过；`avatarKey='unknown'` → `errors.avatar === '请选择头像'`；合法输入 → `errors` 为 `{}` 且 `cleanedNickname` 已 trim；中文/Emoji 长度按码点正确计算（如 `'😀😀😀'` 长度为 3 非 6）。

### 3.5 实现 getProfile() 方法
- [ ] 实现 `getProfile()`：整体 try/catch；通过 `localStorageAdapter.getData()` 读取主数据，取 `data.user`；若 `user` 为非 null 对象且 `nickname` 为非空字符串、`avatarKey` 在预设集合内，则返回 `{ nickname, avatarKey, updatedAt: user.updatedAt ?? null }`；否则（缺失/格式损坏/异常）回退 `getDefaultProfile()`；任何异常均回退默认资料，不抛出。
- **验收**：无 user 字段时返回默认资料；user 字段为 `null` 时返回默认资料；user 字段为合法对象时返回已存资料；user 字段为字符串等异常类型时返回默认资料且不抛异常；`nickname` 与 `avatarKey` 恒为合法非空字符串。

### 3.6 实现 saveProfile({ nickname, avatarKey }) 方法
- [ ] 实现 `saveProfile({ nickname, avatarKey })`：调用 `_validate` 校验；校验失败时返回 `{ success: false, errors }`；校验通过时读取 `data = localStorageAdapter.getData()`，构造 `data.user = { nickname: cleanedNickname, avatarKey, updatedAt: Date.now() }`（仅赋值 `data.user`，不改动 `data.goals/records/checkIns/camps/achievements` 等其他字段），调用 `localStorageAdapter.saveData(data)`；写入返回 true 时返回 `{ success: true, data: data.user }`，返回 false 时返回 `{ success: false, error: '保存失败，请检查浏览器存储设置' }`。
- **验收**：校验失败不写入存储，返回 `errors`；校验通过且写入成功后 `getProfile()` 返回新资料；保存后主数据其他业务字段（goals/records/checkIns/camps/achievements）保持原值不变（可用 `getData()` 对比）；`updatedAt` 为当前毫秒时间戳；返回结构符合 `{success, data}` 或 `{success:false, errors}` 或 `{success:false, error}` 三种范式之一。

---

## 4. 实现个人主页视图

**依赖**：任务 1（常量）、任务 3（userService）、任务 5（样式，可同步进行）
**目标**：新建 `src/views/profileView.js`，渲染个人主页，支持昵称编辑、头像选择与保存，异常兜底不白屏。

### 4.1 创建 profileView.js 文件骨架与依赖引入
- [ ] 新建 `src/views/profileView.js`，引入 `../services/userService.js` 的 `userService`、`./modal.js` 的 `modal`、`../constants.js` 的 `USER_PROFILE_RULES`；导出 `export const profileView = { render() {} }`。
- **验收**：文件存在；`import { profileView } from '../views/profileView.js'` 不报错；`typeof profileView.render === 'function'`。

### 4.2 实现 render() 页面骨架与资料预填
- [ ] 实现 `render()`：整体 try/catch 包裹；清空 `#app`；构建 `.page-container` 容器，内含返回首页链接（`.back-link`，href 为 `#/`）、标题"个人资料"（`.form-title`）、`.form-card` 表单卡片；表单内含昵称 `label` + `<input type="text" id="profile-nickname" maxlength="20">`（maxlength 取自 `USER_PROFILE_RULES.NICKNAME_MAX`）、头像选择网格容器（`.profile-avatar-grid`）、保存按钮（`.btn .btn-primary`）；调用 `userService.getProfile()` 预填昵称输入框 `value` 与当前选中头像 key（用闭包变量 `selectedAvatarKey` 记录）；调用 `userService.getAvatarSet()` 渲染头像网格；绑定保存按钮点击事件调用内部 `_handleSave`；catch 块渲染错误兜底页（错误提示 + "返回首页"按钮，跳转 `#/`）。
- **验收**：进入 `#/profile` 后页面显示返回链接、标题、昵称输入框、12 个头像、保存按钮；昵称输入框预填当前资料昵称（首次为"梦想家"）；当前头像项带 `selected` 样式类；渲染过程抛异常时显示错误兜底页与返回首页按钮，不白屏。

### 4.3 实现头像网格渲染与单选交互
- [ ] 在 `render()` 内（或私有方法 `_renderAvatarGrid`）一次性同步循环 `getAvatarSet()` 构建 12 个 `.profile-avatar-item` 节点（每个含 emoji 与 key），当前选中项添加 `selected` 类；为每个项绑定 click 事件：点击后移除所有项的 `selected` 类、为当前项添加 `selected` 类、更新 `selectedAvatarKey` 变量；禁止异步加载导致跳动。
- **验收**：头像网格一次性渲染 12 项无跳动；点击任一头像后仅该项高亮（`selected` 类），其余取消高亮；`selectedAvatarKey` 更新为所点击项的 key；连续点击不同项始终单选。

### 4.4 实现保存按钮交互 _handleSave
- [ ] 实现保存处理逻辑：读取昵称输入框 `value` 与 `selectedAvatarKey`，调用 `userService.saveProfile({ nickname, avatarKey: selectedAvatarKey })`；若 `result.success` 为 true，调用 `modal.toast('保存成功')` 并 `window.location.hash = '#/'` 跳转首页；若 `result.errors` 存在，调用 `modal.toast(result.errors.nickname || result.errors.avatar)` 并停留当前页；若 `result.error` 存在（写入失败），调用 `modal.toast(result.error)` 并停留当前页不清空输入。
- **验收**：合法输入保存后弹出"保存成功"toast 并跳转 `#/`；空昵称保存弹出"昵称不能为空"toast 且不跳转、输入框内容保留；写入失败时弹出"保存失败，请检查浏览器存储设置"toast 且不跳转、不清空输入。

---

## 5. 新增个人主页与首页身份条样式

**依赖**：无（纯样式追加，可与任务 3、4 并行）
**目标**：在 `src/styles/main.css` 末尾追加身份条与个人主页专属样式，沿用既有 CSS 变量，不修改既有规则。

### 5.1 追加首页身份条样式
- [ ] 在 `src/styles/main.css` 末尾追加 `.home-identity-bar`（横条容器，flex 布局，圆角 `--radius-md`，背景 `--color-card`，边框 `--color-border`，内边距，cursor pointer，过渡 `--ease-out`，hover 时边框/背景微变）、`.home-identity-avatar`（圆形头像区，居中显示 Emoji，字号适中）、`.home-identity-nickname`（昵称文本，颜色 `--color-text`，字号适中，font-weight 适中）、`.home-identity-arrow`（右侧箭头指示可点击，颜色 `--color-text-muted`）等类名规则；全部使用既有 CSS 变量，不硬编码颜色。
- **验收**：身份条样式生效，呈现为可点击横条（头像+昵称+箭头）；hover 有视觉反馈；无硬编码颜色；既有 `.home-*` 类名规则不受影响。

### 5.2 追加个人主页样式
- [ ] 在 `src/styles/main.css` 末尾追加 `.profile-page`（页面容器，复用 `.page-container` 范式或独立类）、`.profile-avatar-grid`（网格容器，display grid，列数自适应如 `repeat(auto-fill, minmax(64px, 1fr))`，间距 gap）、`.profile-avatar-item`（单项，圆形或圆角方块，居中 Emoji，边框 `--color-border`，cursor pointer，过渡）、`.profile-avatar-item.selected`（选中态，边框 `--color-primary`，背景 `--color-primary-light`，缩放或阴影强调）、`.profile-avatar-item:hover`（hover 态）等类名规则；昵称输入框复用既有 `.form-group` 范式；全部使用既有 CSS 变量。
- **验收**：个人主页头像网格呈响应式网格布局；选中头像有明显高亮（边框/背景变化）；hover 有反馈；无硬编码颜色；既有样式规则不受影响。

---

## 6. 首页顶部接入用户身份展示

**依赖**：任务 1（常量）、任务 3（userService）、任务 5（样式）
**目标**：在 `src/views/homeView.js` 顶部追加 userService import，新增 `_renderIdentityBar()` 私有方法，并在 `render()` 内将其作为首个 append 项（位于 `_renderHero` 之前），不修改既有方法体。

### 6.1 追加 userService import
- [ ] 在 `src/views/homeView.js` 顶部 import 区追加 `import { userService } from '../services/userService.js';`，不改动既有 import。
- **验收**：import 追加后文件无语法错误；既有 import 顺序与内容不变。

### 6.2 实现 _renderIdentityBar() 私有方法
- [ ] 在 `homeView` 对象中新增 `_renderIdentityBar()` 方法：整体 try/catch；调用 `userService.getProfile()` 读取资料（异常时回退默认资料继续渲染，不抛出）；构建 `.home-identity-bar` 节点，内含 `.home-identity-avatar`（用 `textContent` 设置 `userService.getAvatarEmojiByKey(profile.avatarKey)`）、`.home-identity-nickname`（用 `textContent` 设置 `profile.nickname`，禁止 innerHTML）、`.home-identity-arrow`（如 "→"）；为整个 bar 绑定 click 事件 `window.location.hash = '#/profile'`；catch 块返回一个空 `span` 节点（不影响后续区块渲染）。
- **验收**：调用返回一个含头像+昵称+箭头的 DOM 节点；昵称与头像均用 `textContent` 设置；点击节点后 `window.location.hash` 变为 `'#/profile'`；读取异常时返回空 span 不抛出。

### 6.3 在 render() 中将身份条作为首个 append 项
- [ ] 在 `homeView.render()` 内，于 `page.appendChild(this._renderHero(streak));` 之前插入 `page.appendChild(this._renderIdentityBar());`，不修改既有 append 顺序与既有方法调用。
- **验收**：首页渲染后顶部第一个子区块为身份条，其后依次为 hero/stats/motivation/badges/goalsSection/disclaimer/settingsEntry（顺序与改动前一致）；身份条异常时不影响后续区块渲染。

---

## 7. 新增个人主页路由分支

**依赖**：任务 4（profileView）
**目标**：在 `src/main.js` 追加 profileView import 与 `#/profile` 精确匹配分支，不修改既有分支顺序与逻辑。

### 7.1 追加 profileView import
- [ ] 在 `src/main.js` 顶部 import 区追加 `import { profileView } from './views/profileView.js';`，不改动既有 import。
- **验收**：import 追加后文件无语法错误；既有 import 不变。

### 7.2 插入 #/profile 路由分支
- [ ] 在 `src/main.js` 的 `router()` 函数内，于 `else if (hash === '#/settings') { settingsView.render(); }` 分支之后、`else if (hash === '#/goal/new')` 分支之前，插入 `else if (hash === '#/profile') { profileView.render(); }` 分支，不改动既有分支顺序与正则匹配区。
- **验收**：浏览器地址栏输入 `#/profile` 后渲染个人主页；`#/`、`#/camps`、`#/camp/new`、`#/camp/join`、`#/settings`、`#/goal/new` 等既有路由行为不变；既有正则匹配分支（camp/withdraw/edit/detail）不受影响。

---

## 8. 集成与功能验证

**依赖**：任务 1-7 全部完成
**目标**：端到端验证个人资料设置与首页身份展示的核心能力，确认需求规格中所有验收条件落地。

### 8.1 验证个人资料设置核心流程
- [ ] 启动应用（`init()` 后），手动进入 `#/profile`：确认昵称输入框预填"梦想家"、star 头像高亮；编辑昵称为"小明"并点选 rocket 头像，点击保存，确认弹出"保存成功"toast 并跳转 `#/`；刷新浏览器后再次进入 `#/profile`，确认昵称为"小明"、rocket 头像高亮（持久化生效）。
- **验收**：默认资料预填正确；编辑保存后 toast 与跳转正确；刷新后资料持久化（对应 spec 5.1.1 规则 4、5）。

### 8.2 验证昵称校验规则
- [ ] 在 `#/profile` 清空昵称点击保存，确认弹出"昵称不能为空"且不跳转；输入 21 字昵称确认被 `maxlength` 限制无法输入超长（或保存时被拒）；输入含换行符的昵称（通过粘贴）保存后确认换行被去除；输入纯中文/纯英文/中英混合/含 Emoji 昵称保存后确认正常展示。
- **验收**：空昵称被拒（spec 5.1.1 规则 1a）；超长被限制（1c）；换行被去除（规则 2a）；中英 Emoji 均可保存展示（2b）。

### 8.3 验证头像选择与回退
- [ ] 在 `#/profile` 依次点击 12 个头像确认单选高亮切换正确；保存任一非默认头像后刷新确认回显正确；手动篡改 localStorage 中 `user.avatarKey` 为 `'unknown'`，刷新首页确认顶部显示默认头像 ⭐（回退默认）。
- **验收**：单选交互正确（spec 5.1.1 规则 3a）；非法 key 回退默认（3b、4.2 可靠性第 4 条）。

### 8.4 验证首页身份展示与跳转
- [ ] 打开首页确认顶部身份条位于 hero 之上，显示当前头像与昵称；点击身份条确认跳转 `#/profile`；在个人主页修改昵称保存返回首页后，确认首页顶部显示新昵称（实时同步）；首次使用（清空 localStorage）打开首页确认显示默认昵称"梦想家"与默认头像 ⭐ 且可点击跳转。
- **验收**：身份条位置正确（spec 5.2.1 规则 1）；跳转生效（规则 2）；保存后实时同步（规则 3）；默认展示可点击（规则 4）。

### 8.5 验证保存不影响其他业务数据
- [ ] 先在首页创建一个储蓄目标并打卡一次，记录目标数量与打卡天数；进入 `#/profile` 修改昵称保存返回首页；确认储蓄目标数量、累计储蓄、连续天数、徽章均与保存前一致（通过 `localStorageAdapter.getData()` 对比 `goals/records/checkIns/camps/achievements` 字段未变）。
- **验收**：保存用户资料后其他业务字段保持原值不变（spec 5.1.1 规则 6、4.2 可靠性第 3 条）。

### 8.6 验证异常兜底不白屏
- [ ] 手动篡改 localStorage 中 `dream_saving_camp_data` 的 `user` 字段为字符串 `"broken"`，刷新首页确认正常显示默认昵称头像不白屏；进入 `#/profile` 确认正常渲染默认资料不白屏；清空 localStorage（模拟首次使用）打开首页与 `#/profile` 确认均显示默认资料不白屏。
- **验收**：字段损坏回退默认不白屏（spec 5.1.3 异常场景 5、4.2 可靠性第 4 条）；首次使用显示默认不白屏（异常场景 4）。

---

## 9. 存量功能回归验证

**依赖**：任务 1-7 全部完成
**目标**：确认新增个人资料模块不影响现有打卡、储蓄营、储蓄目标、数据备份等存量功能。

### 9.1 回归验证储蓄目标与打卡功能
- [ ] 新建储蓄目标、添加储蓄记录、执行打卡，确认流程与改动前一致；进入目标详情、编辑目标、提前支取冷静期流程确认正常；连续打卡天数与徽章解锁确认正常。
- **验收**：储蓄目标 CRUD、打卡、冷静期、徽章功能全部正常，与改动前行为一致。

### 9.2 回归验证储蓄营功能
- [ ] 进入 `#/camps` 储蓄营列表确认正常；新建储蓄营、加入储蓄营、进入储蓄营详情、发送消息确认正常；储蓄营内昵称（camp nickname）与全局用户昵称互不影响。
- **验收**：储蓄营列表/创建/加入/详情/消息功能正常；储蓄营昵称独立于全局用户昵称（spec 1.4 职责边界第 3 条）。

### 9.3 回归验证数据备份功能
- [ ] 进入 `#/settings` 数据管理，执行导出备份，确认导出文件中主数据对象包含 `user` 字段；修改昵称保存后再次导出，确认导出文件中 `user.nickname` 为新值；执行导入备份确认 user 字段随主数据恢复；执行清空数据确认 user 字段一并清除（再次打开首页显示默认资料）。
- **验收**：导出含 user 字段（spec 4.5 兼容性第 2 条）；导入恢复 user；清空清除 user（第 3 条）；备份文件结构未破坏。

### 9.4 回归验证既有路由与首页区块
- [ ] 依次访问 `#/`、`#/camps`、`#/camp/new`、`#/camp/join`、`#/settings`、`#/goal/new` 及目标详情/编辑/支取、储蓄营详情等路由，确认均正常渲染不白屏；首页确认 hero/stats/motivation/badges/goalsSection/disclaimer/settingsEntry 各区块完整渲染且顺序正确。
- **验收**：所有既有路由正常；首页既有区块完整且顺序不变（spec 5.2.3 异常场景 2）。

---

## 10. 代码审查与最终确认

**依赖**：任务 8、9 全部通过
**目标**：对新增与修改代码进行最终审查，确认符合约束条件与设计决策。

### 10.1 代码审查：约束条件核对
- [ ] 审查 `userService.js` 确认仅经 `localStorageAdapter.getData()/saveData()` 读写，无直接 `localStorage` 操作；审查 `profileView.js` 与 `homeView.js` 确认昵称一律 `textContent` 渲染无 `innerHTML` 拼接昵称；审查 `main.js` 确认仅新增一条分支与一个 import，既有分支顺序未变；审查 `index.html` 确认未被修改；审查 `localStorageAdapter.js` 确认仅追加 `user` 兜底，既有读写逻辑未改。
- **验收**：全部约束条件满足；无直接 localStorage 操作（视图层）；无 XSS 风险；路由侵入为零；存储改动最小化。

### 10.2 代码审查：设计决策一致性核对
- [ ] 核对 `PRESET_AVATARS` 共 12 项且 key 唯一、默认为 star；核对昵称长度用 `Array.from` 计算；核对控制字符正则覆盖 `\r\n\t` 及 `0x00-0x1F` 与 `0x7F`；核对 `saveProfile` 仅赋值 `data.user` 不动其他字段；核对身份条位于 hero 之上为首个 append 项；核对 `profileView.render()` 有 try/catch 兜底页。
- **验收**：与 design.md 2.5 关键设计决策全部一致；与 spec 6.2 数据约束全部一致。

### 10.3 语法检查与最终确认
- [ ] 使用 Node.js v24 对新增/修改的 JS 文件（`userService.js`、`profileView.js`、`constants.js`、`localStorageAdapter.js`、`homeView.js`、`main.js`）执行语法检查（如 `node --check`，注意 ES module 文件可用 `node --input-type=module --check < file` 或临时改扩展名），确认无语法错误；最终在浏览器中完整走一遍核心流程与回归流程。
- **验收**：所有新增/修改 JS 文件语法检查通过；浏览器端核心流程与回归流程全部通过；无控制台报错；无白屏。

---

## 任务依赖与执行顺序总览

```
任务 1（常量）┐
              ├──> 任务 3（userService）──> 任务 4（profileView）──┐
任务 2（存储）┘                                                      ├──> 任务 7（路由）──┐
                                                                    │                    │
任务 5（样式）──────────────────────────────────────────────────────┤                    │
                                                                    │                    │
任务 6（首页身份条）<── 任务 3 ── <── 任务 1, 5                       │                    │
                                                                    └──> 任务 8（集成验证）──┐
                                                                                             ├──> 任务 10（审查）
                                                                                             │
                                                                                             └──> 任务 9（回归验证）──┘
```

**推荐执行顺序**：1 → 2 → 3 → 5 → 4 → 6 → 7 → 8 → 9 → 10
（任务 1、2 可并行；任务 5 可与任务 3、4 并行；任务 8、9 须在 1-7 全部完成后进行；任务 10 须在 8、9 通过后进行）