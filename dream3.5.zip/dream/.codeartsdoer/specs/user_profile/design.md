# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

本需求为新增"个人资料（昵称+预设头像）"模块，与存量代码无直接功能重叠，但可复用存量基础设施（存储适配器、常量定义、视图渲染范式、Modal 提示、路由机制、CSS 设计系统）。复用关系如下：

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 用户资料持久化到本地主数据对象 | 主数据（goals/records/checkIns/camps/achievements）经适配器读写 | src/storage/localStorageAdapter.js:18-101（read/write/saveData/getData/initData） | 75%（机制完全可复用，但 getEmptyData() 与 initData 的 cache 构造未含 user 字段，需补兜底） |
| 服务层校验+写入+返回结果结构 | goalService 的 create/update 校验与 saveData 模式 | src/services/goalService.js:22-46（create）、7-20（validateGoalData） | 100%（返回 {success, data, error, errors} 范式可直接套用） |
| 视图渲染（清空 app、构建 page-container、表单、返回链接、modal.toast 提示） | campFormView/settingsView 的渲染范式 | src/views/campFormView.js:7-107、src/views/settingsView.js:14-37 | 100%（页面骨架、form-card、back-link、btn 样式可直接复用） |
| 路由分支匹配 | main.js 的 if/else if hash 链 | src/main.js:14-58 | 100%（在 `#/settings` 分支后插入 `#/profile` 即可，不动既有分支） |
| 常量集中定义 | STORAGE_KEYS/VALIDATION_RULES/CAMP_RULES 等 | src/constants.js:1-61 | 100%（追加 USER_PROFILE_RULES 与 PRESET_AVATARS 即可） |
| 轻量提示 | modal.toast(message) | src/views/modal.js:53-67 | 100% |
| Minimalist Modern 样式与 CSS 变量 | :root 变量与既有类名 | src/styles/main.css:1-27 | 100%（沿用 --color-primary/--color-surface/--color-border/--radius-* 等变量） |
| 数据备份随主数据导出/导入/清空 | backupService 操作 DATA_KEY | src/services/backupService.js:37-96 | 75%（user 字段随主数据对象自动导出/导入/清空，但 validateBackup 未校验 user 字段——因 user 为可选字段，读取时回退默认，无需改校验） |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 主数据对象含 user 字段 | getEmptyData() 返回对象含 goals/records/checkIns/camps/achievements，无 user | 新增字段 user（初始 null），既不影响现有字段，又为 userService 提供挂载点 | 在 getEmptyData() 返回对象中追加 `user: null`；在 initData() 末尾追加 `if (!cache.user) cache.user = null;` 兜底。仅追加，不改动既有字段顺序与逻辑 |
| 首页顶部身份展示区 | homeView.render() 依次 append hero/stats/motivation/badges/goalsSection/disclaimer/settingsEntry，无身份区 | 需在 hero 之前插入身份条，且不破坏既有 append 顺序与 hero 内部结构 | 在 homeView 中新增 _renderIdentityBar() 私有方法，并在 render() 内将其作为第一个 append 项（位于 hero 之上）。仅追加，不修改既有 _renderHero/_renderStats 等方法 |
| 路由 #/profile 分支 | main.js 路由链含 #/、#/camps、#/camp/new、#/camp/join、#/settings、#/goal/new 等，无 #/profile | 需新增分支与 profileView import | 在 main.js 顶部 import 区追加 profileView import；在 `#/settings` 分支之后、`#/goal/new` 分支之前插入 `else if (hash === '#/profile')` 分支。不动既有分支顺序 |

### 1.1.3 需要新增的功能或接口

按业务模块分组，以下为存量代码中完全没有对应实现、需新建的功能点：

**模块 A：用户资料服务（userService.js）**
- 功能点 A1：getProfile() —— 从主数据 user 字段读取资料，缺失/格式异常时回退默认资料；返回 {nickname, avatarKey, updatedAt}
- 功能点 A2：saveProfile({nickname, avatarKey}) —— 校验昵称（去控制字符、trim、长度 1-20）与头像 key（须在预设集合内），通过后写入主数据 user 字段并追加 updatedAt；返回 {success, data} 或 {success:false, errors/error}
- 功能点 A3：getDefaultProfile() —— 返回默认资料常量（昵称"梦想家"，默认头像 key）
- 功能点 A4：getAvatarSet() —— 返回预设头像集合（[{key, emoji}]）
- 功能点 A5：getAvatarEmojiByKey(key) —— 根据 key 查 Emoji，非法/缺失回退默认头像 Emoji
- 依赖：localStorageAdapter（getData/saveData）、constants（PRESET_AVATARS/USER_PROFILE_RULES）

**模块 B：个人主页视图（profileView.js）**
- 功能点 B1：render() —— 渲染页面骨架（返回首页链接、标题、昵称输入框、头像选择网格、保存按钮），从 userService.getProfile() 预填
- 功能点 B2：头像网格交互 —— 点击头像切换选中态（CSS 类切换），仅单选
- 功能点 B3：保存按钮交互 —— 校验通过后调用 userService.saveProfile，成功 toast 并跳转 #/；失败 toast 错误信息停留当前页
- 功能点 B4：渲染异常兜底 —— render 内 try/catch，异常时展示错误兜底页与返回首页按钮
- 依赖：userService、modal、constants（PRESET_AVATARS/USER_PROFILE_RULES）

**模块 C：常量定义（constants.js 追加）**
- 功能点 C1：USER_PROFILE_RULES —— {NICKNAME_MIN:1, NICKNAME_MAX:20, DEFAULT_NICKNAME:'梦想家', DEFAULT_AVATAR_KEY:'star'}
- 功能点 C2：PRESET_AVATARS —— 预设头像集合数组（key 与 Emoji 一一对应，含默认头像标记）

**模块 D：首页身份条（homeView.js 追加）**
- 功能点 D1：_renderIdentityBar() —— 读取 userService.getProfile()，渲染头像+昵称可点击区域，点击跳转 #/profile
- 功能点 D2：render() 中将身份条作为首个 append 项

**模块 E：路由分支（main.js 追加）**
- 功能点 E1：import profileView
- 功能点 E2：`#/profile` 分支调用 profileView.render()

**模块 F：样式（main.css 追加）**
- 功能点 F1：身份条样式（.home-identity-bar 等）
- 功能点 F2：个人主页样式（.profile-page、.profile-avatar-grid、.profile-avatar-item 等）

## 1.2 存量功能详细分析

### 1.2.1 localStorageAdapter（存储适配器）

- **接口契约**：
  - `read(key)` → 对象 | null（JSON 解析失败返回 null，不抛异常）
  - `write(key, data)` → boolean（写入失败返回 false，不抛异常）
  - `initData()` → Promise<cache>（异步初始化，含远端同步尝试，失败回退 getEmptyData()）
  - `saveData(data)` → boolean（同步写 cache 并异步 fetch，始终返回 true；注意：当前实现未捕获 fetch 异常为写入失败，但 userService 仍应按返回值处理）
  - `getData()` → cache 对象（无 cache 时返回 getEmptyData()）
- **业务规则**：主数据对象固定含 _version/goals/records/checkIns/camps/achievements；initData 末尾对 achievements 与 camps 做了兜底补全，但未对 user 兜底。
- **扩展点**：getEmptyData() 与 initData() 是补 user 字段兜底的唯一改动点；getData()/saveData() 无需改动。
- **约束**：所有服务必须经 getData()/saveData() 读写，不得直接操作 localStorage（backupService 因需导出原始快照为例外，但其操作不影响 user 字段存活）。

### 1.2.2 goalService（服务层范式参考）

- **接口契约**：方法返回 {success:true, data} 或 {success:false, errors}（字段级校验失败）或 {success:false, error}（整体失败）。
- **业务规则**：校验在前、写入在后；写入失败时返回友好错误信息，不清空内存数据。
- **约束**：依赖 localStorageAdapter.getData()/saveData()，不直接操作 localStorage。
- **对本设计启示**：userService 完全套用此范式。

### 1.2.3 homeView（首页视图）

- **接口契约**：render() 无入参，操作 #app 元素，依次 append 各区块。
- **业务规则**：render() 内同步构建 page 容器并 append 子区块；私有方法 _renderXxx() 各自返回一个 DOM 节点。
- **约束**：不接收外部数据，所有数据在 render() 内通过 service 获取。
- **对本设计启示**：新增 _renderIdentityBar() 遵循同范式，在 render() 内作为首个 append 项；身份条数据通过 userService.getProfile() 获取，读取异常时回退默认资料继续渲染，不影响后续区块。

### 1.2.4 main.js（路由）

- **接口契约**：router() 同步函数，try/catch 包裹，异常时渲染错误兜底页。
- **业务规则**：精确匹配分支在前，正则匹配分支（camp/withdraw/edit/detail）在后；未匹配 hash 回退 homeView.render()。
- **约束**：新增分支须插入在精确匹配区，不得置于正则匹配区之后（否则可能被正则误吞）；不得修改既有分支顺序。
- **对本设计启示**：`#/profile` 为精确匹配，插入位置选在 `#/settings` 分支之后、`#/goal/new` 分支之前（均在精确匹配区，安全）。

### 1.2.5 backupService（数据备份）

- **接口契约**：exportData() 读取 DATA_KEY 原始对象并入备份；validateBackup() 校验 _version 与 goals/records/checkIns/achievements 数组；applyImport() 整体覆盖写入；clearAllData() 移除全部 APP_DATA_KEYS。
- **业务规则**：user 字段作为主数据对象的子字段，随主数据整体导出/导入/清空，无需单独处理。
- **约束**：validateBackup 未校验 user 字段——因 user 为可选字段，缺失时 userService 回退默认，不影响导入合法性。
- **对本设计启示**：无需修改 backupService；user 字段自动获得备份/迁移/清空能力，满足 spec 4.5 兼容性要求。

### 1.2.6 CSS 设计系统（main.css :root）

- **可用变量**：--color-primary(#4CAF50)/--color-primary-dark/--color-primary-light/--color-primary-gradient/--color-text/--color-text-light/--color-text-muted/--color-bg/--color-card/--color-border/--color-danger/--radius-sm(8px)/--radius-md(12px)/--radius-lg(16px)/--radius-xl(24px)/--shadow-sm/--shadow-md/--shadow-lg/--ease-out。
- **可用类名范式**：.page-container、.form-card、.form-title、.form-hint、.form-group、.form-error、.back-link、.btn、.btn-primary、.btn-secondary、.btn-danger、.modal-btn-group、.empty-state、.empty-text 等。
- **对本设计启示**：个人主页复用 .page-container/.form-card/.form-group/.btn 等；身份条与头像网格新增专属类名（.home-identity-bar、.profile-avatar-grid 等），全部使用上述变量，不引入硬编码颜色。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用使用者" as User
rectangle "前端应用" {
  rectangle "homeView" as Home
  rectangle "profileView" as Profile
  rectangle "userService" as Svc
  rectangle "main.js 路由" as Router
}
storage "localStorageAdapter\n(主数据 dream_saving_camp_data)" as Storage

User --> Home : 打开 #/
User --> Profile : 打开 #/profile\n编辑昵称/选头像/保存
Home --> Svc : getProfile()
Profile --> Svc : getProfile() / saveProfile()
Svc --> Storage : getData() / saveData()
Storage --> Svc : 主数据对象(含 user 字段)
Home --> User : 渲染顶部身份条\n点击跳转 #/profile
Profile --> User : 渲染个人主页\n保存提示
Router --> Profile : hash === '#/profile'
@enduml
```

- 上游调用方：homeView（首页身份条读取）、profileView（个人主页读写）、main.js 路由（分发 #/profile）。
- 下游依赖方：localStorageAdapter（经 getData/saveData 读写主数据 user 字段）。
- 通信协议：纯本地同步调用（getData/saveData 为同步），无中间件、无跨进程通信。
- 调用频率：homeView.render() 每次调用读一次；profileView 保存时写一次。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
rectangle "constants.js" as Cst {
  rectangle "USER_PROFILE_RULES" as R1
  rectangle "PRESET_AVATARS" as R2
}
rectangle "userService.js" as Svc {
  rectangle "getProfile()" as M1
  rectangle "saveProfile()" as M2
  rectangle "getDefaultProfile()" as M3
  rectangle "getAvatarSet()" as M4
  rectangle "getAvatarEmojiByKey()" as M5
  rectangle "_validate()" as M6
}
rectangle "profileView.js" as V1 {
  rectangle "render()" as R
  rectangle "_renderAvatarGrid()" as RG
  rectangle "_handleSave()" as HS
}
rectangle "homeView.js" as V2 {
  rectangle "_renderIdentityBar()" as IB
}
rectangle "localStorageAdapter" as SA

Cst <-- Svc : 读取规则与头像集合
Svc --> SA : getData()/saveData()
V1 --> Svc : getProfile()/saveProfile()/getAvatarSet()
V2 --> Svc : getProfile()/getAvatarEmojiByKey()
@enduml
```

- **constants.js**：追加 USER_PROFILE_RULES 与 PRESET_AVATARS，集中定义规则与预设集合，便于后续调整（满足 spec 4.4 可维护性）。
- **userService.js**：用户资料领域服务，唯一负责 user 字段读写与校验，所有视图经此访问资料。
- **profileView.js**：个人主页视图，负责渲染与交互，不直接操作存储。
- **homeView.js**：追加 _renderIdentityBar()，仅渲染身份条，不触碰既有区块方法。
- **localStorageAdapter.js**：仅追加 user 字段兜底，不改动既有读写逻辑。

### 2.1.3 实现设计文档

#### 状态机：用户资料读取与回退

```plantuml
@startuml
state "读取主数据" as Read
state "user 字段存在且合法" as OK
state "user 字段缺失" as Missing
state "user 字段格式损坏" as Broken
state "返回已存资料" as ReturnStored
state "回退默认资料" as ReturnDefault

[*] --> Read
Read --> OK : user != null 且类型为 object
Read --> Missing : user == null 或 undefined
Read --> Broken : user 类型异常或字段非法
OK --> ReturnStored
Missing --> ReturnDefault
Broken --> ReturnDefault
ReturnStored --> [*]
ReturnDefault --> [*]
@enduml
```

- 触发条件：getProfile() 调用时。
- 处理策略：合法则返回已存；缺失或损坏均回退默认资料，不抛异常（满足 spec 4.2 可靠性第 4 条、5.1.3 异常场景 4/5）。

#### 流程分支：保存校验

```plantuml
@startuml
start
:读取昵称输入与当前选中头像 key;
:去除换行符与不可见控制字符;
:trim 昵称;
if (昵称长度 < 1?) then (是)
  :errors.nickname = '昵称不能为空';
elseif (昵称长度 > 20?) then (是)
  :errors.nickname = '昵称最多 20 个字符';
else (否)
endif
if (avatarKey 在 PRESET_AVATARS 中?) then (否)
  :errors.avatar = '请选择头像';
else (是)
endif
if (存在 errors?) then (是)
  :返回 {success:false, errors};
  stop
else (否)
endif
:写入主数据 user = {nickname, avatarKey, updatedAt: Date.now()};
:saveData(data);
if (写入成功?) then (是)
  :返回 {success:true, data};
else (否)
  :返回 {success:false, error:'保存失败，请检查浏览器存储设置'};
endif
stop
@enduml
```

- 校验在前、写入在后；写入失败保留内存数据（saveData 失败时 cache 不变），不跳转（满足 spec 5.1.3 异常场景 3）。
- 昵称长度按 `Array.from(str).length` 计算，正确计入中文与 Emoji 用户感知字符（满足 spec 5.1.1 规则 1）。
- 去除控制字符策略：先用正则 `/[\r\n\t\u0000-\u001F\u007F]/g` 替换为空，再 trim（满足 spec 5.1.1 规则 2）。

## 2.2 接口设计

### 2.2.1 总体设计

| 接口 | 所属模块 | 稳定性 | 调用方 |
|------|---------|--------|--------|
| getProfile() | userService | 稳定 | homeView、profileView |
| saveProfile({nickname, avatarKey}) | userService | 稳定 | profileView |
| getDefaultProfile() | userService | 稳定 | userService 内部、profileView |
| getAvatarSet() | userService | 稳定 | profileView |
| getAvatarEmojiByKey(key) | userService | 稳定 | homeView、profileView |
| render() | profileView | 稳定 | main.js 路由 |
| _renderIdentityBar() | homeView（私有） | 内部 | homeView.render() |

- 接口分类：userService 为领域服务（数据契约），profileView/homeView 为视图（渲染契约）。
- 接口变更策略：userService 方法签名稳定，预设头像集合仅追加新 key 不复用废弃 key（满足 spec 6.2 稳定性）。

### 2.2.2 接口清单

#### userService.getProfile()

- **接口签名**：`getProfile(): { nickname: string, avatarKey: string, updatedAt: number|null }`
- **业务说明**：读取当前用户资料，缺失或异常时回退默认资料。
- **前置条件**：localStorageAdapter 已 initData()。
- **后置条件**：无副作用，不写入存储；返回对象 nickname 与 avatarKey 必为合法非空字符串。
- **异常映射**：内部 try/catch，任何异常均回退默认资料，不抛出。
- **调用示例**：
```js
import { userService } from '../services/userService.js';
const profile = userService.getProfile();
// profile => { nickname: '梦想家', avatarKey: 'star', updatedAt: null }
```

#### userService.saveProfile({ nickname, avatarKey })

- **接口签名**：`saveProfile({ nickname: string, avatarKey: string }): { success: true, data: UserProfile } | { success: false, errors: object } | { success: false, error: string }`
- **业务说明**：校验并持久化用户资料到主数据 user 字段。
- **前置条件**：nickname 与 avatarKey 由调用方提供（profileView 从输入框与选中态获取）。
- **后置条件**：成功时主数据 user 字段更新为 {nickname, avatarKey, updatedAt: Date.now()}，其他业务字段（goals/records/checkIns/camps/achievements）保持原值不变；失败时不写入。
- **异常映射**：校验失败 → {success:false, errors}（字段级）；写入失败 → {success:false, error:'保存失败，请检查浏览器存储设置'}。
- **调用示例**：
```js
const result = userService.saveProfile({ nickname: '小明', avatarKey: 'rocket' });
if (result.success) {
  modal.toast('保存成功');
  window.location.hash = '#/';
} else if (result.errors) {
  modal.toast(result.errors.nickname || result.errors.avatar);
} else {
  modal.toast(result.error);
}
```

#### userService.getDefaultProfile()

- **接口签名**：`getDefaultProfile(): { nickname: string, avatarKey: string, updatedAt: null }`
- **业务说明**：返回默认资料常量，用于兜底与个人主页首次预填。
- **调用示例**：
```js
const def = userService.getDefaultProfile();
// def => { nickname: '梦想家', avatarKey: 'star', updatedAt: null }
```

#### userService.getAvatarSet()

- **接口签名**：`getAvatarSet(): Array<{ key: string, emoji: string, isDefault: boolean }>`
- **业务说明**：返回预设头像集合，供 profileView 渲染网格。
- **调用示例**：
```js
const set = userService.getAvatarSet();
// set => [{ key: 'star', emoji: '⭐', isDefault: true }, { key: 'rocket', emoji: '🚀', isDefault: false }, ...]
```

#### userService.getAvatarEmojiByKey(key)

- **接口签名**：`getAvatarEmojiByKey(key: string): string`
- **业务说明**：根据 key 查 Emoji 字符，非法或缺失回退默认头像 Emoji。
- **调用示例**：
```js
userService.getAvatarEmojiByKey('rocket'); // '🚀'
userService.getAvatarEmojiByKey('unknown'); // '⭐'（默认）
```

#### profileView.render()

- **接口签名**：`render(): void`
- **业务说明**：渲染个人主页，预填当前资料，绑定头像选择与保存交互。
- **前置条件**：localStorageAdapter 已 initData()。
- **后置条件**：#app 内 DOM 替换为个人主页；保存成功后跳转 #/。
- **异常映射**：渲染过程异常时展示错误兜底页与返回首页按钮（满足 spec 5.1.3 异常场景 6）。
- **调用示例**：
```js
// main.js 路由分支
} else if (hash === '#/profile') {
  profileView.render();
}
```

## 2.3 数据模型

### 2.3.1 设计目标

- 支持单用户本地资料（昵称+预设头像）的持久化与读取。
- 与现有主数据（goals/records/checkIns/camps/achievements）共存于同一对象，不破坏既有字段。
- 历史数据无 user 字段时无缝回退默认资料，无需手动迁移（满足 spec 4.5 兼容性第 1 条）。
- user 字段随主数据自动被备份/导入/清空（满足 spec 4.5 兼容性第 2、3 条）。
- 性能目标：读取 < 5ms（同步内存 cache），保存 < 50ms（同步写 cache + 异步 fetch），远低于 spec 4.1 性能要求。

### 2.3.2 模型实现

```plantuml
@startuml
class MainData {
  _version : number
  goals : Goal[]
  records : Record[]
  checkIns : CheckIn[]
  camps : Camp[]
  achievements : Achievement[]
  user : UserProfile|null
}
class UserProfile {
  nickname : string
  avatarKey : string
  updatedAt : number
}
class PresetAvatar {
  key : string
  emoji : string
  isDefault : boolean
}

MainData "1" o-- "0..1" UserProfile : user
PresetAvatar "*" ..> "1" UserProfile : avatarKey 取值约束

note right of UserProfile
  nickname: 1-20 用户感知字符
  avatarKey: 须属于 PRESET_AVATARS.key 集合
  updatedAt: 毫秒时间戳，对用户不可见
end note
@enduml
```

- **UserProfile**：领域对象，挂载于主数据对象的 user 字段；未设置时 user 为 null，由 userService.getProfile() 回退默认。
- **PresetAvatar**：常量集合元素，{key, emoji, isDefault}；key 一经发布不变更含义（满足 spec 6.2 稳定性）。
- **创建策略**：首次 saveProfile 时由 userService 构造 UserProfile 并赋值于 data.user；updatedAt 每次保存刷新。
- **销毁策略**：随 clearAllData 移除 DATA_KEY 一并销毁，无需单独处理。
- **持久化策略**：经 localStorageAdapter.saveData(data) 写入主数据对象，不单独建键、不绕过适配器（满足 spec 4.4 可维护性第 1 条）。
- **预设头像集合（PRESET_AVATARS）定义**：共 12 个，满足 spec 6.2 数量约束（8-16）：

| key | emoji | isDefault |
|-----|-------|-----------|
| star | ⭐ | true |
| rocket | 🚀 | false |
| fire | 🔥 | false |
| sun | ☀️ | false |
| moon | 🌙 | false |
| rainbow | 🌈 | false |
| gem | 💎 | false |
| crown | 👑 | false |
| cat | 🐱 | false |
| dog | 🐶 | false |
| panda | 🐼 | false |
| fox | 🦊 | false |

## 2.4 文件清单与职责

### 2.4.1 新增文件

| 文件路径 | 职责 |
|---------|------|
| src/services/userService.js | 用户资料领域服务：getProfile/saveProfile/getDefaultProfile/getAvatarSet/getAvatarEmojiByKey 与内部 _validate；经 localStorageAdapter 读写主数据 user 字段；校验昵称长度/字符与头像 key 合法性；异常回退默认资料 |
| src/views/profileView.js | 个人主页视图：render() 渲染页面骨架（返回首页链接、标题、昵称输入框、头像选择网格、保存按钮）；预填当前资料；头像点击切换选中态；保存按钮调用 userService.saveProfile 并 toast 反馈/跳转；渲染异常兜底 |

### 2.4.2 修改文件

| 文件路径 | 修改内容 | 影响范围 |
|---------|---------|---------|
| src/constants.js | 追加 USER_PROFILE_RULES（{NICKNAME_MIN:1, NICKNAME_MAX:20, DEFAULT_NICKNAME:'梦想家', DEFAULT_AVATAR_KEY:'star'}）与 PRESET_AVATARS（12 项数组） | 仅追加常量，不影响既有常量引用 |
| src/storage/localStorageAdapter.js | getEmptyData() 返回对象追加 `user: null`；initData() 末尾追加 `if (!cache.user) cache.user = null;` 兜底 | 仅追加字段兜底，不改动既有字段与读写逻辑；历史数据读取不受影响 |
| src/views/homeView.js | 顶部追加 `import { userService } from '../services/userService.js';`；新增 _renderIdentityBar() 私有方法（渲染头像+昵称可点击区域，点击跳转 #/profile，昵称用 textContent 防 XSS）；render() 内将 `page.appendChild(this._renderIdentityBar())` 作为首个 append 项（位于 _renderHero 之前） | 仅追加方法与一个 append 项，不修改既有 _renderHero/_renderStats 等方法；身份条读取异常时回退默认资料继续渲染，不影响后续区块 |
| src/main.js | 顶部 import 区追加 `import { profileView } from './views/profileView.js';`；在 `#/settings` 分支之后、`#/goal/new` 分支之前插入 `else if (hash === '#/profile') { profileView.render(); }` | 仅新增一条精确匹配分支与一个 import，不修改既有分支顺序与逻辑 |
| src/styles/main.css | 末尾追加身份条样式（.home-identity-bar、.home-identity-avatar、.home-identity-nickname 等）与个人主页样式（.profile-page、.profile-avatar-grid、.profile-avatar-item、.profile-avatar-item.selected 等），全部使用既有 CSS 变量 | 仅追加样式规则，不修改既有规则 |

## 2.5 关键设计决策

### 2.5.1 用户资料存储位置：主数据对象 user 字段

- **决策**：将 UserProfile 挂载于主数据对象（dream_saving_camp_data）的 user 字段，而非单独建 localStorage 键。
- **理由**：
  1. 复用现有 localStorageAdapter 的 getData/saveData 机制，不绕过适配器（满足 spec 4.4 可维护性第 1 条）。
  2. 随主数据自动被 backupService 导出/导入/清空，无需改 backupService（满足 spec 4.5 兼容性第 2、3 条）。
  3. 单用户本地应用，无需多用户集合，单字段足够。
- **替代方案（否决）**：单独建 `dream_user_profile` 键——需新增 STORAGE_KEYS、APP_DATA_KEYS、改 backupService 三处，改动面更大且违背"最小侵入"原则。

### 2.5.2 身份条位置：hero 区上方

- **决策**：身份条作为首页首个 append 项，位于 hero 区上方，作为独立横条。
- **理由**：
  1. spec 5.2.1 规则 1 允许"hero 区域内或其上方"，上方方案不破坏 hero 现有 decor/content/campBtn 结构。
  2. 独立横条语义清晰，点击区域明确，不与 hero 内部元素重叠。
  3. 渲染顺序最前，异常时回退默认资料不影响后续 hero/stats 等区块（满足 spec 5.2.3 异常场景 2）。
- **替代方案（否决）**：嵌入 hero 内部右上角——需修改 _renderHero 内部结构，侵入既有方法，违背"不影响现有功能"约束。

### 2.5.3 头像持久化：存 avatarKey 而非 Emoji

- **决策**：持久化 avatarKey（字符串标识），渲染时经 getAvatarEmojiByKey 映射为 Emoji。
- **理由**：spec 6.2 稳定性要求——集合调整（如替换 Emoji 字形）时，已存数据按 key 仍可正确回显，无需数据迁移。
- **实现**：PRESET_AVATARS 中 key 一经发布不复用废弃 key（仅追加新 key）。

### 2.5.4 昵称长度计算：Array.from 计字符数

- **决策**：用 `Array.from(str).length` 而非 `str.length` 计算昵称长度。
- **理由**：中文与 Emoji 在 JS 中可能由代理对组成，str.length 会高估；Array.from 按码点拆分，正确反映"用户感知字符"数（满足 spec 5.1.1 规则 1）。

### 2.5.5 XSS 防护：textContent 渲染昵称

- **决策**：所有昵称展示（首页身份条、个人主页回显）一律使用 `element.textContent = nickname`，禁止 innerHTML 拼接昵称。
- **理由**：textContent 自动转义 HTML 特殊字符，从源头杜绝 XSS（满足 spec 4.3 安全性第 1 条）。头像 Emoji 来自系统预设集合，非用户输入，无 XSS 风险，但仍用 textContent 设置。
- **输入框**：昵称输入用 `<input type="text" maxlength="20">`，maxlength 限制输入长度；保存前再经 userService 去控制字符 + trim + 长度校验双重保险。

### 2.5.6 控制字符过滤策略

- **决策**：保存前用正则 `/[\r\n\t\u0000-\u001F\u007F]/g` 去除换行符与不可见控制字符，再 trim。
- **理由**：满足 spec 5.1.1 规则 2 与 5.1.3 异常场景 1/2；正则覆盖 \r\n\t 及 ASCII 控制字符区（0x00-0x1F）与 DEL（0x7F）。

### 2.5.7 不影响现有功能的保障措施

1. **存储层**：localStorageAdapter 仅追加 user 字段兜底（getEmptyData + initData 末尾一行），不改动 read/write/saveData/getData 主体逻辑；既有 goals/records/checkIns/camps/achievements 读写路径完全不变。
2. **常量层**：constants.js 仅追加新常量，不修改既有常量值与引用。
3. **服务层**：userService 为新增独立文件，不导入也不修改既有任何 service。
4. **视图层**：homeView 仅追加一个 import、一个私有方法、render() 内一行 append（置于首位），不修改既有 _renderHero/_renderStats/_renderMotivation/_renderBadges/_renderGoalsSection/_renderEmpty/_renderSettingsEntry 任何方法体；profileView 为新增独立文件。
5. **路由层**：main.js 仅追加一个 import 与一条精确匹配分支（插入位置在精确匹配区内 `#/settings` 之后），不修改既有分支顺序与正则匹配区。
6. **样式层**：main.css 仅在末尾追加新类名规则，不修改既有规则；新类名采用 .home-identity-* 与 .profile-* 前缀，与既有 .home-* 类名不冲突。
7. **备份层**：backupService 不修改；user 字段随主数据自动导出/导入/清空。
8. **打卡与储蓄营**：完全不触碰 habitService/campService/campApiService/campDetailView 等，功能不受影响。

## 2.6 验收对照

| spec 验收条件 | 设计落点 |
|--------------|---------|
| 昵称空保存被拒 | saveProfile _validate：trim 后长度 < 1 → errors.nickname='昵称不能为空' |
| 昵称 ≤20 字保存成功 | _validate：Array.from 长度 ≤ 20 通过 |
| 昵称 >20 字被拒 | input maxlength=20 限制 + _validate 双重保险 |
| 换行符被去除 | _validate 正则替换控制字符 |
| 头像必选且须在集合内 | _validate：avatarKey 不在 PRESET_AVATARS → errors.avatar |
| 头像 key 非法回退默认 | getAvatarEmojiByKey 非法回退默认 Emoji；getProfile 异常回退默认资料 |
| 保存即时生效 | saveProfile 同步写 cache，跳转 #/ 后 homeView.render 重读最新 |
| 保存成功 toast | profileView _handleSave 调用 modal.toast('保存成功') |
| 首次使用显示默认 | getProfile 无 user 时回退 getDefaultProfile |
| 个人主页预填默认 | profileView render 用 getProfile 结果预填 input.value 与选中态 |
| 保存不清其他业务数据 | saveProfile 仅赋值 data.user，不动 data.goals 等其他字段 |
| 首页顶部身份区可见 | homeView _renderIdentityBar 作为首个 append 项 |
| 点击跳转 #/profile | _renderIdentityBar 点击事件 window.location.hash='#/profile' |
| 保存后首页显示新值 | 跳转 #/ 触发 homeView.render 重读 getProfile |
| 默认资料区可点击 | _renderIdentityBar 默认资料同样绑定点击事件 |
| 不泄露技术内部信息 | 身份条仅渲染 Emoji+昵称，无存储键名等 |
| 跳转渲染 <200ms | 同步内存读取+DOM 构建，远低于 200ms |
| 保存返回刷新 <300ms | 同步写+跳转+重渲染，远低于 300ms |
| 头像网格单次同步渲染 | profileView 一次性 for 循环 append 全部头像，无异步加载 |
| 存储失败提示且不清内存 | saveData 失败返回 false，userService 返回 error，不跳转；cache 未被替换 |
| 历史数据无 user 正常读取 | getProfile 回退默认；initData 末尾兜底 user=null |
| 字段损坏不白屏 | getProfile try/catch 回退默认；profileView render try/catch 兜底页 |
| 路由渲染异常不白屏 | profileView render try/catch 展示错误兜底页与返回首页按钮 |
| 备份导出含 user | user 随主数据对象导出 |
| 清空清除 user | clearAllData 移除 DATA_KEY，user 一并清除 |
| XSS 防护 | 昵称一律 textContent 渲染 |
| 头像不接受外部 URL | saveProfile 仅接受 PRESET_AVATARS 内 key，忽略任何 URL/base64 输入 |
| 资料仅存本地 | 无网络上传 user 字段的逻辑（saveData 的 fetch 为既有同步机制，非本设计新增） |
| 经适配器存取 | userService 仅用 getData/saveData，不直接操作 localStorage |
| 预设集合与默认集中定义 | PRESET_AVATARS 与 USER_PROFILE_RULES 在 constants.js |
| 新增路由不改既有分支 | main.js 仅插入一条精确匹配分支，不动既有顺序 |
| 头像数量 8-16 | PRESET_AVATARS 共 12 个 |
| avatarKey 唯一且稳定 | key 一经发布不复用废弃 key |
| 默认头像明确 | PRESET_AVATARS 中 isDefault:true 的项为 star |
