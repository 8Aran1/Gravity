# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 文字浮现动画：副标题 `p.home-hero-slogan` 透明度 0→1 | `.page-container` 已有 `pageFadeIn` 淡入动画先例（opacity 0→1 + translateY） | `src/styles/main.css:54-60` | 50% |
| 文字浮现动画：大标题 `h1.home-hero-title` 渐变文字保持 | `.home-hero-title` 已实现 `linear-gradient` + `background-clip: text` 渐变文字填充 | `src/styles/main.css:1511-1521` | 75% |
| 玻璃拟态：`backdrop-filter: blur()` 毛玻璃技术可行性 | `.modal-overlay`（blur 6px）、`.toast`（blur 10px）、`.home-hero-camp`（blur 8px + rgba 半透明）已有三处 backdrop-filter 先例 | `src/styles/main.css:602、638、1534-1535` | 75% |
| 动态背景：CSS `@keyframes` 无限循环动画技术可行性 | 已有 13 个 `@keyframes`，含 `homeOrbFloat`（8s 周期 infinite）等长周期先例 | `src/styles/main.css:57、357、656、661、683、1073、1142、1165、1365、1491、1769、1779、2194` | 50% |
| 主题协调：与 `body.theme-nebula/dawn/cyber` 共存 | 三套主题已通过 `body.theme-*` 选择器设置 `background` 简写覆盖默认 body 背景 | `src/styles/main.css:2115-2131` | 50% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 动态星空背景：深蓝→紫径向渐变 + 缓慢位移（≥8s）+ 呼吸感（≥6s） | `body` 仅有浅色 radial-gradient 装饰（绿/橙，透明度 0.04/0.03），无位移与呼吸动画；三套主题背景为静态渐变 | ① 色域差异：现有为浅色绿橙系，需求为深蓝紫系；② 动态差异：现有背景完全静态，需求需两个独立周期动画；③ 承载层差异：直接在 `body` 上加动画会与主题 `background` 简写冲突 | 新增 `body::before` 伪元素承载动态星空（`position:fixed; z-index:-1`），新增 2 个 `@keyframes`（位移周期 12s、呼吸周期 8s），三套主题下通过 `body.theme-*::before` 降低 opacity 实现协调共存 |
| 玻璃拟态卡片：`.goal-card` 半透明 + blur(10px) + 发光边框 | `.goal-card` 为 `background: var(--color-card)`（纯白不透明）+ `box-shadow: var(--shadow-sm)` + `border: 1px solid rgba(0,0,0,0.04)`，有 `:hover` 上浮与 `::before` 顶部彩条 | ① 背景差异：纯白→rgba(255,255,255,0.1) 半透明；② 模糊差异：无→blur(10px)；③ 边框差异：暗色细边→发光边框；④ 需保留 `:hover` 与 `::before` 交互 | 修改 `.goal-card` 的 `background`/`backdrop-filter`/`border`/`box-shadow` 四项，`:hover` 增强发光，`::before` 彩条保留 |
| 玻璃拟态按钮：`.home-create-btn` 半透明 + blur(10px) + 发光边框 | `.home-create-btn` 为 `background: var(--color-primary)`（绿色不透明）+ `color:#fff` + `box-shadow`，有 `:hover` 加深变色 | ① 背景差异：绿色→rgba(255,255,255,0.1) 半透明；② 模糊差异：无→blur(10px)；③ 需保留 `:hover` 交互与点击区域 | 修改 `.home-create-btn` 的 `background`/`backdrop-filter`/`border`/`box-shadow`，`:hover` 调整为增强发光而非加深底色 |
| 文字浮现动画：`h1.home-hero-title` 自下而上 + 透明度 0→1（0.6s~1.5s） | `.home-hero-title` 有渐变文字但无进入动画；`pageFadeIn`/`slideUp` 有类似位移+透明度模式但作用域不同 | ① 动画差异：无→需新增自下而上浮现；② 约束差异：动画不得触碰 `background`/`background-clip`（否则破坏渐变文字）；③ 时长差异：需落在 0.6s~1.5s | 新增 1 个 `@keyframes heroFadeUp`（仅动 `opacity` + `transform: translateY`），给 `.home-hero-title` 加 `animation`，`both` 保持终态 |
| 文字浮现动画：`p.home-hero-slogan` 自下而上 + 透明度 0→1 | `.home-hero-slogan` 为普通静态文字，无动画 | ① 动画差异：无→需新增浮现；② 需与标题动画节奏协调 | 复用 `heroFadeUp`，给 `.home-hero-slogan` 加 `animation` 并设 `animation-delay` 错峰 |

### 1.1.3 需要新增的功能或接口

本需求为纯 CSS 视觉增强，无新增 JS 接口、无新增 HTML 结构、无新增数据模型。需新增的 CSS 资产如下：

**动画模块（`@keyframes`）**
- `starDrift`：动态星空背景位移动画，周期 12s（满足 ≥8s），通过 `background-position` 缓慢偏移产生光线缓动
- `starBreath`：动态星空背景呼吸感动画，周期 8s（满足 ≥6s），通过 `transform: scale()` 微幅缩放产生脉动
- `heroFadeUp`：文字浮现动画，时长 1.2s（满足 0.6s~1.5s），`opacity` 0→1 + `translateY` 20px→0

**样式规则**
- `body::before`：动态星空背景承载伪元素
- `body.theme-nebula::before` / `body.theme-dawn::before` / `body.theme-cyber::before`：主题下星空背景协调降级
- `.goal-card` 玻璃拟态化改造（修改既有规则）
- `.home-create-btn` 玻璃拟态化改造（修改既有规则）
- `.home-hero-title` / `.home-hero-slogan` 浮现动画绑定（修改既有规则）

## 1.2 存量功能详细分析

### 1.2.1 `body` 背景与主题系统

**接口契约**
- `body` 默认背景：`background: var(--color-bg)`（#F2F4F8）+ `background-image: radial-gradient(...)` 两层淡色装饰 + `background-attachment: fixed`
- `body.theme-nebula`：`background: linear-gradient(135deg, #4B0082, #2D0A4E, #0A0A1A)` + `background-color: #0A0A1A` + `background-attachment: fixed`
- `body.theme-dawn`：`background: radial-gradient(circle at 30% 25%, #FFF8DC, #FFD580, #FF8C42)` + `background-color: #FF8C42`
- `body.theme-cyber`：`background: linear-gradient(135deg, #0B1E3F, #0A4D8C, #00E5FF)` + `background-color: #0B1E3F`

**业务规则**
- 主题切换由 JS `themeService.applyTheme(key)` 通过 `classList.remove` + `classList.add` 实现，CSS 仅通过 class 选择器响应
- 三套主题均用 `background` 简写属性，会覆盖 `body` 默认的 `background-image` 装饰层
- 三套主题均设置 `background-attachment: fixed`，背景不随滚动

**约束**
- 主题背景下 `body` 的 `background` 已被占用，动态星空背景**不能**直接叠加在 `body` 的 `background` 属性上，否则会被主题 `background` 简写覆盖
- 动态星空必须通过独立层（`body::before` 伪元素）承载，`z-index: -1` 置于内容下方
- 主题切换时 `body::before` 不受 `body.background` 简写影响（伪元素有独立背景），需通过 `body.theme-*::before` 选择器协调

### 1.2.2 `.goal-card` 卡片

**接口契约**
- `background: var(--color-card)`（#FFFFFF 纯白不透明）
- `border-radius: var(--radius-lg)`（16px）、`padding: 22px`、`box-shadow: var(--shadow-sm)`
- `border: 1px solid rgba(0, 0, 0, 0.04)`、`position: relative`、`overflow: hidden`
- `cursor: pointer`、`transition: all 0.25s var(--ease-out)`

**业务规则**
- `:hover`：`box-shadow` 升级为 `--shadow-md` + `transform: translateY(-3px)` + `border-color` 变绿
- `::before`：顶部 3px 高的渐变彩条，默认 `opacity: 0`，`:hover` 时 `opacity: 1` 渐显

**约束**
- `overflow: hidden` 会裁剪溢出内容，发光边框的 `box-shadow` 外发光不受影响（外阴影在 overflow 外）
- `position: relative` 已建立定位上下文，`::before` 彩条依赖此定位
- 玻璃拟态改造**必须保留** `:hover` 上浮交互与 `::before` 彩条逻辑，仅替换背景/边框/阴影表现

### 1.2.3 `.home-create-btn` 按钮

**接口契约**
- `background: var(--color-primary)`（#4CAF50 绿色不透明）、`color: #fff`
- `padding: 9px 20px`、`border: none`、`border-radius: var(--radius-lg)`
- `box-shadow: 0 4px 14px rgba(76, 175, 80, 0.25)`、`transition: all 0.2s ease`
- `display: inline-flex`、`cursor: pointer`

**业务规则**
- `:hover`：`background` 加深为 `--color-primary-dark` + `transform: translateY(-2px)` + `box-shadow` 增强
- 该类还被引力场列表复用：`campListView.js:53` 中 `joinBtn.className = 'home-create-btn camp-join-btn'`，叠加 `.camp-join-btn`（`background: rgba(255,255,255,0.7)`）会覆盖背景

**约束**
- 玻璃拟态改造后，`:hover` 不能再用加深底色（底色已变半透明），需改为增强发光
- `.camp-join-btn` 复用时背景会被覆盖，需确认引力场按钮视觉协调（`.camp-join-btn` 已自带半透明 + border，与玻璃拟态风格兼容）
- 点击区域由 `padding` + `border-radius` 决定，`backdrop-filter` 不改变盒模型，点击区域不受影响

### 1.2.4 `.home-hero-title` 与 `.home-hero-slogan`

**接口契约**
- `.home-hero-title`：`font-size: 2.6rem`、`font-weight: 800`、`background: linear-gradient(135deg, #2E7D32, #4CAF50, #66BB6A)`、`-webkit-background-clip: text`、`background-clip: text`、`-webkit-text-fill-color: transparent`
- `.home-hero-slogan`：`font-size: 1.02rem`、`color: var(--color-text-light)`、普通文字
- 移动端 `@media (max-width: 768px)`：`.home-hero-title` `font-size: 2rem`

**业务规则**
- 大标题"引力"依赖 `background-clip: text` 将渐变填充为文字颜色，`-webkit-text-fill-color: transparent` 使文字本身透明以透出渐变

**约束**
- 浮现动画**只能**操作 `opacity` 与 `transform`，**严禁**操作 `background`/`background-clip`/`-webkit-text-fill-color`，否则渐变文字失效
- `opacity` 动画与 `-webkit-text-fill-color: transparent` 兼容（opacity 作用于整个元素层，不影响 background-clip 机制）
- 动画需 `animation-fill-mode: both`，确保动画起始帧 `opacity: 0` 生效（避免首帧闪现），终态保持 `opacity: 1`
- 动画仅播放一次（`infinite` 禁止），避免循环干扰阅读

### 1.2.5 `backdrop-filter` 兼容性现状

**已有先例**
- `.modal-overlay`：`backdrop-filter: blur(6px)`（602 行）
- `.toast`：`backdrop-filter: blur(10px)`（638 行）
- `.home-hero-camp`：`backdrop-filter: blur(8px)` + `background: rgba(255,255,255,0.7)`（1534-1535 行）

**约束**
- 项目已接受 `backdrop-filter` 无降级方案（不支持浏览器仅丢失模糊，半透明背景仍生效）
- 需补充 `-webkit-backdrop-filter` 前缀以兼容 Safari 早期版本
- 不支持 `backdrop-filter` 时：`background: rgba(255,255,255,0.1)` 半透明 + 发光边框仍呈现，满足 spec 4.5.1 降级要求

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用用户" as User
rectangle "浏览器渲染引擎" as Browser {
  rectangle "CSS 解析器" as Parser
  rectangle "动画引擎" as AnimEngine
  rectangle "合成器\n(Compositor)" as Compositor
}
rectangle "引力·Gravity 首页\n(视觉增强组件)" as Component {
  rectangle "body::before\n动态星空层" as StarLayer
  rectangle ".goal-card / .home-create-btn\n玻璃拟态层" as GlassLayer
  rectangle ".home-hero-title / .home-hero-slogan\n文字浮现层" as TextLayer
}
rectangle "现有主题系统\n(theme-nebula/dawn/cyber)" as Theme
database "main.css\n(唯一变更文件)" as CSS

User --> Component : 访问首页
Parser --> CSS : 解析 @keyframes 与规则
AnimEngine --> StarLayer : 驱动 starDrift(12s) + starBreath(8s)
AnimEngine --> TextLayer : 驱动 heroFadeUp(1.2s) 一次性
Compositor --> GlassLayer : 合成 backdrop-filter: blur(10px)
Theme --> StarLayer : body.theme-*::before\n协调降级 opacity
Component --> User : 呈现动态视觉
@enduml
```

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
package "main.css 视觉增强组件" {
  package "动态星空背景模块" {
    [body::before] as StarEl
    [starDrift @keyframes] as DriftKF
    [starBreath @keyframes] as BreathKF
    [body.theme-*::before] as ThemeStar
  }
  package "玻璃拟态模块" {
    [.goal-card 改造] as GoalCard
    [.home-create-btn 改造] as CreateBtn
  }
  package "文字浮现模块" {
    [.home-hero-title 绑定] as HeroTitle
    [.home-hero-slogan 绑定] as HeroSlogan
    [heroFadeUp @keyframes] as FadeKF
  }
  package "既有 CSS 变量体系" as Vars {
    [--ease-out]
    [--radius-lg]
    [--shadow-*]
  }
}

StarEl --> DriftKF : animation 引用
StarEl --> BreathKF : animation 引用
ThemeStar --> StarEl : opacity 覆盖
GoalCard --> Vars
CreateBtn --> Vars
HeroTitle --> FadeKF : animation 引用
HeroSlogan --> FadeKF : animation 引用\n(delay 错峰)
@enduml
```

**模块划分与职责**
- **动态星空背景模块**：`body::before` 伪元素 + 2 个 `@keyframes` + 3 个主题协调规则，负责深蓝→紫径向渐变与缓慢动态
- **玻璃拟态模块**：`.goal-card` 与 `.home-create-btn` 既有规则改造，负责半透明 + 毛玻璃 + 发光边框
- **文字浮现模块**：1 个 `@keyframes` + 2 个元素动画绑定，负责标题与副标题自下而上浮现
- 三模块相互独立，无运行时依赖，仅共享既有 CSS 变量体系（`--ease-out`、`--radius-lg`、`--shadow-*`）

### 2.1.3 实现设计文档

**动态星空背景状态流转**

```plantuml
@startuml
state "默认状态\n(无 theme class)" as Default {
  state "body::before opacity:1\nstarDrift 12s infinite\nstarBreath 8s infinite" as FullStar
}
state "theme-nebula" as Nebula {
  state "body::before opacity:0.35\n与深紫主题融合" as NebulaStar
}
state "theme-dawn" as Dawn {
  state "body::before opacity:0.25\n与暖橙主题融合" as DawnStar
}
state "theme-cyber" as Cyber {
  state "body::before opacity:0.4\n与深蓝青主题融合" as CyberStar
}

[*] --> Default
Default --> Nebula : applyTheme('nebula')
Default --> Dawn : applyTheme('dawn')
Default --> Cyber : applyTheme('cyber')
Nebula --> Dawn : 切换主题
Dawn --> Cyber : 切换主题
Cyber --> Default : 移除 theme class
@enduml
```

**设计决策：主题下星空不隐藏而降级融合**
- 选择理由：spec 5.1.1 规则4 要求"各主题下背景均正常呈现，切换功能不受影响"。若主题下完全隐藏 `body::before`（opacity:0），则主题下丢失动态星空氛围，仅剩静态主题渐变，不符合"协调共存"语义。降级为低 opacity（0.25~0.4）让星空动态隐约透出，与主题色融合，既保留动态感又不喧宾夺主。
- `theme-dawn` 为暖色亮主题，星空深蓝紫在其上会偏暗，故 opacity 最低（0.25）；`theme-cyber` 本身深蓝系，与星空同色系融合最协调，opacity 最高（0.4）；`theme-nebula` 深紫系，居中（0.35）。

**文字浮现时序设计**

```plantuml
@startuml
|浏览器渲染引擎|
start
:解析 .home-hero-title 规则;
:首帧 animation-fill-mode:both\nopacity:0, translateY(20px);
|动画引擎|
:0s 启动 heroFadeUp 1.2s;
:0.2s 启动副标题 heroFadeUp 1.2s\n(标题先 0.2s);
:1.2s 标题动画完成\nopacity:1, translateY(0)\n渐变文字完整呈现;
:1.4s 副标题动画完成\nopacity:1, translateY(0);
|浏览器渲染引擎|
:保持终态(both)\n不再循环;
stop
@enduml
```

**设计决策：副标题延迟 0.2s 错峰**
- 选择理由：spec 5.3.1 规则4 要求总时长 ≤1.5s。标题 1.2s + 副标题延迟 0.2s，副标题 1.4s 完成，均落在 0.6s~1.5s 区间。错峰产生"先主后次"的视觉节奏，比同时浮现更优雅。

**玻璃拟态降级流程**

```plantuml
@startuml
start
:渲染 .goal-card / .home-create-btn;
if (浏览器支持 backdrop-filter?) then (支持! 是)
  :半透明背景 rgba(255,255,255,0.1);
  :毛玻璃 blur(10px) 生效;
  :发光边框 + 外发光阴影;
else (不支持! 否)
  :半透明背景 rgba(255,255,255,0.1) 仍生效;
  :blur 失效(无模糊);
  :发光边框 + 外发光阴影 仍生效;
  :降级为半透明+发光\n(无毛玻璃);
endif
:文字清晰可读;
:点击区域不受影响;
stop
@enduml
```

## 2.2 接口设计

### 2.2.1 总体设计

本组件为纯 CSS 视觉增强，无 JS 接口、无 HTTP 接口、无数据接口。所有"接口"表现为 CSS 选择器契约——即对既有 DOM 结构的样式声明。

| 接口（CSS 选择器） | 类型 | 稳定性 | 变更方式 |
|---------|------|--------|---------|
| `body::before` | 新增 | 稳定 | 新增规则 |
| `body.theme-nebula::before` | 新增 | 稳定 | 新增规则 |
| `body.theme-dawn::before` | 新增 | 稳定 | 新增规则 |
| `body.theme-cyber::before` | 新增 | 稳定 | 新增规则 |
| `@keyframes starDrift` | 新增 | 稳定 | 新增动画 |
| `@keyframes starBreath` | 新增 | 稳定 | 新增动画 |
| `@keyframes heroFadeUp` | 新增 | 稳定 | 新增动画 |
| `.goal-card` | 修改 | 稳定 | 改造 background/border/box-shadow + 新增 backdrop-filter |
| `.goal-card:hover` | 修改 | 稳定 | 增强发光表现 |
| `.home-create-btn` | 修改 | 稳定 | 改造 background/border/box-shadow + 新增 backdrop-filter |
| `.home-create-btn:hover` | 修改 | 稳定 | 改为增强发光 |
| `.home-hero-title` | 修改 | 稳定 | 新增 animation（不触碰 background 相关属性） |
| `.home-hero-slogan` | 修改 | 稳定 | 新增 animation |

**接口变更策略**
- 仅修改既有规则的属性值与新增属性，不删除任何既有属性（除被替换的 `background` 值外）
- 不新增任何 class/HTML 结构，完全依赖既有 DOM
- 动画命名采用 camelCase（`starDrift`/`starBreath`/`heroFadeUp`），与既有 `pageFadeIn`/`homeOrbFloat`/`advisorSlideUp` 命名风格一致

### 2.2.2 接口清单

#### 动态星空背景

**`body::before` 伪元素**
- **签名**：`body::before { content: ''; position: fixed; inset: 0; z-index: -1; background: radial-gradient(...); animation: starDrift 12s ease-in-out infinite, starBreath 8s ease-in-out infinite; }`
- **业务说明**：承载深蓝→紫径向渐变与两个独立周期动画，作为页面最底层动态背景
- **前置条件**：`body` 元素存在（由 `index.html` 保证）
- **后置条件**：页面背景呈现深蓝至紫色径向渐变，缓慢位移与呼吸感动态
- **异常映射**：浏览器不支持 CSS 动画 → 降级为静态径向渐变（`body::before` 仍渲染，仅无动画）
- **色域约束**：径向渐变色值落在 `#0A0A2A`~`#1A1A4E`（深蓝）至 `#4B0082`~`#6A0DAD`（紫）区间

**`@keyframes starDrift`**
- **签名**：`@keyframes starDrift { 0%,100% { background-position: 0% 0%; } 50% { background-position: 100% 100%; } }`
- **业务说明**：通过 `background-position` 缓慢偏移产生光线缓动，周期 12s（满足 ≥8s）
- **前置条件**：`body::before` 背景为径向渐变且 `background-size` 非默认（需设大于 100% 以产生位移空间）

**`@keyframes starBreath`**
- **签名**：`@keyframes starBreath { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.05); opacity: 0.92; } }`
- **业务说明**：微幅缩放（1→1.05）与透明度微变（1→0.92）产生呼吸脉动，周期 8s（满足 ≥6s）
- **前置条件**：`body::before` 已设置 `transform-origin: center`

**`body.theme-nebula::before` / `body.theme-dawn::before` / `body.theme-cyber::before`**
- **签名**：`body.theme-nebula::before { opacity: 0.35; }` / `body.theme-dawn::before { opacity: 0.25; }` / `body.theme-cyber::before { opacity: 0.4; }`
- **业务说明**：主题激活时降低星空层透明度，与主题背景协调共存
- **后置条件**：主题切换时星空动态隐约透出，主题色为主、星空为辅，无视觉撕裂

#### 玻璃拟态卡片

**`.goal-card` 改造**
- **签名**：`background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 0 20px rgba(255, 255, 255, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.15);`
- **业务说明**：卡片改为半透明 + 毛玻璃 + 发光边框，后方动态背景透出并模糊
- **前置条件**：`body::before` 动态背景已渲染（提供模糊源）
- **后置条件**：卡片呈玻璃质感，`:hover` 上浮与 `::before` 彩条保留
- **异常映射**：不支持 `backdrop-filter` → 半透明背景 + 发光边框仍生效，仅无模糊

**`.home-create-btn` 改造**
- **签名**：`background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.25); box-shadow: 0 0 16px rgba(255, 255, 255, 0.15);`
- **业务说明**：按钮改为半透明 + 毛玻璃 + 发光边框，与卡片风格统一
- **后置条件**：按钮玻璃质感，`:hover` 增强发光，点击区域不变

#### 文字浮现动画

**`@keyframes heroFadeUp`**
- **签名**：`@keyframes heroFadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }`
- **业务说明**：自下往上位移 20px + 透明度 0→1，时长由调用方指定
- **约束**：仅操作 `opacity` 与 `transform`，不触碰 `background`/`background-clip`/`-webkit-text-fill-color`

**`.home-hero-title` 动画绑定**
- **签名**：`animation: heroFadeUp 1.2s var(--ease-out) both;`
- **业务说明**：大标题"引力"缓缓浮现，1.2s 完成（满足 0.6s~1.5s）
- **后置条件**：动画完成后 `opacity:1` + `translateY(0)`，渐变文字完整保持
- **异常映射**：弱性能设备帧率降低 → 动画略卡顿但 `both` 保证终态完整显现

**`.home-hero-slogan` 动画绑定**
- **签名**：`animation: heroFadeUp 1.2s var(--ease-out) 0.2s both;`
- **业务说明**：副标题延迟 0.2s 错峰浮现，1.4s 完成（满足 0.6s~1.5s）

## 2.3 数据模型

### 2.3.1 设计目标

本组件为纯 CSS 视觉增强，无业务数据模型、无持久化、无 localStorage 交互。数据模型仅表现为 CSS 层面的"视觉规格常量"：

- **支持的业务场景**：首页动态背景渲染、卡片玻璃拟态呈现、标题文字浮现
- **性能目标**：60fps 流畅动画，`transform`/`opacity` 走合成器线程不阻塞主线程
- **容量目标**：新增 CSS 规则约 30 行，无运行时内存增长
- **兼容策略**：`backdrop-filter` 不支持时降级为半透明 + 发光边框；CSS 动画不支持时降级为静态渐变

### 2.3.2 模型实现

```plantuml
@startuml
class "body::before" as StarLayer {
  +background : radial-gradient
  +position : fixed
  +z-index : -1
  +animation : starDrift + starBreath
  +opacity : 1 (默认) / 0.25~0.4 (主题下)
}

class "starDrift" as Drift {
  +duration : 12s
  +property : background-position
  +iteration : infinite
}

class "starBreath" as Breath {
  +duration : 8s
  +property : transform, opacity
  +iteration : infinite
}

class ".goal-card" as GoalCard {
  +background : rgba(255,255,255,0.1)
  +backdrop-filter : blur(10px)
  +border : rgba(255,255,255,0.2)
  +box-shadow : 外发光 + inset 高光
}

class ".home-create-btn" as CreateBtn {
  +background : rgba(255,255,255,0.1)
  +backdrop-filter : blur(10px)
  +border : rgba(255,255,255,0.25)
  +box-shadow : 外发光
}

class "heroFadeUp" as Fade {
  +duration : 1.2s
  +property : opacity, transform
  +iteration : 1 (both)
}

class ".home-hero-title" as Title {
  +animation : heroFadeUp 1.2s both
  +background-clip : text (保留! 不动)
}

class ".home-hero-slogan" as Slogan {
  +animation : heroFadeUp 1.2s 0.2s both
}

StarLayer "1" *-- "1..2" Drift
StarLayer "1" *-- "1..2" Breath
Title "1" *-- "1" Fade
Slogan "1" *-- "1" Fade
GoalCard ..> StarLayer : backdrop-filter 模糊源
CreateBtn ..> StarLayer : backdrop-filter 模糊源
@enduml
```

**对象关系说明**
- `body::before` 组合拥有 `starDrift` 与 `starBreath` 两个动画（多重 animation 逗号分隔）
- `.home-hero-title` 与 `.home-hero-slogan` 共享同一个 `heroFadeUp` 动画定义，通过 `animation-delay` 区分节奏
- `.goal-card` 与 `.home-create-btn` 依赖 `body::before` 作为 `backdrop-filter` 的模糊源（后方有动态内容才能产生毛玻璃效果）
- 所有视觉对象生命周期与页面一致，无创建/销毁操作

**持久化策略**
- 无持久化。视觉规格常量硬编码于 CSS（色值、时长、透明度），不经过 JS、不读写 localStorage
- 主题协调的 opacity 值（0.25/0.35/0.4）为 CSS 常量，不暴露为 CSS 变量（避免被 JS 覆盖，保持视觉一致性）

**关键约束汇总**
1. **唯一变更文件**：`src/styles/main.css`，新增约 30 行，修改 4 处既有规则
2. **不触碰 HTML/JS**：无新增 class、无新增 DOM 节点、无 JS 改动
3. **渐变文字保护**：`.home-hero-title` 的 `animation` 仅含 `opacity`/`transform`，不触碰 `background`/`background-clip`/`-webkit-text-fill-color`
4. **点击区域保护**：`backdrop-filter` 不改变盒模型，`:hover` 的 `transform` 保留，点击区域与改造前一致
5. **主题协调**：`body::before` 在主题下通过 opacity 降级融合，不与 `body.background` 简写冲突（伪元素独立背景层）
6. **降级安全**：`backdrop-filter` 不支持时半透明背景 + 发光边框仍生效；CSS 动画不支持时静态渐变仍呈现，均无白屏