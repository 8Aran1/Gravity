# 视觉增强组件 - 编码任务清单

> 本清单基于 `spec.md`（需求规格）与 `design.md`（增量设计）生成，将纯 CSS 视觉增强方案转化为可执行、可验收的编码任务。
>
> **唯一变更文件**：`src/styles/main.css`（当前 2389 行）
> **硬约束**：禁止修改任何 `.html` / `.js` 文件，禁止新增/删除文件，禁止变更目录结构，禁止触碰 localStorage 键。

---

## 1. 动态星空背景实现

**写作指导**：本组任务负责新增 `body::before` 伪元素与两个 `@keyframes` 动画，构成页面最底层动态星空层。三套主题下通过 opacity 降级融合，不与 `body.background` 简写冲突。

### 1.1 新增 `@keyframes starDrift` 位移动画

- [ ] 在 `src/styles/main.css` 中新增 `@keyframes starDrift`，通过 `background-position` 在 `0% 0%` → `100% 100%` → `0% 0%` 之间缓慢偏移，周期 12s（满足 spec ≥8s），`ease-in-out` 缓动，`infinite` 循环；动画定义放置于既有 `@keyframes` 区块附近，保持 camelCase 命名风格

### 1.2 新增 `@keyframes starBreath` 呼吸感动画

- [ ] 在 `src/styles/main.css` 中新增 `@keyframes starBreath`，通过 `transform: scale(1)` → `scale(1.05)` 与 `opacity: 1` → `0.92` 微幅缩放与透明度脉动，周期 8s（满足 spec ≥6s），`ease-in-out` 缓动，`infinite` 循环；与 `starDrift` 相邻放置

### 1.3 新增 `body::before` 伪元素承载动态星空

- [ ] 在 `src/styles/main.css` 中新增 `body::before` 规则，设置 `content: ''`、`position: fixed`、`inset: 0`、`z-index: -1`、`transform-origin: center`，`background` 为深蓝至紫色径向渐变（色值落在 `#0A0A2A`~`#1A1A4E` 至 `#4B0082`~`#6A0DAD` 区间），`background-size` 设大于 100% 以产生位移空间，`animation: starDrift 12s ease-in-out infinite, starBreath 8s ease-in-out infinite` 双动画叠加；规则放置于 `body` 基础规则之后

### 1.4 新增主题协调降级规则（依赖 1.3）

- [ ] 在 `src/styles/main.css` 的主题规则区（第 2115-2131 行附近）之后新增三条规则：`body.theme-nebula::before { opacity: 0.35; }`、`body.theme-dawn::before { opacity: 0.25; }`、`body.theme-cyber::before { opacity: 0.4; }`，使星空层在主题激活时降级融合而非隐藏，保证主题切换功能不受影响且无视觉撕裂

---

## 2. 玻璃拟态卡片与按钮改造

**写作指导**：本组任务修改 `.goal-card`（第 220 行）与 `.home-create-btn`（第 1695 行）既有规则，将其改为半透明 + 毛玻璃 + 发光边框。必须保留 `:hover` 交互与 `::before` 彩条逻辑，仅替换表现属性。

### 2.1 改造 `.goal-card` 为玻璃拟态

- [ ] 修改 `src/styles/main.css` 第 220 行 `.goal-card` 规则，将 `background` 改为 `rgba(255, 255, 255, 0.1)`，新增 `backdrop-filter: blur(10px)` 与 `-webkit-backdrop-filter: blur(10px)`，将 `border` 改为 `1px solid rgba(255, 255, 255, 0.2)`，将 `box-shadow` 改为 `0 0 20px rgba(255, 255, 255, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.15)`（外发光 + inset 高光）；保留 `border-radius`、`padding`、`position: relative`、`overflow: hidden`、`cursor: pointer`、`transition` 等既有属性不动

### 2.2 改造 `.goal-card:hover` 增强发光（依赖 2.1）

- [ ] 修改 `src/styles/main.css` 中 `.goal-card:hover` 规则，将 `:hover` 表现从"加深底色 + 升级阴影"调整为"增强外发光 + 保留上浮"，保留 `transform: translateY(-3px)` 上浮交互，`box-shadow` 增强为更大半径的发光光晕，`::before` 顶部彩条渐显逻辑完全保留不动

### 2.3 改造 `.home-create-btn` 为玻璃拟态

- [ ] 修改 `src/styles/main.css` 第 1695 行 `.home-create-btn` 规则，将 `background` 改为 `rgba(255, 255, 255, 0.1)`，新增 `backdrop-filter: blur(10px)` 与 `-webkit-backdrop-filter: blur(10px)`，将 `border` 改为 `1px solid rgba(255, 255, 255, 0.25)`，将 `box-shadow` 改为 `0 0 16px rgba(255, 255, 255, 0.15)`；保留 `color`、`padding`、`border-radius`、`display: inline-flex`、`cursor: pointer`、`transition` 等既有属性不动，确保点击区域（盒模型）不变

### 2.4 改造 `.home-create-btn:hover` 增强发光（依赖 2.3）

- [ ] 修改 `src/styles/main.css` 中 `.home-create-btn:hover` 规则，将 `:hover` 从"加深底色为 `--color-primary-dark`"改为"增强外发光光晕"，保留 `transform: translateY(-2px)` 上浮交互；确认 `.camp-join-btn` 复用时（`campListView.js:53` 叠加该类）视觉协调，不破坏引力场加入按钮的可点击性

---

## 3. 文字浮现动画实现

**写作指导**：本组任务新增 `@keyframes heroFadeUp` 并绑定至首页大标题与副标题。关键约束：动画仅操作 `opacity` 与 `transform`，严禁触碰 `background`/`background-clip`/`-webkit-text-fill-color`，否则渐变文字失效。

### 3.1 新增 `@keyframes heroFadeUp` 浮现动画

- [ ] 在 `src/styles/main.css` 中新增 `@keyframes heroFadeUp`，定义 `from { opacity: 0; transform: translateY(20px); }` 与 `to { opacity: 1; transform: translateY(0); }`，仅操作 `opacity` 与 `transform` 两个属性，不包含任何 `background` 相关属性；放置于既有 `@keyframes` 区块附近

### 3.2 绑定 `.home-hero-title` 浮现动画（依赖 3.1）

- [ ] 修改 `src/styles/main.css` 第 1511 行 `.home-hero-title` 规则，新增 `animation: heroFadeUp 1.2s var(--ease-out) both;`，时长 1.2s（满足 0.6s~1.5s），`both` 保证首帧 `opacity: 0` 生效避免闪现、终态保持 `opacity: 1`；严禁修改该规则中的 `background`、`-webkit-background-clip`、`background-clip`、`-webkit-text-fill-color` 四项渐变文字属性

### 3.3 绑定 `.home-hero-slogan` 错峰浮现动画（依赖 3.1）

- [ ] 修改 `src/styles/main.css` 第 1523 行 `.home-hero-slogan` 规则，新增 `animation: heroFadeUp 1.2s var(--ease-out) 0.2s both;`，`animation-delay: 0.2s` 实现错峰（标题先 0.2s，副标题 1.4s 完成，均落在 0.6s~1.5s 区间），`both` 保持终态；动画仅播放一次，禁止 `infinite`

---

## 4. 集成验证与测试

**写作指导**：本组任务确保三模块视觉增强可用、不破坏既有交互、降级安全。必须包含视觉效果验证、交互保持验证、降级兼容验证与主题协调验证。

### 4.1 视觉效果验证

- [ ] 打开应用首页，确认背景呈现深蓝至紫色径向渐变且在 12s 周期内缓慢位移、8s 周期内呼吸脉动；确认 `.goal-card` 卡片呈半透明毛玻璃质感且后方背景隐约模糊透出、边缘有柔和发光；确认 `.home-create-btn` 按钮呈玻璃质感与卡片风格统一；确认大标题"引力"自下而上由透明渐变为完全显现（1.2s）、副标题延迟 0.2s 后错峰浮现，动画完成后大标题渐变文字效果完整保留

### 4.2 交互保持验证

- [ ] 在首页悬停 `.goal-card` 卡片，确认上浮反馈与顶部彩条渐显均正常生效；点击 `.home-create-btn` 按钮确认跳转/创建行为正常；点击引力场列表中的加入按钮（`.home-create-btn.camp-join-btn`）确认加入行为正常；确认所有按钮点击区域无偏移、无缩小、无遮挡；确认页面无白屏、无布局错乱、无元素消失

### 4.3 降级与兼容验证

- [ ] 在不支持 `backdrop-filter` 的浏览器（或通过 DevTools 禁用）中打开首页，确认卡片与按钮仍呈半透明背景与发光边框、文字清晰可读、无白屏无塌陷；在弱性能设备或 DevTools 限速 6× 下确认文字浮现动画略卡顿但最终完整显现、背景动画不阻塞主线程；确认移动端窄屏（≤768px）与桌面端均无溢出或点击失效

### 4.4 主题协调验证

- [ ] 在首页依次切换 `theme-nebula`、`theme-dawn`、`theme-cyber` 主题，确认各主题下星空背景以低 opacity（0.35/0.25/0.4）隐约透出与主题色融合、无视觉撕裂或残留；确认主题切换功能本身完全正常、切换流畅；确认切回默认主题后星空层恢复 opacity:1 全动态呈现

---

## 5. 部署配置与变更确认

**写作指导**：本组任务确保变更范围受控、可上线、可维护。必须包含变更范围确认、性能与可维护性检查、测试说明。

### 5.1 变更范围最终确认

- [ ] 通过 `git diff` 或文件比对确认本次变更仅涉及 `src/styles/main.css` 单一文件，新增约 30 行（3 个 `@keyframes` + `body::before` + 3 条主题协调规则）、修改 4 处既有规则（`.goal-card`、`.goal-card:hover`、`.home-create-btn`、`.home-create-btn:hover`）及 2 处动画绑定（`.home-hero-title`、`.home-hero-slogan`）；确认无任何 `.html`、`.js` 文件被修改、无新增/删除文件、无目录结构变更、无 localStorage 键被触碰

### 5.2 性能与可维护性检查

- [ ] 确认新增动画仅使用 `transform`、`opacity`、`background-position` 等合成器友好属性，不触发 layout 或 paint，目标 60fps 不阻塞主线程；确认新增规则遵循项目既有 camelCase 命名（`starDrift`/`starBreath`/`heroFadeUp`）与 CSS 变量体系（`var(--ease-out)`）；确认 `body::before` 的 `z-index: -1` 不遮挡前景内容、`position: fixed` 不影响文档流

### 5.3 测试说明文档

- [ ] 在交付物中附上验证步骤说明：① 如何刷新首页观察背景动态变化；② 如何悬停卡片与点击按钮验证交互保持；③ 如何切换主题验证协调共存；④ 如何在 DevTools 中禁用 `backdrop-filter` 验证降级表现；⑤ 如何在移动端视口下验证无溢出无白屏

---

## 6. 审查与最终验证

**写作指导**：最终验证确保交付质量，每个验证点必须有负责人与结果记录。

### 6.1 代码审查

- [ ] 对 `src/styles/main.css` 新增与修改部分进行代码审查，重点核对：`@keyframes` 命名与既有风格一致、`body::before` 不与主题 `background` 简写冲突、`.home-hero-title` 动画未触碰渐变文字四项属性、`backdrop-filter` 均带 `-webkit-` 前缀、无硬编码与既有 CSS 变量重复定义

### 6.2 设计一致性核对

- [ ] 将最终 `main.css` 实现与 `design.md` 第 2.2.2 节接口清单逐项核对，确认 `body::before` 签名、`starDrift`/`starBreath`/`heroFadeUp` 动画签名、`.goal-card`/`.home-create-btn` 改造签名、`.home-hero-title`/`.home-hero-slogan` 动画绑定签名均与设计文档一致；确认主题协调 opacity 值（0.35/0.25/0.4）与设计决策一致

### 6.3 变更范围与风险最终确认

- [ ] 确认 spec.md 第 6.2 节变更范围约束全部满足（唯一变更文件、禁止变更项、localStorage 键不受影响）；确认 spec.md 第 4.2 节可靠性约束全部满足（无白屏、按钮点击有效、卡片悬停保留、降级表现合理）；记录未通过项的跟进措施与负责人