# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 顾问回答入口（接收自然语言文本返回回答） | `advisorService.answer(question)` 已实现问句归一化、空串兜底、关键词分流主干 | `src/services/advisorService.js:53-73` | 75% |
| 情绪安抚意图（冲动/没钱/放弃/太难） | 已有 `_aboutImpulse` `_aboutBroke` `_aboutGiveUp` `_aboutHard` 四个分支，含 Emoji 与多行话术 | `src/services/advisorService.js:75-162` | 75% |
| 进度查询意图（进度/剩余/目标列表） | 已有 `_aboutProgress` `_aboutRemaining` `_aboutGoals`，调用 `progressService.calcProgress` 读取真实数据 | `src/services/advisorService.js:193-262` | 75% |
| 日常问候意图（你好/谢谢） | 已有 `_default` `_aboutThanks`，含自我介绍与玩法引导 | `src/services/advisorService.js:164-173,278-293` | 50% |
| 读取 localStorage 真实数据用于回答 | `_context()` 通过 `localStorageAdapter.getData()` 读取 goals/records，`habitService.getStreakDays()` 读取打卡 | `src/services/advisorService.js:12-51` | 100% |
| 聊天浮窗视图（FAB + 面板 + 输入框 + 消息列表） | `advisorView.mount()` 一次性挂载，含 `_mounted` 防重入、typing 动画、Enter 发送 | `src/views/advisorView.js:1-107` | 100% |
| XSS 防护（用户输入不注入 HTML） | `addMessage` 中 `bubble.textContent = text` 使用 textContent 渲染，未使用 innerHTML 注入用户文本 | `src/views/advisorView.js:67-74` | 100% |
| Minimalist Modern 视觉风格 | `.advisor-*` 系列样式已存在，复用 `--color-primary-gradient` `--color-card` `--radius-xl` 等全局 CSS 变量 | `src/styles/main.css:1101-1330` | 100% |
| 顾问上下文数据计算（日均/月存/预测） | `_context()` 已计算 `dailyAvg` `monthSaved` `forecastMonth` `streak` | `src/services/advisorService.js:12-51` | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 数字动态提取与方案计算 | 现有 `_advice` 仅根据目标日期给出冲刺建议，未从用户输入提取数字；`_aboutMonth` 等也未做数字提取 | 输入差异：用户输入含任意金额数字（300/5000/800）当前被忽略；输出差异：当前回答不含"每天需存 X 元"等基于用户给出数字的方案 | 在 `advisorService` 顶部新增 `_extractAmount(question)` 正则提取工具；在制定计划意图处理中调用，结合目标截止日期计算每日/每周需存 |
| 意图分流机制（四大意图 + 优先级 + 兜底） | 现有 13 个 if 分支顺序匹配，但未归类为四大意图，无显式优先级数值，无配置化数据结构 | 业务逻辑差异：spec 要求"制定计划/情绪安抚/进度查询/日常问候"四大意图分类，且要求开闭原则可扩展；现有为硬编码 if 链 | 重构为 `INTENTS` 配置数组（含 `name` `keywords` `priority` `templates` `handler`），主干循环按 priority 排序匹配，新增意图只需追加配置项 |
| 话术随机性（每意图 ≥3 模板 + 随机选取） | 现有每个 `_aboutXxx` 返回固定字符串，连续触发同一意图回答完全相同 | 输出差异：spec 要求每次随机选取且连续 6 次至少出现 2 种不同回答 | 将每个意图的回答逻辑改为"从模板池随机选取一条 + 注入动态数据"，模板池以数组集中声明 |
| 打卡提示降级 | 现有 `_advice` 中 `if (ctx.streak === 0) tips.push('🔥 今天还没打卡…')` 会将打卡作为主体内容之一；`_aboutStreak` 整段都是打卡 | 业务规则差异：spec 要求匹配到任一意图时仅针对该意图回答，打卡只能作为末尾顺带提示 | 在意图回答生成后统一追加可选的"末尾打卡小提示"（且仅当 streak===0 时追加），删除以打卡为主体的 `_aboutStreak` 调用入口 |
| 快捷指令入口（输入框上方标签 + 点击填入并发送） | 现有 `advisorView` 仅含输入框与发送按钮，无快捷指令区 | 输入差异：用户需手动输入完整问句；交互差异：spec 要求点击标签自动填入并发送 | 在 `advisorView.mount()` 中于 `body` 与 `inputRow` 之间插入 `quickRow` 容器，渲染 `QUICK_COMMANDS` 标签；点击调用 `input.value = text; send()` |
| 边界保护（0/负数/超大数/无截止日期/空数据） | 现有 `_aboutRemaining` 在无目标时已兜底，但数字提取与每日计算尚不存在，未做除零与 Infinity 保护 | 边界条件差异：spec 要求提取值为正有限数、天数 >0 才计算、结果为有限数 | 在数字提取与计算工具中加 `Number.isFinite` 与 `> 0` 校验，计算失败回退到总额建议 |
| 意图匹配正则异常兜底 | 现有 `answer` 直接执行正则 test，未 try/catch；若用户输入含特殊字符可能抛异常导致白屏 | 异常差异：spec 要求捕获异常回退默认回答 | 在 `answer` 主干外层包 `try/catch`，catch 中返回 `_default(ctx)` |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**A. advisorService 数字提取工具模块**
- 功能点：`_extractAmount(question)`
  - 输入：用户自然语言字符串
  - 输出：`{ valid: boolean, value: number }`，valid 为 true 时 value 为正有限数
  - 核心逻辑：正则 `/\d+(\.\d+)?/g` 全局匹配所有数字，过滤掉 0 与负数上下文（"存0""负"），取首个正有限数；无匹配则 valid=false
  - 依赖：无外部依赖，纯字符串处理

**B. advisorService 意图配置模块**
- 功能点：`INTENTS` 配置数组
  - 输入：无（常量声明）
  - 输出：`[{ name, priority, keywords: RegExp, templates: string[], handler?: fn }]`
  - 核心逻辑：集中声明四大意图（制定计划 priority=1、情绪安抚 priority=2、进度查询 priority=3、日常问候 priority=4），每意图 templates 数组长度 ≥3，含 Emoji
  - 依赖：被 `answer` 主干消费

**C. advisorService 每日每周计算工具**
- 功能点：`_calcPlan(amount, goal)`
  - 输入：提取到的正有限数 amount、进行中目标 goal（含 plannedDate）
  - 输出：`{ perDay?: number, perWeek?: number, days?: number }`，无法计算时对应字段缺省
  - 核心逻辑：`days = daysBetween(today(), goal.plannedDate)`，仅当 `days > 0` 时 `perDay = amount / days`、`perWeek = perDay * 7`，结果用 `Number.isFinite` 校验
  - 依赖：`dateUtils.daysBetween` `dateUtils.today`

**D. advisorService 话术随机选取工具**
- 功能点：`_pickTemplate(templates)`
  - 输入：模板字符串数组
  - 输出：随机一条字符串；数组为空时返回默认引导话术
  - 核心逻辑：`templates[Math.floor(Math.random() * templates.length)]`
  - 依赖：无

**E. advisorService 末尾打卡小提示**
- 功能点：`_maybeStreakHint(ctx)`
  - 输入：上下文 ctx
  - 输出：字符串（streak===0 时返回打卡提示行，否则返回空串）
  - 核心逻辑：仅当 `ctx.streak === 0` 时返回 `'\n💡 顺便提醒：今天还没打卡哦～'`，否则返回 `''`
  - 依赖：`ctx.streak`

**F. advisorView 快捷指令常量与渲染**
- 功能点：`QUICK_COMMANDS` 常量与 `_renderQuickCommands(container, onPick)` 渲染函数
  - 输入：容器 DOM、点击回调
  - 输出：在容器内渲染若干 `.advisor-quick-tag` 按钮
  - 核心逻辑：常量含至少 3 条指令（"帮我制定存钱计划""我总是冲动消费""看看我的进度"），文本与意图关键词强对齐；点击触发回调
  - 依赖：被 `advisorView.mount` 调用

**G. main.css 快捷指令样式**
- 功能点：`.advisor-quick-row` `.advisor-quick-tag` 等样式
  - 输入：无
  - 输出：CSS 规则
  - 核心逻辑：复用全局 CSS 变量与渐变，纯 CSS 实现标签外观与 hover 态
  - 依赖：现有 `:root` 变量定义

## 1.2 存量功能详细分析

### 1.2.1 `advisorService.answer(question)` 接口契约
- **接口契约**：入参为字符串 question；出参为字符串；副作用为读取 localStorage 缓存（不写入）；不抛异常（空串返回 `'请输入你的问题～'`）
- **业务规则**：先 trim、空串兜底；再依次执行 13 个正则 test，命中即返回对应 `_aboutXxx(ctx)`；全部未命中返回 `_default(ctx)`
- **扩展点**：当前为硬编码 if 链，无配置化扩展点，新增意图需修改主干
- **约束**：依赖 `_context()` 返回值，`_context()` 内调用 `localStorageAdapter.getData()`（仅读 cache 不发网络请求）、`habitService.getStreakDays()`（内部也仅读 cache）、`progressService`（纯计算）

### 1.2.2 `advisorService._context()` 接口契约
- **接口契约**：无入参；出参为含 goals/activeGoals/doneGoals/withdrawnGoals/totalTarget/totalSaved/monthSaved/dailyAvg/streak/monthLeftDays/forecastMonth/records 的对象
- **业务规则**：从 `localStorageAdapter.getData()` 取 goals/records，按 status 分组，计算本月记录、近 30 天日均、月度预测；`streak` 来自 `habitService.getStreakDays()`
- **扩展点**：无
- **约束**：纯只读，不修改 localStorage；当 goals/records 为空时各聚合值为 0，不抛异常

### 1.2.3 `advisorView.mount()` 接口契约
- **接口契约**：无入参；无出参；副作用为向 `document.body` 追加 `.advisor-root` DOM；`_mounted` 防重入
- **业务规则**：创建 FAB、面板、header、body、inputRow；`addMessage(text, who)` 用 textContent 渲染气泡；`send()` 读取 input.value、追加用户消息、显示 typing、500ms 后调用 `advisorService.answer(text)` 并追加 bot 消息
- **扩展点**：`addMessage` 与 `send` 为闭包内部函数，外部不可访问
- **约束**：仅一次性挂载；不监听 hashchange；不影响路由；不修改其他视图

### 1.2.4 `localStorageAdapter.getData()` 接口契约
- **接口契约**：无入参；出参为缓存对象（`cache || getEmptyData()`）
- **业务规则**：直接返回内存 cache，不读 localStorage、不发网络请求
- **扩展点**：无
- **约束**：**重要**：`getData()` 是纯内存读取，不触发任何网络请求；网络请求仅存在于 `initData()` 与 `saveData()` 中。advisorService 仅调用 `getData()`，因此重构后仍保持"零网络请求"

### 1.2.5 `goalService.getAll()` / `habitService.getStreakDays()` 接口契约
- **接口契约**：`getAll()` 无入参，返回 `data.goals` 数组；`getStreakDays()` 无入参，返回非负整数
- **业务规则**：均通过 `localStorageAdapter.getData()` 读取
- **扩展点**：无
- **约束**：仅读不写；不修改这两个文件的对外接口

### 1.2.6 现有 `.advisor-*` CSS 约束
- **约束**：已定义 `.advisor-root` `.advisor-fab` `.advisor-panel` `.advisor-header` `.advisor-body` `.advisor-input-row` `.advisor-input` `.advisor-send` `.advisor-msg` `.advisor-bubble` `.advisor-typing-dot` 等选择器，均复用全局 CSS 变量；面板采用 `flex-direction: column`，子元素纵向排列；快捷指令区需插入在 `body` 与 `inputRow` 之间，不破坏现有 flex 布局

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
skinparam componentStyle rectangle
actor "储蓄用户" as User
rectangle "存钱顾问模块" as Advisor {
  rectangle "advisorView\n(聊天浮窗+快捷指令)" as View
  rectangle "advisorService\n(意图分流+话术池+数字提取)" as Service
}
database "localStorage\n(localStorageAdapter.getData)" as LS
rectangle "habitService\n(getStreakDays)" as Habit
rectangle "progressService\n(calcProgress/getRemaining)" as Progress
rectangle "goalService\n(getAll)" as Goal

User --> View : 自然语言提问 / 点击快捷指令
View --> Service : answer(question)
Service --> LS : getData() 仅读cache
Service --> Habit : getStreakDays()
Service --> Progress : calcProgress/getRemaining
Service ..> Goal : 可选getAll(等价于getData().goals)
Service --> View : 回答文本(含Emoji)
View --> User : 渲染消息气泡(textContent)
@enduml
```

**说明**：advisorService 仅通过 `localStorageAdapter.getData()` 读取内存缓存（不发网络请求），并复用现有 `habitService` `progressService` `goalService` 的只读方法。所有回答文本经 `textContent` 渲染，杜绝 XSS。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
skinparam componentStyle rectangle
rectangle "advisorService" as S {
  rectangle "answer(question)\n分流主干" as Answer
  rectangle "INTENTS[]\n意图配置(开闭原则)" as Intents
  rectangle "_extractAmount\n正则数字提取" as Extract
  rectangle "_calcPlan\n每日每周计算" as Calc
  rectangle "_pickTemplate\n随机选取" as Pick
  rectangle "_context\n聚合只读数据" as Ctx
  rectangle "_maybeStreakHint\n末尾打卡提示" as Hint
}
rectangle "advisorView" as V {
  rectangle "mount()\n挂载面板" as Mount
  rectangle "QUICK_COMMANDS[]\n快捷指令常量" as Quick
  rectangle "_renderQuickCommands\n渲染标签" as Render
  rectangle "send()\n发送流程" as Send
}
Answer --> Intents : 按priority遍历
Answer --> Extract : 制定计划意图
Answer --> Calc : 计算方案
Answer --> Pick : 选取话术
Answer --> Ctx : 取上下文
Answer --> Hint : 末尾追加
Mount --> Quick : 读取常量
Mount --> Render : 渲染标签
Render --> Send : 点击触发
Send --> Answer : 调用
@enduml
```

**模块划分**：
- **advisorService**：纯逻辑层，无 DOM 依赖，负责意图分流、数字提取、方案计算、话术选取、数据聚合
- **advisorView**：纯视图层，负责 DOM 挂载、快捷指令渲染、消息气泡、发送流程，不包含业务规则
- **main.css 增量**：纯样式层，负责快捷指令标签视觉

**配置项及取值策略**：
- `INTENTS` 数组：每意图含 `name` `priority`（数值越小越优先）`keywords`（RegExp）`templates`（string[]，长度 ≥3）`handler`（可选，用于需要动态数据的意图如制定计划/进度查询）
- `QUICK_COMMANDS` 数组：每项含 `text`（与意图关键词强对齐）`emoji`（标签前缀图标）
- 意图优先级取值：制定计划=1、情绪安抚=2、进度查询=3、日常问候=4

### 2.1.3 实现设计文档

#### 意图分流状态机（活动图）

```plantuml
@startuml
start
:接收 question;
:trim, 空串?;
if (空串?) then (是)
  :返回 "请输入你的问题～";
  stop
else (否)
endif
:try {
  :ctx = _context();
  :按 priority 升序遍历 INTENTS;
  :matched = null;
  while (存在未遍历意图?) is (是)
    if (intent.keywords.test(question)?) then (命中)
      :matched = intent;
      (停止遍历)
    else (未命中)
    endif
  endwhile (否)
  if (matched?) then (命中某意图)
    if (matched.handler 存在?) then (是)
      :answer = matched.handler(question, ctx);
    else (否)
      :answer = _pickTemplate(matched.templates);
    endif
    :answer += _maybeStreakHint(ctx);
  else (未命中)
    :answer = _defaultGuide(ctx);
  endif
  :返回 answer;
}
:catch (e) {
  :返回 _defaultGuide(ctx);
}
stop
@enduml
```

**分支触发条件与处理策略**：
- 空串分支：`q.length === 0`，直接返回固定提示，不进入意图匹配
- 命中分支：按 priority 升序首个 `keywords.test(q) === true` 的意图；有 handler 则调用 handler 注入动态数据，否则从 templates 随机选取
- 未命中分支：返回默认引导话术（含玩法引导与 Emoji）
- 异常分支：正则 test 抛异常时捕获，回退默认引导，不白屏

#### 制定计划意图处理流程

```plantuml
@startuml
start
:提取 amount = _extractAmount(question);
:activeGoals = ctx.activeGoals;
if (amount.valid 且 activeGoals.length > 0?) then (是)
  :goal = activeGoals[0];
  :plan = _calcPlan(amount.value, goal);
  :从制定计划模板池随机选取一条;
  :注入 amount.value / plan.perDay / plan.perWeek / goal.name;
  :返回注入后文本;
elseif (amount.valid 且无目标?) then (是)
  :从无目标模板池随机选取一条;
  :注入 amount.value;
  :返回通用方案;
else (无有效数字)
  :从通用计划模板池随机选取一条;
  :返回通用建议;
endif
stop
@enduml
```

#### 进度查询意图处理流程

```plantuml
@startuml
start
:goals = ctx.goals;
if (goals.length === 0?) then (是)
  :返回空数据引导话术\n"还没有创建目标，去首页创建一个吧";
  stop
else (否)
endif
:从进度模板池随机选取一条;
:遍历 goals 计算进度条与百分比;
:注入真实进度数据(无占位符);
:返回注入后文本;
stop
@enduml
```

## 2.2 接口设计

### 2.2.1 总体设计

| 接口名 | 所属模块 | 类型 | 稳定性 | 说明 |
|--------|---------|------|--------|------|
| `advisorService.answer(question)` | advisorService | 公开方法 | 稳定 | 唯一对外入口，接收问句返回回答 |
| `advisorService._extractAmount(question)` | advisorService | 内部方法 | 内部 | 数字提取工具 |
| `advisorService._calcPlan(amount, goal)` | advisorService | 内部方法 | 内部 | 每日每周计算 |
| `advisorService._pickTemplate(templates)` | advisorService | 内部方法 | 内部 | 随机选取话术 |
| `advisorService._maybeStreakHint(ctx)` | advisorService | 内部方法 | 内部 | 末尾打卡提示 |
| `advisorService._defaultGuide(ctx)` | advisorService | 内部方法 | 内部 | 默认引导话术 |
| `INTENTS` | advisorService | 模块常量 | 实验 | 意图配置（可扩展） |
| `advisorView.mount()` | advisorView | 公开方法 | 稳定 | 一次性挂载（保持现有签名） |
| `QUICK_COMMANDS` | advisorView | 模块常量 | 实验 | 快捷指令列表（可扩展） |

**接口变更策略**：
- `advisorService.answer(question)` 签名与返回类型保持不变（字符串入字符串出），仅重构内部实现，对 `advisorView` 透明
- `advisorView.mount()` 签名与 `_mounted` 防重入机制保持不变，对 `main.js` 透明
- `INTENTS` 与 `QUICK_COMMANDS` 为新增模块常量，标记为实验性，后续可扩展

### 2.2.2 接口清单

#### `advisorService.answer(question)`

**接口签名**：
```js
answer(question: string): string
```

**业务说明**：接收用户自然语言提问，经意图分流、数字提取、话术随机选取后返回含 Emoji 的回答文本。

**前置条件**：`localStorageAdapter.initData()` 已完成（由 `main.js` 保证）。

**后置条件**：不修改 localStorage；不发起网络请求；返回值为非空字符串。

**异常映射**：内部任何异常（含正则异常）均被捕获，返回默认引导话术，不向上抛出。

**调用示例**：
```js
import { advisorService } from './services/advisorService.js';
const reply = advisorService.answer('我想存5000怎么存');
// reply 含基于 5000 的具体方案与 Emoji
```

#### `advisorService._extractAmount(question)`

**接口签名**：
```js
_extractAmount(question: string): { valid: boolean, value: number }
```

**业务说明**：从问句中正则提取首个正有限数；含"0""负"等无效上下文时 valid=false。

**前置条件**：无。

**后置条件**：valid 为 true 时 value 必为正有限数。

**异常映射**：无（纯字符串处理）。

**调用示例**：
```js
this._extractAmount('存5000怎么存');   // { valid: true, value: 5000 }
this._extractAmount('存0元');          // { valid: false, value: 0 }
this._extractAmount('帮我制定计划');    // { valid: false, value: 0 }
```

#### `advisorService._calcPlan(amount, goal)`

**接口签名**：
```js
_calcPlan(amount: number, goal: { plannedDate: string }): { perDay?: number, perWeek?: number, days?: number }
```

**业务说明**：基于金额与目标截止日期计算每日/每周需存；天数 ≤0 或结果非有限时对应字段缺省。

**前置条件**：amount 为正有限数；goal 含 plannedDate 字符串。

**后置条件**：返回字段均为有限数。

**异常映射**：无。

**调用示例**：
```js
this._calcPlan(3000, { plannedDate: '2026-11-13' });
// 假设今天距今 30 天：{ perDay: 100, perWeek: 700, days: 30 }
```

#### `advisorService._pickTemplate(templates)`

**接口签名**：
```js
_pickTemplate(templates: string[]): string
```

**业务说明**：从模板池随机选取一条；空数组返回默认引导话术。

**前置条件**：无。

**后置条件**：返回非空字符串。

**异常映射**：无。

#### `advisorService._maybeStreakHint(ctx)`

**接口签名**：
```js
_maybeStreakHint(ctx: { streak: number }): string
```

**业务说明**：仅当 `streak === 0` 时返回打卡提示行，否则返回空串。保证打卡仅作末尾顺带提示。

**前置条件**：无。

**后置条件**：返回字符串（可能为空）。

#### `advisorView.mount()`

**接口签名**：
```js
mount(): void
```

**业务说明**：一次性挂载聊天浮窗与快捷指令区；`_mounted` 防重入。

**前置条件**：`document.body` 存在。

**后置条件**：`document.body` 末尾追加 `.advisor-root`；重复调用直接返回。

**异常映射**：不抛异常。

## 2.3 数据模型

### 2.3.1 设计目标

- **支持的业务场景**：自然语言意图分流、数字动态提取与方案计算、话术随机选取、快捷指令点击发送、空数据兜底、异常兜底
- **性能目标**：单次 `answer` 响应 ≤50ms（纯本地正则与数组随机，无 IO 阻塞）
- **容量目标**：话术模板池每意图 ≥3 条，快捷指令 ≥3 条，常量内存占用可忽略
- **兼容策略**：不修改 localStorage 数据结构；不修改 `goalService` `habitService` `progressService` `localStorageAdapter` 对外接口；不修改 `main.js`

### 2.3.2 模型实现

```plantuml
@startuml
class IntentConfig {
  +name: string
  +priority: number
  +keywords: RegExp
  +templates: string[]
  +handler: (question, ctx) => string
}

class QuickCommand {
  +text: string
  +emoji: string
}

class ExtractResult {
  +valid: boolean
  +value: number
}

class PlanResult {
  +perDay: number
  +perWeek: number
  +days: number
}

class AdvisorContext {
  +goals: Goal[]
  +activeGoals: Goal[]
  +totalSaved: number
  +streak: number
  +dailyAvg: number
}

IntentConfig "4" -- "1" AdvisorContext : handler读取
QuickCommand "3..*" -- "1" advisorView
ExtractResult ..> IntentConfig : 制定计划handler
PlanResult ..> IntentConfig : 制定计划handler
@enduml
```

**核心领域对象**：
- **IntentConfig**：意图配置，含名称、优先级、关键词正则、话术模板池、可选 handler。生命周期为模块常量（应用启动即存在）
- **QuickCommand**：快捷指令，含文本与 Emoji。生命周期为模块常量
- **ExtractResult**：数字提取结果，valid+value。生命周期为单次 answer 调用
- **PlanResult**：方案计算结果，perDay/perWeek/days。生命周期为单次 answer 调用
- **AdvisorContext**：上下文聚合数据，沿用现有 `_context()` 返回结构。生命周期为单次 answer 调用

**对象关系**：IntentConfig 与 AdvisorContext 为依赖关系（handler 读取 ctx）；QuickCommand 与 advisorView 为组合关系；ExtractResult 与 PlanResult 为 IntentConfig 制定计划 handler 的中间产物

**创建与销毁策略**：INTENTS 与 QUICK_COMMANDS 为模块顶层常量，随模块加载创建、随页面卸载销毁；ExtractResult/PlanResult/AdvisorContext 为函数内局部对象，随调用结束被 GC

**持久化策略**：本模块不持久化任何对象。所有数据读取自 `localStorageAdapter.getData()` 内存缓存，不写入 localStorage
