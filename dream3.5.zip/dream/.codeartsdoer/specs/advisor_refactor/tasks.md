# 存钱顾问重构 - 编码任务清单

> 约束条件（贯穿所有任务，执行前必读）：
> 1. **绝对不引入网络请求**：禁止 XMLHttpRequest、fetch、WebSocket；仅可通过 `localStorageAdapter.getData()` 读取内存缓存。
> 2. **不修改 main.js 及其他无关功能模块**：`main.js`、`goalService.js`、`habitService.js`、`progressService.js`、`localStorageAdapter.js` 的对外接口保持不变。
> 3. **不白屏**：任意输入（空串、纯符号、超长文本、正则异常）都必须返回非空字符串，禁止未捕获异常上抛。
> 4. **保留情绪话术与 Emoji**：每条回答模板必须含至少 1 个 Emoji，不得删除现有情绪支持内容。
> 5. **沿用 Minimalist Modern 风格**：新增样式复用全局 CSS 变量与渐变，纯 CSS 实现视觉效果，不使用图片文件。
> 6. **camelCase 命名**：文件名、变量名、函数名统一 camelCase。
> 7. **开闭原则**：新增意图只需追加 `INTENTS` 配置项，不改动分流主干。

---

## 1. 搭建 advisorService 基础工具层

**依赖**：无（本组为最底层工具，被后续所有任务依赖）
**涉及文件**：`src/services/advisorService.js`
**目标**：为意图分流主干提供纯函数工具，无 DOM 依赖、无网络依赖、无副作用。

### 1.1 实现 _extractAmount 数字提取工具
- [ ] 在 `src/services/advisorService.js` 中新增 `_extractAmount(question)` 方法，使用正则 `/\d+(\.\d+)?/g` 全局匹配问句中所有数字，过滤掉 0 与负数上下文（如"存0""负"），取首个正有限数返回 `{ valid: true, value }`；无匹配或全为无效时返回 `{ valid: false, value: 0 }`。
- [ ] 对 0、负数、超大数（如 99999999）做边界保护：仅当 `Number.isFinite(value) && value > 0` 时 valid 为 true。
- **验收标准**：`_extractAmount('存5000怎么存')` → `{valid:true,value:5000}`；`_extractAmount('存0元')` → `{valid:false,value:0}`；`_extractAmount('帮我制定计划')` → `{valid:false,value:0}`；`_extractAmount('存99999999')` → `{valid:true,value:99999999}`。

### 1.2 实现 _calcPlan 每日每周计算工具
- [ ] 在 `src/services/advisorService.js` 中新增 `_calcPlan(amount, goal)` 方法，复用现有 `dateUtils.daysBetween` 与 `dateUtils.today` 计算 `days = daysBetween(today(), goal.plannedDate)`。
- [ ] 仅当 `days > 0` 时计算 `perDay = amount / days`、`perWeek = perDay * 7`，并用 `Number.isFinite` 校验；天数 ≤0 或结果非有限时对应字段缺省，返回 `{ perDay?, perWeek?, days? }`。
- **验收标准**：`_calcPlan(3000, {plannedDate:'2026-11-13'})`（假设距今 30 天）→ `{perDay:100, perWeek:700, days:30}`；`_calcPlan(3000, {plannedDate:'2020-01-01'})` → `{}`（天数 ≤0，字段缺省）；结果中无 NaN、Infinity。

### 1.3 实现 _pickTemplate 话术随机选取工具
- [ ] 在 `src/services/advisorService.js` 中新增 `_pickTemplate(templates)` 方法，从模板数组中随机选取一条返回；数组为空或非数组时回退到默认引导话术（含 Emoji）。
- **验收标准**：`_pickTemplate(['A','B','C'])` 返回 'A'/'B'/'C' 之一；`_pickTemplate([])` 返回非空默认引导字符串；连续调用 6 次同一非空数组至少出现 2 种不同结果（统计验证）。

### 1.4 实现 _maybeStreakHint 末尾打卡提示工具
- [ ] 在 `src/services/advisorService.js` 中新增 `_maybeStreakHint(ctx)` 方法，仅当 `ctx.streak === 0` 时返回 `'\n💡 顺便提醒：今天还没打卡哦～'`，否则返回空串 `''`。
- **验收标准**：`_maybeStreakHint({streak:0})` → 含 Emoji 的非空提示行；`_maybeStreakHint({streak:3})` → `''`；打卡仅作末尾顺带提示，不作为主体回答。

### 1.5 抽取 _defaultGuide 默认引导话术
- [ ] 在 `src/services/advisorService.js` 中将现有 `_default(ctx)` 重命名/抽取为 `_defaultGuide(ctx)`（保留原 `_default` 兼容或直接替换调用点），保留自我介绍、玩法引导、Emoji，未命中意图与异常兜底统一调用此方法。
- **验收标准**：`_defaultGuide(ctx)` 返回非空字符串，含 👋 Emoji 与"试试问我"玩法引导；无目标时含"先去首页创建一个吧"引导。

---

## 2. 声明四大意图配置与话术模板池

**依赖**：1.1、1.2、1.3、1.4、1.5（工具层就绪后声明配置）
**涉及文件**：`src/services/advisorService.js`
**目标**：以可读数据结构集中声明意图配置，满足开闭原则，每意图模板池 ≥3 条且含 Emoji。

### 2.1 声明 INTENTS 配置数组骨架
- [ ] 在 `src/services/advisorService.js` 顶部声明 `INTENTS` 模块常量数组，每项结构为 `{ name, priority, keywords: RegExp, templates: string[], handler? }`。
- [ ] 四大意图优先级：制定计划=1、情绪安抚=2、进度查询=3、日常问候=4；`keywords` 正则复用现有 `_aboutXxx` 的关键词集合并按 spec 5.2.1 对齐。
- **验收标准**：`INTENTS` 为数组且长度 ≥4；每项 `priority` 为唯一数值；`keywords` 为 RegExp 实例；`templates` 为数组且长度 ≥3。

### 2.2 编写制定计划意图话术模板池
- [ ] 为制定计划意图编写 ≥3 条模板，含 Emoji（🎯📅✨等），含动态占位（如 `{amount}` `{perDay}` `{perWeek}` `{goalName}`），覆盖"有目标且有截止日期""有目标无截止日期""无目标"三种场景。
- **验收标准**：模板数量 ≥3；每条含至少 1 个 Emoji；占位符以 `{xxx}` 形式声明，便于 handler 注入。

### 2.3 编写情绪安抚意图话术模板池
- [ ] 为情绪安抚意图编写 ≥3 条模板，保留现有 `_aboutImpulse` `_aboutBroke` `_aboutGiveUp` `_aboutHard` 的情绪价值内容与 Emoji（🛒🫂😔💪等），可结合 ctx.activeGoals 注入目标名与进度。
- **验收标准**：模板数量 ≥3；每条含至少 1 个 Emoji；保留"延迟满足""48 小时冷静期""你不是一个人"等情绪话术。

### 2.4 编写进度查询意图话术模板池
- [ ] 为进度查询意图编写 ≥3 条模板，含 Emoji（📊✅⏰等），含动态占位（如 `{goalList}` `{totalRemain}`），覆盖"有目标""无目标空数据引导"两种场景。
- **验收标准**：模板数量 ≥3；每条含至少 1 个 Emoji；无目标场景含"还没有创建目标，去首页创建一个吧"引导。

### 2.5 编写日常问候意图话术模板池
- [ ] 为日常问候意图编写 ≥3 条模板，含 Emoji（👋😊🌱等），保留现有 `_default` 自我介绍与玩法引导风格。
- **验收标准**：模板数量 ≥3；每条含至少 1 个 Emoji；含"我是你的存钱顾问"自我介绍或玩法引导。

---

## 3. 实现意图 handler 与动态数据注入

**依赖**：2.1、2.2、2.3、2.4、2.5（配置就绪后实现 handler）
**涉及文件**：`src/services/advisorService.js`
**目标**：为需要动态数据的意图实现 handler，将真实计算结果注入模板占位符，禁止出现未替换的 `{xxx}`。

### 3.1 实现制定计划意图 handler
- [ ] 在 `src/services/advisorService.js` 中实现制定计划 handler：调用 `_extractAmount(question)` 提取数字，读取 `ctx.activeGoals`，按 design 2.1.3 流程分三支（有目标且有截止日期 / 有目标无截止日期 / 无目标或无有效数字）。
- [ ] 有目标且有截止日期时调用 `_calcPlan` 计算每日/每周，从模板池随机选取一条并注入 `{amount}` `{perDay}` `{perWeek}` `{goalName}`；注入后不得残留 `{xxx}` 占位符。
- **验收标准**：`answer('我想存5000怎么存')`（存在进行中目标且截止日期距今 50 天）→ 回答含"5000"与"每天需存"具体数值，无 `{xxx}`；`answer('存800怎么存')`（无目标）→ 回答含"800"通用方案；`answer('存0元怎么存')` → 回退通用计划建议，无除零错误。

### 3.2 实现进度查询意图 handler
- [ ] 在 `src/services/advisorService.js` 中实现进度查询 handler：读取 `ctx.goals`，无目标时返回空数据引导话术；有目标时遍历计算进度（复用 `progressService.calcProgress`）与剩余金额（复用 `progressService.getRemaining`），从模板池随机选取并注入真实数据。
- **验收标准**：`answer('看看我的进度')`（有目标）→ 回答含真实目标名、进度百分比、剩余金额，无 `{xxx}`、无 NaN；`answer('看看我的进度')`（无目标）→ 回答含"还没有创建目标"引导，不报错。

### 3.3 实现情绪安抚与日常问候的模板选取
- [ ] 情绪安抚与日常问候意图无需独立 handler（templates 静态），由主干直接调用 `_pickTemplate` 选取；情绪安抚模板中涉及 ctx 数据时（如 activeGoals、streak）在 handler 中注入或改为静态多模板覆盖不同 ctx 场景。
- **验收标准**：`answer('我总是冲动消费')` → 回答主体为情绪安抚，含 Emoji，不得仅回复"去打卡"；`answer('你好')` → 回答为日常问候，含 👋 Emoji。

---

## 4. 重构 answer 主干为配置化分流

**依赖**：3.1、3.2、3.3（handler 就绪后重构主干）
**涉及文件**：`src/services/advisorService.js`
**目标**：将现有 13 个 if 硬编码链重构为按 `INTENTS` priority 升序遍历匹配的配置化主干，满足开闭原则与异常兜底。

### 4.1 重写 answer 主干为按 priority 升序遍历匹配
- [ ] 重写 `answer(question)`：trim 后空串返回 `'请输入你的问题～'`；否则 `ctx = this._context()`，将 `INTENTS` 按 `priority` 升序排列，依次执行 `intent.keywords.test(q)`，首个命中者记为 `matched`。
- [ ] 命中时：有 `handler` 则 `answer = matched.handler(question, ctx)`，否则 `answer = this._pickTemplate(matched.templates)`；统一追加 `answer += this._maybeStreakHint(ctx)`。未命中时 `answer = this._defaultGuide(ctx)`。
- **验收标准**：`answer('我想存5000怎么存')` 命中制定计划；`answer('我总是冲动消费')` 命中情绪安抚；`answer('看看我的进度')` 命中进度查询；`answer('你好')` 命中日常问候；`answer('asdfgh')` 返回默认引导非空；多意图同时命中时按 priority 返回单一意图回答，不混合。

### 4.2 在 answer 外层包裹 try/catch 异常兜底
- [ ] 在 `answer` 主干外层包裹 `try/catch`，catch 中返回 `this._defaultGuide(ctx)`（ctx 可能未初始化时传入空对象兜底），禁止异常上抛导致白屏。
- **验收标准**：`answer('***特殊正则字符***')` 不抛异常，返回默认引导话术；`answer('<<<>>>')` 同样不白屏。

### 4.3 删除以打卡为主体的 _aboutStreak 调用入口与冗余分支
- [ ] 删除 `answer` 中 `/打卡|连续|坚持/.test(q)` 命中 `_aboutStreak` 的分支（打卡仅通过 `_maybeStreakHint` 末尾顺带提示）。
- [ ] 删除或合并现有冗余 `_aboutMonth` `_aboutRemaining` `_aboutGoals` `_aboutWithdraw` `_aboutThanks` `_advice` 等分支中与四大意图重复的逻辑，将其关键词并入对应 `INTENTS` 配置；保留 `_aboutWithdraw`（支取冷静期）等不在四大意图内的可并入默认引导或保留为扩展意图（但不破坏主干）。
- **验收标准**：`answer('我总是冲动消费')` 回答主体为情绪安抚，末尾最多一行打卡提示，不得仅回复"去打卡"；`answer('看看我的进度')` 回答主体为进度数据汇报；连续输入 5 个不同意图问题得到至少 3 种不同主体的回答。

### 4.4 确认 _context() 不变且仅读 localStorage
- [ ] 保留 `_context()` 现有实现不变，确认仅调用 `localStorageAdapter.getData()`（内存读取）、`habitService.getStreakDays()`、`progressService` 纯计算，不触发任何网络请求。
- **验收标准**：grep `_context` 内部无 `fetch` `XMLHttpRequest` `WebSocket`；`getData()` 调用不触发 `initData` 或 `saveData`；重构后 `_context()` 返回结构不变。

---

## 5. 实现快捷指令视图层

**依赖**：4.1、4.2、4.3、4.4（service 重构完成后再动 view）
**涉及文件**：`src/views/advisorView.js`
**目标**：在聊天输入框上方渲染快捷指令标签，点击自动填入并发送，不破坏现有 mount 机制。

### 5.1 声明 QUICK_COMMANDS 常量
- [ ] 在 `src/views/advisorView.js` 顶部声明 `QUICK_COMMANDS` 模块常量数组，每项 `{ text, emoji }`，至少含"帮我制定存钱计划""我总是冲动消费""看看我的进度"三条，文本与意图关键词强对齐。
- **验收标准**：`QUICK_COMMANDS.length >= 3`；每项 `text` 非空；`text` 命中对应意图（"帮我制定存钱计划"→制定计划、"我总是冲动消费"→情绪安抚、"看看我的进度"→进度查询）。

### 5.2 实现 _renderQuickCommands 渲染函数
- [ ] 在 `src/views/advisorView.js` 中实现 `_renderQuickCommands(container, onPick)` 函数：遍历 `QUICK_COMMANDS`，为每项创建 `.advisor-quick-tag` 按钮（textContent 渲染，防 XSS），点击触发 `onPick(item.text)`。
- **验收标准**：调用后容器内新增 ≥3 个 `.advisor-quick-tag` 按钮；按钮文本含 Emoji 前缀与指令文本；点击触发 onPick 回调，参数为指令文本。

### 5.3 在 mount() 中插入 quickRow 容器并绑定点击自动发送
- [ ] 在 `advisorView.mount()` 中于 `body` 与 `inputRow` 之间插入 `<div class="advisor-quick-row">` 容器，调用 `_renderQuickCommands(quickRow, (text) => { input.value = text; send(); })`。
- [ ] 点击快捷指令后自动将文本填入输入框并调用 `send()`，无需用户手动点发送。
- **验收标准**：挂载后聊天面板输入框上方可见 ≥3 个快捷指令标签；点击"看看我的进度"→ 输入框填入该文本并自动发送，出现对应用户消息与回答；快速连续点击不累积重复填充、不白屏。

### 5.4 保持 mount() 签名与 _mounted 防重入不变
- [ ] 保持 `mount()` 无入参无出参签名不变，保持 `_mounted` 防重入机制（重复调用直接 return），对 `main.js` 透明。
- **验收标准**：`main.js` 中 `advisorView.mount()` 调用方式不变；连续调用 `mount()` 两次只挂载一次；不影响路由与其他视图。

---

## 6. 新增快捷指令样式

**依赖**：5.2、5.3（DOM 结构确定后写样式）
**涉及文件**：`src/styles/main.css`（在现有 `.advisor-*` 样式区约 1101-1330 行附近追加）
**目标**：快捷指令标签沿用 Minimalist Modern 风格，纯 CSS 实现视觉效果。

### 6.1 新增 .advisor-quick-row 与 .advisor-quick-tag 样式
- [ ] 在 `src/styles/main.css` 的 advisor 样式区追加 `.advisor-quick-row`（横向 flex、wrap、gap、padding，复用 `--color-card` `--radius-*` 等变量）与 `.advisor-quick-tag`（圆角标签、复用 `--color-primary-gradient` 或变量、textContent 字体）样式。
- **验收标准**：快捷指令标签横向排列、间距均匀、圆角标签外观；复用全局 CSS 变量，无硬编码颜色值（除透明度 alpha 外）；无图片引用（`background-image` 仅用 `linear-gradient`）。

### 6.2 实现 hover 态与纯 CSS 视觉效果
- [ ] 为 `.advisor-quick-tag` 添加 `:hover` `:active` 态（渐变变化或阴影），使用 CSS 渐变实现视觉效果，不使用图片文件。
- **验收标准**：鼠标悬停标签有视觉反馈（颜色/阴影/缩放变化）；纯 CSS 实现，无图片、无 JS 动画；深色主题下标签可读（复用 CSS 变量自动适配）。

---

## 7. 验证与测试

**依赖**：1~6 全部完成
**涉及文件**：`src/services/advisorService.js`、`src/views/advisorView.js`、`src/styles/main.css`
**目标**：逐项验证 spec 验收条件与约束条件，确保不影响现有功能。

### 7.1 单元验证：数字提取边界
- [ ] 验证 `_extractAmount` 对 0、负数、超大数（99999999）、无数字、纯符号、小数（300.5）的提取结果，确认 valid 与 value 符合 spec 6.3。
- **验收标准**：`存0元`→invalid；`存-100`→invalid；`存99999999`→valid,value=99999999；`存300.5`→valid,value=300.5；`帮我制定计划`→invalid。

### 7.2 单元验证：意图分流命中率
- [ ] 验证 `answer` 对四大意图关键词的命中：含"计划/存多少/怎么存"→制定计划；含"冲动/想买/坚持不下去/没钱"→情绪安抚；含"进度/还差多少/目标"→进度查询；含"你好/在吗"→日常问候；未命中"asdfgh"→默认引导。
- **验收标准**：每类关键词命中对应意图；多意图同时命中按 priority 返回单一意图；未命中返回非空默认引导。

### 7.3 单元验证：话术随机性
- [ ] 对同一意图连续触发 6 次，统计不同回答文本数量；验证每条回答含至少 1 个 Emoji；验证动态值已注入（无 `{xxx}` 占位符、无 NaN/undefined）。
- **验收标准**：6 次中至少出现 2 种不同回答；每条含 Emoji；无占位符与 NaN。

### 7.4 单元验证：快捷指令点击自动发送且命中对应意图
- [ ] 验证 `QUICK_COMMANDS` 每条指令文本经 `answer(text)` 命中对应意图；验证点击后输入框填入文本并自动发送（DOM 操作验证）。
- **验收标准**：三条快捷指令分别命中制定计划、情绪安抚、进度查询；点击后出现用户消息与对应回答，无需手动点发送。

### 7.5 回归验证：现有功能不受影响
- [ ] 确认 `goalService.getAll()`、`habitService.getStreakDays()`、`progressService`、`localStorageAdapter.getData()` 对外接口未修改；确认 `main.js` 中 `advisorView.mount()` 调用方式不变；确认其他视图（储蓄目标、打卡、储蓄营、个人主页、主题切换）正常工作。
- **验收标准**：grep 确认未修改 `main.js` `goalService.js` `habitService.js` `progressService.js` `localStorageAdapter.js`；浏览器手动验证其他功能无异常。

### 7.6 约束验证：无网络请求、无白屏、保留 Emoji 与情绪话术、Minimalist Modern 风格
- [ ] grep 确认 `advisorService.js` `advisorView.js` 中无 `fetch` `XMLHttpRequest` `WebSocket`；验证空串、纯符号、超长文本、特殊正则字符输入均不白屏；验证回答保留 Emoji 与情绪支持话术；验证快捷指令标签复用全局 CSS 变量与渐变。
- **验收标准**：grep 无网络请求关键字；异常输入返回默认引导不抛错；回答含 Emoji 与情绪话术；样式无图片引用、复用 CSS 变量。

### 7.7 Node.js 语法检查通过
- [ ] 使用 Node.js v24 对 `src/services/advisorService.js` 与 `src/views/advisorView.js` 执行语法检查（`node --check` 或 `--input-type=module` 方式），确认无语法错误。
- **验收标准**：`node --check` 两个文件均无错误输出；ES Module import/export 语法正确。