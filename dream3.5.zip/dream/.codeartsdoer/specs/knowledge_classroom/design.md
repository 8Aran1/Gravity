# 金融知识小课堂 — 技术设计文档

> 项目：引力 · Gravity
> 范围：knowledge_classroom 特性
> 技术栈：vanilla JS + ES Module + localStorage + 传统 CSS（毛玻璃拟态）
> 约束：不改 index.html 骨架 / 不改 localStorage 顶层结构 / 不改既有路由匹配规则；不破坏既有功能；不白屏

---

# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| hash 路由分发（#/xxx 与 #/xxx/:id 模式） | main.js router() 已实现 hash 字符串匹配 + 正则匹配 `#/goal/:id` 等 | src/main.js:20-66 | 100% |
| hashchange 监听复用 | init() 中 `window.addEventListener('hashchange', router)` 已绑定单监听器 | src/main.js:79 | 100% |
| 视图渲染入口模式（render 方法挂载到 #app） | homeView.render / goalDetailView.render(id) / campListView.render 等均同模式 | src/views/homeView.js:11-36；src/views/goalDetailView.js | 100% |
| 视图渲染 try/catch 降级返回空 span | homeView._renderIdentityBar / _renderCharityHint 已有 try/catch + 空 span 兜底 | src/views/homeView.js:46-72、135-144 | 100% |
| 路由渲染整体 try/catch 兜底 | router() 外层 try/catch 已展示"页面加载出错"兜底页 | src/main.js:22、61-65 | 100% |
| 毛玻璃拟态卡片样式（backdrop-filter + 半透明背景） | .home-stats / .home-hero-camp / .charity-hint-card 等已有 blur + rgba 背景 | src/styles/main.css:1542-1561、2593-2604 | 100% |
| backdrop-filter 不支持时降级为纯色半透明 | .charity-* 系列已有 `@supports not (backdrop-filter: blur(1px))` 降级段 | src/styles/main.css:2947-2964 | 100% |
| 深色星空主题文字对比度（白色/半透明白色文字） | .home-hero-title / .charity-modal-title 等已用 #fff 与 rgba(255,255,255,0.7) | src/styles/main.css:1522-1540、2712-2727 | 100% |
| toast 温柔提示 | modal.toast(message) 玻璃拟态底部提示，2 秒自动消失 | src/views/modal.js:53-67 | 100% |
| localStorage 独立键读写适配 | localStorageAdapter.read(key)/write(key,data) 已提供带异常兜底的独立键读写 | src/storage/localStorageAdapter.js:20-40 | 100% |
| 首页分模块渲染骨架（identityBar/hero/stats/motivation/charityHint/badges/goalsSection/settingsEntry） | homeView.render() 已按顺序 appendChild 各私有渲染方法 | src/views/homeView.js:25-33 | 100% |
| 首页入口按钮模式（点击切换 hash） | home-hero-camp 按钮 `window.location.hash = '#/camps'` 模式 | src/views/homeView.js:91-94 | 100% |
| ES Module 导出对象字面量服务/视图模式 | charityService / charityView / homeView 均用 `export const xxx = { ... }` | src/services/charityService.js:35；src/views/charityView.js:11 | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 首页"金融小课堂"入口按钮 | homeView._renderHero 已有"引力场"入口按钮（home-hero-camp），位于 hero 内容区 | 现有 hero 区仅一个"引力场"按钮，无知识课堂入口；spec 5.2.1 要求入口位于"引力小助手附近"，与既有首页元素视觉协调 | homeView 新增 _renderKnowledgeEntry() 私有方法，插入位置为 hero 之后、stats 之前（语义上属于"探索入口"层，与"引力场"并列）；按钮样式复用 home-hero-camp 视觉语言但使用独立类名 .home-knowledge-entry 避免选择器冲突 |
| main.js 路由分支 | router() 已有 hash 字符串匹配（#/、#/camps 等）与正则匹配（#/camp/:id、#/goal/:id 等） | 现有路由无 #/knowledge 与 #/knowledge/:id 分支；既有正则分支位于 else 块内 | 在 router() 的 else 块内既有正则匹配之前，新增 `#/knowledge` 字符串匹配与 `#/knowledge/:id` 正则匹配；import knowledgeListView / knowledgeDetailView；不新增 hashchange 监听器，不修改既有分支 |
| main.css 样式段 | main.css 已有 .home-hero-camp / .charity-* 等玻璃拟态样式段 | 现有样式无 .knowledge-* 类名；既有 @supports 降级段仅覆盖 .charity-* | main.css 末尾追加"金融知识小课堂"样式段（.home-knowledge-entry / .knowledge-list-page / .knowledge-card / .knowledge-detail-page 等）+ 追加 @supports 降级段覆盖新增类名 |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**A. knowledgeService（src/services/knowledgeService.js）— 全新服务模块**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 获取全部文章 getAllArticles | 无 | Article[]（含 id/title/summary/content/readMinutes） | 返回预置常量 KNOWLEDGE_ARTICLES 数组的副本；异常降级返回空数组 | 无 |
| 按 ID 获取单篇文章 getArticleById | (id: string) | { found: boolean, article: Article\|null } | 在 KNOWLEDGE_ARTICLES 中查找 id 匹配项；命中返回 { found:true, article }，未命中返回 { found:false, article:null }；异常降级返回未找到 | 无 |
| 读取已读文章 ID 数组 getReadIds | 无 | string[] | 读取 localStorage 键 `read_knowledge_ids`，JSON.parse；非数组/解析失败/不可访问时返回空数组 | localStorage（独立键，不经 localStorageAdapter） |
| 判断文章是否已读 isRead | (id: string) | boolean | 调用 getReadIds，返回数组是否包含 id；异常返回 false | getReadIds |
| 标记文章已读 markAsRead | (id: string) | { success: boolean, alreadyRead: boolean } | 调用 getReadIds，若已包含 id 则幂等返回 alreadyRead=true；否则追加 id 并写回 localStorage；写入失败静默返回 success=false；异常降级返回 success=false | getReadIds、localStorage |

**B. knowledgeListView（src/views/knowledgeListView.js）— 全新视图模块**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 渲染列表页 render | 无 | void（挂载到 #app） | 清空 #app；创建 .knowledge-list-page 容器；渲染页面标题与返回首页按钮；同步调用 knowledgeService.getAllArticles + getReadIds；文章数组为空则渲染兜底空状态；否则遍历文章渲染 .knowledge-card（含标题、阅读时长、已读标签、点击跳转）；整体 try/catch 兜底返回空 span | knowledgeService |

**C. knowledgeDetailView（src/views/knowledgeDetailView.js）— 全新视图模块**

| 功能点 | 输入 | 输出 | 核心逻辑 | 依赖 |
|--------|------|------|---------|------|
| 渲染详情页 render | (id: string) | void（挂载到 #app） | 清空 #app；创建 .knowledge-detail-page 容器；调用 knowledgeService.getArticleById(id)；命中则渲染标题、阅读时长、正文段落、返回列表按钮，并调用 knowledgeService.markAsRead(id) 自动标记已读；未命中则渲染兜底提示"文章走丢啦"与返回列表按钮；整体 try/catch 兜底返回空 span | knowledgeService |

**D. main.css 追加样式段**

| 功能点 | 核心逻辑 |
|--------|---------|
| .home-knowledge-entry 首页入口按钮 | 复用 .home-hero-camp 视觉语言（玻璃拟态 + 渐变背景 + hover 微动），独立类名避免选择器冲突 |
| .knowledge-list-page 列表页容器 | 居中、最大宽度、纵向间距 |
| .knowledge-list-header 列表页头部 | 标题 + 返回首页按钮 |
| .knowledge-card 知识卡片 | 玻璃拟态背景、圆角、内边距、hover 微动、cursor pointer |
| .knowledge-card-title 卡片标题 | 白色、字号、行高 |
| .knowledge-card-meta 卡片元信息 | 阅读时长 + 已读标签行 |
| .knowledge-card-read-tag 已读标签 | 半透明绿色背景、小字号、圆角 |
| .knowledge-empty 空状态 | 居中提示文案 + 返回首页按钮 |
| .knowledge-detail-page 详情页容器 | 玻璃拟态背景、最大宽度、居中、内边距 |
| .knowledge-detail-back 返回按钮 | 复用既有 .btn 视觉或独立玻璃拟态按钮 |
| .knowledge-detail-title 详情页标题 | 大字号白色 |
| .knowledge-detail-meta 详情页阅读时长 | 半透明白色小字 |
| .knowledge-detail-content 详情页正文 | 段落分明、行高 1.8、白色文字保证对比度 |
| .knowledge-detail-not-found 兜底提示 | 居中、提示文案 + 返回列表按钮 |
| backdrop-filter 不支持时的降级 | @supports not (backdrop-filter: blur(1px)) 下 .home-knowledge-entry / .knowledge-card / .knowledge-detail-page 改为纯色半透明背景 |

## 1.2 存量功能详细分析

### 1.2.1 main.js router 路由分发契约

- **入参**：无（读取 window.location.hash）
- **出参**：void（调用对应视图 render 方法挂载到 #app）
- **业务规则**：hash 默认 '#/'；先字符串精确匹配（#/、#/camps、#/camp/new、#/camp/join、#/settings、#/profile、#/goal/new），再正则匹配（`#/camp/:id`、`#/goal/:id/withdraw`、`#/goal/:id/edit`、`#/goal/:id`），均不命中则回退到 homeView.render()
- **异常处理**：外层 try/catch 捕获任意渲染异常，展示"页面加载出错"兜底页 + 返回首页按钮；campDetailView.render 单独 .catch 兜底
- **关键约束**：单 hashchange 监听器；正则匹配位于 else 块内；既有分支顺序不可调整
- **对本组件启示**：新增 `#/knowledge` 字符串匹配应放入 else 之前的字符串匹配段；新增 `#/knowledge/:id` 正则匹配应放入 else 块内既有正则之前，避免被 `#/goal/:id` 误匹配（因 `#/knowledge/xxx` 不匹配 `^#/goal/([^/]+)$`，实际无冲突风险，但仍按声明顺序前置以保持清晰）

### 1.2.2 homeView.render 渲染管线契约

- **渲染顺序**：identityBar → hero → stats → motivation → charityHint → badges → goalsSection → disclaimer → settingsEntry
- **异常处理**：_renderIdentityBar / _renderCharityHint 已有 try/catch 降级返回空 span；其余方法未显式 try/catch 但依赖 router 外层兜底
- **关键约束**：app.innerHTML = '' 清空后 appendChild 各模块；既有顺序对应首页视觉层次
- **对本组件启示**：知识课堂入口按钮插入点选在 hero 之后、stats 之前（语义上属于"探索入口"层，与"引力场"按钮并列呼应）；需用 try/catch 包裹保证不白屏；新增 _renderKnowledgeEntry() 私有方法，与既有 _renderCharityHint 异常降级模式一致

### 1.2.3 localStorageAdapter 契约

- **顶层键**：`dream_saving_camp_data`（含 goals/records/checkIns/camps/achievements/user）
- **read(key)**：读取任意键，JSON.parse，异常返回 null
- **write(key, data)**：写入任意键，JSON.stringify，异常返回 false
- **getData()**：返回 cache 引用（仅限 dream_saving_camp_data）
- **saveData(data)**：仅写入 dream_saving_camp_data（同步 cache + 异步 fetch API）
- **对本组件启示**：spec 6.3 明确已读记录使用独立键 `read_knowledge_ids`，不写入 dream_saving_camp_data。因此 knowledgeService 须直接通过 localStorage.getItem/setItem 读写该独立键，并复用 localStorageAdapter.read/write 的异常兜底模式（try/catch + JSON.parse/stringify）；不调用 localStorageAdapter.getData/saveData，避免触碰既有顶层结构

### 1.2.4 modal.toast 契约

- **入参**：message: string
- **出参**：void
- **业务规则**：创建 .toast DOM，2 秒后自动移除；z-index 2000
- **约束**：仅文本，不支持 HTML
- **对本组件启示**：本组件核心流程（列表渲染、详情渲染、已读标记）均为静默流程，spec 未要求 toast 提示。但保留 modal.toast 作为可选降级通道（如卡片点击 hash 切换异常时 toast 提示），不强制使用

### 1.2.5 charityService / charityView 模块模式契约

- **charityService 模式**：`export const charityService = { method1() {...}, method2() {...} }`；所有方法同步、try/catch 内部捕获、返回安全默认值；常量集中于模块顶部
- **charityView 模式**：`export const charityView = { renderXxx() {...}, _renderYyy() {...} }`；公开方法无 _ 前缀，私有方法 _ 前缀；所有 DOM 操作 try/catch；依赖通过 import 注入
- **对本组件启示**：knowledgeService / knowledgeListView / knowledgeDetailView 严格遵循此模式；knowledgeService 所有方法同步且内部 try/catch；knowledgeListView.render / knowledgeDetailView.render 整体 try/catch 兜底返回空 span（与 homeView._renderCharityHint 一致）

### 1.2.6 既有 @supports 降级模式契约

- **位置**：main.css 末尾 `@supports not (backdrop-filter: blur(1px)) { ... }` 段
- **覆盖范围**：仅 .charity-* 系列类名
- **降级策略**：将 backdrop-filter 模糊背景替换为纯色半透明背景（如 rgba(30,35,55,0.9)）
- **对本组件启示**：新增 .home-knowledge-entry / .knowledge-card / .knowledge-detail-page 须在同一 @supports 段内追加降级规则，或新增独立 @supports 段紧随其后；保持降级策略一致（纯色半透明背景）

---

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "引力场使用者" as user
rectangle "金融知识小课堂" as comp {
  rectangle "knowledgeService" as svc
  rectangle "knowledgeListView" as list
  rectangle "knowledgeDetailView" as detail
}
storage "localStorage\nread_knowledge_ids" as ls
rectangle "homeView" as home
rectangle "main.js 路由器" as router

user --> home : 点击"金融小课堂"入口按钮
home --> router : 切换 hash 为 #/knowledge
router --> list : render()
user --> list : 点击知识卡片
list --> router : 切换 hash 为 #/knowledge/:id
router --> detail : render(id)
list --> svc : getAllArticles + getReadIds
detail --> svc : getArticleById + markAsRead
svc --> ls : 读取/写入已读 ID 数组
ls --> svc : 返回已读 ID 数组
detail --> user : 渲染正文 + 返回入口
user --> detail : 点击返回入口
detail --> router : 切换 hash 为 #/knowledge
@enduml
```

**通信协议与频率**：
- homeView → 路由器：用户点击入口按钮触发 1 次 hash 切换
- 路由器 → knowledgeListView / knowledgeDetailView：每次 hashchange 至多调用 1 次 render
- knowledgeListView → knowledgeService：单次 render 调用 1 次 getAllArticles + 1 次 getReadIds
- knowledgeDetailView → knowledgeService：单次 render 调用 1 次 getArticleById + 至多 1 次 markAsRead
- knowledgeService → localStorage：单次 getReadIds 1 次 getItem；单次 markAsRead 至多 1 次 getItem + 1 次 setItem
- 全部同步调用，无网络请求，无异步等待

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
rectangle "knowledgeService" as svc {
  rectangle "getAllArticles()" as s1
  rectangle "getArticleById(id)" as s2
  rectangle "getReadIds()" as s3
  rectangle "isRead(id)" as s4
  rectangle "markAsRead(id)" as s5
}
rectangle "knowledgeListView" as list {
  rectangle "render()" as l1
  rectangle "_renderHeader()" as l2
  rectangle "_renderCard(article, isRead)" as l3
  rectangle "_renderEmpty()" as l4
}
rectangle "knowledgeDetailView" as detail {
  rectangle "render(id)" as d1
  rectangle "_renderArticle(article)" as d2
  rectangle "_renderNotFound()" as d3
}
rectangle "常量" as consts {
  rectangle "KNOWLEDGE_ARTICLES 预置文章"
  rectangle "READ_KEY = 'read_knowledge_ids'"
  rectangle "COPY 文案常量"
}

l1 --> s1
l1 --> s3
l1 --> l2
l1 --> l3
l1 --> l4
d1 --> s2
d1 --> s5
d1 --> d2
d1 --> d3
s4 --> s3
s5 --> s3
svc --> consts
list --> consts
detail --> consts
@enduml
```

**模块职责**：
- **knowledgeService**：纯逻辑层，无 DOM 依赖；getAllArticles / getArticleById / isRead 为纯读取无副作用；markAsRead 写入 localStorage 独立键 `read_knowledge_ids`，幂等；所有方法同步且内部 try/catch 返回安全默认值
- **knowledgeListView**：纯渲染层，不直接读写 localStorage；render() 整体 try/catch 兜底；已读状态在卡片渲染前同步读取完成，避免后补闪烁
- **knowledgeDetailView**：纯渲染层，不直接读写 localStorage；render(id) 整体 try/catch 兜底；自动标记已读在正文渲染后触发，写入失败静默降级不影响阅读
- **常量集中管理**：KNOWLEDGE_ARTICLES（预置文章数组）、READ_KEY（存储键名）、COPY（文案常量）集中于 knowledgeService / knowledgeListView / knowledgeDetailView 各自顶部，便于后续扩展

**配置项及取值策略**：
- READ_KEY = `'read_knowledge_ids'`（固定字符串，与 spec 6.3 一致）
- KNOWLEDGE_ARTICLES：3-5 篇预置文章，覆盖储蓄方法、风险识别、理性理财三个方向，每篇含 id/title/summary/content/readMinutes 字段
- COPY：列表页标题"金融小课堂"、空状态"暂时还没有内容哦"、详情页兜底"文章走丢啦"、返回按钮文案等

### 2.1.3 实现设计文档

#### 2.1.3.1 列表页 ↔ 详情页导航状态机

```plantuml
@startuml
[*] --> Home : hash = #/

Home --> KnowledgeList : 点击"金融小课堂"入口按钮\n(hash → #/knowledge)
KnowledgeList --> KnowledgeDetail : 点击知识卡片\n(hash → #/knowledge/:id)
KnowledgeDetail --> KnowledgeList : 点击返回列表按钮\n(hash → #/knowledge)
KnowledgeList --> Home : 点击返回首页按钮\n(hash → #/)
KnowledgeDetail --> Home : 浏览器后退两次\n(hash → #/)

KnowledgeList --> KnowledgeList : 文章数据为空 → 渲染空状态
KnowledgeDetail --> KnowledgeDetail : ID 无效 → 渲染兜底提示

KnowledgeDetail : 进入时自动 markAsRead(id)\n(幂等，重复进入不重复写入)
@enduml
```

**触发条件与处理策略**：
- Home → KnowledgeList：用户点击首页入口按钮，hash 切换为 `#/knowledge`，路由器调用 knowledgeListView.render()
- KnowledgeList → KnowledgeDetail：用户点击卡片，hash 切换为 `#/knowledge/:id`，路由器调用 knowledgeDetailView.render(id)
- 任意状态 → 任意状态：均通过 hash 切换驱动，复用既有 hashchange 监听器，不新增监听器
- KnowledgeDetail 进入即触发 markAsRead(id)：幂等，重复进入同一文章不产生重复 ID 记录
- 任意异常态：try/catch 捕获，渲染兜底提示或空 span，不白屏

#### 2.1.3.2 已读标记幂等流程

```plantuml
@startuml
start
:读取 ids = getReadIds();
if (ids 包含 id) then (是)
  :返回 {success:true, alreadyRead:true};
  stop
else (否)
endif
:追加 id 到 ids 末尾;
:JSON.stringify(ids);
:localStorage.setItem('read_knowledge_ids', json);
if (写入成功) then (是)
  :返回 {success:true, alreadyRead:false};
  stop
else (否)
  :静默降级，返回 {success:false, alreadyRead:false};
  stop
endif
@enduml
```

**幂等保证**：通过写入前数组包含性检查，重复调用 markAsRead(id) 不产生重复 ID、不触发 localStorage 写入

**事务边界**：单次 setItem 为原子边界；失败时静默降级，不影响详情页正文渲染

#### 2.1.3.3 列表页渲染流程

```plantuml
@startuml
start
:清空 #app;
:创建 .knowledge-list-page 容器;
:渲染头部（标题 + 返回首页按钮）;
:articles = knowledgeService.getAllArticles();
:readIds = knowledgeService.getReadIds();
if (articles 为空数组) then (是)
  :渲染空状态 .knowledge-empty;
  :挂载到 #app;
  stop
else (否)
endif
:遍历 articles;
:对每篇文章校验字段完整性\n(id/title/summary/content/readMinutes 非空);
:字段缺失则跳过该篇;
:创建 .knowledge-card\n(标题 + 阅读时长 + 已读标签 if id ∈ readIds);
:绑定卡片点击 → hash 切换 #/knowledge/:id;
:挂载到 #app;
stop
@enduml
```

**关键约束**：已读状态在卡片渲染前同步读取完成（getReadIds 在遍历 articles 之前调用），卡片首次渲染即带正确已读标签，无后补闪烁

#### 2.1.3.4 详情页渲染流程

```plantuml
@startuml
start
:清空 #app;
:创建 .knowledge-detail-page 容器;
:result = knowledgeService.getArticleById(id);
if (result.found) then (是)
  :渲染返回列表按钮;
  :渲染标题 + 阅读时长;
  :渲染正文段落（textContent 或受信任静态 HTML）;
  :挂载到 #app;
  :knowledgeService.markAsRead(id);\n(写入失败静默降级);
  stop
else (否)
  :渲染兜底提示"文章走丢啦" + 返回列表按钮;
  :挂载到 #app;
  stop
endif
@enduml
```

**关键约束**：markAsRead 在正文渲染后触发，即使写入失败也不影响正文展示；正文渲染使用 textContent 或受信任静态 HTML 段落（spec 4.3.2）

## 2.2 接口设计

### 2.2.1 总体设计

**接口分类依据**：
- knowledgeService 对外暴露纯函数式同步接口，无 DOM 依赖，可被任意视图或服务调用
- knowledgeListView / knowledgeDetailView 对外暴露 render 入口，内部方法以 _ 前缀标记私有
- 不新增全局对象，全部通过 ES Module import/export 通信

**接口继承体系**：无继承，三个模块均为平级独立对象字面量

**接口变更策略**：
- knowledgeService / knowledgeListView / knowledgeDetailView 为全新模块，无既有调用方，无兼容负担
- main.js router() 局部扩展：在既有字符串匹配段与正则匹配段各新增一条分支，既有分支不变
- homeView.render() 局部扩展：在渲染管线中插入 _renderKnowledgeEntry() 调用，既有模块不变

**稳定性等级**：
- knowledgeService 全部接口：稳定（本特性范围内）
- knowledgeListView.render / knowledgeDetailView.render：稳定（本特性范围内）
- homeView._renderKnowledgeEntry：实验（内部私有方法）

### 2.2.2 接口清单

#### knowledgeService.getAllArticles()

```js
// 接口签名
getAllArticles(): Article[]
// Article = { id: string, title: string, summary: string, content: string, readMinutes: number }
```

- **业务说明**：返回全部预置文章数组（含正文 content 字段）
- **前置条件**：无
- **后置条件**：无副作用，纯读取；返回值为新数组副本，调用方修改不影响内部常量
- **异常映射**：KNOWLEDGE_ARTICLES 常量异常 → 返回空数组 [] 并 console.warn
- **调用示例**：
```js
import { knowledgeService } from '../services/knowledgeService.js';
const articles = knowledgeService.getAllArticles();
articles.forEach(a => console.log(a.title));
```

#### knowledgeService.getArticleById(id)

```js
// 接口签名
getArticleById(id: string): { found: boolean, article: Article|null }
```

- **业务说明**：按 ID 查找单篇预置文章
- **前置条件**：id 为字符串（非字符串时返回 found=false）
- **后置条件**：无副作用，纯读取
- **异常映射**：id 为空/非字符串 → { found:false, article:null }；常量异常 → { found:false, article:null }
- **调用示例**：
```js
const { found, article } = knowledgeService.getArticleById('week52_saving');
if (found) { knowledgeDetailView.render(article.id); }
```

#### knowledgeService.getReadIds()

```js
// 接口签名
getReadIds(): string[]
```

- **业务说明**：读取 localStorage 键 `read_knowledge_ids` 的已读文章 ID 数组
- **前置条件**：无
- **后置条件**：无副作用，纯读取
- **异常映射**：键不存在 → 返回 []；JSON.parse 失败 → 返回 []；值非数组 → 返回 []；localStorage 不可访问 → 返回 []
- **调用示例**：
```js
const readIds = knowledgeService.getReadIds();
const isRead = readIds.includes('week52_saving');
```

#### knowledgeService.isRead(id)

```js
// 接口签名
isRead(id: string): boolean
```

- **业务说明**：判断指定文章是否已读
- **前置条件**：id 为字符串
- **后置条件**：无副作用
- **异常映射**：id 为空/非字符串 → 返回 false；getReadIds 异常 → 返回 false
- **调用示例**：
```js
if (knowledgeService.isRead(article.id)) { /* 渲染已读标签 */ }
```

#### knowledgeService.markAsRead(id)

```js
// 接口签名
markAsRead(id: string): { success: boolean, alreadyRead: boolean }
```

- **业务说明**：将指定文章 ID 追加到 `read_knowledge_ids` 数组，幂等
- **前置条件**：id 为非空字符串
- **后置条件**：成功时 localStorage 键 `read_knowledge_ids` 包含该 id（至多一次）；幂等时不触发写入；失败时 localStorage 不变
- **异常映射**：id 为空/非字符串 → { success:false, alreadyRead:false }；已读 → { success:true, alreadyRead:true }；localStorage 不可访问/空间不足 → { success:false, alreadyRead:false }；既有值非数组 → 按空数组处理并覆盖写入
- **调用示例**：
```js
const result = knowledgeService.markAsRead('week52_saving');
if (result.success && !result.alreadyRead) { /* 首次标记 */ }
```

#### knowledgeListView.render()

```js
// 接口签名
render(): void
```

- **业务说明**：渲染知识列表页，挂载到 #app 容器
- **前置条件**：#app 容器存在；knowledgeService 已可调用
- **后置条件**：#app 内新增 .knowledge-list-page 子树；既有 #app 内容被清空
- **异常映射**：任意异常 → try/catch 捕获，#app 渲染空 span 或兜底提示，不白屏；文章数据为空 → 渲染空状态；已读记录异常 → 按"全部未读"渲染
- **调用示例**：
```js
import { knowledgeListView } from '../views/knowledgeListView.js';
knowledgeListView.render();
```

#### knowledgeDetailView.render(id)

```js
// 接口签名
render(id: string): void
```

- **业务说明**：渲染指定 ID 的知识详情页，挂载到 #app 容器，并自动标记已读
- **前置条件**：#app 容器存在；knowledgeService 已可调用；id 为字符串
- **后置条件**：#app 内新增 .knowledge-detail-page 子树；既有 #app 内容被清空；若文章命中则 localStorage 键 `read_knowledge_ids` 包含该 id
- **异常映射**：任意异常 → try/catch 捕获，#app 渲染空 span 或兜底提示，不白屏；id 无效/文章未命中 → 渲染"文章走丢啦"兜底提示 + 返回列表按钮；markAsRead 失败 → 静默降级，不影响正文渲染
- **调用示例**：
```js
import { knowledgeDetailView } from '../views/knowledgeDetailView.js';
knowledgeDetailView.render('week52_saving');
```

## 2.3 数据模型

### 2.3.1 设计目标

**需支持的业务场景**：
- 列表页一次性展示全部预置文章卡片（含已读状态）
- 详情页按 ID 展示单篇文章正文并自动标记已读
- 跨会话保留已读状态（用户关闭浏览器后重新打开，已读标签仍存在）

**性能/容量/扩展性目标**：
- 预置文章数量 3-5 篇，常量数组 O(1) 访问
- getReadIds 单次 localStorage.getItem + JSON.parse，O(n) 解析（n ≤ 5，常数级）
- markAsRead 单次数组包含性检查 O(n) + 至多 1 次 setItem，O(1) 写入
- 已读数组至多 5 个字符串元素，存储空间 < 200 字节，无容量压力
- 后续扩展文章只需追加 KNOWLEDGE_ARTICLES 常量项，无需修改接口

**与存量数据兼容策略**：
- 不新增 dream_saving_camp_data 顶层字段
- 不修改既有 checkIns / goals / records / camps / achievements / user 形状
- 已读记录使用独立键 `read_knowledge_ids`，与既有键完全隔离
- 既有路由分支、既有视图渲染管线、既有样式段均保持不变

### 2.3.2 模型实现

```plantuml
@startuml
class Article {
  +id : string
  +title : string
  +summary : string
  +content : string
  +readMinutes : number
}

class KnowledgeArticleConstant {
  +id : string = "week52_saving"
  +title : string = "52周存钱法：无痛攒下第一桶金"
  +summary : string
  +content : string
  +readMinutes : number = 5
}

class ReadIdsStorage {
  +key : string = "read_knowledge_ids"
  +type : "string[]"
  +element : "文章 id 字符串"
  +uniqueness : "至多出现一次"
  +initial : "键不存在时按空数组兜底"
}

class ReadKey {
  +value : string = "read_knowledge_ids"
}

class Copy {
  +listTitle : string = "金融小课堂"
  +emptyHint : string = "暂时还没有内容哦"
  +notFoundTitle : string = "文章走丢啦"
  +backToList : string = "返回列表"
  +backToHome : string = "返回首页"
  +readTag : string = "已读"
  +minutesSuffix : string = " 分钟"
}

Article "1" -- "1" KnowledgeArticleConstant : 预置常量实例 >
ReadIdsStorage "1" -- "1" ReadKey : 键名 >
@enduml
```

**对象关系与生命周期**：
- **Article**：常量对象，无生命周期，运行时不可变；getAllArticles 返回数组副本，getArticleById 返回原对象引用（只读语义）
- **KnowledgeArticleConstant**：Article 的预置实例，3-5 个，集中于 knowledgeService 顶部 KNOWLEDGE_ARTICLES 数组；覆盖储蓄方法、风险识别、理性理财三个方向
- **ReadIdsStorage**：localStorage 键值对，由 knowledgeService.markAsRead 追加写入，由 getReadIds 读取；初始状态键不存在，首次 markAsRead 时创建；生命周期与浏览器 localStorage 同步（持久化，跨会话保留）
- **ReadKey**：常量字符串 `'read_knowledge_ids'`，集中于 knowledgeService 顶部
- **Copy**：文案常量对象，分别集中于 knowledgeListView 与 knowledgeDetailView 顶部，无生命周期

**持久化策略**：
- Article / KnowledgeArticleConstant / ReadKey / Copy 为内存常量，不持久化
- ReadIdsStorage 通过 localStorage.setItem('read_knowledge_ids', JSON.stringify(ids)) 持久化；读取通过 localStorage.getItem + JSON.parse；异常时按空数组兜底

**预置文章内容方向约束**（spec 6.2）：
- 储蓄方法方向：至少 1 篇，如《52周存钱法：无痛攒下第一桶金》
- 风险识别方向：至少 1 篇，如《警惕"杀猪盘"：高收益背后的陷阱》
- 理性理财方向：至少 1 篇，如《复利的力量：时间才是最好的杠杆》
- 总数量 3-5 篇，每篇 id 唯一（如 `week52_saving`、`anti_pig_butcher`、`compound_power`）

**禁用词与隐私约束**（spec 4.3）：
- 文章内容为前端静态常量文本，不动态拼接用户输入、localStorage 数据或外部数据源
- 已读记录仅存储文章 ID，不存储用户身份、设备指纹、阅读时长行为画像等敏感信息
- 全流程不出现真实金额、账户、支付方式、用户储蓄余额等隐私字段

---

## 2.4 关键实现约束与降级策略

### 2.4.1 不白屏保证（5 项降级措施）

| 场景 | 降级策略 |
|------|---------|
| 1. knowledgeService 任意方法异常 | try/catch 返回安全默认值（getAllArticles → []；getArticleById → { found:false, article:null }；getReadIds → []；isRead → false；markAsRead → { success:false, alreadyRead:false }） |
| 2. knowledgeListView.render 异常 | 整体 try/catch 包裹，#app 渲染空 span 或兜底提示"暂时还没有内容哦" + 返回首页按钮，不向上抛出 |
| 3. knowledgeDetailView.render 异常 | 整体 try/catch 包裹，#app 渲染空 span 或兜底提示"文章走丢啦" + 返回列表按钮，不向上抛出 |
| 4. localStorage 不可访问 / 空间不足 / 解析失败 | getReadIds 返回 []（按全部未读渲染）；markAsRead 静默返回 { success:false, alreadyRead:false }，不影响详情页正文阅读 |
| 5. #app 容器缺失 | render 方法首部 `const app = document.getElementById('app'); if (!app) return;` 静默退出，不抛错 |

### 2.4.2 既有功能保护措施（6 项保护措施）

| 既有功能 | 保护措施 |
|---------|---------|
| 1. main.js 既有路由分支 | 不修改既有字符串匹配分支（#/、#/camps、#/camp/new、#/camp/join、#/settings、#/profile、#/goal/new）与既有正则匹配分支（`#/camp/:id`、`#/goal/:id/withdraw`、`#/goal/:id/edit`、`#/goal/:id`）；新增 `#/knowledge` 字符串匹配置于既有字符串匹配段末尾，新增 `#/knowledge/:id` 正则匹配置于既有正则匹配段之前 |
| 2. hashchange 监听器 | 不新增 addEventListener('hashchange', ...)；复用既有 router 函数，新增分支内嵌于 router() 内部 |
| 3. localStorage 顶层结构 | 不调用 localStorageAdapter.getData/saveData；不修改 dream_saving_camp_data 键；已读记录通过 localStorage.getItem/setItem 直接读写独立键 `read_knowledge_ids` |
| 4. 粒子动画 / 组队留言 / 引力场 / 储蓄打卡 / 新手教程 / 滚动叙事 / Q弹交互 / 公益赎回 | 不修改其代码文件；knowledgeService / knowledgeListView / knowledgeDetailView 与其无依赖关系；homeView 仅追加 _renderKnowledgeEntry() 方法，既有 _renderXxx 方法不变 |
| 5. index.html 骨架 | 不修改；所有 DOM 由 JS 动态创建并挂载到既有 #app 容器 |
| 6. backdrop-filter 不支持 | @supports not (backdrop-filter: blur(1px)) 段内追加 .home-knowledge-entry / .knowledge-card / .knowledge-detail-page 降级为纯色半透明背景（如 rgba(30,35,55,0.9)），不白屏 |

### 2.4.3 性能保证

| 性能指标（spec 4.1） | 实现策略 |
|---------|---------|
| 列表页渲染 < 80ms | getAllArticles 常量访问 O(1) + getReadIds 单次 localStorage.getItem + JSON.parse O(n≤5) + DOM 创建节点数 ≤ 5 卡片 × 3 子节点 + 头部 2 节点 ≈ 17 节点；全部同步，无主线程阻塞 |
| 详情页渲染 < 80ms | getArticleById 数组 find O(n≤5) + DOM 创建节点数 ≈ 10 节点 + markAsRead 单次 setItem；全部同步 |
| 已读状态读取在卡片渲染前完成 | getReadIds 在遍历 articles 之前调用，已读标签随卡片首次渲染即正确展示，无后补闪烁 |
| 已读状态写入 < 16ms | markAsRead 单次数组 includes + 单次 setItem，同步完成 |
| 首页入口按钮渲染 < 30ms | _renderKnowledgeEntry 单次 DOM 创建 1 节点 + 1 事件绑定，同步完成 |

### 2.4.4 文件修改清单

| 文件 | 操作 | 修改范围 |
|------|------|---------|
| src/services/knowledgeService.js | 新建 | 全新文件，约 100 行（含 3-5 篇预置文章常量 + 5 个方法） |
| src/views/knowledgeListView.js | 新建 | 全新文件，约 90 行（含文案常量 + render + 3 个私有方法） |
| src/views/knowledgeDetailView.js | 新建 | 全新文件，约 80 行（含文案常量 + render + 2 个私有方法） |
| src/main.js | 局部修改 | 顶部新增 2 行 import；router() 字符串匹配段新增 1 条 `#/knowledge` 分支；else 块内新增 1 条 `#/knowledge/:id` 正则匹配分支；既有分支不变 |
| src/views/homeView.js | 局部修改 | 顶部新增 1 行 import knowledgeListView；render() 中插入 `page.appendChild(this._renderKnowledgeEntry());` 调用；新增 _renderKnowledgeEntry() 私有方法；既有方法不变 |
| src/styles/main.css | 局部追加 | 末尾追加"金融知识小课堂"样式段（.home-knowledge-entry / .knowledge-* 系列）约 150 行 + 追加 @supports 降级段覆盖新增类名约 15 行 |

### 2.4.5 homeView 局部修改示意（仅描述，不含代码）

**修改点 1：顶部 import 段**
- 在既有 `import { charityView } from './charityView.js';` 之后追加 `import { knowledgeListView } from './knowledgeListView.js';`
- 不修改既有 import 顺序与既有模块导入

**修改点 2：render() 渲染管线**
- 在既有 `page.appendChild(this._renderHero(streak));` 之后、`page.appendChild(this._renderStats(...));` 之前，插入：
  ```
  page.appendChild(this._renderKnowledgeEntry());
  ```
- 不调整既有 appendChild 顺序，既有 9 个模块调用不变

**修改点 3：新增 _renderKnowledgeEntry() 私有方法**
- try 块内：
  - 创建 button 元素，className = 'home-knowledge-entry'
  - innerHTML 设置图标 + "金融小课堂"文案（与 home-hero-camp 视觉语言一致）
  - 绑定 click 事件 → `window.location.hash = '#/knowledge'`
  - 返回 button
- catch 块返回空 span（与 _renderIdentityBar / _renderCharityHint 降级模式一致）
- 不修改既有 _renderXxx 方法

### 2.4.6 main.js 路由局部修改示意（仅描述，不含代码）

**修改点 1：顶部 import 段**
- 在既有 import 末尾追加：
  ```
  import { knowledgeListView } from './views/knowledgeListView.js';
  import { knowledgeDetailView } from './views/knowledgeDetailView.js';
  ```
- 不修改既有 import 顺序

**修改点 2：router() 字符串匹配段**
- 在既有 `} else if (hash === '#/goal/new') {` 分支之后、`} else {` 之前，插入：
  ```
  } else if (hash === '#/knowledge') {
    knowledgeListView.render();
  } else {
  ```
- 即将原 else 块改为 `else if (hash === '#/knowledge')` + 新 else 块

**修改点 3：router() 正则匹配段**
- 在既有 else 块内 `const campMatch = ...` 之前，新增：
  ```
  const knowledgeDetailMatch = hash.match(/^#\/knowledge\/([^/]+)$/);
  ```
- 在既有 `if (campMatch) {` 之前，新增：
  ```
  if (knowledgeDetailMatch) {
    knowledgeDetailView.render(knowledgeDetailMatch[1]);
  } else if (campMatch) {
  ```
- 即将原 `if (campMatch)` 链改为 `if (knowledgeDetailMatch) ... else if (campMatch) ...`
- 既有正则匹配分支（campMatch / withdrawMatch / editMatch / detailMatch）逻辑完全不变
- 既有外层 try/catch 兜底自动覆盖新增分支

**路由匹配优先级验证**：
- `#/knowledge` 由字符串匹配段捕获，不进入 else 块，与既有字符串匹配分支互斥
- `#/knowledge/:id` 由 else 块内 knowledgeDetailMatch 正则捕获，`^#/knowledge/([^/]+)$` 不匹配既有 `#/camp/:id`、`#/goal/:id/withdraw`、`#/goal/:id/edit`、`#/goal/:id`，无冲突
- 既有 hash（`#/`、`#/camps`、`#/camp/new`、`#/camp/join`、`#/settings`、`#/profile`、`#/goal/new`、`#/camp/{id}`、`#/goal/{id}/withdraw`、`#/goal/{id}/edit`、`#/goal/{id}`）均不匹配 `#/knowledge` 与 `^#/knowledge/([^/]+)$`，既有路由行为不变

### 2.4.7 main.css 局部追加示意（仅描述，不含代码）

**追加位置**：main.css 末尾，紧随既有 `@supports not (backdrop-filter: blur(1px)) { ... }` 段之后

**追加内容 1：首页入口按钮样式段**
- .home-knowledge-entry：复用 .home-hero-camp 视觉语言（display: inline-flex、padding、linear-gradient 背景、backdrop-filter: blur(10px)、border、border-radius、color: #fff、cursor: pointer、transition、box-shadow）
- .home-knowledge-entry:hover：translateY(-3px) + 增强边框/阴影
- 图标与文案间距 gap: 8px

**追加内容 2：列表页样式段**
- .knowledge-list-page：max-width、margin: 0 auto、padding、display: flex、flex-direction: column、gap
- .knowledge-list-header：display: flex、justify-content: space-between、align-items: center、margin-bottom
- .knowledge-list-title：font-size、font-weight、color: #fff
- .knowledge-back-btn：复用既有 .btn 视觉或独立玻璃拟态按钮样式
- .knowledge-card：background: rgba(255,255,255,0.08)、backdrop-filter: blur(12px)、border、border-radius: 16px、padding、margin、cursor: pointer、transition、box-shadow
- .knowledge-card:hover：translateY(-2px) + 增强边框/阴影
- .knowledge-card-title：font-size、font-weight: 600、color: #fff、line-height: 1.4、margin-bottom
- .knowledge-card-meta：display: flex、align-items: center、gap、font-size、color: rgba(255,255,255,0.7)
- .knowledge-card-read-tag：background: rgba(76,175,80,0.18)、color: #4CAF50、font-size、padding、border-radius、margin-left
- .knowledge-empty：text-align: center、padding、color: rgba(255,255,255,0.7)

**追加内容 3：详情页样式段**
- .knowledge-detail-page：max-width、margin: 0 auto、padding、background: rgba(28,32,52,0.78)、backdrop-filter: blur(18px)、border、border-radius: 20px、box-shadow
- .knowledge-detail-back：玻璃拟态按钮、margin-bottom
- .knowledge-detail-title：font-size: 1.6rem、font-weight: 700、color: #fff、line-height: 1.3、margin-bottom
- .knowledge-detail-meta：font-size、color: rgba(255,255,255,0.7)、margin-bottom
- .knowledge-detail-content：font-size、color: rgba(255,255,255,0.88)、line-height: 1.8、white-space: pre-line 或段落间距
- .knowledge-detail-content p：margin-bottom: 1em（段落分明）
- .knowledge-detail-not-found：text-align: center、padding
- .knowledge-detail-not-found-title：font-size、font-weight、color: #fff、margin-bottom

**追加内容 4：backdrop-filter 降级段**
- 在既有 `@supports not (backdrop-filter: blur(1px)) { ... }` 段内追加：
  - .home-knowledge-entry { background: rgba(30,35,55,0.9); }
  - .knowledge-card { background: rgba(30,35,55,0.9); }
  - .knowledge-detail-page { background: rgba(30,35,55,0.92); }
- 或新增独立 @supports 段紧随其后，保持与既有降级策略一致

---

## 2.5 验收对齐

本设计与 spec.md 核心能力的对齐映射：

| spec 章节 | 设计落点 |
|----------|---------|
| 5.1 知识文章数据服务 | knowledgeService.getAllArticles / getArticleById + KNOWLEDGE_ARTICLES 预置常量（含字段完整性、ID 唯一性、内容方向、禁止运行时修改） |
| 5.2 金融小课堂入口 | homeView._renderKnowledgeEntry + .home-knowledge-entry 样式 + hash 切换 #/knowledge |
| 5.3 知识列表页 | knowledgeListView.render + _renderHeader / _renderCard / _renderEmpty + .knowledge-list-page / .knowledge-card 样式 + 已读标签同步渲染 |
| 5.4 知识详情页 | knowledgeDetailView.render + _renderArticle / _renderNotFound + .knowledge-detail-page 样式 + 自动 markAsRead + 返回列表 |
| 5.5 已读记录管理 | knowledgeService.getReadIds / isRead / markAsRead + 独立键 `read_knowledge_ids` + 幂等写入 + 空值兜底 |
| 5.6 路由接入 | main.js router() 新增 `#/knowledge` 字符串匹配 + `#/knowledge/:id` 正则匹配 + 复用既有 hashchange 监听器 |
| 6.1 知识文章数据结构 | 2.3.2 模型实现中 Article 字段定义（id/title/summary/content/readMinutes） |
| 6.2 预置文章内容方向约束 | 2.3.2 预置文章内容方向约束（储蓄方法/风险识别/理性理财各至少 1 篇，总数量 3-5 篇） |
| 6.3 已读记录结构 | 2.3.2 ReadIdsStorage 模型（键名/类型/元素/唯一性/初始状态/写入时机/持久性） |
| 6.4 变更范围约束 | 2.4.4 文件修改清单（新增 3 文件 + 修改 3 文件，禁止触碰其他文件） |
| 4.1 性能 | 2.4.3 性能保证（列表 < 80ms / 详情 < 80ms / 已读读取在渲染前 / 写入 < 16ms / 入口 < 30ms） |
| 4.2 可靠性 | 2.4.1 不白屏保证（5 项降级措施）+ 幂等写入 + 字段缺失跳过 + 无效 ID 兜底 |
| 4.3 安全性 | 2.3.2 禁用词与隐私约束（静态常量、textContent 渲染、不存储敏感信息、无网络请求） |
| 4.4 可维护性 | 常量集中管理 + camelCase + ES Module + 传统 CSS + 路由分支模式一致 |
| 4.5 兼容性 | 2.4.2 既有功能保护措施（6 项）+ 既有路由/数据/骨架/功能不变 + backdrop-filter 降级 |