# 金融知识小课堂 — 编码任务列表

> 特性：knowledge_classroom
> 项目：引力 · Gravity
> 技术栈：vanilla JS + ES Module + localStorage + 传统 CSS（毛玻璃拟态）
> 约束：不改 index.html 骨架 / 不改 localStorage 顶层结构 / 不改既有路由匹配规则；不破坏既有功能；不白屏；camelCase 命名

---

## 1. knowledgeService 基础搭建（常量与文章数据服务）

### 1.1 新建 knowledgeService 文件骨架与常量定义
- [ ] 新建文件 `src/services/knowledgeService.js`，使用 ES Module `export const knowledgeService = {}` 形式，与既有 charityService / habitService 风格一致
- [ ] 在文件顶部集中定义常量：
  - `READ_KEY = 'read_knowledge_ids'`（固定字符串，与 spec 6.3 一致）
  - `KNOWLEDGE_ARTICLES` 预置文章数组，3-5 篇，覆盖储蓄方法、风险识别、理性理财三个方向，每篇含 `id` / `title` / `summary` / `content` / `readMinutes` 字段
  - 推荐预置文章：
    - 储蓄方法方向：`{ id: 'week52_saving', title: '52周存钱法：无痛攒下第一桶金', summary: '按周递增的小额储蓄法，一年攒下一笔可观的梦想基金', content: '...', readMinutes: 5 }`
    - 风险识别方向：`{ id: 'anti_pig_butcher', title: '警惕"杀猪盘"：高收益背后的陷阱', summary: '识别网络交友诱导投资诈骗的常见话术与应对方法', content: '...', readMinutes: 4 }`
    - 理性理财方向：`{ id: 'compound_power', title: '复利的力量：时间才是最好的杠杆', summary: '理解复利曲线与长期持有带来的累积效应', content: '...', readMinutes: 6 }`
  - 文章 `content` 字段为受信任的静态文本段落（含换行符 `\n\n` 用于段落分隔），不动态拼接用户输入或 localStorage 数据
- [ ] 不引入任何外部依赖（不 import localStorageAdapter / idUtils / dateUtils），仅使用原生 `localStorage.getItem` / `localStorage.setItem` / `JSON.parse` / `JSON.stringify`
- [ ] 验收：文件存在且可被 `import` 不报错；常量未被外部修改；不依赖任何 DOM 对象；不依赖任何外部模块；不出现任何 `fetch` / `XMLHttpRequest` / `WebSocket` 调用

### 1.2 实现 getAllArticles 获取全部文章
- [ ] 在 `knowledgeService` 对象上实现 `getAllArticles()` 方法，返回 `Article[]`（`Article = { id, title, summary, content, readMinutes }`）
- [ ] 逻辑：返回 `KNOWLEDGE_ARTICLES` 数组的浅拷贝副本（`return [...KNOWLEDGE_ARTICLES]` 或 `KNOWLEDGE_ARTICLES.map(a => ({ ...a }))`），保证调用方修改不影响内部常量
- [ ] 异常降级：整体 try/catch 包裹，若 `KNOWLEDGE_ARTICLES` 常量异常（undefined / 非数组），返回空数组 `[]` 并 `console.warn('knowledgeService.getAllArticles fallback')`
- [ ] 验收：返回数组长度等于预置文章数量（3-5）；返回项含完整 `id` / `title` / `summary` / `content` / `readMinutes` 字段；多次调用返回不同数组引用但内容一致；常量异常时返回 `[]` 不抛错

### 1.3 实现 getArticleById 按 ID 查找单篇文章
- [ ] 在 `knowledgeService` 对象上实现 `getArticleById(id)` 方法，返回 `{ found: boolean, article: Article|null }`
- [ ] 逻辑：校验 `id` 为非空字符串，否则返回 `{ found: false, article: null }`；在 `KNOWLEDGE_ARTICLES` 中 `find` 匹配项；命中返回 `{ found: true, article }`，未命中返回 `{ found: false, article: null }`
- [ ] 异常降级：整体 try/catch 包裹，常量异常或 `id` 非字符串时返回 `{ found: false, article: null }`
- [ ] 验收：传入有效 ID 返回 `found: true` 与对应文章对象；传入无效 ID 返回 `found: false, article: null`；传入 `undefined` / `null` / `''` / 数字类型返回 `found: false`；常量异常时不抛错

### 1.4 预置文章内容方向与字段完整性自检
- [ ] 在 `KNOWLEDGE_ARTICLES` 常量定义后追加自检逻辑（运行时一次性校验，仅 `console.warn` 不抛错）：
  - 校验文章数量在 3-5 之间
  - 校验所有 `id` 两两不等（唯一性）
  - 校验每篇含 `id` / `title` / `summary` / `content` / `readMinutes` 字段且非空（`readMinutes` 为正整数）
  - 校验覆盖储蓄方法、风险识别、理性理财三个方向（按 `id` 前缀或 `title` 关键字判定，至少各 1 篇）
- [ ] 自检失败时 `console.warn` 提示具体缺失项，不阻断模块加载
- [ ] 验收：预置文章数量为 3-5；所有 `id` 唯一；所有字段非空且 `readMinutes` 为正整数；三个方向各至少 1 篇；控制台无自检警告（或仅有可预期的警告）

---

## 2. 已读记录管理（localStorage 独立键读写）

### 2.1 实现 getReadIds 读取已读文章 ID 数组
- [ ] 在 `src/services/knowledgeService.js` 的 `knowledgeService` 对象上实现 `getReadIds()` 方法，返回 `string[]`
- [ ] 逻辑：调用 `localStorage.getItem(READ_KEY)` 读取原始值；若为 `null`（键不存在）返回 `[]`；否则 `JSON.parse` 解析；解析结果非数组（如字符串、对象、数字）时返回 `[]`；数组元素非字符串时过滤后返回（或整体返回 `[]`）
- [ ] 异常降级：整体 try/catch 包裹，`JSON.parse` 失败、`localStorage` 不可访问（如禁用）时返回 `[]`，并 `console.warn('knowledgeService.getReadIds fallback')`
- [ ] 不调用 `localStorageAdapter.getData` / `localStorageAdapter.read`，直接使用原生 `localStorage.getItem`
- [ ] 验收：键不存在时返回 `[]`；键为合法 JSON 字符串数组时返回该数组；键为非数组 JSON（如 `"abc"` / `123` / `{"a":1}`）时返回 `[]`；键为非法 JSON（如 `"{broken"`）时返回 `[]`；localStorage 禁用时不抛错

### 2.2 实现 isRead 判断文章是否已读
- [ ] 在 `knowledgeService` 对象上实现 `isRead(id)` 方法，返回 `boolean`
- [ ] 逻辑：校验 `id` 为非空字符串，否则返回 `false`；调用 `this.getReadIds()` 获取已读数组；返回 `readIds.includes(id)`
- [ ] 异常降级：整体 try/catch 包裹，任意异常返回 `false`
- [ ] 验收：`id` 在已读数组中返回 `true`；不在时返回 `false`；`id` 为空 / 非字符串时返回 `false`；`getReadIds` 异常时返回 `false`

### 2.3 实现 markAsRead 标记文章已读（幂等）
- [ ] 在 `knowledgeService` 对象上实现 `markAsRead(id)` 方法，返回 `{ success: boolean, alreadyRead: boolean }`
- [ ] 逻辑：
  - 校验 `id` 为非空字符串，否则返回 `{ success: false, alreadyRead: false }`
  - 调用 `this.getReadIds()` 获取当前已读数组
  - 若 `readIds.includes(id)` 为 `true`，返回 `{ success: true, alreadyRead: true }`（幂等，不触发写入）
  - 否则追加 `id` 到数组末尾：`readIds.push(id)`，调用 `localStorage.setItem(READ_KEY, JSON.stringify(readIds))`
  - 写入成功返回 `{ success: true, alreadyRead: false }`
- [ ] 异常降级：整体 try/catch 包裹，`setItem` 抛错（如空间不足、localStorage 禁用）时静默返回 `{ success: false, alreadyRead: false }`，并 `console.warn('knowledgeService.markAsRead fallback')`
- [ ] 不调用 `localStorageAdapter.saveData` / `localStorageAdapter.write`，直接使用原生 `localStorage.setItem`
- [ ] 验收：
  - 首次标记某 ID：返回 `{ success: true, alreadyRead: false }`，`localStorage.getItem('read_knowledge_ids')` 包含该 ID
  - 重复标记同一 ID：返回 `{ success: true, alreadyRead: true }`，数组中该 ID 仅出现一次，不触发 `setItem`
  - `id` 为空 / 非字符串：返回 `{ success: false, alreadyRead: false }`，不触发写入
  - localStorage 禁用或空间不足：返回 `{ success: false, alreadyRead: false }`，不抛错
  - 既有 `dream_saving_camp_data` 键内容不被触碰

---

## 3. knowledgeListView 列表页（卡片流渲染、已读标签、点击跳转）

### 3.1 新建 knowledgeListView 文件骨架与文案常量
- [ ] 新建文件 `src/views/knowledgeListView.js`，使用 ES Module `export const knowledgeListView = {}` 形式
- [ ] 在文件顶部定义 `COPY` 文案常量对象：
  - `listTitle: '金融小课堂'`
  - `emptyHint: '暂时还没有内容哦'`
  - `backToHome: '返回首页'`
  - `readTag: '已读'`
  - `minutesSuffix: ' 分钟'`
- [ ] 在文件顶部 import `knowledgeService`（from `'../services/knowledgeService.js'`）
- [ ] 验收：文件存在且可被 `import` 不报错；文案集中于 `COPY` 常量，未散落于 DOM 字符串；不依赖任何外部模块除 knowledgeService 外

### 3.2 实现 render 列表页主入口
- [ ] 在 `knowledgeListView` 对象上实现 `render()` 方法，返回 `void`（挂载到 `#app`）
- [ ] 逻辑：
  - 整体 try/catch 包裹
  - `const app = document.getElementById('app'); if (!app) return;`（容器缺失静默退出）
  - `app.innerHTML = ''` 清空容器
  - 创建 `.knowledge-list-page` 容器节点
  - 调用 `this._renderHeader()` 渲染头部（标题 + 返回首页按钮），appendChild 到容器
  - 同步调用 `const articles = knowledgeService.getAllArticles()` 与 `const readIds = knowledgeService.getReadIds()`（已读状态在卡片渲染前同步读取完成，避免后补闪烁）
  - 若 `articles.length === 0`，调用 `this._renderEmpty()` 渲染空状态，appendChild 到容器
  - 否则遍历 `articles`，对每篇校验字段完整性（`id` / `title` / `summary` / `content` / `readMinutes` 非空），字段缺失则跳过；通过校验的文章调用 `this._renderCard(article, readIds.includes(article.id))` 渲染卡片，appendChild 到容器
  - `app.appendChild(container)`
- [ ] 异常降级：catch 块内尝试 `app.innerHTML = ''` 并 appendChild 一个空 `span`（与 homeView._renderCharityHint 降级模式一致），不向上抛出
- [ ] 验收：调用后 `#app` 内出现 `.knowledge-list-page` 子树；文章数量为预置数量（3-5）；已读状态在卡片首次渲染即正确展示，无后补闪烁；`#app` 不存在时静默退出不抛错；任意异常时 `#app` 渲染空 span 不白屏

### 3.3 实现 _renderHeader 列表页头部
- [ ] 在 `knowledgeListView` 对象上实现 `_renderHeader()`（以 `_` 前缀标记私有）
- [ ] 逻辑：创建 `.knowledge-list-header` 容器节点；创建 `.knowledge-list-title` 节点，`textContent = COPY.listTitle`；创建 `.knowledge-back-btn` 返回首页按钮，`textContent = COPY.backToHome`，绑定 click → `window.location.hash = '#/'`；appendChild 标题与按钮到容器；返回容器
- [ ] 异常降级：try/catch 包裹，异常返回 `document.createElement('span')`
- [ ] 验收：返回节点含 `.knowledge-list-header` 类名；标题文本为"金融小课堂"；按钮文本为"返回首页"；点击按钮后 `window.location.hash` 变为 `#/`

### 3.4 实现 _renderCard 单张知识卡片
- [ ] 在 `knowledgeListView` 对象上实现 `_renderCard(article, isRead)`（以 `_` 前缀标记私有）
- [ ] 逻辑：
  - 创建 `.knowledge-card` 容器节点，`cursor: pointer`（由 CSS 实现）
  - 创建 `.knowledge-card-title` 节点，`textContent = article.title`（使用 textContent 避免 XSS）
  - 创建 `.knowledge-card-meta` 容器节点；创建阅读时长文本节点，`textContent = article.readMinutes + COPY.minutesSuffix`（如"5 分钟"）
  - 若 `isRead === true`，创建 `.knowledge-card-read-tag` 节点，`textContent = COPY.readTag`（"已读"），appendChild 到 meta；否则不创建已读标签节点
  - appendChild 标题与 meta 到卡片
  - 绑定卡片 click → `window.location.hash = '#/knowledge/' + article.id`（hash 切换为 `#/knowledge/:id`）
  - 返回卡片节点
- [ ] 异常降级：try/catch 包裹，异常返回 `document.createElement('span')`
- [ ] 验收：返回节点含 `.knowledge-card` 类名；卡片可见文章完整标题与"X 分钟"阅读时长；`isRead === true` 时卡片含 `.knowledge-card-read-tag` 子节点且文本为"已读"；`isRead === false` 时无已读标签子节点；点击卡片后 `window.location.hash` 变为 `#/knowledge/{article.id}`；卡片不展示文章正文内容（仅标题 + 阅读时长 + 已读标签）

### 3.5 实现 _renderEmpty 列表页空状态
- [ ] 在 `knowledgeListView` 对象上实现 `_renderEmpty()`（以 `_` 前缀标记私有）
- [ ] 逻辑：创建 `.knowledge-empty` 容器节点；创建提示文本节点，`textContent = COPY.emptyHint`（"暂时还没有内容哦"）；创建返回首页按钮，`textContent = COPY.backToHome`，绑定 click → `window.location.hash = '#/'`；appendChild 提示与按钮到容器；返回容器
- [ ] 异常降级：try/catch 包裹，异常返回 `document.createElement('span')`
- [ ] 验收：返回节点含 `.knowledge-empty` 类名；提示文本为"暂时还没有内容哦"；按钮文本为"返回首页"；点击按钮后 `window.location.hash` 变为 `#/`

---

## 4. knowledgeDetailView 详情页（文章详情渲染、自动标记已读、返回按钮）

### 4.1 新建 knowledgeDetailView 文件骨架与文案常量
- [ ] 新建文件 `src/views/knowledgeDetailView.js`，使用 ES Module `export const knowledgeDetailView = {}` 形式
- [ ] 在文件顶部定义 `COPY` 文案常量对象：
  - `notFoundTitle: '文章走丢啦'`
  - `notFoundHint: '可能被流星带走啦，回列表看看其他的吧'`
  - `backToList: '返回列表'`
  - `minutesSuffix: ' 分钟'`
- [ ] 在文件顶部 import `knowledgeService`（from `'../services/knowledgeService.js'`）
- [ ] 验收：文件存在且可被 `import` 不报错；文案集中于 `COPY` 常量；不依赖任何外部模块除 knowledgeService 外

### 4.2 实现 render 详情页主入口
- [ ] 在 `knowledgeDetailView` 对象上实现 `render(id)` 方法，返回 `void`（挂载到 `#app`）
- [ ] 逻辑：
  - 整体 try/catch 包裹
  - `const app = document.getElementById('app'); if (!app) return;`（容器缺失静默退出）
  - `app.innerHTML = ''` 清空容器
  - 创建 `.knowledge-detail-page` 容器节点
  - 调用 `const result = knowledgeService.getArticleById(id)`
  - 若 `result.found === true`：调用 `this._renderArticle(result.article)` 渲染文章正文，appendChild 到容器；`app.appendChild(container)`；随后调用 `knowledgeService.markAsRead(id)` 自动标记已读（写入失败静默降级，不影响正文展示）
  - 若 `result.found === false`：调用 `this._renderNotFound()` 渲染兜底提示，appendChild 到容器；`app.appendChild(container)`
- [ ] 异常降级：catch 块内尝试 `app.innerHTML = ''` 并 appendChild 一个空 `span`，不向上抛出
- [ ] 验收：
  - 传入有效 ID：`#app` 内出现 `.knowledge-detail-page` 子树，含文章标题、阅读时长、正文段落、返回列表按钮；`localStorage.getItem('read_knowledge_ids')` 包含该 ID
  - 传入无效 ID：`#app` 内出现兜底提示"文章走丢啦"与返回列表按钮
  - `#app` 不存在时静默退出不抛错
  - 任意异常时 `#app` 渲染空 span 不白屏
  - `markAsRead` 失败时不影响正文渲染

### 4.3 实现 _renderArticle 文章正文渲染
- [ ] 在 `knowledgeDetailView` 对象上实现 `_renderArticle(article)`（以 `_` 前缀标记私有）
- [ ] 逻辑：
  - 创建 `.knowledge-detail-back` 返回列表按钮，`textContent = COPY.backToList`，绑定 click → `window.location.hash = '#/knowledge'`
  - 创建 `.knowledge-detail-title` 标题节点，`textContent = article.title`
  - 创建 `.knowledge-detail-meta` 阅读时长节点，`textContent = article.readMinutes + COPY.minutesSuffix`
  - 创建 `.knowledge-detail-content` 正文容器；将 `article.content` 按 `\n\n` 分段，每段创建 `<p>` 子节点，`textContent = 段落文本`（使用 textContent 避免 XSS），appendChild 到正文容器；若 `content` 无换行分段则整体作为一个 `<p>`
  - 将返回按钮、标题、阅读时长、正文容器 appendChild 到一个 wrapper（或按顺序返回数组由调用方 appendChild）
  - 返回 wrapper 节点（或文档片段）
- [ ] 异常降级：try/catch 包裹，异常返回 `document.createElement('span')`
- [ ] 验收：返回节点含返回列表按钮、标题、阅读时长、正文段落；标题文本为 `article.title`；阅读时长文本为"X 分钟"；正文按段落分明展示（多个 `<p>` 子节点）；点击返回按钮后 `window.location.hash` 变为 `#/knowledge`；正文使用 textContent 渲染不引入 XSS 风险；不展示用户储蓄金额、目标备注等隐私字段

### 4.4 实现 _renderNotFound 兜底提示
- [ ] 在 `knowledgeDetailView` 对象上实现 `_renderNotFound()`（以 `_` 前缀标记私有）
- [ ] 逻辑：创建 `.knowledge-detail-not-found` 容器节点；创建 `.knowledge-detail-not-found-title` 标题节点，`textContent = COPY.notFoundTitle`（"文章走丢啦"）；创建提示文本节点，`textContent = COPY.notFoundHint`；创建返回列表按钮，`textContent = COPY.backToList`，绑定 click → `window.location.hash = '#/knowledge'`；appendChild 标题、提示、按钮到容器；返回容器
- [ ] 异常降级：try/catch 包裹，异常返回 `document.createElement('span')`
- [ ] 验收：返回节点含 `.knowledge-detail-not-found` 类名；标题文本为"文章走丢啦"；按钮文本为"返回列表"；点击按钮后 `window.location.hash` 变为 `#/knowledge`

---

## 5. 路由接入（main.js 新增 #/knowledge 与 #/knowledge/:id 路由分支）

### 5.1 main.js 顶部 import 段扩展
- [ ] 修改文件 `src/main.js`：在既有 import 段末尾追加：
  - `import { knowledgeListView } from './views/knowledgeListView.js';`
  - `import { knowledgeDetailView } from './views/knowledgeDetailView.js';`
- [ ] 不修改既有 import 顺序与既有模块导入
- [ ] 验收：main.js 顶部 import 段新增 2 行；既有 import 行不变；模块加载不报错

### 5.2 router() 字符串匹配段新增 #/knowledge 分支
- [ ] 修改文件 `src/main.js` 的 `router()` 函数：在既有字符串匹配段中，于 `} else if (hash === '#/goal/new') {` 分支之后、`} else {` 之前，插入：
  - `} else if (hash === '#/knowledge') {`
  - `knowledgeListView.render();`
- [ ] 即将原 `else { ... }` 块改为 `else if (hash === '#/knowledge') { knowledgeListView.render(); } else { ... }`
- [ ] 不修改既有字符串匹配分支（`#/` / `#/camps` / `#/camp/new` / `#/camp/join` / `#/settings` / `#/profile` / `#/goal/new`）的匹配规则与渲染调用
- [ ] 验收：地址栏 hash 为 `#/knowledge` 时调用 `knowledgeListView.render()`；既有字符串匹配 hash 仍按原逻辑匹配与渲染；既有分支代码与行为不变

### 5.3 router() 正则匹配段新增 #/knowledge/:id 分支
- [ ] 修改文件 `src/main.js` 的 `router()` 函数 else 块内：在既有 `const campMatch = hash.match(/^#\/camp\/([^/]+)$/);` 之前，新增：
  - `const knowledgeDetailMatch = hash.match(/^#\/knowledge\/([^/]+)$/);`
- [ ] 在既有 `if (campMatch) {` 之前，新增：
  - `if (knowledgeDetailMatch) {`
  - `knowledgeDetailView.render(knowledgeDetailMatch[1]);`
  - `} else if (campMatch) {`
- [ ] 即将原 `if (campMatch) { ... } else if (withdrawMatch) { ... } ...` 链改为 `if (knowledgeDetailMatch) { ... } else if (campMatch) { ... } else if (withdrawMatch) { ... } ...`
- [ ] 不修改既有正则匹配分支（`campMatch` / `withdrawMatch` / `editMatch` / `detailMatch`）的匹配规则与渲染调用
- [ ] 既有外层 try/catch 兜底自动覆盖新增分支
- [ ] 验收：
  - 地址栏 hash 为 `#/knowledge/{有效ID}` 时调用 `knowledgeDetailView.render(有效ID)`
  - 地址栏 hash 为 `#/knowledge/{无效ID}` 时调用 `knowledgeDetailView.render(无效ID)`（由详情页兜底处理）
  - 既有正则匹配 hash（`#/camp/{id}` / `#/goal/{id}/withdraw` / `#/goal/{id}/edit` / `#/goal/{id}`）仍按原逻辑匹配与渲染
  - 既有 hash（`#/` / `#/camps` / `#/camp/new` / `#/camp/join` / `#/settings` / `#/profile` / `#/goal/new`）均不匹配 `#/knowledge` 与 `^#/knowledge/([^/]+)$`
  - 不新增 `addEventListener('hashchange', ...)` 监听器，复用既有 router 函数

---

## 6. 首页入口按钮（homeView.js 新增"金融小课堂"入口）

### 6.1 homeView 顶部 import 段扩展
- [ ] 修改文件 `src/views/homeView.js`：在既有 import 段中 `import { charityView } from './charityView.js';` 之后追加 `import { knowledgeListView } from './knowledgeListView.js';`
- [ ] 不修改既有 import 顺序与既有模块导入
- [ ] 验收：homeView.js 顶部 import 段新增 1 行；既有 import 行不变；模块加载不报错

### 6.2 homeView.render 渲染管线插入入口按钮调用
- [ ] 修改文件 `src/views/homeView.js` 的 `render()` 方法：在既有 `page.appendChild(this._renderHero(streak));` 之后、`page.appendChild(this._renderStats(...));` 之前，插入：
  - `page.appendChild(this._renderKnowledgeEntry());`
- [ ] 不调整既有 appendChild 顺序，既有 9 个模块调用（identityBar / hero / stats / motivation / charityHint / badges / goalsSection / disclaimer / settingsEntry）不变
- [ ] 验收：首页渲染后，hero 区块下方、stats 区块上方出现"金融小课堂"入口按钮；既有首页元素位置与可点击性不被破坏

### 6.3 实现 _renderKnowledgeEntry 入口按钮私有方法
- [ ] 在 `homeView` 对象上新增私有方法 `_renderKnowledgeEntry()`：
  - try 块内：
    - 创建 `button` 元素，`className = 'home-knowledge-entry'`
    - 设置 `innerHTML` 为图标 + "金融小课堂"文案（如 `<span class="home-knowledge-entry-icon">📚</span><span class="home-knowledge-entry-text">金融小课堂</span>`，与 home-hero-camp 视觉语言一致）
    - 绑定 click 事件 → `window.location.hash = '#/knowledge'`
    - 返回 `button`
  - catch 块返回 `document.createElement('span')`（空 span，与 _renderIdentityBar / _renderCharityHint 降级模式一致）
- [ ] 不修改既有 `_renderIdentityBar` / `_renderHero` / `_renderStats` / `_renderMotivation` / `_renderCharityHint` / `_renderBadges` / `_renderGoalsSection` 等方法的任何代码
- [ ] 验收：
  - 首页渲染后引力小助手附近出现"金融小课堂"入口按钮
  - 按钮文案含"金融小课堂"字样
  - 点击按钮后 `window.location.hash` 变为 `#/knowledge` 且列表页渲染
  - 按钮异常时返回空 span，首页其余部分正常可用，不白屏
  - 既有首页元素（目标卡片、打卡入口、引力小助手等）不被遮挡或推移

---

## 7. 样式与降级（main.css 追加 .knowledge-* 样式 + @supports 降级）

### 7.1 main.css 追加首页入口按钮样式
- [ ] 修改文件 `src/styles/main.css`：在文件末尾追加 `.home-knowledge-entry` 样式段
- [ ] 样式复用 `.home-hero-camp` 视觉语言（玻璃拟态）：
  - `display: inline-flex`、`align-items: center`、`gap: 8px`
  - `padding: 12px 20px`
  - `background: linear-gradient(135deg, rgba(255,255,255,0.12), rgba(255,255,255,0.06))`
  - `backdrop-filter: blur(10px)`、`-webkit-backdrop-filter: blur(10px)`
  - `border: 1px solid rgba(255,255,255,0.18)`、`border-radius: 14px`
  - `color: #fff`、`cursor: pointer`、`transition: all 0.25s ease`
  - `box-shadow: 0 4px 16px rgba(0,0,0,0.18)`
- [ ] 追加 `.home-knowledge-entry:hover`：`transform: translateY(-3px)` + 增强边框 `border-color: rgba(255,255,255,0.32)` + 增强阴影
- [ ] 追加 `.home-knowledge-entry-icon`（字号、行高）与 `.home-knowledge-entry-text`（字号、字重）子元素样式
- [ ] 验收：入口按钮在深色星空背景下可读、有玻璃拟态效果；hover 有微动；不与既有 `.home-hero-camp` / `.home-stats` 等样式冲突

### 7.2 main.css 追加列表页样式段
- [ ] 在 `src/styles/main.css` 末尾追加列表页样式段：
  - `.knowledge-list-page`：`max-width: 720px`、`margin: 0 auto`、`padding: 24px 16px`、`display: flex`、`flex-direction: column`、`gap: 16px`
  - `.knowledge-list-header`：`display: flex`、`justify-content: space-between`、`align-items: center`、`margin-bottom: 8px`
  - `.knowledge-list-title`：`font-size: 1.5rem`、`font-weight: 700`、`color: #fff`
  - `.knowledge-back-btn`：复用既有 `.btn` 视觉或独立玻璃拟态按钮样式（`background: rgba(255,255,255,0.08)`、`backdrop-filter: blur(8px)`、`border: 1px solid rgba(255,255,255,0.16)`、`border-radius: 10px`、`padding: 8px 16px`、`color: #fff`、`cursor: pointer`、`transition: all 0.2s ease`）
  - `.knowledge-back-btn:hover`：`background: rgba(255,255,255,0.14)` + `transform: translateY(-1px)`
  - `.knowledge-card`：`background: rgba(255,255,255,0.08)`、`backdrop-filter: blur(12px)`、`-webkit-backdrop-filter: blur(12px)`、`border: 1px solid rgba(255,255,255,0.14)`、`border-radius: 16px`、`padding: 18px 22px`、`cursor: pointer`、`transition: all 0.25s ease`、`box-shadow: 0 4px 18px rgba(0,0,0,0.18)`
  - `.knowledge-card:hover`：`transform: translateY(-2px)` + `border-color: rgba(255,255,255,0.28)` + 增强阴影
  - `.knowledge-card-title`：`font-size: 1.1rem`、`font-weight: 600`、`color: #fff`、`line-height: 1.4`、`margin-bottom: 10px`
  - `.knowledge-card-meta`：`display: flex`、`align-items: center`、`gap: 10px`、`font-size: 0.9rem`、`color: rgba(255,255,255,0.7)`
  - `.knowledge-card-read-tag`：`background: rgba(76,175,80,0.18)`、`color: #4CAF50`、`font-size: 0.78rem`、`padding: 2px 10px`、`border-radius: 10px`、`margin-left: 4px`
  - `.knowledge-empty`：`text-align: center`、`padding: 48px 16px`、`color: rgba(255,255,255,0.7)`
- [ ] 验收：列表页在深色星空背景下可读、卡片有玻璃拟态效果；hover 有微动；已读标签绿色调清晰；不与既有 `.home-*` / `.charity-*` 样式冲突

### 7.3 main.css 追加详情页样式段
- [ ] 在 `src/styles/main.css` 末尾追加详情页样式段：
  - `.knowledge-detail-page`：`max-width: 720px`、`margin: 0 auto`、`padding: 32px 24px`、`background: rgba(28,32,52,0.78)`、`backdrop-filter: blur(18px)`、`-webkit-backdrop-filter: blur(18px)`、`border: 1px solid rgba(255,255,255,0.14)`、`border-radius: 20px`、`box-shadow: 0 8px 32px rgba(0,0,0,0.28)`
  - `.knowledge-detail-back`：玻璃拟态按钮、`margin-bottom: 20px`（复用 `.knowledge-back-btn` 视觉或独立样式）
  - `.knowledge-detail-title`：`font-size: 1.6rem`、`font-weight: 700`、`color: #fff`、`line-height: 1.3`、`margin-bottom: 12px`
  - `.knowledge-detail-meta`：`font-size: 0.9rem`、`color: rgba(255,255,255,0.7)`、`margin-bottom: 24px`
  - `.knowledge-detail-content`：`font-size: 1rem`、`color: rgba(255,255,255,0.88)`、`line-height: 1.8`
  - `.knowledge-detail-content p`：`margin-bottom: 1em`（段落分明）
  - `.knowledge-detail-not-found`：`text-align: center`、`padding: 48px 16px`
  - `.knowledge-detail-not-found-title`：`font-size: 1.4rem`、`font-weight: 700`、`color: #fff`、`margin-bottom: 12px`
- [ ] 验收：详情页在深色星空背景下可读、有玻璃拟态效果；正文文字对比度满足可读性要求（不出现低对比度灰字）；段落分明；不与既有样式冲突

### 7.4 backdrop-filter 不支持时的降级
- [ ] 在 `src/styles/main.css` 末尾既有 `@supports not (backdrop-filter: blur(1px)) { ... }` 段内追加降级规则，或新增独立 `@supports not (backdrop-filter: blur(1px)) { ... }` 段紧随其后
- [ ] 降级规则：
  - `.home-knowledge-entry { background: rgba(30,35,55,0.9); }`（纯色半透明，移除 blur 依赖）
  - `.knowledge-card { background: rgba(30,35,55,0.9); }`
  - `.knowledge-detail-page { background: rgba(30,35,55,0.92); }`
  - `.knowledge-back-btn` / `.knowledge-detail-back`（如有 backdrop-filter）改为纯色半透明
- [ ] 验收：在不支持 backdrop-filter 的浏览器（如旧版 Edge）上入口按钮、卡片、详情页仍可读、不白屏；支持 backdrop-filter 的浏览器降级段不生效

---

## 8. 集成验证与回归测试

### 8.1 知识文章数据服务端到端验证
- [ ] 在浏览器控制台执行 `import('/src/services/knowledgeService.js').then(m => console.log(m.knowledgeService.getAllArticles()))`，验证返回 3-5 篇文章，每篇含完整 `id` / `title` / `summary` / `content` / `readMinutes` 字段
- [ ] 验证所有 `id` 两两不等（唯一性）
- [ ] 验证覆盖储蓄方法、风险识别、理性理财三个方向（按 `id` 或 `title` 关键字判定，至少各 1 篇）
- [ ] 验证 `getArticleById('week52_saving')` 返回 `{ found: true, article: {...} }`；`getArticleById('invalid_id')` 返回 `{ found: false, article: null }`
- [ ] 验证 `getAllArticles()` 多次调用返回不同数组引用但内容一致（常量未被外部修改）
- [ ] 验收：5 项验证全部符合预期；全流程无 `fetch` 调用、无外部接口请求

### 8.2 已读记录管理端到端验证
- [ ] 清空 localStorage 后调用 `knowledgeService.getReadIds()`，验证返回 `[]`
- [ ] 调用 `markAsRead('week52_saving')`，验证返回 `{ success: true, alreadyRead: false }`，`localStorage.getItem('read_knowledge_ids')` 为 `["week52_saving"]`
- [ ] 再次调用 `markAsRead('week52_saving')`，验证返回 `{ success: true, alreadyRead: true }`，数组中 `week52_saving` 仅出现一次（幂等）
- [ ] 调用 `isRead('week52_saving')` 验证返回 `true`；调用 `isRead('anti_pig_butcher')` 验证返回 `false`
- [ ] 手动破坏 `localStorage.setItem('read_knowledge_ids', 'invalid_json')`，调用 `getReadIds()` 验证返回 `[]` 不抛错
- [ ] 手动破坏 `localStorage.setItem('read_knowledge_ids', '"not_array"')`，调用 `getReadIds()` 验证返回 `[]` 不抛错
- [ ] 验证 `dream_saving_camp_data` 键内容在所有操作后不变
- [ ] 验收：7 项验证全部符合预期；幂等性成立；异常降级不抛错；既有数据键不被触碰

### 8.3 列表页端到端验证
- [ ] 在浏览器地址栏输入 `#/knowledge`，验证列表页渲染：顶部标题"金融小课堂"、返回首页按钮、3-5 张知识卡片
- [ ] 验证每张卡片含文章标题与"X 分钟"阅读时长，不展示正文内容
- [ ] 验证已读文章卡片展示"已读"标签，未读文章不展示
- [ ] 验证已读状态在卡片首次渲染即正确展示，无后补闪烁
- [ ] 点击某张卡片，验证地址栏 hash 变为 `#/knowledge/{文章ID}` 且详情页渲染
- [ ] 点击返回首页按钮，验证 hash 变为 `#/` 且首页渲染
- [ ] 验收：6 项验证全部符合预期；列表页渲染耗时 < 80ms（Performance.now 包测）

### 8.4 详情页端到端验证
- [ ] 从列表页点击卡片进入详情页，验证页面展示文章标题、阅读时长、正文段落、返回列表按钮
- [ ] 验证正文段落分明（多个 `<p>` 子节点）、文字对比度满足可读性要求
- [ ] 验证进入详情页后 `localStorage.getItem('read_knowledge_ids')` 包含该文章 ID（自动标记已读）
- [ ] 重复进入同一文章详情页，验证 `read_knowledge_ids` 中该 ID 仅出现一次（幂等）
- [ ] 点击返回列表按钮，验证 hash 变为 `#/knowledge` 且列表页渲染，对应卡片展示"已读"标签
- [ ] 在地址栏输入 `#/knowledge/invalid_id`，验证详情页展示"文章走丢啦"兜底提示与返回列表按钮，不白屏
- [ ] 验收：6 项验证全部符合预期；详情页渲染耗时 < 80ms；自动标记已读耗时 < 16ms

### 8.5 首页入口按钮端到端验证
- [ ] 进入首页 `#/`，验证引力小助手附近出现"金融小课堂"入口按钮
- [ ] 验证按钮文案含"金融小课堂"字样，采用玻璃拟态风格，与既有首页按钮视觉协调
- [ ] 验证既有首页元素（目标卡片、打卡入口、引力小助手等）位置与可点击性不被破坏
- [ ] 点击入口按钮，验证地址栏 hash 变为 `#/knowledge` 且列表页渲染
- [ ] 验收：4 项验证全部符合预期；入口按钮渲染耗时 < 30ms

### 8.6 异常降级与不白屏验证
- [ ] 清空 localStorage 后进入 `#/knowledge`，验证列表页正常渲染（所有卡片未读），不白屏、控制台无未捕获异常
- [ ] 手动破坏 `localStorage.setItem('read_knowledge_ids', '{broken')`，进入 `#/knowledge`，验证列表页所有卡片不展示"已读"标签，不抛错
- [ ] 进入 `#/knowledge/invalid_id`，验证详情页展示"文章走丢啦"兜底提示，不白屏
- [ ] 模拟 `#app` 容器缺失（如临时 `document.getElementById('app').remove()`），进入 `#/knowledge`，验证不抛错、不白屏，浏览器后退后首页正常可用
- [ ] 模拟 `knowledgeService.getAllArticles` 抛错（如临时覆盖方法），进入 `#/knowledge`，验证列表页展示空状态或空 span，不白屏
- [ ] 在不支持 backdrop-filter 的浏览器（或通过 DevTools 模拟）上进入 `#/knowledge` 与 `#/knowledge/{id}`，验证卡片与详情页降级为纯色半透明背景，不白屏
- [ ] 验收：6 个异常场景全部降级处理，无白屏、无未捕获异常、主页其他模块正常可用

### 8.7 既有功能回归验证
- [ ] 验证粒子动画在首页正常播放
- [ ] 验证组队留言、引力场列表功能正常
- [ ] 验证储蓄打卡（今日 checkIn）正常工作
- [ ] 验证新手教程、滚动叙事、Q弹交互正常
- [ ] 验证公益赎回功能（柔性提示卡片、公益赎回弹窗、公益守护者徽章）正常
- [ ] 验证既有三枚徽章（streak_7 / streak_30 / first_goal_done）的解锁条件与展示不变
- [ ] 验证 main.js 既有路由分支（`#/` / `#/camps` / `#/camp/new` / `#/camp/join` / `#/settings` / `#/profile` / `#/goal/new` / `#/camp/{id}` / `#/goal/{id}/withdraw` / `#/goal/{id}/edit` / `#/goal/{id}`）全部正常匹配与渲染
- [ ] 验证 index.html 页面骨架未被修改
- [ ] 验证 localStorage `dream_saving_camp_data` 顶层字段结构（goals / records / checkIns / camps / achievements / user）不变
- [ ] 验收：10 项既有功能全部正常；diff 范围仅限 `knowledgeService.js` / `knowledgeListView.js` / `knowledgeDetailView.js` 新建 + `main.js` / `homeView.js` / `main.css` 局部修改

### 8.8 性能与文案合规验证
- [ ] 验证列表页从路由触发到卡片流渲染完成耗时 < 80ms（Performance.now 包测）
- [ ] 验证详情页从路由触发到正文渲染完成耗时 < 80ms
- [ ] 验证已读状态写入耗时 < 16ms
- [ ] 验证首页入口按钮渲染耗时 < 30ms
- [ ] 验证全流程无 `fetch` / `XMLHttpRequest` / `WebSocket` 调用
- [ ] 全量审查 knowledgeListView / knowledgeDetailView 所有文案字符串，确认不含禁用词（如 `['惩罚', '断签', '失败', '扣款', '警告']`）
- [ ] 验证文章正文使用 textContent 渲染，不引入 XSS 风险
- [ ] 验收：7 项性能与合规指标达标；文案零禁用词；无 XSS 风险

---

## 9. 代码审查与交付确认

### 9.1 代码审查
- [ ] 审查 `src/services/knowledgeService.js`：
  - 确认所有方法同步、无 DOM 依赖、所有异常 try/catch 包裹
  - 确认常量 `KNOWLEDGE_ARTICLES` / `READ_KEY` 集中于文件顶部
  - 确认不调用 `localStorageAdapter.getData` / `saveData` / `read` / `write`，直接使用原生 `localStorage.getItem` / `setItem`
  - 确认 `markAsRead` 幂等性（写入前数组包含性检查）
  - 确认不出现任何 `fetch` / `XMLHttpRequest` / `WebSocket` 调用
- [ ] 审查 `src/views/knowledgeListView.js`：
  - 确认所有 DOM 操作 try/catch 包裹
  - 确认文案集中于 `COPY` 常量
  - 确认私有方法以 `_` 前缀标记
  - 确认 `render()` 整体 try/catch 兜底返回空 span
  - 确认已读状态在卡片渲染前同步读取完成（`getReadIds` 在遍历 `articles` 之前调用）
  - 确认正文使用 textContent 渲染
- [ ] 审查 `src/views/knowledgeDetailView.js`：
  - 确认所有 DOM 操作 try/catch 包裹
  - 确认文案集中于 `COPY` 常量
  - 确认私有方法以 `_` 前缀标记
  - 确认 `render(id)` 整体 try/catch 兜底返回空 span
  - 确认 `markAsRead` 在正文渲染后触发，写入失败静默降级
  - 确认正文使用 textContent 渲染
- [ ] 审查 `src/main.js` diff：
  - 确认仅新增 2 行 import + 1 条 `#/knowledge` 字符串匹配分支 + 1 条 `#/knowledge/:id` 正则匹配分支
  - 确认既有路由分支代码与行为不变
  - 确认不新增 `addEventListener('hashchange', ...)` 监听器
- [ ] 审查 `src/views/homeView.js` diff：
  - 确认仅新增 1 行 import + 1 行 `page.appendChild(this._renderKnowledgeEntry());` + 1 个 `_renderKnowledgeEntry` 方法
  - 确认既有 `_renderXxx` 方法不变
- [ ] 审查 `src/styles/main.css` diff：
  - 确认仅末尾追加 `.home-knowledge-entry` / `.knowledge-*` 段与 `@supports` 降级段
  - 确认既有样式不变
  - 确认未引入 Tailwind 等原子类框架
- [ ] 验收：6 个文件审查通过，diff 范围与设计文档 2.4.4 节文件修改清单一致

### 9.2 设计一致性核对
- [ ] 核对 design.md 2.2.2 节接口清单中 6 个接口签名（`getAllArticles` / `getArticleById` / `getReadIds` / `isRead` / `markAsRead` / `knowledgeListView.render` / `knowledgeDetailView.render`）与实现一致
- [ ] 核对 design.md 2.1.3.1 节状态机所有状态转移已实现（Home / KnowledgeList / KnowledgeDetail 之间的 hash 切换）
- [ ] 核对 design.md 2.1.3.2 节已读标记幂等流程与 `markAsRead` 实现一致
- [ ] 核对 design.md 2.1.3.3 节列表页渲染流程与 `knowledgeListView.render` 实现一致
- [ ] 核对 design.md 2.1.3.4 节详情页渲染流程与 `knowledgeDetailView.render` 实现一致
- [ ] 核对 design.md 2.4.1 节不白屏降级策略 5 项全部落地
- [ ] 核对 design.md 2.4.2 节既有功能保护措施 6 项全部落地
- [ ] 核对 design.md 2.4.3 节性能保证 5 项指标全部达标
- [ ] 验收：8 项核对全部一致

### 9.3 变更范围最终确认
- [ ] 确认新建文件仅以下 3 个：
  - `src/services/knowledgeService.js`
  - `src/views/knowledgeListView.js`
  - `src/views/knowledgeDetailView.js`
- [ ] 确认修改文件仅以下 3 个：
  - `src/main.js`（仅追加 2 行 import + 2 条路由分支）
  - `src/views/homeView.js`（仅追加 1 行 import + 1 行 appendChild + 1 个 `_renderKnowledgeEntry` 方法）
  - `src/styles/main.css`（仅末尾追加 `.home-knowledge-entry` / `.knowledge-*` 样式段 + `@supports` 降级段）
- [ ] 确认未修改以下文件：
  - `index.html`
  - `src/constants.js`
  - `src/storage/localStorageAdapter.js`
  - `src/utils/splashAnimation.js`
  - `src/utils/scrollAnimation.js`
  - `src/utils/jellyInteraction.js`
  - `src/services/habitService.js`
  - `src/services/charityService.js`
  - `src/services/achievementService.js`
  - `src/views/charityView.js`
  - `src/views/onboardingTutorial.js`
  - 其他既有文件
- [ ] 确认未引入新的 npm 依赖、未引入 Tailwind 等原子类框架、未引入 TypeScript、未引入第三方 SDK
- [ ] 确认未引入任何 `fetch` / `XMLHttpRequest` / `WebSocket` 网络能力
- [ ] 验收：变更范围严格限定，与 spec 6.4 节变更范围约束一致，可安全合入主分支