# 新手教程（OnboardingTutorial）编码任务列表

> 本任务列表基于 `spec.md`（新增气泡半透明黑色背景等要求）与 `design.md`（确认唯一改动为 main.css 气泡样式段配色调整）重新生成，遵循"垂直切割、可验收、原子性、有序性"原则。所有任务按依赖顺序排列，被依赖者在前。
>
> **改造性质**：经 design.md 核查，现有 `onboardingTutorial.js` / `tutorialStorage.js` / `tutorialSteps.js` / `termMapping.js` / `main.js` / `settingsView.js` / `backupService.js` / `constants.js` 在功能层面已完全符合新 spec（3 步教程 + 三通道感知自动推进 + 旧版兼容 + 路由跟随 + 定位避让 + 跳过按钮 + textContent 防注入 + 挂 document.body + 独立 try-catch）。**本次基于新 spec 的唯一实际代码改动集中在 `src/styles/main.css` 气泡样式段（约 2180-2304 行）的配色调整**：气泡背景由半透明白色改为半透明黑色、文字由深色改为浅色、箭头配色同步、术语对照块与 secondary 按钮背景适配深底。结构与动效（圆角/留白/入场动效/箭头定位/避让/响应式断点）完全复用，`onboardingTutorial.js` 无需改动。
>
> **全局保命约束（贯穿所有任务，违反任一即停止）**：
> 1. 教程通过浮动气泡提示框引导，绝不拦截/修改原有按钮点击事件，源码中不得出现作用于原有元素的 `e.preventDefault()` / `e.stopPropagation()` / `addEventListener` 拦截 / 替换 `onclick` / 叠加蒙层
> 2. 用 localStorage 的 `tutorialStep`（数字，默认 0，取值 0~3）记录引导进度，禁止用布尔值
> 3. 保证原有所有按钮正常点击，发现白屏风险立即停止
> 4. 不改 `main.js` 既有 `init()` 调用顺序与内容，教程启动挂载点（`init()` 末尾 `try { onboardingTutorial.start(); } catch (e) {}`）保持不变
> 5. 教程推进方式：感知用户实际操作后自动推进（非教程自带按钮推进），气泡仅保留"跳过"按钮，不提供"下一步""上一步"
> 6. 操作感知三通道：hashchange 路由变化 / localStorage 业务键只读轮询 / MutationObserver DOM 变化；三通道全部只读，禁止对原有按钮 addEventListener / 替换 onclick / 叠加蒙层
> 7. 异常全捕获，最坏情况为教程静默退出而非白屏
> 8. 不引入第三方库，文案一律用 `textContent` 防注入
> 9. `tutorialStep` 独立存储不纳入 `APP_DATA_KEYS`；气泡挂 `document.body` 非 `#app`；追加 `hashchange` 监听不替换既有；启动包裹独立 try-catch
> 10. 旧版兼容：`tutorialStep >= 3` 视为完成不再弹出，1~2 对应新步骤继续引导，0 视为未开始
> 11. **本次仅改 `main.css` 气泡样式段配色，不改任何 JS 文件逻辑、不改 `index.html`、不改非教程样式段**

---

## 1. 气泡主体与文字配色改造

> 本组改造 `src/styles/main.css` 气泡样式段（约 2181-2239 行）的气泡容器背景与各级文字配色，使气泡呈现半透明黑色深色蒙层质感 + 浅色高对比文字。无外部依赖，可优先开发。1.1 ~ 1.5 实际为同一文件 `src/styles/main.css` 的不同选择器，按职责拆分以便逐项验收，开发时合并实现。

### 1.1 改造气泡容器背景与基础文字色
- [ ] 修改文件 `src/styles/main.css` 第 2186 行 `.tutorial-bubble` 的 `background` 属性，由 `rgba(255, 255, 255, 0.96)`（半透明白色）改为 `rgba(0, 0, 0, 0.7)`（半透明黑色，深色蒙层质感）
- [ ] 修改第 2189 行 `.tutorial-bubble` 的 `color` 属性，由 `var(--color-text)`（主题深色文字）改为 `#fff`（白色，脱离主题变量固定浅色）
- [ ] 保留 `.tutorial-bubble` 的 `position: fixed` / `z-index: 1500` / `max-width: 340px` / `width: calc(100vw - 32px)` / `border-radius: var(--radius-lg)` / `box-shadow: var(--shadow-lg)` / `padding` / `animation` 等结构与动效属性不变
- **验收标准**：渲染教程气泡后 `.tutorial-bubble` 计算样式 `background-color` 为 `rgba(0, 0, 0, 0.7)`、`color` 为 `rgb(255, 255, 255)`；气泡仍为 `position: fixed` 局部小尺寸卡片（max-width 340px），无全屏遮罩

### 1.2 改造标题文字色为白色
- [ ] 修改文件 `src/styles/main.css` 第 2208 行 `.tutorial-bubble-title` 的 `color` 属性，由 `var(--color-text)` 改为 `#fff`
- [ ] 保留 `.tutorial-bubble-title` 的 `font-size` / `font-weight` / `margin` / `line-height` 不变
- **验收标准**：气泡标题计算样式 `color` 为 `rgb(255, 255, 255)`，在半透明黑色背景上高对比可读

### 1.3 改造通俗文案文字色为浅灰白
- [ ] 修改文件 `src/styles/main.css` 第 2215 行 `.tutorial-bubble-plain` 的 `color` 属性，由 `var(--color-text-light)` 改为 `rgba(255, 255, 255, 0.85)`
- [ ] 保留 `.tutorial-bubble-plain` 的 `font-size` / `line-height` / `margin` 不变
- **验收标准**：气泡通俗文案计算样式 `color` 为 `rgba(255, 255, 255, 0.85)`，在半透明黑色背景上清晰可读

### 1.4 改造术语对照块背景与文字色
- [ ] 修改文件 `src/styles/main.css` 第 2223 行 `.tutorial-bubble-term` 的 `background` 属性，由 `var(--color-bg)` 改为 `rgba(255, 255, 255, 0.12)`（半透明白叠在黑底上形成深灰区分层）
- [ ] 修改第 2222 行 `.tutorial-bubble-term` 的 `color` 属性，由 `var(--color-text-muted)` 改为 `rgba(255, 255, 255, 0.75)`
- [ ] 修改第 2232 行 `.tutorial-bubble-term-label` 的 `color` 属性，由 `var(--color-text)` 改为 `#fff`
- [ ] 保留 `.tutorial-bubble-term` 的 `font-size` / `border-radius` / `padding` / `margin` / `line-height` 与 `.tutorial-bubble-term-label` 的 `font-weight` 不变
- **验收标准**：术语对照块计算样式 `background-color` 为 `rgba(255, 255, 255, 0.12)`、`color` 为 `rgba(255, 255, 255, 0.75)`；术语标签 `color` 为 `rgb(255, 255, 255)`；块在黑底上形成可辨识的深灰区分层

### 1.5 改造进度指示文字色为浅灰
- [ ] 修改文件 `src/styles/main.css` 第 2237 行 `.tutorial-bubble-progress` 的 `color` 属性，由 `var(--color-text-muted)` 改为 `rgba(255, 255, 255, 0.6)`
- [ ] 保留 `.tutorial-bubble-progress` 的 `font-size` / `margin` 不变
- **验收标准**：进度指示（如"第 1 步 / 共 3 步"）计算样式 `color` 为 `rgba(255, 255, 255, 0.6)`，在半透明黑色背景上可读

---

## 2. 按钮与指向箭头配色改造

> 本组改造 `src/styles/main.css` 气泡样式段（约 2259-2293 行）的按钮与箭头配色。依赖第 1 组完成（气泡已为黑底浅字）。2.1 / 2.2 / 2.3 按选择器拆分以便逐项验收，开发时合并实现。

### 2.1 保留 primary 按钮品牌主色配色
- [ ] 确认 `src/styles/main.css` 第 2259-2262 行 `.tutorial-bubble-btn-primary` 的 `background: var(--color-primary)` 与 `color: #fff` 保持不变（品牌主色在黑底上仍醒目，与品牌呼应）
- [ ] 确认第 2264-2267 行 `.tutorial-bubble-btn-primary:hover` 的 `filter: brightness(1.08)` 与 `transform: translateY(-1px)` 保持不变
- **验收标准**：primary 按钮计算样式 `background-color` 为品牌主色、`color` 为白色，hover 效果不变；该按钮样式段未被改动（git diff 为空）

### 2.2 改造 secondary 按钮背景与文字色适配深底
- [ ] 修改文件 `src/styles/main.css` 第 2270 行 `.tutorial-bubble-btn-secondary` 的 `background` 属性，由 `var(--color-bg)` 改为 `rgba(255, 255, 255, 0.15)`（半透明白叠黑底成浅灰按钮）
- [ ] 修改第 2271 行 `.tutorial-bubble-btn-secondary` 的 `color` 属性，由 `var(--color-text-light)` 改为 `#fff`
- [ ] 修改第 2275 行 `.tutorial-bubble-btn-secondary:hover` 的 `background` 属性，由 `var(--color-border)` 改为 `rgba(255, 255, 255, 0.25)`（hover 加亮）
- [ ] 保留 `.tutorial-bubble-btn` 通用样式（flex / padding / border / border-radius / font / cursor / transition）不变
- **验收标准**：secondary 按钮（跳过按钮）计算样式 `background-color` 为 `rgba(255, 255, 255, 0.15)`、`color` 为 `rgb(255, 255, 255)`；hover 时 `background-color` 为 `rgba(255, 255, 255, 0.25)`；按钮在黑底上清晰可辨可点击

### 2.3 改造指向箭头配色与气泡背景一致
- [ ] 修改文件 `src/styles/main.css` 第 2287 行 `.tutorial-bubble-arrow-up` 的 `border-bottom-color` 属性，由 `rgba(255, 255, 255, 0.96)` 改为 `rgba(0, 0, 0, 0.7)`（与气泡背景一致）
- [ ] 修改第 2292 行 `.tutorial-bubble-arrow-down` 的 `border-top-color` 属性，由 `rgba(255, 255, 255, 0.96)` 改为 `rgba(0, 0, 0, 0.7)`
- [ ] 保留 `.tutorial-bubble-arrow` 的 `position: absolute` / `width` / `height` / `border: 7px solid transparent` 与箭头定位（`bottom: 100%` / `top: 100%`）不变
- **验收标准**：上箭头 `border-bottom-color` 为 `rgba(0, 0, 0, 0.7)`、下箭头 `border-top-color` 为 `rgba(0, 0, 0, 0.7)`；箭头颜色与气泡背景视觉一致无缝衔接

---

## 3. 既有功能与文件复用确认

> 本组确认教程组件 JS 文件、挂载点与非教程样式段对新 spec 完全适用，无需改动。依赖第 1、2 组完成。

### 3.1 确认教程组件 JS 文件无需改动
- [ ] 确认 `src/views/onboardingTutorial.js` 已完整实现 3 步教程 + 三通道感知（hashchange / storagePoll / mutationObserver）+ 自动推进（`_tryAdvance`）+ 路由切换判定（`_updateBubbleForRoute`）+ 气泡定位避让（`_positionBubble`）+ 刷新恢复 + 局部小尺寸定位 + 跳过按钮 + textContent 防注入 + 挂 document.body + 追加 hashchange 监听 + 独立 try-catch，功能层面已完全符合新 spec，无需改动
- [ ] 确认 `src/views/tutorialSteps.js` 已为 3 步配置含 sensing 字段（步 0 hashchange 感知 #/goal/new、步 1 storagePoll + mutationObserver 感知打卡、步 2 hashchange + mutationObserver 感知面板或 #/camps），`TOTAL === 3`，无需改动
- [ ] 确认 `src/storage/tutorialStorage.js` 已实现旧版 7 步历史值兼容（read 中 `num >= tutorialSteps.TOTAL` 返回 TOTAL 完成态），无需改动
- [ ] 确认 `src/views/termMapping.js` 现有 5 个术语对照（引力源/引力场/引力小助手/逃逸速度/打卡）的 `term` / `plain` / `detail` 文案与 design.md 术语对照表完全一致，无需改动
- **验收标准**：`onboardingTutorial.js` / `tutorialSteps.js` / `tutorialStorage.js` / `termMapping.js` 四个文件均未被改动（git diff 为空）；`tutorialSteps.TOTAL === 3`；`termMapping.ALL.length === 5`

### 3.2 确认既有挂载点与常量文件无需改动
- [ ] 确认 `src/main.js` 的 `init()` 末尾 `try { onboardingTutorial.start(); } catch (e) {}`（约 77 行）对新方案完全适用，`start()` 行为语义不变，无需修改
- [ ] 确认 `src/views/settingsView.js` 的 `_renderTutorialCard()`（约 157-180 行）"重新观看教程"卡片点击调用 `onboardingTutorial.restart()`，`restart()` 签名不变，无需修改
- [ ] 确认 `src/services/backupService.js` 的 `clearAllData()` 中 `localStorage.removeItem('tutorialStep')`（约 92 行）清理教程进度，`tutorialStep` 键名不变，无需修改
- [ ] 确认 `src/constants.js` 的 `APP_DATA_KEYS` 仅含三个业务键未含 `tutorialStep`，教程键独立于业务键，无需修改
- **验收标准**：`main.js` / `settingsView.js` / `backupService.js` / `constants.js` 四个文件均未被改动（git diff 为空）；既有 `init()` 调用顺序与内容不变；设置页"重新观看教程"卡片功能正常；清空数据后 `tutorialStep` 被一并清理

### 3.3 确认 main.css 非教程样式段与结构动效样式无需改动
- [ ] 确认 `src/styles/main.css` 第 2180 行之前与第 2304 行之后的非教程样式段未被改动（git diff 仅限 2181-2293 行的配色属性）
- [ ] 确认 `.tutorial-bubble` 的 `position: fixed` / `max-width: 340px` / `width: calc(100vw - 32px)` / `border-radius` / `box-shadow` / `padding` / `animation` 结构属性不变
- [ ] 确认 `@keyframes tutorialBubbleIn` 入场动效（opacity + translateY）不变
- [ ] 确认 `.tutorial-bubble-actions` 的 flex 布局不变（移除上一步/下一步按钮后单按钮 flex:1 自动占满）
- [ ] 确认 `.tutorial-bubble-btn` 通用按钮样式（flex / padding / border / border-radius / font / cursor / transition）不变
- [ ] 确认 `.tutorial-bubble-arrow` 的 `position: absolute` / `width: 0` / `height: 0` / `border: 7px solid transparent` 与箭头定位不变
- [ ] 确认 `@media (max-width: 480px)` 响应式断点样式不变
- **验收标准**：`main.css` git diff 仅涉及配色属性（background / color / border-bottom-color / border-top-color），不涉及任何结构、布局、动效、定位属性；非教程样式段零改动

---

## 4. 集成测试与验证

> 本组为端到端验证，依赖第 1-3 组全部完成。按场景逐项手动/脚本验证，每项须记录通过/失败。重点验证配色改造后的三套主题可读性与既有功能零回归。

### 4.1 验证气泡配色改造效果
- [ ] 清空 localStorage 后首次打开应用进入首页，教程第一步气泡弹出后检查 `.tutorial-bubble` 计算样式：`background-color` 为 `rgba(0, 0, 0, 0.7)`（半透明黑色蒙层质感）
- [ ] 检查气泡内标题 `.tutorial-bubble-title` 文字为白色、通俗文案 `.tutorial-bubble-plain` 为浅灰白（rgba(255,255,255,0.85)）、进度 `.tutorial-bubble-progress` 为浅灰（rgba(255,255,255,0.6)），均在黑底上高对比可读
- [ ] 检查术语对照块 `.tutorial-bubble-term` 背景为半透明白叠黑底（rgba(255,255,255,0.12)）形成深灰区分层，文字与标签可读
- [ ] 检查跳过按钮 `.tutorial-bubble-btn-secondary` 背景为半透明白（rgba(255,255,255,0.15)）+ 白字，hover 加亮至 rgba(255,255,255,0.25)
- [ ] 检查指向箭头颜色与气泡背景一致（rgba(0,0,0,0.7)），视觉无缝衔接
- **验收标准**：气泡呈现半透明黑色深色蒙层质感，所有文字与按钮为浅色高对比可读，箭头与背景一致，视觉风格符合 Minimalist Modern

### 4.2 验证三套主题下气泡可读性
- [ ] 在星云紫（nebula）主题下完整走一遍三步教程，验证气泡背景为半透明黑色、文字与按钮为浅色，在紫色背景上高对比清晰可读，风格与页面协调
- [ ] 在晨曦黄（dawn）主题下完整走一遍三步教程，验证气泡在黄色背景上高对比清晰可读，风格协调
- [ ] 在赛博蓝（cyber）主题下完整走一遍三步教程，验证气泡在蓝色背景上高对比清晰可读，风格协调
- [ ] 验证三套主题下气泡视觉完全一致（配色固定不依赖主题变量），切换主题时气泡可读性不受影响
- [ ] 验证 primary 按钮保留品牌主色 `var(--color-primary)` + 白字，在三套主题下均醒目且与品牌呼应
- **验收标准**：三套主题下教程气泡均高对比可读，视觉风格符合 Minimalist Modern 无突兀感；配色固定脱离主题变量，三套主题统一呈现

### 4.3 验证既有教程功能零回归
- [ ] 清空 localStorage 后首次打开应用进入首页，验证首页完整渲染后自动弹出教程第一步气泡（指向 `.home-create-btn`），文案为"第一步：点击这里，写下你的存钱目标。"，进度显示"第 1 步 / 共 3 步"，`tutorialStep` 仍为 0
- [ ] 第一步气泡展示时点击首页"建立引力源"按钮，验证正常跳转到 `#/goal/new`（原有事件不被拦截），教程通过 hashchange 感知后 `tutorialStep` 自动变为 1，气泡移除
- [ ] 从 `#/goal/new` 返回首页 `#/` 后，验证自动弹出第二步气泡（指向 `.home-stats` 打卡区域），文案为"第二步：点这里存入一笔钱，进度条就会增长！"
- [ ] 第二步气泡展示时执行打卡操作存入一笔钱，验证教程感知后 `tutorialStep` 自动变为 2，气泡切换为第三步
- [ ] 第三步气泡展示时点击右下角引力小助手（`.advisor-fab`），验证面板正常打开，教程感知后 `tutorialStep` 自动变为 3，气泡移除引导结束
- [ ] 验证全程无须点击任何教程自带"下一步"按钮即完成三步推进（教程仅提供"跳过"按钮）
- **验收标准**：完整走完三步后 `tutorialStep===3`，全程通过感知用户实际操作自动推进，原有按钮点击行为完全正常，教程未替用户点击任何按钮

### 4.4 验证不拦截原有交互与路由跟随
- [ ] 教程气泡弹出时点击首页"新建引力源"按钮，验证正常跳转 `#/goal/new` 不被拦截
- [ ] 教程气泡弹出时点击"引力场"入口，验证正常跳转 `#/camps`
- [ ] 教程气泡弹出时点击右下角顾问 FAB，验证顾问面板正常打开
- [ ] 教程气泡存在时尝试滚动页面，验证滚动正常生效不被阻断
- [ ] `tutorialStep=1` 时从 `#/` 跳到 `#/camps`，验证第二步气泡移除（第二步仅在首页展示），返回 `#/` 后气泡重新出现
- [ ] 教程进行中依次切换 `#/` / `#/camps` / `#/settings` / `#/profile` / `#/goal/new`，验证各页面均正常渲染无白屏，教程气泡按当前步 `targetHash` 匹配情况展示/移除
- [ ] 全局搜索教程源码，验证不存在 `e.preventDefault` / `e.stopPropagation` 作用于原有元素、不存在对原有按钮的 `addEventListener` 拦截、不存在替换原有 `onclick`、不存在叠加蒙层
- **验收标准**：教程气泡存在期间，原有所有按钮/链接/卡片/滚动均完全正常响应，教程零拦截；路由切换时新页面完整渲染且气泡按 targetHash 匹配正确展示/移除

### 4.5 验证旧版兼容与异常兜底
- [ ] 手动 `localStorage.setItem('tutorialStep','4')` 后启动应用，验证教程视为完成态不弹出气泡（旧版 4 >= 新 TOTAL 3）
- [ ] 手动 `localStorage.setItem('tutorialStep','7')` 后启动应用，验证教程视为完成态不弹出气泡
- [ ] 手动 `localStorage.setItem('tutorialStep','1')` 后启动应用进入首页，验证自动弹出第二步气泡（旧版 1 对应新教程同序号继续引导）
- [ ] 手动 `localStorage.setItem('tutorialStep','2')` 后启动应用进入首页，验证自动弹出第三步气泡
- [ ] 篡改 `tutorialStep` 为 `"abc"` / `-1` / `NaN` 后启动应用，验证教程回退为从第一步开始，应用正常不白屏
- [ ] 模拟 localStorage 禁用（如浏览器隐私模式），验证教程捕获异常降级为仅本次会话引导，应用不白屏
- [ ] 模拟 MutationObserver 不可用环境，验证教程降级依赖 hashchange + 业务键轮询通道继续工作不白屏
- [ ] 验证教程结束后无残留 hashchange 监听、无残留 setInterval、无残留 MutationObserver（感知通道全部清理）
- **验收标准**：旧版 7 步历史值 4~7 升级后视为完成不再弹出，1~2 对应新教程同序号继续引导，0 视为未开始；所有异常场景下应用均不白屏，教程静默退出或降级，教程结束后无监听泄漏

### 4.6 验证数据隔离与清空联动
- [ ] 先走完教程使 `tutorialStep===3`，再在设置页点击"清空所有数据"，验证清空后 `tutorialStep` 也被清理（`localStorage.getItem('tutorialStep')` 为 `null`），刷新后教程重新自动开始
- [ ] 走到教程某步使 `tutorialStep` 为非 0 非 3 的值，在设置页点击"导出数据"，验证导出的 JSON 文件中**不含** `tutorialStep` 字段
- [ ] 将导出的 JSON 重新"导入数据"，验证导入后业务数据恢复，但 `tutorialStep` 不受导入影响
- [ ] 在设置页点击"重新观看教程"，验证 `tutorialStep` 重置为 0，教程从第一步重新弹出
- **验收标准**：教程进度独立于业务键，清空数据后一并重置，不被备份导出，不被导入覆盖；重新观看功能正常

---

## 5. 审查与最终确认

> 本组为交付前最终把关，确保设计与实现一致、变更范围可控。

### 5.1 代码审查
- [ ] 审查 `src/styles/main.css` 气泡样式段配色改动是否符合 camelCase 无关（CSS 用 kebab-case）、原生 CSS 无第三方依赖、无硬编码主题专用颜色（配色改为固定半透明黑 + 浅色反而消除对主题变量的依赖）
- [ ] 审查 `main.css` 改动仅限配色属性（background / color / border-bottom-color / border-top-color），不涉及结构、布局、动效、定位属性
- [ ] 审查复用的 8 个文件（`onboardingTutorial.js` / `tutorialSteps.js` / `tutorialStorage.js` / `termMapping.js` / `main.js` / `settingsView.js` / `backupService.js` / `constants.js`）均未被改动（git diff 为空）
- [ ] 审查全教程源码无 `e.preventDefault` / `e.stopPropagation` 作用于原有元素、无对原有按钮 `addEventListener` 拦截、无替换 `onclick`、无叠加蒙层、无 `innerHTML` 拼接外部数据、无第三方库 import
- [ ] 审查三通道全部只读：hashchange 追加监听不替换既有、`_onStoragePoll` 仅 `localStorage.getItem` 无 `setItem` 写业务键、`_onMutation` 仅接收记录不修改 DOM
- **验收标准**：代码审查清单全部通过，无违反保命约束的代码

### 5.2 设计一致性核对
- [ ] 核对气泡配色与 design.md 2.1.2 节配置项取值策略完全一致：背景 `rgba(0,0,0,0.7)`、标题 `#fff`、通俗文案 `rgba(255,255,255,0.85)`、术语对照块背景 `rgba(255,255,255,0.12)` + 文字 `rgba(255,255,255,0.75)` + 标签 `#fff`、进度 `rgba(255,255,255,0.6)`、secondary 按钮 `rgba(255,255,255,0.15)` + 白字（hover `rgba(255,255,255,0.25)`）、primary 按钮保留 `var(--color-primary)` + 白字、箭头 `rgba(0,0,0,0.7)`
- [ ] 核对配色改造范围与 design.md 1.2.4 节扩展点一致：仅改 `.tutorial-bubble` / `.tutorial-bubble-title` / `.tutorial-bubble-plain` / `.tutorial-bubble-term` / `.tutorial-bubble-term-label` / `.tutorial-bubble-progress` / `.tutorial-bubble-btn-secondary` / `.tutorial-bubble-btn-secondary:hover` / `.tutorial-bubble-arrow-up` / `.tutorial-bubble-arrow-down` 的配色属性
- [ ] 核对教程 3 步序列、sensing 配置、术语对照表、气泡定位策略、挂载点、旧版兼容策略均与 design.md 一致（均复用既有实现无需改动）
- **验收标准**：实现与 design.md 设计方案完全一致，无偏离

### 5.3 变更范围最终确认
- [ ] 确认变更文件清单为：改造 1 文件（`src/styles/main.css` 气泡样式段约 2181-2293 行的配色属性），无其他文件被改动
- [ ] 确认 `onboardingTutorial.js` / `tutorialSteps.js` / `tutorialStorage.js` / `termMapping.js` / `main.js` / `settingsView.js` / `backupService.js` / `constants.js` / `index.html` 均未被改动
- [ ] 确认 `index.html` 未被改动（未新增 `<script>` 入口破坏既有加载顺序）
- [ ] 确认既有所有视图（homeView / goalDetailView / campListView / advisorView 等）未被改动
- [ ] 确认对外接口 `start()` / `restart()` / `destroy()` 签名不变，现有调用方零改动
- [ ] 确认 `main.css` 非教程样式段零改动，既有页面样式无回归
- **验收标准**：变更范围严格限定在 `main.css` 气泡样式段的配色属性内，无意外扩散，既有功能零回归
