# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 教程进度独立存储于 `tutorialStep` 键，数字类型，默认 0，非法值兜底 + 旧版 7 步历史值兼容 | `tutorialStorage` 已实现 read/write/reset/complete/remove，含合法性校验、异常兜底与旧版兼容（>=TOTAL 视为完成） | `src/storage/tutorialStorage.js` | 100% |
| 引力系术语 → 通俗说法对照表集中定义 | `termMapping` 已定义 5 个术语对照（引力源/引力场/引力小助手/逃逸速度/打卡） | `src/views/termMapping.js:1-35` | 100% |
| 教程步骤配置以常量集中定义（3 步 + sensing 字段） | `tutorialSteps.ALL` 已定义 3 步有序配置数组含 sensing 字段，`TOTAL` 为总步数 | `src/views/tutorialSteps.js` | 100% |
| 教程核心控制器：启动/跳过/完成/重新观看/销毁/气泡构建/定位/更新/移除 + 三通道感知启停 + 推进判定 | `onboardingTutorial` 已实现 start/restart/destroy/_skip/_complete/_tryAdvance/_startSensing/_stopSensing/_onHashChange/_onStoragePoll/_onMutation/_updateBubbleForRoute/_renderBubble/_positionBubble/_updateBubble/_removeBubble | `src/views/onboardingTutorial.js:1-364` | 100% |
| 教程以追加 `hashchange` 监听方式感知路由，不替换既有 | `_startSensing` 中 `window.addEventListener('hashchange', this._hashHandler)` 追加监听 | `src/views/onboardingTutorial.js:82-85` | 100% |
| 气泡用 `createElement` + `textContent` 安全构建，防 XSS | `_renderBubble` 全程 `createElement` + `textContent` | `src/views/onboardingTutorial.js:220-273` | 100% |
| 气泡定位避让策略（下方→上方→视口底部兜底） | `_positionBubble` 已实现三段避让 | `src/views/onboardingTutorial.js:175-237` | 100% |
| 气泡为绝对/固定定位的小尺寸局部卡片，禁止全屏遮罩 | `.tutorial-bubble` 为 `position: fixed` + `max-width: 340px` + `width: calc(100vw - 32px)`，无全屏蒙层 | `src/styles/main.css:2181-2186` | 100% |
| 气泡挂 document.body 非 #app，路由切换不被销毁 | `_updateBubble` 中 `document.body.appendChild(bubble)` | `src/views/onboardingTutorial.js:346` | 100% |
| 刷新后气泡显示与位置完全由 tutorialStep 决定（断点续传） | `start()` 读取 tutorialStep 决定弹出第几步，`_positionBubble` 据此定位 | `src/views/onboardingTutorial.js:14-30` | 100% |
| 推进时切换为下一步气泡并定位到下一步目标位置（局部更新非全屏覆盖） | `_tryAdvance` 匹配后 `_currentStep++` → `_updateBubble` 重建气泡 + `_positionBubble` 重新定位 | `src/views/onboardingTutorial.js:179-195` | 100% |
| Minimalist Modern 气泡结构与动效（圆角/留白/入场动效/箭头/避让） | `main.css` 已定义 `.tutorial-bubble*` 结构样式段 + `tutorialBubbleIn` 入场动效 | `src/styles/main.css:2180-2304` | 100% |
| 教程启动挂载在 `init()` 末尾，独立 try-catch | `main.js` 的 `init()` 末尾 `try { onboardingTutorial.start(); } catch (e) {}` | `src/main.js:77` | 100% |
| 设置页"重新观看教程"入口 | `settingsView._renderTutorialCard()` 已实现，点击调用 `onboardingTutorial.restart()` | `src/views/settingsView.js:157-180` | 100% |
| 清空数据时一并清理 `tutorialStep` | `backupService.clearAllData()` 中 `localStorage.removeItem('tutorialStep')` | `src/services/backupService.js:92` | 100% |
| `tutorialStep` 不纳入 `APP_DATA_KEYS`，独立于业务键 | `constants.js` 的 `APP_DATA_KEYS` 仅含三个业务键，未含 `tutorialStep` | `src/constants.js:7-11` | 100% |
| 既有 `hashchange` 监听 + `router()` 路由机制 | `main.js` 中 `window.addEventListener('hashchange', router)` | `src/main.js:76` | 100% |

### 1.1.2 需要扩展的功能

> **现状注脚**：经核查现有代码，下表前 6 行描述的改造（7 步→3 步、推进方式、三通道感知、路由跟随、旧版兼容、sensing 字段）**均已实现完成**，保留以记录方案演进；本次基于新 spec 的**唯一待改项为最后一行"气泡配色"**（半透明白色→半透明黑色 + 浅色文字）。

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 教程总步数从 7 步缩减为 3 步 | `tutorialSteps.ALL` 当前为 7 步配置，`TOTAL=7` | 新 spec 5.4 明确为 3 步（建立引力源 / 打卡 / 引力小助手或引力场），每步引导用户完成一个实际操作；旧 7 步含欢迎/引力源/引力场/引力小助手/逃逸速度/打卡/完成，含纯讲解步无实际操作 | 重写 `tutorialSteps.ALL` 为 3 步配置，每步新增 `sensing` 字段（感知方式 + 感知条件），移除 `buttons.showPrev/showNext`（仅保留 `showSkip`）；`TOTAL` 自动变为 3 |
| 教程推进方式从"自带下一步按钮"改为"感知用户实际操作后自动推进" | `onboardingTutorial._next()` 由教程"下一步"按钮触发推进；`_renderBubble` 渲染上一步/下一步/跳过三按钮 | 新 spec 1.4 规则 3 明确禁止教程自带"下一步"按钮推进，推进完全靠感知用户对原有按钮的实际操作；气泡仅保留"跳过" | 移除 `_next()` / `_prev()` 方法；`_renderBubble` 移除上一步/下一步按钮渲染，仅保留跳过；新增 `_tryAdvance(signalType, signalData)` 方法根据感知信号判定是否完成当前步并推进 |
| 操作感知三通道：hashchange / localStorage 业务键只读轮询 / MutationObserver | 仅 hashchange 一通道，且 `_onHashChange` 仅更新气泡位置，不判定推进 | 新 spec 5.3 要求三通道全部只读感知用户操作自动推进；hashchange 感知路由变化（如 #/goal/new）、业务键轮询感知打卡、MutationObserver 感知面板打开/进度条增长 | 新增 `_startSensing()` / `_stopSensing()` 统一启停三通道；扩展 `_onHashChange` 增加推进判定；新增 `_onStoragePoll()` 业务键轮询 + `_onMutation()` DOM 变化感知；新增 `_storagePollTimer` / `_mutationObserver` / `_storageSnapshot` 引用 |
| 气泡跟随路由切换更新指向与展示判定 | `_onHashChange` 仅调用 `_positionBubble` 重新定位，不判定当前步是否应在当前页展示 | 新 spec 5.6 要求路由切换后根据新 hash + tutorialStep 判定是否展示/移除气泡（如第二步仅在首页展示，跳到非首页则移除气泡待回首页再展示） | 扩展 `_onHashChange`：先判定当前步的 `targetHash` 是否匹配新 hash，匹配则更新气泡定位，不匹配则移除气泡待用户回到正确页面 |
| 旧版 7 步教程历史 `tutorialStep` 值兼容 | `tutorialStorage._isValid` 判定 `value >= 0 && value <= TOTAL`，历史值 4~7 被判非法回退 0，会导致老用户被重新引导 | 新 spec 4.5 规则 7 要求历史值 >= 新 TOTAL（3）视为已完成不再弹出；1~2 对应新步骤继续 | 调整 `read()` 兜底逻辑：历史值 >= TOTAL 返回 TOTAL（完成态），0~TOTAL-1 正常返回，负数/NaN/非数字回退 0；`_isValid` 拆分为写入校验（严格 0~TOTAL）与读取兼容（>=TOTAL 视为完成） |
| 教程步骤配置新增"推进感知方式 + 感知条件"字段 | `tutorialSteps.ALL` 每步仅有 `id/title/plainText/termRef/targetHash/targetSelector/targetHint/buttons/fallback`，无感知配置 | 新 spec 6.3 要求每步配置 `sensing`（感知方式：hashchange/storagePoll/mutationObserver）+ `sensingCondition`（判定条件：如 hash 等于 #/goal/new、业务键变化、DOM 节点出现）+ `pollInterval`（轮询间隔，>=1000ms）+ `observeSelector`（MutationObserver 观察节点选择器） | 在 `tutorialSteps.ALL` 每步新增 `sensing` 配置对象；`onboardingTutorial` 消费该配置启停对应通道 |
| 气泡背景色从半透明白色改为半透明黑色，文字/箭头改为浅色高对比 | `main.css` 现有 `.tutorial-bubble` 背景为 `rgba(255,255,255,0.96)`（半透明白底），文字色依赖 `var(--color-text)` 等主题变量（深色），箭头为 `rgba(255,255,255,0.96)` | 新 spec 5.2.1 规则 8 明确要求气泡背景为半透明黑色（`rgba(0,0,0,0.7)` 量级，深色蒙层质感），标题/通俗文案/术语对照/进度/按钮文字为浅色（白色或浅灰）保证高对比可读，指向箭头颜色与气泡背景一致（半透明黑色），三套主题下均清晰可读 | 改造 `main.css` 气泡样式段配色：`.tutorial-bubble` 背景改 `rgba(0,0,0,0.7)` + `color: #fff`；标题/文案/术语/进度/按钮文字改浅色（`#fff` / `rgba(255,255,255,0.85)` / `rgba(255,255,255,0.75)` / `rgba(255,255,255,0.6)`）；术语对照块背景改 `rgba(255,255,255,0.12)`（半透明白叠黑底成深灰）；secondary 按钮背景改 `rgba(255,255,255,0.15)` + 白字；箭头 `border-color` 改 `rgba(0,0,0,0.7)`；primary 按钮保留 `var(--color-primary)` 品牌主色 + 白字 |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**模块 A：操作感知管理（onboardingTutorial 内部扩展）**
- 功能点：统一启停三通道（hashchange / 业务键轮询 / MutationObserver）、根据当前步配置选择性启用对应通道、感知信号触发推进判定
- 输入：当前步骤配置（`sensing` 字段）
- 输出：感知到匹配操作时调用 `_tryAdvance` 推进教程
- 核心逻辑：`_startSensing(stepConfig)` 根据 `sensing` 字段决定启用哪些通道；hashchange 通道复用既有 `_hashHandler` 但扩展判定逻辑；业务键轮询通道用 `setInterval` 每 `pollInterval`（>=1000ms）调用 `localStorage.getItem` 只读比对快照；MutationObserver 通道用 `MutationObserver` 观察具体节点（非 document.body）；任一通道初始化失败捕获降级依赖其余通道
- 依赖关系：依赖浏览器 `window.addEventListener` / `setInterval` / `MutationObserver` / `localStorage.getItem`；与既有 `router` 的 hashchange 监听并存

**模块 B：推进判定（onboardingTutorial 内部扩展）**
- 功能点：根据感知信号与当前步骤的 `sensingCondition` 判定是否完成当前步，匹配则 `tutorialStep++` 并切换/移除气泡
- 输入：感知信号类型（hash/storage/mutation）+ 信号数据（新 hash / 业务键新值 / DOM 变化记录）
- 输出：匹配则推进教程，不匹配则忽略
- 核心逻辑：`_tryAdvance(signalType, signalData)` 读取当前步 `sensingCondition`，按信号类型分支判定（hash 通道比对 `signalData === sensingCondition.hash`；storage 通道比对业务键快照变化 + 可选的打卡特征校验；mutation 通道比对观察节点是否出现/进度条数值是否增长）；判定匹配且当前步未完成则 `_currentStep++` → `tutorialStorage.write` → 切换/移除气泡；不匹配则忽略；异常捕获静默退出
- 依赖关系：依赖 `tutorialStorage` / `tutorialSteps`；与具体业务视图解耦

## 1.2 存量功能详细分析

### 1.2.1 教程进度存储（`src/storage/tutorialStorage.js:1-61`）

- **接口契约**：`read()` 无入参返回数字；`write(step)` 入参数字返回布尔；`reset()` / `complete()` / `remove()` 无入参返回布尔。`STORAGE_KEY` 为模块级常量 `'tutorialStep'`。
- **业务规则**：`_isValid(value)` 判定 `typeof === 'number' && Number.isFinite && Number.isInteger && 0 <= value <= tutorialSteps.TOTAL`；`read` 对 null/NaN/非数字/负数/超大值兜底返回 0；`write` 对非法入参拒绝写入返回 false；`setItem` 抛错（配额超限/隐私模式）捕获返回 false。
- **扩展点**：`read` 的兜底逻辑需扩展兼容旧版 7 步教程历史值——当前 `_isValid` 将 `value > TOTAL` 判为非法回退 0，会导致旧用户（tutorialStep 曾为 4~7）被重新引导；需调整为 `value >= TOTAL` 视为完成态返回 TOTAL，仅负数/NaN/非数字回退 0。
- **约束**：`STORAGE_KEY` 独立于 `STORAGE_KEYS`，不经过 `localStorageAdapter`；`_isValid` 用于 `write` 的严格校验（仅允许 0~TOTAL），`read` 需单独的兼容逻辑（允许 >=TOTAL 视为完成）。

### 1.2.2 教程步骤配置（`src/views/tutorialSteps.js:1-85`）

- **接口契约**：`ALL` 为有序步骤对象数组，`TOTAL = ALL.length`。每步含 `id/title/plainText/termRef/targetHash/targetSelector/targetHint/buttons/fallback`。
- **业务规则**：步骤一经发布序号稳定；`buttons` 含 `showPrev/showNext/showSkip/nextLabel` 控制按钮渲染。
- **扩展点**：需重写为 3 步配置，每步新增 `sensing` 字段（感知方式 + 感知条件 + 轮询间隔 + 观察节点选择器）；移除 `buttons.showPrev/showNext`（仅保留 `showSkip`）；`termRef` 可选保留用于术语对照展示。
- **约束**：步骤序号 0/1/2 对应 tutorialStep 0/1/2；`TOTAL` 自动为 3；文案须为系统预设固定文本（防注入）。

### 1.2.3 教程核心控制器（`src/views/onboardingTutorial.js:1-264`）

- **接口契约**：`start()` / `restart()` / `destroy()` 对外；`_next()` / `_prev()` / `_skip()` / `_complete()` / `_onHashChange()` / `_renderBubble()` / `_positionBubble()` / `_updateBubble()` / `_removeBubble()` 内部。模块级单例导出，持有 `_mounted` / `_currentStep` / `_bubbleEl` / `_hashHandler`。
- **业务规则**：`start` 读取 tutorialStep，完成态直接返回，否则构建气泡 + 追加 hashchange 监听；`_next`/`_prev` 由教程按钮触发推进；`_onHashChange` 仅重新定位气泡；`_renderBubble` 用 createElement + textContent 构建标题/通俗文案/术语对照/指向提示/进度/按钮；`_positionBubble` 三段避让定位；所有方法包裹 try-catch 静默退出。
- **扩展点**：
  - 移除 `_next()` / `_prev()` 及对应按钮渲染（教程不再自带推进按钮）
  - 扩展 `_onHashChange`：先判定当前步 `targetHash` 是否匹配新 hash（匹配则更新定位，不匹配则移除气泡），再调用 `_tryAdvance('hash', newHash)` 判定推进
  - 新增 `_startSensing(stepConfig)` / `_stopSensing()` 统一启停三通道
  - 新增 `_onStoragePoll()` 业务键只读轮询 + 快照比对
  - 新增 `_onMutation(records)` DOM 变化感知
  - 新增 `_tryAdvance(signalType, signalData)` 推进判定
  - 新增 `_storagePollTimer` / `_mutationObserver` / `_storageSnapshot` 引用
  - `destroy` 扩展：统一清理三通道（removeEventListener hashchange / clearInterval / observer.disconnect）
- **约束**：三通道全部只读，禁止对原有按钮 addEventListener / 替换 onclick / 叠加蒙层；任一通道失败捕获降级；异常全捕获静默退出不白屏。

### 1.2.4 教程气泡样式（`src/styles/main.css:2180-2304`）

- **接口契约**：`.tutorial-bubble` 为 fixed 定位 + z-index 1500 + 半透明背景 + 强阴影 + 圆角 + 入场动效；`.tutorial-bubble-title/plain/term/progress/actions/btn/arrow` 等子元素样式；含 480px 响应式断点。
- **业务规则**：复用既有 `--radius-lg` / `--shadow-lg` / `--ease-out` 令牌；当前背景为半透明白色 `rgba(255,255,255,0.96)`，文字色依赖 `var(--color-text)` / `var(--color-text-light)` / `var(--color-text-muted)` 主题变量（深色），箭头为 `rgba(255,255,255,0.96)`；三套主题下深色文字在白底上高对比可读。
- **扩展点**：
  - **配色改造（新 spec 5.2.1 规则 8）**：气泡背景从半透明白色改为半透明黑色 `rgba(0,0,0,0.7)`（深色蒙层质感）；标题/通俗文案/术语对照/术语标签/进度/按钮文字全部改为浅色（`#fff` / `rgba(255,255,255,0.85)` / `rgba(255,255,255,0.75)` / `rgba(255,255,255,0.6)`），脱离主题色变量改为固定浅色，保证在半透明黑色背景上高对比可读且三套主题统一呈现；术语对照块背景从 `var(--color-bg)` 改为 `rgba(255,255,255,0.12)`（半透明白叠在黑底上形成深灰区分层）；secondary 按钮背景从 `var(--color-bg)` 改为 `rgba(255,255,255,0.15)` + 白字，hover 改 `rgba(255,255,255,0.25)`；指向箭头 `border-bottom-color` / `border-top-color` 从 `rgba(255,255,255,0.96)` 改为 `rgba(0,0,0,0.7)`（与气泡背景一致）；primary 按钮保留 `var(--color-primary)` 品牌主色 + `#fff` 白字（品牌主色在黑底上仍醒目，与品牌呼应）。
  - 移除"上一步/下一步"按钮后，`.tutorial-bubble-actions` 仅含"跳过"按钮，布局自动适应（flex:1 单按钮占满）；`.tutorial-bubble-btn-primary` 样式保留以备后用但不渲染；其余结构与动效样式完全复用。
- **约束**：不改动既有非教程样式段；不硬编码主题专属颜色（配色改为固定半透明黑 + 浅色，反而消除对主题变量的依赖，三套主题统一可读）；保持 `position: fixed` + `max-width: 340px` 局部小尺寸定位，禁止全屏遮罩。

### 1.2.5 既有挂载点（`src/main.js:77`、`src/views/settingsView.js:157-180`、`src/services/backupService.js:92`）

- **接口契约**：`main.js` 的 `init()` 末尾 `try { onboardingTutorial.start(); } catch (e) {}`；`settingsView._renderTutorialCard()` 渲染"重新观看教程"卡片点击调用 `restart()`；`backupService.clearAllData()` 中 `localStorage.removeItem('tutorialStep')`。
- **业务规则**：教程启动挂载在既有 init 流程之后，独立 try-catch；重新观看入口在设置页第四张卡片；清空数据时一并清理教程进度。
- **扩展点**：**无需改动**——这三个挂载点对新 3 步教程方案完全适用，`start()` / `restart()` / `clearAllData` 行为不变。
- **约束**：不得修改 `init()` 既有调用顺序与内容；不得改动 `settingsView` 既有三张卡片；不得将 `tutorialStep` 纳入 `APP_DATA_KEYS`。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用使用者" as User

rectangle "既有应用（不改动逻辑）" as App {
  rectangle "main.js init()/router()" as Main
  rectangle "hashchange 既有监听" as RouterListener
  storage "localStorage 业务键\ndream_saving_camp_data 等" as BizStorage
  rectangle "homeView 渲染\n(.home-create-btn / .home-hero-camp / 进度条)" as Home
  rectangle "advisorView\n(.advisor-fab / 面板)" as Advisor
}

rectangle "新手教程组件（基于现有改造）" as Tutorial {
  rectangle "onboardingTutorial\n(start/restart/destroy/\n_tryAdvance/_startSensing/_stopSensing/\n_onHashChange/_onStoragePoll/_onMutation)" as Core
  rectangle "tutorialStorage\n(读写 tutorialStep + 旧版兼容)" as TStorage
  rectangle "tutorialSteps\n(3 步配置常量 + sensing 字段)" as Steps
  rectangle "termMapping\n(术语对照常量, 复用)" as Terms
}

storage "localStorage\ntutorialStep 键" as TutorialStorage
rectangle "settingsView\n(重新观看卡片, 复用)" as Settings

User --> Main : 打开应用 / 点击原有按钮
Main --> Core : init() 末尾调用 start()（既有挂载点, 不改）
Core --> TStorage : 读取/写入 tutorialStep
TStorage --> TutorialStorage : getItem/setItem/removeItem
Core --> Steps : 读取当前步配置（含 sensing）
Core --> Terms : 读取术语对照（复用）
Core --> RouterListener : 追加 hashchange 监听（只读, 不替换）
RouterListener --> Core : 路由变化通知（感知通道 1）
BizStorage --> Core : 只读轮询业务键变化（感知通道 2, setInterval >=1s）
Home --> Core : MutationObserver 感知进度条/按钮 DOM（感知通道 3）
Advisor --> Core : MutationObserver 感知面板出现（感知通道 3）
Core --> User : document.body 叠加浮动气泡（仅跳过按钮）
User --> Settings : 点击"重新观看教程"（既有, 不改）
Settings --> Core : 调用 restart()
Core --> TutorialStorage : 写入 tutorialStep = 0
@enduml
```

**说明**：本方案基于现有 3 步教程代码进行最小化改造，不新增文件、不改动既有挂载点（main.js / settingsView.js / backupService.js 均无需修改）。经核查现有代码：`onboardingTutorial.js` 已完整实现 3 步教程 + 三通道感知（hashchange/storagePoll/mutationObserver）+ 自动推进（`_tryAdvance`）+ 路由切换判定（`_updateBubbleForRoute`）+ 气泡定位避让（`_positionBubble`）+ 刷新恢复 + 局部小尺寸定位 + 跳过按钮 + textContent 防注入 + 挂 document.body + 追加 hashchange 监听 + 独立 try-catch，**功能层面已完全符合新 spec**；`tutorialSteps.js` 已为 3 步配置含 sensing 字段；`tutorialStorage.js` 已实现旧版兼容。**本次基于新 spec 的实际代码改动集中在 `main.css` 气泡样式段（2180-2304）的配色调整**：背景半透明白色→半透明黑色 `rgba(0,0,0,0.7)`、文字深色→浅色（`#fff` / `rgba(255,255,255,0.85)` 等）、箭头配色同步、术语对照块与 secondary 按钮背景适配深底；`onboardingTutorial.js` 无需改动。教程通过三个只读感知通道被动感知用户对原有按钮的实际操作自动推进，气泡仅保留"跳过"按钮，绝不拦截原有事件。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
package "新手教程组件（基于现有改造）" {
  component "onboardingTutorial" as Core #LightGreen
  component "tutorialStorage" as TStorage #LightBlue
  component "tutorialSteps (常量, 重写为 3 步)" as Steps #LightYellow
  component "termMapping (常量, 复用)" as Terms #LightYellow
  component "tutorialStyles (CSS, 配色改造)" as Styles #LightYellow
}

package "操作感知三通道（新增）" as Sensing #LightCoral {
  component "hashchange 通道\n(扩展 _onHashChange)" as Ch1
  component "业务键轮询通道\n(_onStoragePoll + setInterval)" as Ch2
  component "MutationObserver 通道\n(_onMutation + observe)" as Ch3
}

package "既有应用（无需改动）" {
  component "main.js init()" as Main
  component "settingsView" as Settings
  component "backupService.clearAllData" as Backup
  component "hashchange 既有监听" as Router
  component "homeView / advisorView" as Views
}

package "浏览器 localStorage" {
  storage "tutorialStep" as TSKey
  storage "业务键 (只读感知)" as BizKeys
}

Core --> TStorage : 读写进度
Core --> Steps : 读取步配置（含 sensing）
Core --> Terms : 读取术语对照
Core --> Styles : 应用气泡样式（类名）
Core --> Sensing : 启停感知通道

Ch1 --> Router : 追加 hashchange 监听（只读）
Ch2 --> BizKeys : setInterval getItem 只读比对
Ch3 --> Views : MutationObserver observe 具体节点

TStorage --> TSKey : getItem/setItem/removeItem

Main --> Core : init() 末尾 start()（既有, 不改）
Settings --> Core : restart()（既有, 不改）
Backup --> TSKey : removeItem('tutorialStep')（既有, 不改）
@enduml
```

**模块划分与职责**：

| 模块 | 职责 | 文件位置 | 改动类型 |
|------|------|---------|---------|
| `onboardingTutorial` | 教程核心控制器：启动/跳过/完成/重新观看/销毁/气泡构建/定位/更新/移除 + 三通道感知启停 + 推进判定 | `src/views/onboardingTutorial.js` | 已实现（3 步 + 三通道感知 + 自动推进 + 路由判定 + 定位避让 + 刷新恢复，符合新 spec 功能要求，无需改动） |
| `tutorialStorage` | 教程进度读写适配器：读写 `tutorialStep` + 旧版 7 步历史值兼容 | `src/storage/tutorialStorage.js` | 已实现（read 兼容旧版历史值，符合新 spec，无需改动） |
| `tutorialSteps` | 教程步骤配置常量：3 步配置 + 每步 sensing 字段 | `src/views/tutorialSteps.js` | 已实现（3 步 + sensing 配置，符合新 spec，无需改动） |
| `termMapping` | 术语对照常量（引力系术语 → 通俗说法） | `src/views/termMapping.js` | 复用（无改动） |
| 教程样式 | 气泡/箭头/进度/按钮/动效样式 | `src/styles/main.css`（2180-2304 段） | 改造（背景半透明白→半透明黑、文字深色→浅色、箭头配色同步、术语块/secondary 按钮背景适配深底；结构与动效复用） |
| `main.js` | `init()` 末尾教程启动调用 | `src/main.js:77` | 复用（无改动） |
| `settingsView.js` | "重新观看教程"卡片 | `src/views/settingsView.js:157-180` | 复用（无改动） |
| `backupService.js` | `clearAllData` 清理 `tutorialStep` | `src/services/backupService.js:92` | 复用（无改动） |

**配置项及取值策略**：
- `tutorialStep` 键名：固定 `'tutorialStep'`，独立于 `STORAGE_KEYS`
- 教程总步数：`tutorialSteps.TOTAL = 3`（由重写后的数组长度决定）
- 完成态：`tutorialStep === 3`
- 业务键轮询间隔：`1500ms`（>= 1000ms 满足 spec 4.1 性能规则 5）
- MutationObserver 观察范围：具体节点（`.home-stats` 进度条容器 / `.advisor-root` 面板根节点），`subtree: true` 但 target 非 document.body
- 气泡避让策略：复用既有"下方优先 → 上方次之 → 视口底部兜底"三段策略
- 气泡配色（新 spec 5.2.1 规则 8）：背景 `rgba(0,0,0,0.7)`（半透明黑色，深色蒙层质感）；标题 `#fff`；通俗文案 `rgba(255,255,255,0.85)`；术语对照块背景 `rgba(255,255,255,0.12)` + 文字 `rgba(255,255,255,0.75)` + 标签 `#fff`；进度 `rgba(255,255,255,0.6)`；secondary 按钮 `rgba(255,255,255,0.15)` + 白字（hover `rgba(255,255,255,0.25)`）；primary 按钮保留 `var(--color-primary)` + 白字；箭头 `rgba(0,0,0,0.7)`（与背景一致）。配色固定不依赖主题变量，三套主题统一呈现。

### 2.1.3 实现设计文档

#### 教程状态机（3 步 + 自动推进）

```plantuml
@startuml
title 教程引导进度状态机（3 步自动推进）

[*] --> 未启动 : 应用启动 / tutorialStep 不存在或为 0

未启动 --> 引导中第一步 : 首页渲染就绪 & start() 调用 & 在首页 #/
未启动 --> 已完成 : tutorialStep >= 3（含旧版 4~7 历史值, 视为完成）

引导中第一步 --> 引导中第二步 : 感知 hashchange 到 #/goal/new（用户点击建立引力源）
引导中第二步 --> 引导中第三步 : 感知业务键变化或进度条 DOM 增长（用户打卡成功）
引导中第三步 --> 已完成 : 感知面板 DOM 出现（引力小助手）或 hashchange 到 #/camps（引力场）

引导中第一步 --> 引导中第一步 : hashchange 到非 #/goal/new（移除气泡待回首页）
引导中第二步 --> 引导中第二步 : hashchange 到非首页（移除气泡待回首页）
引导中第一步 --> 已完成 : 点击"跳过"（tutorialStep 置 3）
引导中第二步 --> 已完成 : 点击"跳过"
引导中第三步 --> 已完成 : 点击"跳过"

已完成 --> 未启动 : 设置页点击"重新观看教程"（tutorialStep 置 0）
已完成 --> 已完成 : 应用启动 / 路由切换（不弹出）

note right of 引导中第一步
  气泡指向 .home-create-btn
  启用 hashchange 通道
  气泡仅含"跳过"按钮
end note

note right of 引导中第二步
  气泡指向打卡区域/进度条
  启用 storagePoll + mutationObserver 通道
  仅在首页 #/ 展示
end note

note right of 引导中第三步
  气泡指向 .advisor-fab / .home-hero-camp
  启用 hashchange + mutationObserver 通道
end note

note right of 已完成
  气泡与三通道监听已清理
  恢复纯净原有体验
end note
@enduml
```

#### 操作感知与自动推进时序

```plantuml
@startuml
title 操作感知与自动推进时序（三通道容错）

actor User
participant "原有按钮/业务" as Orig
participant "onboardingTutorial" as T
participant "hashchange 通道" as Ch1
participant "业务键轮询通道" as Ch2
participant "MutationObserver 通道" as Ch3
database "localStorage" as S

User -> T : start() 调用
T -> T : _startSensing(stepConfig)
T -> Ch1 : addEventListener('hashchange')（若该步需 hashchange）
T -> Ch2 : setInterval(getItem, 1500ms)（若该步需 storagePoll）
T -> Ch3 : observer.observe(targetNode)（若该步需 mutationObserver）

User -> Orig : 点击原有按钮 / 执行业务操作
Orig -> Orig : 原有事件正常执行（教程不拦截）

alt 通道 1：路由变化
  Orig -> Ch1 : hash 变为 #/goal/new 或 #/camps
  Ch1 -> T : _onHashChange(newHash)
  T -> T : _tryAdvance('hash', newHash)
else 通道 2：业务键变化
  Orig -> S : 写入 dream_saving_camp_data
  Ch2 -> S : getItem 只读比对快照
  Ch2 -> T : _onStoragePoll(新值)
  T -> T : _tryAdvance('storage', 新值)
else 通道 3：DOM 变化
  Orig -> Orig : 进度条增长 / 面板出现
  Ch3 -> T : _onMutation(records)
  T -> T : _tryAdvance('mutation', records)
end

alt 感知信号匹配当前步 sensingCondition
  T -> T : _currentStep++ 并 tutorialStorage.write
  T -> T : _stopSensing() 清理当前步通道
  alt 未达总步数
    T -> T : _startSensing(下一步配置) 启用下一步通道
    T --> User : 切换/移除气泡
  else 达到总步数
    T -> T : _complete() 教程结束
    T --> User : 移除气泡, 恢复纯净体验
  end
else 不匹配
  T -> T : 忽略, 保持当前步等待正确操作
end

note right of T
  任一通道初始化失败：
  捕获异常降级依赖其余通道
  不白屏不崩溃
end note
@enduml
```

#### 气泡跟随路由切换判定流程

```plantuml
@startuml
title 路由切换时气泡展示判定

start
:感知到 hashchange (newHash);
:读取当前步 config.targetHash;
if (newHash === targetHash?) then (是, 应展示当前步气泡)
  if (气泡已存在?) then (是)
    :_positionBubble 重新定位到指向元素;
  else (否)
    :_renderBubble 构建气泡;
    :document.body.appendChild;
    :_positionBubble 定位;
  endif
else (否, 不应展示, 如第二步仅在首页)
  :_removeBubble 移除气泡;
  :等待用户回到正确页面;
endif
:_tryAdvance('hash', newHash) 判定推进;
stop
@enduml
```

**分支触发条件与处理策略**：
- **当前步 targetHash 匹配新 hash**：展示/更新气泡定位到指向元素，引导用户视线聚焦
- **当前步 targetHash 不匹配新 hash**（如第二步仅在首页，用户跳到 #/camps）：移除气泡，待用户回到正确页面再展示；不强行跳转
- **hash 信号匹配当前步 sensingCondition**（如第一步感知 hash 变为 #/goal/new）：推进教程
- **hash 信号不匹配**（如第二步等待打卡时用户跳到 #/camps）：忽略不推进，保持当前步

## 2.2 接口设计

### 2.2.1 总体设计

教程组件对外暴露的接口分两类：（1）**生命周期接口**（`start`/`restart`/`destroy`），由 `main.js` 与 `settingsView` 调用，**签名不变，现有调用方无需改动**；（2）**内部感知与推进接口**（`_tryAdvance`/`_startSensing`/`_stopSensing`/`_onHashChange`/`_onStoragePoll`/`_onMutation`/`_skip`/`_complete`），由教程内部感知通道与跳过按钮调用，不对外暴露。

| 接口 | 调用方 | 稳定性 | 说明 |
|------|--------|--------|------|
| `onboardingTutorial.start()` | `main.js` 的 `init()`（既有，不改） | 稳定 | 应用启动时被动调用，读取 tutorialStep 决定是否弹出及弹出第几步 |
| `onboardingTutorial.restart()` | `settingsView` 重新观看卡片（既有，不改） | 稳定 | 重置 tutorialStep 为 0 并从第一步重新弹出 |
| `onboardingTutorial.destroy()` | 内部（完成/跳过时） | 稳定 | 移除气泡与三通道监听，恢复纯净体验 |
| `tutorialStorage.read()` | `onboardingTutorial` | 稳定 | 读取 tutorialStep，含旧版 7 步历史值兼容（>=3 视为完成） |
| `tutorialStorage.write(step)` | `onboardingTutorial` | 稳定 | 写入合法步骤值（严格 0~3），异常返回 false |
| `onboardingTutorial._tryAdvance(signalType, signalData)` | 内部三通道 | 内部 | 根据感知信号与当前步 sensingCondition 判定是否推进 |
| `onboardingTutorial._startSensing(stepConfig)` | 内部 start/restart/推进后 | 内部 | 根据当前步 sensing 配置启用对应通道 |
| `onboardingTutorial._stopSensing()` | 内部 destroy/推进前/跳过 | 内部 | 统一清理三通道监听 |

**接口变更策略**：对外接口（start/restart/destroy）签名不变，现有调用方（main.js/settingsView.js）无需改动；内部接口随感知通道新增而扩展，不影响外部。

### 2.2.2 接口清单

#### onboardingTutorial.start()（复用既有，行为扩展）

```javascript
// 接口签名（不变）
onboardingTutorial.start()  // 无入参，无返回值
```

- **业务说明**：应用启动时由 `main.js` 的 `init()` 末尾调用（既有挂载点，不改）。读取 `tutorialStep`（含旧版兼容），若为完成态（>=3）直接返回不弹出；否则构建对应步骤气泡，调用 `_startSensing` 启用当前步感知通道。
- **前置条件**：首页路由已渲染完成；`document.body` 可用。
- **后置条件**：若 `tutorialStep < 3`，`document.body` 上存在 `.tutorial-bubble` 元素，三通道按当前步配置启用；若 `tutorialStep >= 3`，无任何 DOM 变化。
- **异常映射**：任何异常被内部 try-catch 捕获，静默退出，不影响既有页面。
- **调用示例**（`src/main.js:77`，既有不改）：
```javascript
try { onboardingTutorial.start(); } catch (e) {}
```

#### onboardingTutorial.restart()（复用既有，行为扩展）

```javascript
// 接口签名（不变）
onboardingTutorial.restart()  // 无入参，无返回值
```

- **业务说明**：用户在设置页点击"重新观看教程"时调用（既有挂载点，不改）。先 `destroy()` 清理旧气泡与监听，再 `tutorialStorage.reset()` 置 0，从第一步重新构建气泡并 `_startSensing`。
- **前置条件**：`document.body` 可用。
- **后置条件**：`tutorialStep` 为 0；`document.body` 上存在新气泡；第一步感知通道已启用。
- **异常映射**：重置或启动抛错则捕获，`modal.toast('教程启动失败，请重试')` 提示，不影响设置页。
- **调用示例**（`src/views/settingsView.js:170-177`，既有不改）：
```javascript
btn.addEventListener('click', () => {
  try {
    onboardingTutorial.restart();
    modal.toast('教程已重置');
  } catch (e) {
    modal.toast('教程启动失败，请重试');
  }
});
```

#### onboardingTutorial._tryAdvance(signalType, signalData)（新增）

```javascript
// 接口签名
onboardingTutorial._tryAdvance(signalType, signalData)
// signalType: 'hash' | 'storage' | 'mutation'
// signalData: string（新 hash）| string（业务键新值）| MutationRecord[]（DOM 变化）
// 无返回值
```

- **业务说明**：三通道感知到信号后调用。读取当前步 `sensingCondition`，按 signalType 分支判定是否匹配（hash 通道比对 `signalData === sensingCondition.hash`；storage 通道比对业务键快照变化 + 可选打卡特征校验；mutation 通道比对观察节点出现/进度条数值增长）。匹配且当前步未完成则 `_currentStep++` → `tutorialStorage.write` → `_stopSensing` → 切换/移除气泡 → 若未达总步数则 `_startSensing(下一步)`；不匹配则忽略。
- **前置条件**：教程已启动（`_mounted === true`）；当前步配置含 `sensing` 字段。
- **后置条件**：匹配则教程推进一步或完成；不匹配则状态不变。
- **异常映射**：判定或推进过程抛错则捕获，静默退出，不影响原有页面与按钮可点击性。
- **调用示例**（内部）：
```javascript
// hashchange 通道触发
_onHashChange() {
  const newHash = window.location.hash || '#/';
  // 先判定气泡展示/移除
  this._updateBubbleForRoute(newHash);
  // 再判定推进
  this._tryAdvance('hash', newHash);
}

// 业务键轮询通道触发
_onStoragePoll() {
  try {
    const newValue = localStorage.getItem('dream_saving_camp_data');
    if (newValue !== this._storageSnapshot) {
      this._storageSnapshot = newValue;
      this._tryAdvance('storage', newValue);
    }
  } catch (e) {}
}
```

#### onboardingTutorial._startSensing(stepConfig) / _stopSensing()（新增）

```javascript
// 接口签名
onboardingTutorial._startSensing(stepConfig)  // 入参：当前步配置对象；无返回值
onboardingTutorial._stopSensing()  // 无入参，无返回值
```

- **业务说明**：`_startSensing` 根据 `stepConfig.sensing` 字段决定启用哪些通道：含 `hashchange` 则追加 `addEventListener('hashchange', _hashHandler)`；含 `storagePoll` 则 `setInterval(_onStoragePoll, stepConfig.sensing.pollInterval || 1500)` 并初始化业务键快照；含 `mutationObserver` 则 `new MutationObserver(_onMutation)` 并 `observe(targetNode, {childList: true, subtree: true})`。`_stopSensing` 统一清理：`removeEventListener` hashchange / `clearInterval` / `observer.disconnect`，置空引用。
- **前置条件**：`_startSensing` 需传入含 `sensing` 字段的步配置；`_stopSensing` 可在任意状态调用（幂等）。
- **后置条件**：`_startSensing` 后对应通道已启用；`_stopSensing` 后三通道全部清理，无残留监听。
- **异常映射**：任一通道初始化失败捕获降级依赖其余通道，不抛异常不白屏。
- **调用示例**（内部）：
```javascript
_startSensing(stepConfig) {
  try {
    const sensing = stepConfig.sensing || {};
    if (sensing.hashchange) {
      this._hashHandler = () => this._onHashChange();
      window.addEventListener('hashchange', this._hashHandler);
    }
    if (sensing.storagePoll) {
      this._storageSnapshot = localStorage.getItem(sensing.storagePoll.key);
      this._storagePollTimer = setInterval(() => this._onStoragePoll(), sensing.pollInterval || 1500);
    }
    if (sensing.mutationObserver) {
      const target = document.querySelector(sensing.mutationObserver.selector);
      if (target) {
        this._mutationObserver = new MutationObserver((records) => this._onMutation(records));
        this._mutationObserver.observe(target, { childList: true, subtree: true });
      }
    }
  } catch (e) {}
}

_stopSensing() {
  try {
    if (this._hashHandler) {
      window.removeEventListener('hashchange', this._hashHandler);
      this._hashHandler = null;
    }
    if (this._storagePollTimer) {
      clearInterval(this._storagePollTimer);
      this._storagePollTimer = null;
    }
    if (this._mutationObserver) {
      this._mutationObserver.disconnect();
      this._mutationObserver = null;
    }
  } catch (e) {}
}
```

#### tutorialStorage.read()（改造：旧版兼容）

```javascript
// 接口签名（不变）
tutorialStorage.read()  // 无入参，返回数字（0 到 3）
```

- **业务说明**：读取 `localStorage.getItem('tutorialStep')`，解析为数字。**兼容旧版 7 步教程历史值**：若历史值 >= 新 TOTAL（3）视为完成态返回 3；0~2 正常返回；负数/NaN/非数字回退 0。
- **前置条件**：无。
- **后置条件**：返回值为 0 到 3 之间的非负整数。
- **异常映射**：localStorage 禁用、键不存在、值非数字均兜底返回 0；不抛异常。
- **调用示例**（改造后实现）：
```javascript
read() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return 0;
    const num = Number(raw);
    if (typeof num !== 'number' || !Number.isFinite(num) || !Number.isInteger(num) || num < 0) {
      return 0;  // 非法值回退 0
    }
    if (num >= tutorialSteps.TOTAL) {
      return tutorialSteps.TOTAL;  // 旧版 4~7 历史值视为完成态
    }
    return num;  // 0 ~ TOTAL-1 正常返回
  } catch (e) {
    return 0;
  }
}
```

## 2.3 数据模型

### 2.3.1 设计目标

教程数据模型需支持以下业务场景：
- **进度持久化与恢复**：刷新或重启后从上次进度继续引导（未完成）或不再自动弹出（已完成）
- **旧版 7 步教程兼容**：历史 `tutorialStep` 值 4~7 视为完成态不再弹出，1~2 对应新教程同序号步骤继续引导，0 视为未开始
- **进度合法性自愈**：被篡改为非法值（字符串/负数/NaN）时回退 0，不报错不白屏
- **与业务数据隔离**：教程进度独立存储，不污染业务键，不影响备份/导入/清空既有机制（清空时显式清理）
- **步骤配置可维护**：3 步序列与术语对照集中定义，每步含感知配置，便于调整文案与感知条件

性能与容量目标：`tutorialStep` 为单数字键，读写耗时 < 1ms，无容量压力。

与存量数据兼容策略：`tutorialStep` 键独立于 `APP_DATA_KEYS`，不纳入 `backupService.exportData` 备份范围；老用户升级后若 `tutorialStep` 不存在则返回 0 自动开始引导，若为旧版 4~7 则视为完成不再弹出。

### 2.3.2 模型实现

```plantuml
@startuml
title 教程数据模型类图（3 步 + 感知配置）

class tutorialStorage {
  +read() : number
  +write(step : number) : boolean
  +reset() : boolean
  +complete() : boolean
  +remove() : boolean
  -_isValidForWrite(value) : boolean
}

class termMapping {
  {static} GRAVITY_SOURCE : TermItem
  {static} GRAVITY_FIELD : TermItem
  {static} GRAVITY_ASSISTANT : TermItem
  {static} ESCAPE_VELOCITY : TermItem
  {static} CHECK_IN : TermItem
  {static} ALL : TermItem[]
}

class tutorialSteps {
  {static} ALL : StepConfig[]
  {static} TOTAL : number
}

class TermItem {
  term : string
  plain : string
  detail : string
}

class StepConfig {
  id : number
  title : string
  plainText : string
  termRef : TermItem
  targetHash : string
  targetSelector : string
  targetHint : string
  sensing : SensingConfig
  fallback : string
}

class SensingConfig {
  hashchange : boolean
  storagePoll : StoragePollConfig
  mutationObserver : MutationObserverConfig
  condition : SensingCondition
  pollInterval : number
}

class StoragePollConfig {
  key : string
}

class MutationObserverConfig {
  selector : string
}

class SensingCondition {
  hash : string
  storageChanged : boolean
  domAppears : string
}

class onboardingTutorial {
  -_mounted : boolean
  -_currentStep : number
  -_bubbleEl : HTMLElement
  -_hashHandler : Function
  -_storagePollTimer : number
  -_mutationObserver : MutationObserver
  -_storageSnapshot : string
  +start() : void
  +restart() : void
  +destroy() : void
  -_skip() : void
  -_complete() : void
  -_tryAdvance(signalType : string, signalData : any) : void
  -_startSensing(stepConfig : StepConfig) : void
  -_stopSensing() : void
  -_onHashChange() : void
  -_onStoragePoll() : void
  -_onMutation(records : MutationRecord[]) : void
  -_renderBubble(step : number) : HTMLElement
  -_positionBubble(bubble : HTMLElement, step : number) : void
  -_updateBubble(step : number) : void
  -_updateBubbleForRoute(hash : string) : void
  -_removeBubble() : void
}

tutorialStorage --> tutorialSteps : 读取 TOTAL 校验合法性
onboardingTutorial --> tutorialStorage : 读写进度
onboardingTutorial --> tutorialSteps : 读取步配置（含 sensing）
onboardingTutorial --> termMapping : 读取术语对照
tutorialSteps --> termMapping : 步骤引用术语
termMapping "1" *-- "5" TermItem
tutorialSteps "1" *-- "3" StepConfig
StepConfig --> TermItem
StepConfig --> SensingConfig
SensingConfig --> StoragePollConfig
SensingConfig --> MutationObserverConfig
SensingConfig --> SensingCondition

@enduml
```

**核心领域对象说明**：

| 对象 | 职责 | 生命周期 | 持久化策略 |
|------|------|----------|------------|
| `tutorialStorage` | 教程进度读写适配器，封装 localStorage 访问 + 旧版兼容 | 应用级单例（模块级常量导出） | 通过 localStorage 的 `tutorialStep` 键持久化数字 |
| `termMapping` | 引力系术语 → 通俗说法对照表（常量，复用） | 编译期固定，运行期只读 | 不持久化（常量） |
| `tutorialSteps` | 教程步骤配置序列（3 步 + sensing，重写） | 编译期固定，运行期只读 | 不持久化（常量） |
| `TermItem` | 单个术语对照项（复用） | 随 termMapping 常量创建 | 不持久化 |
| `StepConfig` | 单步教程配置（文案/术语/指向/sensing/兜底） | 随 tutorialSteps 常量创建 | 不持久化 |
| `SensingConfig` | 单步感知配置（hashchange/storagePoll/mutationObserver/condition/pollInterval） | 随 StepConfig 创建 | 不持久化 |
| `onboardingTutorial` | 教程核心控制器，持有当前步骤、气泡元素、三通道引用、业务键快照 | 应用启动时创建，完成/跳过时销毁气泡与三通道（单例保留供 restart） | 不直接持久化，通过 tutorialStorage 间接持久化 |

**对象创建与销毁策略**：
- `tutorialStorage`/`termMapping`/`tutorialSteps`：模块级常量导出，ES Module 自动初始化，无显式销毁
- `onboardingTutorial`：模块级单例；`start()` 时初始化 `_currentStep` 与三通道引用；`destroy()` 时 `_stopSensing()` 清理三通道 + `_removeBubble()` 移除气泡，单例本身保留供 `restart()` 重新激活
- 气泡元素：`_renderBubble` 时 createElement 创建，`_removeBubble` 时 removeChild 销毁
- 三通道引用：`_startSensing` 时创建（addEventListener/setInterval/new MutationObserver），`_stopSensing` 时清理（removeEventListener/clearInterval/disconnect）

**新版 3 步教程步骤序列**：

| 步序 | 标题 | 通俗文案 | 术语对照 | 指向路由 | 指向元素 | 感知方式 | 感知条件 | 推进后 |
|------|------|---------|---------|---------|---------|---------|---------|--------|
| 0 | 第一步：建立引力源 | 第一步：点击这里，写下你的存钱目标。 | 引力源 = 你要存钱实现的目标 | `#/` | `.home-create-btn` | hashchange | hash 变为 `#/goal/new` | tutorialStep=1，移除气泡待回首页展示第二步 |
| 1 | 第二步：打卡 | 第二步：点这里存入一笔钱，进度条就会增长！ | 打卡 = 每天标记坚持存钱 | `#/` | `.home-stats`（统计区/进度条上方） | storagePoll + mutationObserver | `dream_saving_camp_data` 变化 OR 进度条数值增长 | tutorialStep=2，切换为第三步气泡 |
| 2 | 第三步：引力小助手/引力场 | 第三步：点这里，找个搭子一起存钱，或者问问AI顾问！ | 引力小助手 = 能聊天的智能顾问 / 引力场 = 一起存钱的小组 | `#/` | `.advisor-fab`（优先）或 `.home-hero-camp` | hashchange + mutationObserver | 面板 DOM 出现 OR hash 变为 `#/camps` | tutorialStep=3，引导结束 |

**术语对照表（termMapping，复用既有）**：

| 项目用语（term） | 通俗说法（plain） | 详细解释（detail） |
|----------------|----------------|----------------|
| 引力源 | 你要存钱实现的目标 | 比如买一部新手机、去一次旅行。在首页点"新建引力源"就能建立一个 |
| 引力场 | 一起存钱的小组 | 一群人一起存钱、互相打气的小组。在首页点"引力场"看看 |
| 引力小助手 | 能聊天的智能存钱顾问 | 一个能用大白话聊天的智能存钱顾问，你可以直接打字问它问题。点右下角气泡就能聊 |
| 逃逸速度 | 提前把钱取出来 | 就是提前支取。取钱前会给你一段时间冷静冷静（冷静期倒计时），倒计时结束才能真正取 |
| 打卡 | 每天标记坚持存钱 | 每天点一下，证明你今天也坚持存钱啦。连续打卡能解锁成就徽章 |

**关键设计决策与理由**：

1. **基于现有 7 步教程代码最小化改造，不新增文件**：理由——现有 `tutorialStorage`/`tutorialSteps`/`termMapping`/`onboardingTutorial` 四个文件 + main.js/settingsView.js/backupService.js 三个挂载点 + main.css 样式段已完整覆盖教程组件骨架；新 3 步方案仅改变步骤数与推进方式，文件结构无需变更，改造集中在 tutorialSteps.js（重写为 3 步）、onboardingTutorial.js（移除 _next/_prev + 新增感知）、tutorialStorage.js（旧版兼容），其余复用。

2. **教程推进从"自带下一步按钮"改为"感知用户实际操作自动推进"**：理由——spec 1.4 规则 3 明确禁止教程自带"下一步"按钮推进，要求推进完全靠感知用户对原有按钮的实际操作；移除 `_next()`/`_prev()` 与对应按钮渲染，新增 `_tryAdvance` 根据感知信号判定推进，气泡仅保留"跳过"。

3. **操作感知三通道全部只读，禁止拦截原有事件**：理由——spec 5.3.1 规则 1/8 明确禁止对原有按钮 addEventListener/替换 onclick/叠加蒙层/e.preventDefault；三通道（hashchange 追加监听 / localStorage.getItem 只读轮询 / MutationObserver observe）均为被动感知副作用，不触碰原有事件；任一通道失败捕获降级依赖其余通道。

4. **业务键轮询间隔 1500ms（>= 1000ms）**：理由——spec 4.1 性能规则 5 要求轮询间隔不低于 1 秒避免高频拖累性能；1500ms 在感知及时性与性能间取平衡，优先用 hashchange + MutationObserver 事件驱动，storagePoll 仅用于打卡感知（无路由变化与明显 DOM 信号的场景）。

5. **MutationObserver 观察具体节点而非 document.body**：理由——spec 4.1 性能规则 6 与 5.3.1 规则 4 要求观察范围限定在教程关心的具体节点；第二步观察 `.home-stats`（进度条容器）感知数值增长，第三步观察 `.advisor-root`（引力小助手面板根节点）感知面板出现，subtree: true 但 target 非 document.body，避免大量回调拖累渲染。

6. **旧版 7 步教程历史值兼容：>=3 视为完成，1~2 继续引导**：理由——spec 4.5 兼容性规则 7 明确要求；调整 `tutorialStorage.read()` 兜底逻辑：历史值 >= 新 TOTAL（3）返回 TOTAL（完成态），0~2 正常返回，负数/NaN/非数字回退 0；`_isValid` 拆分为写入校验（严格 0~3）与读取兼容（>=3 视为完成），避免老用户（tutorialStep 曾为 4~7）被重新引导。

7. **气泡跟随路由切换判定：当前步 targetHash 匹配则展示，不匹配则移除待回正确页面**：理由——spec 5.6.1 规则 3 要求路由切换后根据新 hash + tutorialStep 判定展示/移除气泡（如第二步仅在首页展示，跳到非首页则移除待回首页）；扩展 `_onHashChange` 先判定展示再判定推进，不强行跳转。

8. **既有挂载点（main.js/settingsView.js/backupService.js）无需改动**：理由——`start()`/`restart()`/`clearAllData` 签名与行为语义不变（start 仍读 tutorialStep 决定弹出，restart 仍置 0 重新弹出，clearAllData 仍清理 tutorialStep）；改造集中在教程组件内部，对外接口稳定，现有调用方零改动。

9. **教程样式段改造集中在配色，结构与动效复用**：理由——移除"上一步/下一步"按钮后，`.tutorial-bubble-actions` 仅含"跳过"按钮，flex:1 单按钮占满，无需新增/修改布局样式；新 spec 5.2.1 规则 8 要求气泡背景改为半透明黑色 + 浅色文字 + 箭头配色同步，仅改 `main.css` 气泡样式段的配色属性（背景/文字色/箭头色/术语块背景/secondary 按钮背景），结构与动效（圆角/留白/入场动效/箭头定位/避让/响应式断点）完全复用；`onboardingTutorial.js` 无需改动。

10. **三通道启停统一管理，教程结束清理无泄漏**：理由——spec 4.4 可维护性规则 6 与 5.5.1 规则 6 要求教程结束时统一清理所有监听；`_startSensing`/`_stopSensing` 集中管理三通道引用（`_hashHandler`/`_storagePollTimer`/`_mutationObserver`），`destroy` 调用 `_stopSensing` 确保 removeEventListener/clearInterval/disconnect 全部执行，避免监听泄漏。

11. **气泡配色固定不依赖主题变量，三套主题统一呈现**：理由——新 spec 5.2.1 规则 8 要求气泡为半透明黑色背景 + 浅色文字，且三套主题（星云紫/晨曦黄/赛博蓝）下均清晰可读；若继续依赖 `var(--color-text)` 等主题变量，在浅色主题（晨曦黄）下深色文字叠在半透明黑底上虽可读但与"浅色文字"要求不符，在深色主题（赛博蓝）下深色文字对比度不足；改为固定浅色（`#fff` / `rgba(255,255,255,0.85)` 等）脱离主题变量，三套主题下气泡视觉完全一致且高对比可读，同时消除主题切换对气泡可读性的影响。primary 按钮保留 `var(--color-primary)` 品牌主色，在黑底上仍醒目且与品牌呼应。

12. **气泡为局部小尺寸卡片，禁止全屏遮罩**：理由——新 spec 5.2.1 规则 1 明确要求气泡以绝对/固定定位的小尺寸局部卡片叠加，定位到目标按钮旁，不得全屏遮罩/蒙层/强制覆盖整个屏幕；现有 `.tutorial-bubble` 为 `position: fixed` + `max-width: 340px` + `width: calc(100vw - 32px)`，`_positionBubble` 三段避让定位到目标元素旁，无全屏蒙层元素，已完全符合；推进时 `_updateBubble` 重建气泡 + `_positionBubble` 重新定位为局部位置更新，非全屏覆盖。
