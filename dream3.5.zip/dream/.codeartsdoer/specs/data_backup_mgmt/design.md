# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| localStorage 键值读取/写入/移除的底层能力 | `localStorageAdapter.read/write/remove` 三个通用方法，封装了 try/catch 与 JSON 解析 | `src/storage/localStorageAdapter.js:18-48` | 75% |
| 数据版本标识常量 | `DATA_VERSION = 1` 已定义并用于写入时打版本戳 | `src/constants.js:39`、`src/storage/localStorageAdapter.js:33` | 100% |
| 主数据键常量 | `STORAGE_KEYS.DATA_KEY = 'dream_saving_camp_data'` 已集中声明 | `src/constants.js:1-3` | 50% |
| 二次确认弹窗与轻提示 | `modal.show(message, onConfirm, onCancel)` 与 `modal.toast(message)` 已实现，含遮罩、危险按钮、自动消失 | `src/views/modal.js:1-68` | 75% |
| 首页渲染入口与 DOM 挂载点 | `homeView.render()` 构建 `.home-page` 并 append 到 `#app`，已有 hero/stats/motivation/badges/goals 多个分区 | `src/views/homeView.js:7-29` | 75% |
| 路由分发与容错 | `router()` 基于 `window.location.hash` 分发，已有 try/catch 兜底渲染错误页 | `src/main.js:13-55` | 75% |
| Minimalist Modern 视觉令牌 | CSS 变量体系（`--color-*`、`--radius-*`、`--shadow-*`）与按钮类（`.btn-primary/secondary/danger/accent`）已建立 | `src/styles/main.css:1-27`、`139-178` | 100% |
| 旧数据兼容约定（allowWithdraw / pendingWithdrawDetail 默认值） | `goalService` 在 `requestWithdraw/confirmWithdraw/getWithdrawStatus` 中已实现"缺失 cooldownHours 默认 48h、缺失 amount 默认全额"的兜底 | `src/services/goalService.js:164-194` | 100% |

匹配度判定依据：
- **100%**：存量代码完全覆盖需求语义，可直接复用无需改动。
- **75%**：存量能力可复用，但需新增调用方或扩展参数（如 modal 当前仅支持单行文本，长警示文案需验证换行展示）。
- **50%**：仅部分覆盖（如 `STORAGE_KEYS` 只声明了主数据键，储蓄营两个键仍硬编码在 service 内）。

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 本应用相关数据键集合的单一来源 | `STORAGE_KEYS` 仅含 `DATA_KEY`，`dream_camps_data`、`dream_joined_camps` 以局部常量散落在 `campService.js:1-2` 与 `campApiService.js:2` | 清空/导出需遍历三个键，若各自硬编码易遗漏；且未来新增键时无统一维护点 | 在 `constants.js` 的 `STORAGE_KEYS` 中补齐 `CAMPS_KEY`、`JOINED_KEY` 两个键名，并导出 `APP_DATA_KEYS` 数组作为"本应用相关数据键集合"的单一来源；`campService`/`campApiService` 改为从 constants 引用，行为不变 |
| 二次确认弹窗的文案长度 | `modal.show` 当前 `.modal-message` 为单段 `<p>`，未验证多行警示文案（如"将清空全部储蓄目标、打卡记录、储蓄营等数据且不可恢复"）的换行与可读性 | 长文案在窄屏可能溢出 | 复用 `modal.show`，依赖现有 CSS 的 `word-break` 与 `max-width`；若样式不足，在 `main.css` 中针对 `.modal-message` 补充 `line-height` 与 `max-width` 约束，不改 modal.js 接口 |
| 首页设置入口的可达性 | `homeView` 现有 hero 区含"储蓄营"按钮，但无"设置/数据管理"入口 | 需求要求设置入口从首页可达，且导出/导入/清空三操作聚合 | 在 `homeView` 新增一个设置入口（hero 区或页面底部固定区），点击跳转 `#/settings`；新增 `settingsView.js` 渲染聚合页 |
| 路由表新增设置页 | `router()` 仅识别 `#/`、`#/camps`、`#/camp/new`、`#/camp/join`、`#/goal/*` 等 | 需新增 `#/settings` 路由分支 | 在 `main.js` 的 `router()` 中新增 `hash === '#/settings'` 分支，调用 `settingsView.render()` |

扩展方向的兼容性说明：
- `STORAGE_KEYS` 补齐两键为纯增量常量，不改动现有 `DATA_KEY` 值，所有现存读取逻辑行为不变。
- `campService`/`campApiService` 改为从 constants 引用键名，是等价替换（键名字符串不变），无数据迁移风险。

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**A. 数据备份服务模块（`src/services/backupService.js`，新增文件）**
- `exportData()`：采集三个键的当前值，组装为带版本标识的 JSON 对象，返回 `{ success, data?, error? }`。无外部依赖。
- `importData(parsed)`：对已解析的 JSON 对象执行格式与版本校验，返回 `{ success, error? }`，不写入。写入由调用方在用户确认后触发。
- `applyImport(parsed)`：将校验通过的数据覆盖写入三个键，返回 `{ success, error? }`。
- `clearAllData()`：移除三个键，返回 `{ success, error? }`。
- `validateBackup(parsed)`：纯函数校验器，返回 `{ valid, reason? }`，供 `importData` 内部及单测复用。
- 依赖：`constants.js`（`APP_DATA_KEYS`、`DATA_VERSION`）、浏览器 `localStorage`、`JSON`。

**B. 文件下载/读取工具模块（`src/utils/fileUtils.js`，新增文件）**
- `downloadJson(filename, obj)`：将对象序列化为 JSON Blob，通过 `<a download>` 触发浏览器下载。返回 `{ success, error? }`。
- `pickJsonFile()`：返回 Promise，创建 `<input type="file" accept="application/json,.json">`，用户选择后读取为文本并 `JSON.parse`，resolve `{ parsed, filename }`；用户取消则 reject `{ canceled: true }`。
- 依赖：浏览器 DOM、`Blob`、`URL.createObjectURL`。

**C. 设置视图模块（`src/views/settingsView.js`，新增文件）**
- `render()`：渲染聚合页，含"导出数据""导入数据""清空所有数据"三个操作入口及简短说明，挂载到 `#app`。清空入口使用 `.btn-danger` 视觉区分。
- 依赖：`backupService`、`fileUtils`、`modal`、`homeView`（导入/清空后刷新）。

**D. 全局免责声明组件（`src/views/disclaimerView.js`，新增文件）**
- `render()`：返回一个 DOM 元素（`.home-disclaimer`），含固定文案"本应用为模拟记账，不涉及真实资金交易"与弱化提示图标。无外部依赖，纯展示。
- 由 `homeView` 在首屏渲染时 append 到 `.home-page`。

**E. 首页与路由集成点（修改现有文件）**
- `homeView.js`：在 `render()` 中追加免责声明元素与设置入口元素。
- `main.js`：在 `router()` 中新增 `#/settings` 分支。
- `constants.js`：补齐 `STORAGE_KEYS.CAMPS_KEY`、`STORAGE_KEYS.JOINED_KEY` 与 `APP_DATA_KEYS` 数组。
- `campService.js`、`campApiService.js`：将局部键常量改为从 `constants.js` 引用。
- `main.css`：追加 `.home-disclaimer`、`.settings-*` 样式（沿用现有 CSS 变量）。

## 1.2 存量功能详细分析

### 1.2.1 localStorageAdapter（`src/storage/localStorageAdapter.js`）

- **接口契约**：
  - `read(key)` → `object | null`：读取并 `JSON.parse`，失败返回 `null`。
  - `write(key, data)` → `boolean`：写入时自动注入 `_version: DATA_VERSION`，失败返回 `false`。
  - `remove(key)` → `boolean`：移除键，失败返回 `false`。
  - `getVersion()` → `number`：返回 `DATA_VERSION`。
  - `initData()` / `saveData(data)` / `getData()`：与 server 端 fetch 耦合，非本组件使用范围。
- **业务规则**：`write` 会强制覆盖 `_version` 字段，意味着导出文件中若包含 `_version`，经 `write` 写入后会被当前版本覆盖——本组件导入时需绕过 `write`，直接使用 `localStorage.setItem` 以保留备份文件原始版本，或先校验版本再写入。
- **约束**：所有方法已 try/catch，不会向调用方抛错，仅以返回值传达成败。本组件可复用 `read/remove`，但 `write` 因强制改版本不适用于"忠实覆盖导入数据"场景。

### 1.2.2 modal（`src/views/modal.js`）

- **接口契约**：
  - `show(message, onConfirm, onCancel)`：同步渲染遮罩 + 对话框，确认按钮文案"确认"且类名 `.btn-danger`，取消按钮"取消"且 `.btn-secondary`。点击遮罩空白等同取消。
  - `toast(message)`：渲染顶部 toast，2 秒后自动消失。
- **业务规则**：`show` 的确认按钮固定为危险样式（红色），适合清空/导入覆盖两类危险确认；若需非危险确认（如导出无破坏性），仍可复用，视觉上红色确认按钮可接受（语义为"确认执行"）。
- **扩展点**：无显式扩展点；如需自定义按钮文案，需扩展 `show` 参数。本设计选择不修改 modal 接口，导出操作用 `toast` 反馈即可，无需确认弹窗。
- **约束**：`show` 是阻塞式交互（DOM 遮罩），同一时刻仅能展示一个弹窗。

### 1.2.3 homeView（`src/views/homeView.js`）

- **接口契约**：`render()` 清空 `#app` 并 append `.home-page`，内部分区为 hero → stats → motivation → badges → goals。各分区由私有 `_render*` 方法构建。
- **业务规则**：`render` 是首页唯一入口，由 `router()` 在 `hash === '#/'` 时调用。无显式扩展点（无 hook）。
- **约束**：`render` 会清空 `#app`，新增的免责声明与设置入口必须在 `render` 内部 append，不能在外部后挂载（否则被下次 render 清空）。
- **集成策略**：在 `_renderGoalsSection` 之后追加 `_renderDisclaimer()` 与 `_renderSettingsEntry()`，保证首屏可见区域内出现免责声明，设置入口常驻。

### 1.2.4 constants.js 的 STORAGE_KEYS

- **现状**：仅 `DATA_KEY: 'dream_saving_camp_data'`。
- **约束**：`campService` 与 `campApiService` 各自硬编码了 `dream_camps_data`、`dream_joined_camps`，未走 constants。这是历史遗留，导致"本应用相关数据键集合"无单一来源。
- **风险**：若清空逻辑独立枚举三个键字符串，未来新增键时需同步多处，易遗漏。故设计要求将三键集中到 `STORAGE_KEYS` 并导出 `APP_DATA_KEYS` 数组。

### 1.2.5 goalService 旧数据兼容约定

- **现状**：`requestWithdraw` 写入 `pendingWithdrawDetail`；`confirmWithdraw`/`getWithdrawStatus` 读取时若 `detail.cooldownHours` 缺失则取 `WITHDRAW_COOLDOWN_HOURS`（48），若 `detail.amount` 缺失则取 `goal.currentAmount`（全额）；`create` 时 `allowWithdraw !== false` 即默认 true。
- **约束**：导入时若备份文件中 goal 对象缺失这两个字段，无需在导入阶段补全——现有 goalService 读取时已兜底。导入逻辑只需保证 goal 对象原样写入，不主动改写字段，兼容性由 goalService 自身保证。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "应用用户" as user

rectangle "数据备份与免责声明组件" {
  rectangle "settingsView" as sv
  rectangle "disclaimerView" as dv
  rectangle "backupService" as bs
  rectangle "fileUtils" as fu
}

storage "浏览器 localStorage\n(三个应用键)" as ls
usecase "浏览器下载/文件选择" as file
rectangle "现有 homeView / main.js / modal" as exist

user --> sv : 点击导出/导入/清空
user --> dv : 打开首页即见
sv --> bs : 调用导出/导入/清空
sv --> fu : 触发下载/选择文件
sv --> exist : 复用 modal.show/toast
bs --> ls : read/write/remove 三个键
fu --> file : Blob 下载 / input[file]
file --> user : 保存/选取 JSON
exist --> user : toast 反馈
@enduml
```

通信协议与频率：
- 用户 → settingsView：低频，人工触发，单次点击。
- settingsView → backupService：同步函数调用，无中间件。
- backupService → localStorage：同步读写，单次操作 ≤ 3 个键。
- settingsView → fileUtils：`downloadJson` 同步触发下载；`pickJsonFile` 返回 Promise（等待用户选择）。
- 导入/清空成功后 → `location.reload()`：一次性页面刷新，重载应用状态。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
rectangle "src/constants.js" as constants {
  rectangle "STORAGE_KEYS\n{DATA_KEY, CAMPS_KEY, JOINED_KEY}" as sk
  rectangle "APP_DATA_KEYS\n[3个键名]" as ak
  rectangle "DATA_VERSION = 1" as dv
}

rectangle "src/services/backupService.js" as bs {
  rectangle "exportData()" as exp
  rectangle "validateBackup(parsed)" as val
  rectangle "importData(parsed)" as imp
  rectangle "applyImport(parsed)" as app
  rectangle "clearAllData()" as clr
}

rectangle "src/utils/fileUtils.js" as fu {
  rectangle "downloadJson(name, obj)" as dl
  rectangle "pickJsonFile()" as pick
}

rectangle "src/views/settingsView.js" as sv {
  rectangle "render()" as svr
}

rectangle "src/views/disclaimerView.js" as dvv {
  rectangle "render()" as dvr
}

rectangle "现有 homeView.js" as hv
rectangle "现有 main.js (router)" as main
rectangle "现有 modal.js" as modal
storage "localStorage" as ls

constants <-- bs : 引用键集合/版本
bs --> ls : read/remove + 原生 setItem
fu --> ls : 无
sv --> bs
sv --> fu
sv --> modal
sv --> main : location.reload
dvv --> constants : 无（纯文案）
hv --> dvv : append 免责声明
hv --> main : hash 跳 #/settings
main --> sv : #/settings 路由
@enduml
```

模块职责与依赖关系：
- **constants.js**（修改）：补齐三键与 `APP_DATA_KEYS` 数组，作为键集合单一来源。无新增依赖。
- **backupService.js**（新增）：纯业务逻辑层，不依赖 DOM，仅依赖 `constants` 与 `localStorage`/`JSON`。可独立单测。
- **fileUtils.js**（新增）：纯浏览器 I/O 工具，不依赖业务常量。
- **settingsView.js**（新增）：视图层，编排 backupService + fileUtils + modal + reload。
- **disclaimerView.js**（新增）：纯展示组件，无依赖。
- **homeView.js**（修改）：仅追加两行 append 调用，不改动现有分区逻辑。
- **main.js**（修改）：仅追加一个路由分支。
- **campService.js / campApiService.js**（修改）：键常量改为从 constants 引用，等价替换。

配置项及取值策略：
- 导出文件名格式：`dream-backup-YYYYMMDD-HHmm.json`，时间取 `new Date()`，便于多次备份区分。
- 导出 JSON 顶层字段名：`_version`、`dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps`（直接以键名为字段名，便于人工核查与一一对应）。
- 导入版本不兼容阈值：备份文件 `_version > DATA_VERSION` 则中止；`_version < DATA_VERSION` 则按宽松策略导入（依赖 goalService 兜底）；`_version === DATA_VERSION` 正常导入。

### 2.1.3 实现设计文档

#### 导出流程活动图

```plantuml
@startuml
start
:用户点击"导出数据";
:backupService.exportData();
:遍历 APP_DATA_KEYS 读取 localStorage;
if (读取抛错?) then (是)
  :toast("导出失败，浏览器存储不可用");
  stop
else (否)
endif
:组装 {_version, 三个键值} 对象;
:fileUtils.downloadJson(filename, obj);
if (序列化或下载触发抛错?) then (是)
  :toast("导出失败，数据异常");
  stop
else (否)
endif
:toast("导出成功");
stop
@enduml
```

#### 导入流程活动图（含校验与二次确认）

```plantuml
@startuml
start
:用户点击"导入数据";
:fileUtils.pickJsonFile();
if (用户取消?) then (是)
  stop
else (否)
endif
:JSON.parse 文件文本;
if (解析抛错?) then (是)
  :toast("文件解析失败，请确认其为本应用导出的 JSON 备份");
  stop
else (否)
endif
:backupService.validateBackup(parsed);
if (格式合法?) then (否)
  :toast(具体原因);
  stop
else (是)
endif
if (版本 > 当前?) then (是)
  :toast("备份文件版本过高，请升级应用后重试");
  stop
else (否)
endif
:modal.show("导入将覆盖现有全部数据且不可恢复，是否继续？",
            onConfirm, onCancel);
if (用户确认?) then (否)
  :关闭弹窗，数据不变;
  stop
else (是)
endif
:backupService.applyImport(parsed);
if (写入抛错?) then (是)
  :toast("导入失败，本地存储空间不足或不可用");
  stop
else (否)
endif
:location.reload();
stop
@enduml
```

#### 清空流程活动图（二次确认 + 危险区分）

```plantuml
@startuml
start
:用户点击"清空所有数据"(红色危险按钮);
:modal.show("将清空全部储蓄目标、打卡记录、储蓄营等数据且不可恢复，是否继续？",
            onConfirm, onCancel);
if (用户确认?) then (否)
  :关闭弹窗，数据不变;
  stop
else (是)
endif
:backupService.clearAllData();
if (移除抛错?) then (是)
  :toast("清空失败，浏览器存储不可用，请手动清理浏览器数据");
  stop
else (否)
endif
:location.reload();
stop
@enduml
```

#### 导入校验状态机（validateBackup 内部）

```plantuml
@startuml
state "入参 parsed" as in
state "非对象?" as c1
state "缺 _version?" as c2
state "版本 > 当前?" as c3
state "缺核心业务字段?" as c4
state "合法" as ok
state "不合法+原因" as bad

[*] --> in
in --> c1
c1 --> bad : 是 → "文件格式不合法，非本应用备份文件"
c1 --> c2 : 否
c2 --> bad : 是 → "文件格式不合法，非本应用备份文件"
c2 --> c3 : 否
c3 --> bad : 是 → "备份文件版本过高，请升级应用后重试"
c3 --> c4 : 否
c4 --> bad : 是 → "文件格式不合法，非本应用备份文件"
c4 --> ok : 否
ok --> [*]
bad --> [*]
@enduml
```

核心字段校验规则（`c4`）：备份对象必须包含 `dream_saving_camp_data` 字段且其为对象，且该对象含 `goals`、`records`、`checkIns`、`achievements` 四个数组字段（`camps` 字段在主数据中可选，因 campService 实际使用独立键）。`dream_camps_data` 与 `dream_joined_camps` 字段若缺失，按空数据兜底（不视为不合法，因早期版本可能无储蓄营数据）。

扩展点设计：本组件无二次开发扩展点需求。`validateBackup` 为纯函数，未来若新增数据键，只需在 `APP_DATA_KEYS` 与校验规则中同步增补，无需改流程。

## 2.2 接口设计

### 2.2.1 总体设计

接口分类：
- **业务服务接口**（`backupService`）：导出/校验/导入/清空，返回 `{ success, error? }` 统一结构。
- **浏览器 I/O 接口**（`fileUtils`）：下载/选择文件，`downloadJson` 同步返回，`pickJsonFile` 返回 Promise。
- **视图接口**（`settingsView.render`、`disclaimerView.render`）：无参 render，挂载 DOM。

接口继承体系：无继承，均为扁平对象字面量导出（与现有 service/view 风格一致）。

接口变更策略：本组件为新增，无历史接口需兼容。`STORAGE_KEYS` 补齐两键为纯增量，不破坏现有 `DATA_KEY` 引用。

| 接口 | 所属模块 | 稳定性 | 调用方 |
|------|---------|--------|--------|
| `backupService.exportData()` | backupService | 稳定 | settingsView |
| `backupService.validateBackup(parsed)` | backupService | 稳定 | settingsView、单测 |
| `backupService.applyImport(parsed)` | backupService | 稳定 | settingsView |
| `backupService.clearAllData()` | backupService | 稳定 | settingsView |
| `fileUtils.downloadJson(name, obj)` | fileUtils | 稳定 | settingsView |
| `fileUtils.pickJsonFile()` | fileUtils | 稳定 | settingsView |
| `settingsView.render()` | settingsView | 稳定 | main.js router |
| `disclaimerView.render()` | disclaimerView | 稳定 | homeView |

### 2.2.2 接口清单

#### backupService.exportData()

```js
// 返回 { success: true, data: BackupObject } 或 { success: false, error: string }
backupService.exportData()
```

- **业务说明**：采集 `APP_DATA_KEYS` 全部键的当前 localStorage 值，组装为带 `_version` 的备份对象。
- **前置条件**：无。
- **后置条件**：不修改 localStorage，仅读取。
- **异常映射**：localStorage 读取抛错 → `{ success: false, error: '导出失败，浏览器存储不可用，请检查浏览器设置' }`；JSON 序列化抛错 → `{ success: false, error: '导出失败，数据异常，请联系开发者' }`。
- **调用示例**：
```js
const result = backupService.exportData();
if (!result.success) { modal.toast(result.error); return; }
const dl = fileUtils.downloadJson(filename, result.data);
modal.toast(dl.success ? '导出成功' : dl.error);
```

#### backupService.validateBackup(parsed)

```js
// 返回 { valid: true } 或 { valid: false, reason: string }
backupService.validateBackup(parsed)
```

- **业务说明**：纯函数校验备份对象格式与版本，不触碰 localStorage。
- **前置条件**：`parsed` 为已解析的 JS 对象（调用方先 `JSON.parse`）。
- **后置条件**：无副作用。
- **异常映射**：非对象/缺版本/缺核心字段 → `{ valid: false, reason: '文件格式不合法，非本应用备份文件' }`；版本过高 → `{ valid: false, reason: '备份文件版本过高，请升级应用后重试' }`。
- **调用示例**：
```js
const v = backupService.validateBackup(parsed);
if (!v.valid) { modal.toast(v.reason); return; }
```

#### backupService.applyImport(parsed)

```js
// 返回 { success: true } 或 { success: false, error: string }
backupService.applyImport(parsed)
```

- **业务说明**：将校验通过的备份对象覆盖写入 `APP_DATA_KEYS` 全部键。对缺失的可选字段（`dream_camps_data`、`dream_joined_camps`）写入空值（`{camps:[]}`、`[]`），保证清空态一致。
- **前置条件**：`parsed` 已通过 `validateBackup`。
- **后置条件**：localStorage 三个键被覆盖；不主动改写 goal 对象的 `allowWithdraw`/`pendingWithdrawDetail`（兼容性由 goalService 兜底）。
- **异常映射**：`localStorage.setItem` 抛错 → `{ success: false, error: '导入失败，本地存储空间不足或不可用' }`。
- **调用示例**：
```js
const r = backupService.applyImport(parsed);
if (r.success) location.reload(); else modal.toast(r.error);
```

#### backupService.clearAllData()

```js
// 返回 { success: true } 或 { success: false, error: string }
backupService.clearAllData()
```

- **业务说明**：对 `APP_DATA_KEYS` 全部键执行 `localStorage.removeItem`，仅移除本应用键，不触碰其他应用键。
- **前置条件**：无（调用方应已二次确认）。
- **后置条件**：三个键不存在；其他 localStorage 键不变。
- **异常映射**：`removeItem` 抛错 → `{ success: false, error: '清空失败，浏览器存储不可用，请手动清理浏览器数据' }`。
- **调用示例**：
```js
modal.show('将清空全部储蓄目标、打卡记录、储蓄营等数据且不可恢复，是否继续？', () => {
  const r = backupService.clearAllData();
  if (r.success) location.reload(); else modal.toast(r.error);
});
```

#### fileUtils.downloadJson(filename, obj)

```js
// 返回 { success: true } 或 { success: false, error: string }
fileUtils.downloadJson(filename, obj)
```

- **业务说明**：将 `obj` 序列化为 JSON Blob，创建 `<a download=filename>` 触发点击下载，`revokeObjectURL` 释放。
- **前置条件**：浏览器支持 `Blob` 与 `URL.createObjectURL`。
- **后置条件**：触发浏览器下载对话框（或静默下载，取决于浏览器设置）。
- **异常映射**：序列化或 DOM 操作抛错 → `{ success: false, error: '导出失败，数据异常' }`。

#### fileUtils.pickJsonFile()

```js
// 返回 Promise<{ parsed: object, filename: string }>
// 用户取消时 reject({ canceled: true })
fileUtils.pickJsonFile()
```

- **业务说明**：创建 `<input type="file" accept="application/json,.json">`，监听 change，读取为文本并 `JSON.parse`。
- **前置条件**：浏览器支持 `FileReader` 或 `File.text()`。
- **后置条件**：无副作用（input 不挂载到可见 DOM，触发后移除）。
- **异常映射**：`JSON.parse` 抛错 → reject `{ parseError: true }`；用户取消 → reject `{ canceled: true }`。
- **调用示例**：
```js
try {
  const { parsed } = await fileUtils.pickJsonFile();
  const v = backupService.validateBackup(parsed);
  if (!v.valid) { modal.toast(v.reason); return; }
  // ...进入确认流程
} catch (e) {
  if (e.canceled) return;
  if (e.parseError) modal.toast('文件解析失败，请确认其为本应用导出的 JSON 备份');
}
```

#### settingsView.render()

```js
settingsView.render()
```

- **业务说明**：清空 `#app`，渲染设置聚合页（标题 + 三个操作卡片 + 返回首页按钮），挂载事件监听。
- **前置条件**：`#app` DOM 存在。
- **后置条件**：`#app` 内含设置页 DOM；点击导出/导入/清空触发对应流程。

#### disclaimerView.render()

```js
// 返回 HTMLElement
disclaimerView.render()
```

- **业务说明**：返回 `.home-disclaimer` 元素，含固定文案与弱化图标，由 homeView append。
- **前置条件**：无。
- **后置条件**：返回的元素未挂载，由调用方决定挂载位置。

## 2.3 数据模型

### 2.3.1 设计目标

需支持的业务场景：
- 导出：将 localStorage 三个键的当前值快照为单一 JSON 文件。
- 导入：从 JSON 文件恢复三个键的值，覆盖现有数据。
- 清空：移除三个键，回到初始空状态。
- 版本兼容：识别备份文件版本，高版本拒绝，低版本宽松导入。

性能、容量、扩展性目标：
- 备份文件体积通常 < 5MB（spec 4.1），单次 `JSON.stringify` 与 Blob 构造在 1 秒内完成。
- 校验为纯函数，O(1) 字段检查，毫秒级。
- 扩展性：新增应用数据键时，仅在 `APP_DATA_KEYS` 与导出对象字段映射处增补，不改流程。

与存量数据的兼容策略：
- 导出对象字段名直接使用 localStorage 键名，一一对应，便于人工核查。
- 导入时对 `dream_camps_data`/`dream_joined_camps` 缺失按空值兜底，兼容早期无储蓄营功能的版本。
- goal 对象的 `allowWithdraw`/`pendingWithdrawDetail` 缺失由 goalService 读取时兜底，导入不主动补全。

### 2.3.2 模型实现

#### 备份文件对象结构（导出/导入的 JSON 顶层）

```plantuml
@startuml
class BackupObject {
  + _version : number
  + dream_saving_camp_data : MainData
  + dream_camps_data : CampsData
  + dream_joined_camps : JoinedCamp[]
}

class MainData {
  + _version : number
  + goals : Goal[]
  + records : Record[]
  + checkIns : CheckIn[]
  + camps : Camp[]
  + achievements : Achievement[]
}

class CampsData {
  + camps : Camp[]
}

class JoinedCamp {
  + campId : string
  + code : string
  + memberId : string
  + nickname : string
  + campName : string
}

BackupObject --> MainData
BackupObject --> CampsData
BackupObject --> JoinedCamp : 0..*
@enduml
```

字段说明：
- `_version`：整数，导出时取 `DATA_VERSION`（当前为 1）。导入时若 > 当前版本则拒绝。
- `dream_saving_camp_data`：主数据对象，结构同 `localStorageAdapter.getEmptyData()` 返回值。其内部 `_version` 字段保留备份原值（不强制改写）。
- `dream_camps_data`：`{ camps: Camp[] }`，缺失时导入写 `{ camps: [] }`。
- `dream_joined_camps`：`JoinedCamp[]`，缺失时导入写 `[]`。

#### 服务返回值统一结构

```plantuml
@startuml
class ServiceResult {
  + success : boolean
  + error : string
}
class ValidateResult {
  + valid : boolean
  + reason : string
}
class ExportResult {
  + success : boolean
  + error : string
  + data : BackupObject
}
@enduml
```

对象创建与销毁策略：
- `BackupObject` 在 `exportData` 中由字面量组装，无生命周期管理。
- 导入时 `parsed` 对象由 `JSON.parse` 创建，写入后无需保留引用，由 GC 回收。
- `Blob` 与 `ObjectURL` 在 `downloadJson` 中创建后立即 `revokeObjectURL` 释放，无内存泄漏。

持久化策略：
- 不引入新存储介质，仍使用浏览器 localStorage。
- 导入写入直接使用 `localStorage.setItem(key, JSON.stringify(value))`，绕过 `localStorageAdapter.write`（因其强制改 `_version`），以忠实保留备份文件原始数据。
- 清空使用 `localStorage.removeItem(key)`，与 `localStorageAdapter.remove` 等价（可直接复用）。

#### 与现有打卡和储蓄营功能的隔离保证

- **打卡功能**（`habitService`）：仅依赖主数据键的 `checkIns` 数组。导出/导入对该键整体快照与覆盖，不解析单个 checkIn 对象，不破坏 `checkInDate`/`checkInTime` 字段。清空移除主数据键后，`habitService.getStreakDays` 读取 `getData()` 返回空数据，连续天数归零，符合 spec 5.4.4。
- **储蓄营功能**（`campService`/`campApiService`）：依赖 `dream_camps_data` 与 `dream_joined_camps` 两键。导出/导入对两键整体快照与覆盖，不解析 camp 对象内部结构。清空移除两键后，`campService.getJoinedCamps` 读取返回空数组，储蓄营列表为空。
- **集成点隔离**：`backupService` 仅通过 `APP_DATA_KEYS` 数组与 localStorage 交互，不调用任何现有 service 的业务方法，不触发 `localStorageAdapter.initData/saveData`（避免触发 fetch）。现有 service 不感知备份组件存在，双向解耦。
- **刷新重载**：导入/清空后 `location.reload()` 触发 `main.js` 的 `init()` 重新执行 `localStorageAdapter.initData()`，基于新数据重建缓存与界面，保证 UI 与数据一致。

#### 集成点清单（修改现有文件的具体位置）

| 文件 | 修改位置 | 修改内容 | 影响范围 |
|------|---------|---------|---------|
| `src/constants.js` | `STORAGE_KEYS` 对象（第 1-3 行） | 新增 `CAMPS_KEY: 'dream_camps_data'`、`JOINED_KEY: 'dream_joined_camps'`；新增 `export const APP_DATA_KEYS = [STORAGE_KEYS.DATA_KEY, STORAGE_KEYS.CAMPS_KEY, STORAGE_KEYS.JOINED_KEY]` | 全局常量，无运行时副作用 |
| `src/services/campService.js` | 第 1-2 行 | 删除局部 `CAMPS_KEY`/`JOINED_KEY` 常量，改为 `import { STORAGE_KEYS } from '../constants.js'` 并用 `STORAGE_KEYS.CAMPS_KEY`/`JOINED_KEY` 替换引用 | 等价替换，键名不变，行为不变 |
| `src/services/campApiService.js` | 第 2 行 | 同上，`JOINED_KEY` 改为从 constants 引用 | 等价替换 |
| `src/views/homeView.js` | `render()` 方法（第 8-29 行） | 在 `_renderGoalsSection` 之后追加 `page.appendChild(disclaimerView.render())` 与 `page.appendChild(this._renderSettingsEntry())`；新增 `_renderSettingsEntry()` 私有方法构建设置入口按钮 | 首页新增两块 DOM，不改动现有分区 |
| `src/main.js` | `router()`（第 13-55 行） | 新增 `import { settingsView }` 与 `hash === '#/settings'` 分支 | 新增路由，不影响现有分支 |
| `src/styles/main.css` | 文件末尾追加 | 新增 `.home-disclaimer`、`.home-disclaimer-icon`、`.home-settings-entry`、`.settings-page`、`.settings-card`、`.settings-card-danger` 等样式，沿用现有 CSS 变量 | 纯样式增量，不影响现有规则 |

#### 全局免责声明展示位置与样式方案

- **位置**：`homeView.render()` 中，追加在 `.home-goals` 之后、`.home-page` 末尾，属首屏可见区域（页面较短时无需滚动即可见；若目标列表较长，免责声明位于列表下方但仍为首页常驻内容，符合 spec 5.3.1 规则 2"显著位置"——与现有 motivation/badges 同级）。
- **样式**（沿用 Minimalist Modern）：
  - 容器 `.home-disclaimer`：`background: var(--color-primary-light)`（淡绿底）、`border: 1px solid var(--color-border)`、`border-radius: var(--radius-md)`、`padding: 12px 16px`、`margin-top: 16px`、`display: flex; align-items: center; gap: 8px`。
  - 图标 `.home-disclaimer-icon`：`💡` 或 `ℹ️`，`color: var(--color-text-muted)`，弱化色调。
  - 文案 `.home-disclaimer-text`：`color: var(--color-text-light)`、`font-size: 13px`、`line-height: 1.5`，与正文（`--color-text`）形成可辨识区分但不至于过小（≥ 辅助文本字号）。
  - 不使用折叠、不使用弹窗，常驻渲染。

#### 设置入口呈现形式与聚合方式

- **首页入口**：在 `homeView` 末尾追加 `.home-settings-entry` 按钮（`.btn-secondary` 风格，含齿轮图标 ⚙ 与文字"数据管理"），点击 `location.hash = '#/settings'`。常驻首页，符合 spec 5.5.1 规则 2"从首页可达"。
- **聚合页 `#/settings`**：`settingsView.render()` 渲染 `.settings-page`，含：
  - 页面标题"数据管理"与返回首页按钮。
  - 三张 `.settings-card` 卡片纵向排列：
    1. 导出数据（`.btn-primary`，绿色，含说明"将全部数据下载为 JSON 文件"）。
    2. 导入数据（`.btn-secondary`，灰色，含说明"从 JSON 备份恢复数据，将覆盖现有数据"）。
    3. 清空所有数据（`.btn-danger`，红色，含说明"移除全部本地数据，不可恢复"），与上两张卡片间距加大并附警示边框 `.settings-card-danger`，符合 spec 5.5.1 规则 4"危险操作区分"。
  - 三个入口均有文字标签 + 图标 + 说明，符合 spec 5.5.1 规则 3"禁止仅用图标无文字"。
