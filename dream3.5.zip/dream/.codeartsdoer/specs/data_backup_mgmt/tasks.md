# 数据备份与免责声明组件 - 编码任务清单

> 本任务清单基于 `.codeartsdoer/specs/data_backup_mgmt/spec.md`（需求规格）与 `design.md`（实现方案）生成。
> 项目技术栈：纯前端 vanilla JS + localStorage，无 Node 后端，无外部 API。命名采用 camelCase。
> 任务按依赖关系排序，被依赖者在前；每个任务可独立验证。

---

## 1. 集中本应用数据键常量（基础设施）

**目标**：将散落在 `campService.js`、`campApiService.js` 中的硬编码键名集中到 `constants.js`，建立"本应用相关数据键集合"的单一来源，为后续导出/导入/清空提供遍历依据。
**依赖**：无（最先执行，是后续所有备份任务的基石）。
**影响范围**：纯增量常量 + 等价替换，不改动现有 `DATA_KEY` 值，所有现存读取逻辑行为不变。

### 1.1 在 constants.js 补齐 STORAGE_KEYS 三键与 APP_DATA_KEYS 数组
- [ ] 修改 `src/constants.js`：在 `STORAGE_KEYS` 对象中新增 `CAMPS_KEY: 'dream_camps_data'` 与 `JOINED_KEY: 'dream_joined_camps'` 两个键名（保持 `DATA_KEY: 'dream_saving_camp_data'` 不变）。
- [ ] 在 `src/constants.js` 中新增导出 `export const APP_DATA_KEYS = [STORAGE_KEYS.DATA_KEY, STORAGE_KEYS.CAMPS_KEY, STORAGE_KEYS.JOINED_KEY]`，作为"本应用相关数据键集合"的单一来源。
- [ ] 验收：在浏览器控制台执行 `import('./src/constants.js').then(m => console.log(m.APP_DATA_KEYS))`，输出为 `['dream_saving_camp_data', 'dream_camps_data', 'dream_joined_camps']` 三个字符串，长度为 3，无重复。

### 1.2 campService.js 改为从 constants 引用键名
- [ ] 修改 `src/services/campService.js`：删除文件顶部局部常量 `const CAMPS_KEY = 'dream_camps_data'` 与 `const JOINED_KEY = 'dream_joined_camps'`，改为 `import { STORAGE_KEYS } from '../constants.js'`，并将文件内所有 `CAMPS_KEY` 引用替换为 `STORAGE_KEYS.CAMPS_KEY`、`JOINED_KEY` 替换为 `STORAGE_KEYS.JOINED_KEY`。
- [ ] 验收：在浏览器中打开应用，进入储蓄营列表页 `#/camps`，能正常加载已有储蓄营数据（无报错、列表渲染与改动前一致）；新建一个储蓄营并加入，刷新页面后数据仍在，证明键名替换为等价替换。

### 1.3 campApiService.js 改为从 constants 引用键名
- [ ] 修改 `src/services/campApiService.js`：删除局部常量 `const JOINED_KEY = 'dream_joined_camps'`，改为 `import { STORAGE_KEYS } from '../constants.js'`，将文件内 `JOINED_KEY` 引用替换为 `STORAGE_KEYS.JOINED_KEY`。
- [ ] 验收：在浏览器中执行"加入储蓄营"流程（通过邀请码加入），刷新页面后已加入小组记录仍在（`localStorage.getItem('dream_joined_camps')` 返回非空数组），证明替换无行为变化。

---

## 2. 实现数据备份服务模块（backupService.js）

**目标**：新增纯业务逻辑层 `src/services/backupService.js`，提供导出、校验、导入写入、清空四个方法，不依赖 DOM，仅依赖 `constants` 与 `localStorage`/`JSON`，可独立单测。
**依赖**：任务组 1（需 `APP_DATA_KEYS` 与 `DATA_VERSION` 已就绪）。
**影响范围**：新增文件，不触碰任何现有 service 业务方法，不触发 `localStorageAdapter.initData/saveData`（避免触发 fetch）。

### 2.1 新建 backupService.js 文件骨架与 exportData 方法
- [ ] 新建 `src/services/backupService.js`，导入 `{ APP_DATA_KEYS, STORAGE_KEYS, DATA_VERSION }` from `'../constants.js'`。
- [ ] 实现 `exportData()`：遍历 `APP_DATA_KEYS`，对每个键执行 `localStorage.getItem(key)` 读取原始字符串并 `JSON.parse`（缺失键兜底为空值：主数据键缺失时返回 `{goals:[],records:[],checkIns:[],camps:[],achievements:[]}`，`dream_camps_data` 缺失返回 `{camps:[]}`，`dream_joined_camps` 缺失返回 `[]`）；组装为 `{ _version: DATA_VERSION, dream_saving_camp_data, dream_camps_data, dream_joined_camps }` 对象（字段名直接使用键名）；全部 try/catch，读取抛错返回 `{ success: false, error: '导出失败，浏览器存储不可用，请检查浏览器设置' }`，序列化抛错返回 `{ success: false, error: '导出失败，数据异常，请联系开发者' }`，成功返回 `{ success: true, data: <备份对象> }`。
- [ ] 验收：在浏览器控制台执行 `import('./src/services/backupService.js').then(m => m.backupService.exportData())`，返回对象 `success === true` 且 `data._version === 1`，`data.dream_saving_camp_data`、`data.dream_camps_data`、`data.dream_joined_camps` 三个字段均存在；当 localStorage 为空时，三个字段分别为空数据对象、`{camps:[]}`、`[]`。

### 2.2 实现 validateBackup 纯函数校验器
- [ ] 在 `backupService.js` 实现 `validateBackup(parsed)`：纯函数，不触碰 localStorage。校验顺序：① `parsed` 非对象（`typeof !== 'object'` 或 `null`）→ `{ valid: false, reason: '文件格式不合法，非本应用备份文件' }`；② 缺 `_version` 字段或非整数 → 同前原因；③ `_version > DATA_VERSION` → `{ valid: false, reason: '备份文件版本过高，请升级应用后重试' }`；④ 缺 `dream_saving_camp_data` 字段或其非对象，或该对象缺 `goals`/`records`/`checkIns`/`achievements` 四个数组字段 → `{ valid: false, reason: '文件格式不合法，非本应用备份文件' }`；⑤ `dream_camps_data` 与 `dream_joined_camps` 缺失不视为不合法（早期版本兼容）；⑥ 全部通过 → `{ valid: true }`。
- [ ] 验收：在控制台对 4 类输入分别调用 `validateBackup`：a) `null` → `valid:false`；b) `{_version:2, dream_saving_camp_data:{goals:[],records:[],checkIns:[],achievements:[]}}` → `valid:false, reason` 含"版本过高"；c) `{_version:1}` → `valid:false, reason` 含"格式不合法"；d) `{_version:1, dream_saving_camp_data:{goals:[],records:[],checkIns:[],achievements:[]}}` → `valid:true`。校验过程不修改 localStorage（前后 `localStorage.length` 不变）。

### 2.3 实现 applyImport 覆盖写入方法
- [ ] 在 `backupService.js` 实现 `applyImport(parsed)`：对 `APP_DATA_KEYS` 三个键执行 `localStorage.setItem(key, JSON.stringify(value))`，其中 `value` 取 `parsed[key]`，缺失的 `dream_camps_data` 写入 `{camps:[]}`、`dream_joined_camps` 写入 `[]`；**直接使用原生 `localStorage.setItem`，绕过 `localStorageAdapter.write`**（因其强制改 `_version`，会破坏备份文件原始版本）；不主动改写 goal 对象的 `allowWithdraw`/`pendingWithdrawDetail`（兼容性由 goalService 兜底）；try/catch，写入抛错返回 `{ success: false, error: '导入失败，本地存储空间不足或不可用' }`，成功返回 `{ success: true }`。
- [ ] 验收：先在控制台构造一个合法备份对象（含一个 goal），调用 `applyImport` 后 `localStorage.getItem('dream_saving_camp_data')` 包含该 goal；再调用 `applyImport` 传入缺 `dream_camps_data` 的对象，写入后 `localStorage.getItem('dream_camps_data')` 等于 `JSON.stringify({camps:[]})`；写入前后 `_version` 字段保留备份原值（不被强制改为当前版本）。

### 2.4 实现 clearAllData 清空方法
- [ ] 在 `backupService.js` 实现 `clearAllData()`：对 `APP_DATA_KEYS` 三个键执行 `localStorage.removeItem(key)`，**仅移除本应用键，不触碰其他键**；try/catch，移除抛错返回 `{ success: false, error: '清空失败，浏览器存储不可用，请手动清理浏览器数据' }`，成功返回 `{ success: true }`。
- [ ] 验收：先在 localStorage 写入本应用三个键与一个无关键（如 `other_app_data = 'xxx'`），调用 `clearAllData` 后，三个本应用键均 `null`，而 `localStorage.getItem('other_app_data')` 仍为 `'xxx'`（证明不误删非本应用键）。

---

## 3. 实现文件下载/读取工具模块（fileUtils.js）

**目标**：新增 `src/utils/fileUtils.js`，封装浏览器原生文件下载与文件选择能力，不依赖业务常量。
**依赖**：无（可与任务组 2 并行）。
**影响范围**：新增文件，纯浏览器 I/O 工具。

### 3.1 实现 downloadJson 文件下载方法
- [ ] 新建 `src/utils/fileUtils.js`，实现 `downloadJson(filename, obj)`：将 `obj` 通过 `JSON.stringify` 序列化为字符串，构造 `new Blob([jsonStr], { type: 'application/json' })`，`URL.createObjectURL(blob)` 生成临时 URL，创建 `<a download={filename} href={url}>`，`document.body.appendChild` 后触发 `a.click()`，随后 `document.body.removeChild(a)` 与 `URL.revokeObjectURL(url)` 释放；try/catch，序列化或 DOM 操作抛错返回 `{ success: false, error: '导出失败，数据异常' }`，成功返回 `{ success: true }`。
- [ ] 验收：在控制台执行 `import('./src/utils/fileUtils.js').then(m => m.fileUtils.downloadJson('test-backup.json', {a:1,b:2}))`，浏览器触发下载，下载的文件用文本编辑器打开内容为 `{"a":1,"b":2}`，文件名为 `test-backup.json`；调用后无内存泄漏（`URL.revokeObjectURL` 已执行，可通过 Performance API 或无控制台报错间接验证）。

### 3.2 实现 pickJsonFile 文件选择方法
- [ ] 在 `fileUtils.js` 实现 `pickJsonFile()`：返回 Promise；创建 `<input type="file" accept="application/json,.json">`，`input.style.display = 'none'`，`document.body.appendChild(input)`；监听 `change` 事件，取 `input.files[0]`，调用 `file.text()`（或 `FileReader.readAsText`）读取为字符串，`JSON.parse` 后 resolve `{ parsed, filename: file.name }`；监听 `change` 若 `input.files.length === 0` 视为取消，reject `{ canceled: true }`；`JSON.parse` 抛错 reject `{ parseError: true }`；触发 `input.click()` 打开选择框；完成后 `document.body.removeChild(input)`。需处理"用户直接关闭对话框不触发 change"的边界（可借助 `window.focus` 事件 + 短延时检测，或接受该边界由调用方按取消处理）。
- [ ] 验收：在控制台执行 `import('./src/utils/fileUtils.js').then(m => m.fileUtils.pickJsonFile())`，浏览器弹出文件选择对话框；选择一个合法 JSON 文件后 Promise resolve，`parsed` 为解析后的对象，`filename` 为所选文件名；选择一个非 JSON 文本文件（如 `.txt`）后 Promise reject 且 `parseError === true`；不选择直接关闭对话框时 Promise reject（`canceled === true` 或无响应，调用方按取消处理）。

---

## 4. 实现全局免责声明组件并集成到首页

**目标**：新增 `src/views/disclaimerView.js` 纯展示组件，并在 `homeView.render()` 中追加免责声明元素与设置入口元素，保证首屏可见区域内常驻展示。
**依赖**：无（可与任务组 2、3 并行；但集成到 homeView 需在任务组 1 完成后，避免合并冲突）。
**影响范围**：新增文件 + `homeView.js` 追加两行 append 调用，不改动现有 hero/stats/motivation/badges/goals 分区逻辑。

### 4.1 新建 disclaimerView.js 纯展示组件
- [ ] 新建 `src/views/disclaimerView.js`，实现 `render()`：返回一个 `HTMLElement`（`document.createElement('div')`，className 为 `home-disclaimer`），内含图标 `<span class="home-disclaimer-icon">💡</span>` 与文案 `<span class="home-disclaimer-text">本应用为模拟记账，不涉及真实资金交易</span>`（文案**逐字固定**，不得修改措辞）；无外部依赖，无事件监听，纯展示。
- [ ] 验收：在控制台执行 `import('./src/views/disclaimerView.js').then(m => m.disclaimerView.render())`，返回一个 DOM 元素，`className` 含 `home-disclaimer`，`textContent` 含完整文案"本应用为模拟记账，不涉及真实资金交易"。

### 4.2 在 homeView.js 追加免责声明与设置入口
- [ ] 修改 `src/views/homeView.js`：在文件顶部新增 `import { disclaimerView } from './disclaimerView.js'`。
- [ ] 在 `homeView.render()` 中，于 `page.appendChild(this._renderGoalsSection(goals))` 之后追加 `page.appendChild(disclaimerView.render())` 与 `page.appendChild(this._renderSettingsEntry())`，保证免责声明与设置入口常驻首页末尾（首屏可见区域内）。
- [ ] 在 `homeView` 对象中新增私有方法 `_renderSettingsEntry()`：构造一个 `<button class="home-settings-entry btn btn-secondary">`，内含齿轮图标 `⚙` 与文字"数据管理"，点击事件 `() => { window.location.hash = '#/settings'; }`，返回该按钮元素。
- [ ] 验收：打开应用首页 `#/`，页面底部出现免责声明区域（淡绿底、含 💡 图标与完整文案）与"数据管理"按钮；点击"数据管理"按钮后 `window.location.hash` 变为 `#/settings`；多次刷新首页，免责声明每次均渲染（常驻，不随操作隐藏）；现有 hero/stats/motivation/badges/goals 分区渲染与改动前完全一致（无错位、无报错）。

---

## 5. 实现设置视图模块并集成路由

**目标**：新增 `src/views/settingsView.js` 渲染数据管理聚合页（导出/导入/清空三操作入口），并在 `main.js` 路由中新增 `#/settings` 分支。
**依赖**：任务组 1（constants）、任务组 2（backupService）、任务组 3（fileUtils）；任务组 4 的设置入口按钮（首页可达性）。
**影响范围**：新增文件 + `main.js` 追加一个路由分支，不影响现有路由。

### 5.1 新建 settingsView.js 渲染聚合页骨架
- [ ] 新建 `src/views/settingsView.js`，导入 `{ backupService }` from `'../services/backupService.js'`、`{ fileUtils }` from `'../utils/fileUtils.js'`、`{ modal }` from `'./modal.js'`。
- [ ] 实现 `render()`：清空 `#app`，构造 `.settings-page` 容器，内含：① 页面标题"数据管理"与返回首页按钮（点击 `location.hash = '#/'`）；② 三张 `.settings-card` 卡片纵向排列：导出数据（`.btn-primary` 绿色，含 📥 图标、文字"导出数据"、说明"将全部数据下载为 JSON 文件"）、导入数据（`.btn-secondary` 灰色，含 📤 图标、文字"导入数据"、说明"从 JSON 备份恢复数据，将覆盖现有数据"）、清空所有数据（`.btn-danger` 红色 + `.settings-card-danger` 警示边框，含 🗑 图标、文字"清空所有数据"、说明"移除全部本地数据，不可恢复"，与上两张卡片间距加大）；③ 三个入口均含文字标签（非仅图标）；将 `.settings-page` append 到 `#app`。
- [ ] 验收：在浏览器地址栏输入 `#/settings`（此时路由尚未集成，需临时在控制台调用 `settingsView.render()` 验证），页面渲染三张卡片，三张卡片均有文字标签与说明，清空卡片视觉与导出/导入卡片明显区分（红色 + 警示边框）；点击返回首页按钮 `location.hash` 变为 `#/`。

### 5.2 绑定导出按钮事件
- [ ] 在 `settingsView.render()` 中为导出按钮绑定 click 事件：调用 `backupService.exportData()`，若 `!result.success` 则 `modal.toast(result.error)` 并 return；构造文件名 `dream-backup-YYYYMMDD-HHmm.json`（时间取 `new Date()`，年月日时分均补零至 2 位）；调用 `fileUtils.downloadJson(filename, result.data)`，若 `dl.success` 则 `modal.toast('导出成功')`，否则 `modal.toast(dl.error)`。
- [ ] 验收：在设置页点击"导出数据"，浏览器触发下载，文件名形如 `dream-backup-20261013-2245.json`，文件内容为合法 JSON，顶层含 `_version` 与三个键名字段；页面顶部出现"导出成功"toast；导出耗时 < 1 秒（spec 4.1 性能要求）。

### 5.3 绑定导入按钮事件（含校验与二次确认）
- [ ] 在 `settingsView.render()` 中为导入按钮绑定 click 事件：`async` 处理；`try { const { parsed } = await fileUtils.pickJsonFile(); ... } catch (e) { if (e.canceled) return; if (e.parseError) modal.toast('文件解析失败，请确认其为本应用导出的 JSON 备份'); return; }`；文件读取成功后调用 `backupService.validateBackup(parsed)`，若 `!v.valid` 则 `modal.toast(v.reason)` 并 return；校验通过后调用 `modal.show('导入将覆盖现有全部数据且不可恢复，是否继续？', onConfirm, onCancel)`，`onConfirm` 中调用 `backupService.applyImport(parsed)`，若 `r.success` 则 `location.reload()`，否则 `modal.toast(r.error)`；`onCancel` 无操作（数据不变）。
- [ ] 验收：在设置页点击"导入数据"，弹出文件选择对话框；选择非 JSON 文件 → toast"文件解析失败..."，现有数据不变；选择缺核心字段的 JSON → toast"文件格式不合法..."，现有数据不变；选择版本过高的备份 → toast"备份文件版本过高..."，现有数据不变；选择合法备份 → 弹出确认弹窗"导入将覆盖现有全部数据且不可恢复，是否继续？"，点取消 → 弹窗关闭、数据不变、无错误提示，点确认 → 页面刷新、首页展示导入后的储蓄目标与打卡数据；导入校验耗时 < 2 秒（spec 4.1）。

### 5.4 绑定清空按钮事件（二次确认 + 危险区分）
- [ ] 在 `settingsView.render()` 中为清空按钮绑定 click 事件：调用 `modal.show('将清空全部储蓄目标、打卡记录、储蓄营等数据且不可恢复，是否继续？', onConfirm, onCancel)`，`onConfirm` 中调用 `backupService.clearAllData()`，若 `r.success` 则 `location.reload()`，否则 `modal.toast(r.error)`；`onCancel` 无操作。
- [ ] 验收：在设置页点击"清空所有数据"（红色按钮），弹出确认弹窗，弹窗文案含"清空全部"与"不可恢复"明确警示，确认按钮为红色危险样式；点取消 → 弹窗关闭、数据不变；点确认 → 页面刷新、首页展示空状态（无目标、连续天数归零、储蓄营列表为空）；清空耗时 < 500 毫秒（spec 4.1）；清空后 `localStorage.getItem('dream_saving_camp_data')`、`getItem('dream_camps_data')`、`getItem('dream_joined_camps')` 均为 `null`。

### 5.5 在 main.js 路由新增 #/settings 分支
- [ ] 修改 `src/main.js`：在文件顶部新增 `import { settingsView } from './views/settingsView.js'`。
- [ ] 在 `router()` 函数中，于 `hash === '#/camps'` 等分支同级位置新增 `else if (hash === '#/settings') { settingsView.render(); }` 分支。
- [ ] 验收：在浏览器地址栏输入 `#/settings` 回车，页面渲染设置聚合页（三张卡片）；从首页点击"数据管理"按钮可跳转至设置页；从设置页点击返回首页按钮可跳回 `#/`；现有路由 `#/`、`#/camps`、`#/camp/new`、`#/camp/join`、`#/goal/*` 等均正常工作（无路由冲突、无 404 兜底）。

---

## 6. 追加样式（main.css）

**目标**：在 `src/styles/main.css` 末尾追加免责声明与设置页样式，沿用现有 CSS 变量（Minimalist Modern 风格），不改动现有规则。
**依赖**：任务组 4（disclaimerView 已使用 `.home-disclaimer` 类名）、任务组 5（settingsView 已使用 `.settings-*` 类名）。
**影响范围**：纯样式增量，不影响现有规则。

### 6.1 追加免责声明样式
- [ ] 在 `src/styles/main.css` 末尾追加 `.home-disclaimer` 样式：`background: var(--color-primary-light)`（淡绿底）、`border: 1px solid var(--color-border)`、`border-radius: var(--radius-md)`、`padding: 12px 16px`、`margin-top: 16px`、`display: flex`、`align-items: center`、`gap: 8px`；`.home-disclaimer-icon` 样式：`color: var(--color-text-muted)`；`.home-disclaimer-text` 样式：`color: var(--color-text-light)`、`font-size: 13px`、`line-height: 1.5`（≥ 辅助文本字号，不致过小被忽略）。
- [ ] 验收：打开首页，免责声明区域呈淡绿底、淡边框、圆角，图标与文案横向排列，文案颜色弱于正文但清晰可读；在窄屏（如 375px 宽）下文案不溢出、不换行错乱（依赖现有 `word-break` 或追加 `word-break: break-word`）。

### 6.2 追加设置入口与设置页样式
- [ ] 在 `src/styles/main.css` 末尾追加 `.home-settings-entry` 样式（首页"数据管理"按钮，沿用 `.btn-secondary` 基础上追加 `margin-top: 16px`、`width: 100%` 或合适宽度）。
- [ ] 追加 `.settings-page`、`.settings-card`、`.settings-card-danger`、`.settings-card-title`、`.settings-card-desc` 等样式：`.settings-page` 含 `max-width`、`margin: 0 auto`、`padding`；`.settings-card` 含 `background: var(--color-surface)`、`border: 1px solid var(--color-border)`、`border-radius: var(--radius-md)`、`padding: 16px`、`margin-bottom: 12px`、`display: flex`、`align-items: center`、`gap: 12px`；`.settings-card-danger` 含 `border-color: var(--color-danger)`（红色警示边框）、`margin-top: 24px`（与上两张卡片间距加大）；按钮沿用现有 `.btn-primary`/`.btn-secondary`/`.btn-danger`。
- [ ] 追加 `.modal-message` 样式补强（如现有不足）：`line-height: 1.5`、`max-width: 80vw`、`word-break: break-word`，保证长警示文案（如"将清空全部储蓄目标、打卡记录、储蓄营等数据且不可恢复，是否继续？"）在窄屏不溢出、可读。
- [ ] 验收：打开设置页 `#/settings`，三张卡片纵向排列、视觉协调；清空卡片有红色警示边框且与上两张卡片间距明显加大；点击导入/清空弹出确认弹窗，长文案在弹窗内完整展示、不溢出、可读；整体风格与首页极简现代风格一致（沿用同一套 CSS 变量）。

---

## 7. 集成测试与回归验证

**目标**：验证新增备份/免责声明功能可用，且不影响现有打卡、储蓄营、储蓄目标、成就等功能。
**依赖**：任务组 1–6 全部完成。
**影响范围**：仅测试，不改动代码。

### 7.1 验证导出→清空→导入完整闭环
- [ ] 在浏览器中先创建若干储蓄目标、打卡若干天、加入若干储蓄营，作为"原始数据集"。
- [ ] 进入设置页点击"导出数据"，确认下载 JSON 文件，记录文件名与内容。
- [ ] 点击"清空所有数据"并确认，页面刷新后首页为空状态。
- [ ] 点击"导入数据"选择刚才下载的 JSON，确认覆盖，页面刷新后首页恢复"原始数据集"（储蓄目标、打卡连续天数、储蓄营列表均与导出前一致）。
- [ ] 验收：导出→清空→导入闭环后，应用状态与原始数据集完全一致；中间无数据丢失或字段错乱。

### 7.2 验证不影响现有打卡功能
- [ ] 执行任务 7.1 闭环后，进入目标详情页执行一次打卡，确认打卡成功、连续天数正确递增；导出当前数据后清空再导入，再次进入目标详情页，打卡记录与连续天数与导入前一致。
- [ ] 验收：打卡功能（`habitService.getStreakDays`、`habitService.checkIn`）在备份/恢复前后行为一致；清空后连续天数归零、无残留打卡记录。

### 7.3 验证不影响现有储蓄营功能
- [ ] 执行任务 7.1 闭环后，进入储蓄营列表页 `#/camps`，确认已加入的储蓄营仍可见；进入某储蓄营详情页，确认留言、成员列表与导出前一致；新建一个储蓄营并加入，刷新后数据持久化正常。
- [ ] 验收：储蓄营功能（`campService`/`campApiService`）在备份/恢复前后行为一致；清空后储蓄营列表为空、已加入小组记录为空。

### 7.4 验证不影响现有储蓄目标与冷静期功能
- [ ] 执行任务 7.1 闭环后，新建一个储蓄目标（含 `allowWithdraw: false` 与 `allowWithdraw: true` 两种），对允许支取的目标发起提前支取并进入冷静期，导出当前数据后清空再导入，确认冷静期状态（`pendingWithdrawDetail`）与导入前一致；对缺失 `allowWithdraw` 字段的旧数据导入后，goalService 读取时默认视为允许支取（与旧数据兼容约定一致）。
- [ ] 验收：储蓄目标 CRUD、提前支取冷静期（`goalService.requestWithdraw/confirmWithdraw/getWithdrawStatus`）在备份/恢复前后行为一致；旧数据兼容约定（缺失 `allowWithdraw` 视为 true、缺失 `pendingWithdrawDetail` 默认 48h 全额）在导入后仍生效。

### 7.5 验证异常场景与边界
- [ ] 异常场景测试：a) 导入非 JSON 文件（如 `.txt`）→ toast"文件解析失败..."；b) 导入缺核心字段的 JSON（如 `{_version:1}`）→ toast"文件格式不合法..."；c) 导入版本过高备份（`_version: 999`）→ toast"备份文件版本过高..."；d) 导入空数据备份（各字段为空数组/空对象）→ 成功导入、首页空状态；e) 导出空数据（应用无任何业务数据）→ 成功导出含空集合与版本标识的 JSON；f) 清空时点取消 → 数据不变；g) 导入时点取消 → 数据不变。
- [ ] 验收：7 个异常/边界场景均按 spec 5.1.3/5.2.3/5.4.3 预期行为执行，现有数据在所有失败场景下保持不变（无部分写入中间状态）。

### 7.6 验证免责声明常驻与样式
- [ ] 多次刷新首页、从其他页面返回首页，确认免责声明每次均渲染、文案逐字为"本应用为模拟记账，不涉及真实资金交易"、位于首屏可见区域、不在折叠区域、字号不小于首页辅助文本字号。
- [ ] 验收：免责声明满足 spec 5.3.1 全部 5 条业务规则（内容、位置、常驻、样式、禁止项）。

---

## 8. 部署与配置

**目标**：提供清旧数据重测说明与必要的配置项确认，确保功能可上线、可重测。
**依赖**：任务组 1–7 全部完成。
**影响范围**：无代码改动，仅文档与配置确认。

### 8.1 整理本次修改文件清单与清旧数据重测说明
- [ ] 整理本次新增/修改文件清单：新增 `src/services/backupService.js`、`src/utils/fileUtils.js`、`src/views/disclaimerView.js`、`src/views/settingsView.js`；修改 `src/constants.js`、`src/services/campService.js`、`src/services/campApiService.js`、`src/views/homeView.js`、`src/main.js`、`src/styles/main.css`。
- [ ] 编写清旧数据重测说明：在浏览器 DevTools → Application → Local Storage 中删除 `dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps` 三个键后刷新页面，即可回到初始空状态重新测试；或直接在设置页点击"清空所有数据"。
- [ ] 验收：清旧数据后刷新页面，首页为空状态，无控制台报错；新增功能可在空状态下正常工作（导出空数据、导入空数据、清空空数据）。

### 8.2 确认配置项取值
- [ ] 确认导出文件名格式为 `dream-backup-YYYYMMDD-HHmm.json`（时间取 `new Date()`，便于多次备份区分）。
- [ ] 确认导出 JSON 顶层字段名为 `_version`、`dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps`（直接以键名为字段名，便于人工核查）。
- [ ] 确认导入版本兼容阈值：`_version > DATA_VERSION` 中止；`_version < DATA_VERSION` 宽松导入（依赖 goalService 兜底）；`_version === DATA_VERSION` 正常导入。
- [ ] 验收：三项配置项取值与 design.md 2.1.2 节"配置项及取值策略"一致，已在代码中硬编码且与现有 `DATA_VERSION = 1` 协同。

---

## 9. 评审与最终验证

**目标**：对关键代码进行 Review，核对设计与实现一致性，确认变更范围。
**依赖**：任务组 1–8 全部完成。
**影响范围**：无代码改动，仅评审记录。

### 9.1 代码审查关键点
- [ ] 审查 `backupService.js`：确认 `applyImport` 使用原生 `localStorage.setItem` 而非 `localStorageAdapter.write`（避免 `_version` 被强制改写）；确认 `clearAllData` 仅遍历 `APP_DATA_KEYS` 三个键、不触碰其他键；确认所有方法 try/catch 且返回值结构统一。
- [ ] 审查 `fileUtils.js`：确认 `downloadJson` 已 `URL.revokeObjectURL` 释放无内存泄漏；确认 `pickJsonFile` 的 `<input>` 触发后已从 DOM 移除。
- [ ] 审查 `settingsView.js`：确认导入流程顺序为"读取→校验→确认→写入→刷新"，校验失败时不写入；确认清空流程有二次确认。
- [ ] 审查 `homeView.js`/`main.js` 改动：确认仅为追加调用与追加分支，未改动现有分区逻辑与现有路由分支。
- [ ] 验收：4 个审查点均通过，无遗漏；关键代码无 `console.log` 调试残留。

### 9.2 设计与实现一致性核对
- [ ] 核对 spec 5.1–5.5 全部业务规则与验收条件，逐条在浏览器中验证通过。
- [ ] 核对 design.md 2.2.2 接口清单中 8 个接口的签名与返回值结构，与实现一致。
- [ ] 核对 design.md 2.3.2 备份文件对象结构（`BackupObject`/`MainData`/`CampsData`/`JoinedCamp`），导出文件结构与设计一致。
- [ ] 验收：spec 与 design 的全部条目在实现中均有对应，无遗漏、无偏离。

### 9.3 变更范围最终确认
- [ ] 确认本次变更仅涉及任务 8.1 所列 4 个新增文件与 6 个修改文件，无其他文件被改动。
- [ ] 确认无新增第三方依赖（纯前端 vanilla JS + 浏览器原生 API）。
- [ ] 确认无付费/商业授权组件引入（符合偏好）。
- [ ] 验收：变更范围与 design.md 1.1.3 节"集成点清单"一致，无范围蔓延。