# 引力场 UI 提示优化 · 编码任务列表

> 改动范围：仅 `src/constants.js`、`src/views/campFormView.js`、`src/views/campJoinView.js`、`src/views/campListView.js`、`src/styles/main.css` 五个文件。
> 不修改：`campService.js`、`modal.js`、`main.js`、`index.html`、路由、localStorage 结构。
> 命名约定：JS 变量/方法用 camelCase；CSS 类名沿用项目既有 kebab-case 风格（与 `.form-hint`、`.camp-list-actions` 一致）。

---

## 1. 基础设施：文案常量与样式类

### 1.1 在 constants.js 新增 CAMP_UI_HINTS 文案常量
- [ ] 在 `src/constants.js` 文件末尾追加导出常量 `CAMP_UI_HINTS`，结构为 `{ DISCLAIMER_HINT, HELP_TITLE, HELP_CONTENT }`，满足 spec 4.4.1 集中维护
- [ ] `DISCLAIMER_HINT` 取值固定为 `'💡 提示：本功能为纯前端模拟，组队码仅在当前电脑/浏览器内生效。用于演示多人互动效果。'`（与 spec 6.1 字符级一致，不得改写）
- [ ] `HELP_TITLE` 取值为 `'如何测试多人加入'`
- [ ] `HELP_CONTENT` 取值为多行纯用户操作指引文本，必须包含核心句"请打开无痕窗口模拟另一个成员加入"，不得出现 localStorage 键名、代码路径等技术术语（满足 spec 5.3.1 禁止项 5）
- [ ] 不修改 `STORAGE_KEYS`、`CAMP_RULES` 等既有常量，仅在文件末尾新增

**验收标准**：浏览器控制台执行 `import('./src/constants.js')` 可拿到 `CAMP_UI_HINTS`，三字段均为非空字符串；`DISCLAIMER_HINT` 与 spec 6.1 完全一致；`HELP_CONTENT` 含"请打开无痕窗口模拟另一个成员加入"且不含 `dream_camps_data`/`localStorage`/`campService` 等技术词。

---

## 1.2 在 main.css 新增 5 个 CSS 类
- [ ] 在 `src/styles/main.css` 文件末尾追加 `.form-disclaimer` 类：`font-size:0.72rem`、`color:var(--color-text-muted)`、`opacity:0.85`、`text-align:center`、`margin-top:12px`、`line-height:1.5`，视觉弱于 `.form-hint`（0.8rem），满足 spec 5.1.1 规则 3
- [ ] 追加 `.camp-help-fab` 类：`position:fixed`、`right:32px`、`bottom:32px`、`width:48px`、`height:48px`、`border-radius:50%`、`border:1.5px solid var(--color-primary)`、`background:var(--color-card)`、`color:var(--color-primary)`、`font-size:1.4rem`、`font-weight:600`、`box-shadow:var(--shadow-lg)`、`cursor:pointer`、`z-index:900`、`transition:all 0.2s var(--ease-out)`，复用既有 CSS 变量保证极简现代风格一致
- [ ] 追加 `.camp-help-fab:hover` 状态：`transform:scale(1.06)`，与全站按钮 hover 风格一致
- [ ] 追加 `.camp-help-overlay` 类：复用 `.modal-overlay` 视觉（`position:fixed`、`inset:0`、`background:rgba(10,10,26,0.45)`、`backdrop-filter:blur(6px)`、`display:flex`、`align-items:center`、`justify-content:center`、`z-index:1000`、`animation:fadeIn 0.25s var(--ease-out)`）
- [ ] 追加 `.camp-help-dialog` 类：复用 `.modal-dialog` 视觉（`background:var(--color-card)`、`border-radius:var(--radius-lg)`、`box-shadow:var(--shadow-lg)`、`padding:24px`、`max-width:360px`、`width:86vw`、`animation:slideUp 0.3s var(--ease-out)`）
- [ ] 追加 `.camp-help-close` 类：单关闭按钮样式，`margin-top:16px`、`align-self:flex-end`，复用 `.btn .btn-secondary` 视觉 token（`border-radius:var(--radius-lg)`、`padding:8px 18px`、`cursor:pointer`）
- [ ] 不修改既有 `.form-hint`、`.modal-overlay`、`.modal-dialog` 等类，仅追加新类

**验收标准**：浏览器 DevTools 在 `#/camps` 页面可查到 `.camp-help-fab` 计算样式 `position:fixed`、`right:32px`、`bottom:32px`；在创建/加入页可查到 `.form-disclaimer` 计算样式 `font-size` 换算后小于 `.form-hint` 的字号；既有页面样式无回归（首页、打卡页视觉无变化）。

---

## 2. 免责提示渲染（创建/加入表单）

### 2.1 在 campFormView.render 末尾追加免责提示节点
- [ ] 在 `src/views/campFormView.js` 顶部 import 区追加 `import { CAMP_UI_HINTS } from '../constants.js';`（与既有 `CAMP_RULES` import 合并到同一行或新增一行均可）
- [ ] 在 `campFormView.render` 内 `form.innerHTML += …` 语句之后、`container.appendChild(form)` 之前，新增约 4 行：判空 `if (CAMP_UI_HINTS.DISCLAIMER_HINT)` → `const disclaimer = document.createElement('p')` → `disclaimer.className = 'form-disclaimer'` → `disclaimer.textContent = CAMP_UI_HINTS.DISCLAIMER_HINT` → `form.appendChild(disclaimer)`
- [ ] 不得改写既有 `hint.textContent`（"创建后系统会生成一个6位组队码…"），保证两者并存（满足 spec 5.1.4）
- [ ] 不得改动 `camp-submit`/`camp-cancel` 事件绑定逻辑与 `campService.create` 调用

**验收标准**：访问 `#/camp/new` → 输入区下方可见灰色小字"💡 提示：本功能为纯前端模拟…"，且原"创建后系统会生成一个6位组队码…"提示仍在；填写表单点击"创建小组"流程正常，组队码正常生成并跳转详情页。

---

## 2.2 在 campJoinView.render 末尾追加免责提示节点
- [ ] 在 `src/views/campJoinView.js` 顶部 import 区追加 `import { CAMP_UI_HINTS } from '../constants.js';`
- [ ] 在 `campJoinView.render` 内 `form.innerHTML += …` 语句之后、`container.appendChild(form)` 之前，新增与 2.1 相同的 4 行免责提示追加逻辑（`p.form-disclaimer` + `CAMP_UI_HINTS.DISCLAIMER_HINT`）
- [ ] 不得改写既有 `hint.textContent`（"输入搭子分享的6位组队码，一起存钱"）
- [ ] 不得改动 `join-code` 输入过滤（`\D` 正则）、`join-submit`/`join-cancel` 事件绑定与 `campService.join` 调用

**验收标准**：访问 `#/camp/join` → 组队码输入框下方可见灰色免责小字，文案与创建页完全一致，原"输入搭子分享的6位组队码…"提示仍在；输入组队码与昵称提交流程不受影响。

---

## 3. 悬浮帮助按钮与弹层（引力场列表页）

### 3.1 在 campListView.render 追加悬浮问号按钮
- [ ] 在 `src/views/campListView.js` 顶部 import 区追加 `import { CAMP_UI_HINTS } from '../constants.js';`
- [ ] 在 `campListView.render` 内 `app.appendChild(page)` 之前，新增约 6 行：创建 `const helpFab = document.createElement('button')` → `helpFab.className = 'camp-help-fab'` → `helpFab.type = 'button'` → `helpFab.setAttribute('aria-label', '如何测试多人加入')` → `helpFab.textContent = '?'` → `page.appendChild(helpFab)`
- [ ] 按钮 append 到 `page`（在 `app` 内），不 append 到 `document.body`，保证路由切换 `app.innerHTML=''` 时自动销毁（满足 spec 5.3 数据约束 4，仅在 `#/camps` 展示）

**验收标准**：访问 `#/camps` → 页面右下角可见圆形问号悬浮按钮，按钮固定不随列表滚动消失；切换到 `#/`、`#/camp/new`、`#/camp/join` 等路由后悬浮按钮消失；按钮不遮挡顶部"新建小组""加入小组"按钮。

---

### 3.2 实现帮助弹层切换与关闭逻辑
- [ ] 在 `campListView.render` 内悬浮按钮创建之后，为 `helpFab` 绑定 `click` 事件：先 `const existing = document.getElementById('camp-help-overlay')` 判断弹层是否已存在 → 存在则 `existing.remove()` 并 `return`（切换关闭，避免叠加，满足 spec 5.3.3 异常 1）→ 不存在则创建弹层
- [ ] 创建弹层 DOM 结构：`div.camp-help-overlay#camp-help-overlay` > `div.camp-help-dialog` > [`h3.camp-help-title`（textContent = `CAMP_UI_HINTS.HELP_TITLE`）、`p.camp-help-content`（textContent = `CAMP_UI_HINTS.HELP_CONTENT`，支持换行可用 `white-space:pre-line` 或 innerHTML 拼接 `<br>`）、`button.camp-help-close`（textContent = '我知道了'）]
- [ ] 弹层 append 到 `page`（随路由销毁），不 append 到 `document.body`
- [ ] 关闭途径一：关闭按钮 `camp-help-close` 点击 → `overlay.remove()`
- [ ] 关闭途径二：遮罩 `camp-help-overlay` 点击（`e.target === overlay` 时）→ `overlay.remove()`
- [ ] 关闭途径三：悬浮按钮再次点击切换（已在 3.2 第一步实现）
- [ ] 弹层展示响应时间 ≤ 100ms（纯 DOM 创建，无网络请求，天然满足 spec 4.1.3）
- [ ] 不得调用 `modal.show`（语义错位，design 2.5 决策 2），不得修改 `modal.js`

**验收标准**：在 `#/camps` 点击悬浮按钮 → 弹出帮助弹层，标题为"如何测试多人加入"，内容包含"请打开无痕窗口模拟另一个成员加入"，无 localStorage/代码路径等技术术语；点击"我知道了"关闭按钮 → 弹层消失；再次点击悬浮按钮 → 弹层重新出现；弹层展示状态下再次点击悬浮按钮 → 弹层关闭（不叠加双层）；点击弹层外遮罩空白 → 弹层关闭；弹层关闭后引力场列表可正常点击"新建小组""加入小组"与小组卡片。

---

## 4. 重复组队码友好加入（回归验证，无代码改动）

### 4.1 确认 campService.join 已满足 spec 5.2 全部规则
- [ ] 阅读 `src/services/campService.js` 的 `join` 方法，确认以下分支已存在且文案一致，**不修改任何代码**：
  - 组队码不存在 → 返回 `{ success:false, error:'组队码不存在' }`
  - 成员数 ≥ max_members → 返回 `{ success:false, error:'小组成员已满' }`
  - 昵称命中已有成员 → 返回 `{ success:false, error:'该昵称已被使用，请换一个' }`
  - 其余情况 → push 新成员并以新昵称覆盖 `dream_joined_camps` 同 code 记录
- [ ] 确认 `campJoinView` 提交回调已透传 `result.error`（`modal.toast(result.error || '加入失败')`），无需改动

**验收标准**：`campService.js` 与 `campJoinView.js` 在本任务中无任何字符变更；design.md 1.2.1 接口契约表中 4 条业务规则分支与源码逐一对应。

---

## 5. 集成验证与回归测试

### 5.1 免责提示与表单功能集成验证
- [ ] 验证 `#/camp/new` 页面：免责小字与原 hint 并存，填写小组名称/昵称/最大人数后点击"创建小组" → 正常生成 6 位组队码并 toast 提示，800ms 后跳转 `#/camp/{code}`
- [ ] 验证 `#/camp/join` 页面：免责小字与原 hint 并存，输入组队码过滤非数字字符，提交校验"组队码为6位数字"逻辑正常

**验收标准**：创建与加入两条主流程端到端可用，免责提示不阻断提交、不遮挡错误文案、不引发控制台报错。

---

### 5.2 悬浮按钮与弹层集成验证
- [ ] 验证 `#/camps` 列表为空状态：悬浮按钮可见，点击弹出帮助弹层，关闭后空状态文案与"新建小组""加入小组"按钮仍可点击
- [ ] 验证 `#/camps` 列表有小组状态：悬浮按钮不遮挡小组卡片，点击卡片可正常跳转 `#/camp/{code}` 详情页
- [ ] 验证页面滚动：列表较长时滚动页面，悬浮按钮保持右下角固定可见（满足 spec 5.3.3 异常 2）

**验收标准**：列表空/非空两种状态下悬浮按钮与弹层行为一致；滚动后按钮位置不变；弹层关闭后页面所有交互恢复正常。

---

### 5.3 重复加入场景回归验证
- [ ] 场景一：创建小组得到组队码 A → 在 `#/camp/join` 输入 A 与新昵称"小红" → 加入成功，成为 A 小组新成员
- [ ] 场景二：已加入 A 小组后，再次以另一新昵称"小蓝"输入 A → 加入成功（模拟多人互动，不提示"已加入"）
- [ ] 场景三：输入 A 与小组内已占用昵称 → toast 提示"该昵称已被使用，请换一个"，流程不中断
- [ ] 场景四：输入不存在的 6 位组队码 → toast 提示"组队码不存在"，不出现矛盾文案
- [ ] 场景五：输入已达上限小组的组队码 → toast 提示"小组成员已满"

**验收标准**：五种场景 toast 文案与 spec 5.2.1 规则 1-4 逐一对应；加入后 `dream_camps_data` 成员数据结构与 `dream_joined_camps` 记录结构未改变（DevTools Application 面板核对）。

---

### 5.4 全局回归验证（不白屏、不影响其他模块）
- [ ] 验证首页 `#/` 正常渲染，背景主题、引力源卡片无视觉变化
- [ ] 验证打卡页、逃逸速度页、引力小助手聊天窗口正常打开与交互
- [ ] 验证路由切换 `#/` ↔ `#/camps` ↔ `#/camp/new` ↔ `#/camp/join` ↔ `#/camp/{code}` 无白屏、无控制台报错、无残留悬浮按钮
- [ ] 验证 localStorage 键 `dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps` 结构未改变

**验收标准**：全站主路由无白屏；控制台无新增 error；引力小助手、打卡、逃逸速度三大模块功能无回归；localStorage 数据结构核对无差异。

---

## 6. 部署与配置确认

### 6.1 确认无后端/无数据迁移/无环境配置
- [ ] 确认本次增量无新增网络请求、无新增 localStorage 键、无新增环境变量或配置开关
- [ ] 确认 `index.html` 未修改，无需重新部署 HTML 入口
- [ ] 确认 `main.js` 路由表未修改，hash 路由 `#/camps`、`#/camp/new`、`#/camp/join`、`#/camp/{code}` 不变

**验收标准**：`git diff --stat` 仅显示 5 个目标文件变更；无新增依赖包；无数据迁移脚本。

---

## 7. 评审与交付确认

### 7.1 代码审查
- [ ] 审查 `constants.js`：`CAMP_UI_HINTS` 三字段文案与 spec 6.1 / 6.2 字符级一致
- [ ] 审查 `campFormView.js` / `campJoinView.js`：仅追加 import 与 4 行 DOM 追加，无逻辑改动
- [ ] 审查 `campListView.js`：悬浮按钮 append 到 `page`、弹层切换逻辑先判存在再创建、三关闭途径齐全
- [ ] 审查 `main.css`：5 个新类均复用既有 CSS 变量，无硬编码色值，无 `!important`

### 7.2 设计一致性核对
- [ ] 对照 design.md 2.6 验收对照表，逐条确认 spec 条款已落地
- [ ] 对照 design.md 2.4 改动文件清单，确认仅 5 个文件变更、未越界修改 `campService.js`/`modal.js`/`main.js`/`index.html`

### 7.3 变更范围最终确认
- [ ] 执行 `git diff --name-only` 确认变更文件集合等于 `{src/constants.js, src/views/campFormView.js, src/views/campJoinView.js, src/views/campListView.js, src/styles/main.css}`
- [ ] 确认无新增第三方依赖、无新增 npm 包

**验收标准**：代码审查无 blocker；design 2.6 验收对照表 13 条全部勾选；`git diff --name-only` 输出恰好 5 个文件路径。