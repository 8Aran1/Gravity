# 引力场 UI 提示优化 · 技术设计文档

# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 5.2 重复组队码以新昵称加入（不阻断） | `campService.join` 在组队码存在时不阻断，直接 push 新成员并覆盖 joined 记录为新昵称身份 | `src/services/campService.js:68-84` | 100% |
| 5.2 昵称冲突友好提示"该昵称已被使用，请换一个" | `join` 命中 `camp.members.find(m => m.nickname === nickname)` 时返回 `{ success:false, error:'该昵称已被使用，请换一个' }` | `src/services/campService.js:73` | 100% |
| 5.2 视图层展示服务层友好文案 | `campJoinView` 提交回调直接 `modal.toast(result.error || '加入失败')`，已透传服务层文案 | `src/views/campJoinView.js:98-104` | 100% |
| 5.2 小组成员已满提示 | `join` 在 `members.length >= max_members` 时返回 `{ success:false, error:'小组成员已满' }` | `src/services/campService.js:72` | 100% |
| 5.2 组队码格式前端校验 | `campJoinView` 对 `join-code` 输入做 `\D` 过滤，提交前校验 `code.length !== 6` 提示"组队码为6位数字" | `src/views/campJoinView.js:71-73,85` | 100% |
| 5.1 灰色小字提示样式基座 | `.form-hint` 已定义 `font-size:0.8rem; color:var(--color-text-muted); text-align:center`，可作为免责文案样式参照 | `src/styles/main.css:543-548` | 75% |
| 5.3 弹层遮罩与卡片视觉基座 | `.modal-overlay`（fixed 全屏遮罩 + backdrop-blur + fadeIn）与 `.modal-dialog`（白卡 + radius-xl + shadow-lg + slideUp）已存在 | `src/styles/main.css:595-618` | 50% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 5.1 创建表单输入区下方免责提示 | `campFormView` 已有 `hint.form-hint`，但内容是"创建后系统会生成一个6位组队码…"，且 spec 5.1.4 要求两者并存、不得替换 | 现有 hint 是业务引导文案，与免责文案语义不同；需新增独立元素而非改写现有 hint 的 textContent | 在 `form.innerHTML += …` 之后通过 `createElement` 追加一个 `p.form-disclaimer` 元素到表单输入区下方（按钮组之前），新增 `.form-disclaimer` CSS 类（比 form-hint 更弱化：字号 0.72rem、opacity 0.85） |
| 5.1 加入表单输入区下方免责提示 | `campJoinView` 已有 `hint.form-hint`，内容是"输入搭子分享的6位组队码，一起存钱" | 同上，需并存展示 | 同上，在 `campJoinView` 的 `form.innerHTML += …` 之后追加 `p.form-disclaimer` |
| 5.3 帮助说明弹层 | `modal.show` 是带"取消/确认"双按钮的确认对话框，语义为危险操作确认，不适合纯展示型帮助说明 | `modal.show` 强制渲染两个按钮且无标题位，复用会引入语义错位 | 在 `campListView` 内自建轻量帮助弹层（复用 `.modal-overlay`/`.modal-dialog` 视觉类，但内容结构自定义：标题 + 指引段落 + 单关闭按钮），不修改 `modal.js` |

### 1.1.3 需要新增的功能或接口

按业务模块分组：

**模块 A：免责提示文案常量与渲染**
- 功能点 A1：集中定义免责文案常量 `DISCLAIMER_HINT`（固定文本，spec 6.1 规定内容）
- 功能点 A2：集中定义帮助说明常量 `HELP_TITLE` / `HELP_CONTENT`（含"请打开无痕窗口模拟另一个成员加入"核心指引）
- 功能点 A3：在 `campFormView.render` 与 `campJoinView.render` 中追加免责提示 DOM 节点
- 依赖：无跨模块依赖，仅 DOM 追加

**模块 B：悬浮帮助按钮与弹层**
- 功能点 B1：在 `campListView.render` 中创建悬浮问号按钮 `button.camp-help-fab`，`position:fixed` 定位
- 功能点 B2：点击按钮切换帮助弹层显隐（避免重复叠加）
- 功能点 B3：弹层关闭途径：关闭按钮 / 遮罩点击 / 按钮再次点击切换
- 依赖：仅在 `#/camps` 路由内创建，路由切换时随 `app.innerHTML=''` 自动销毁

## 1.2 存量功能详细分析

### 1.2.1 campService.join 接口契约

- **入参**：`(code: string, nickname: string, goalName: string, progress: number)`
- **出参**：成功 `{ success:true, campId, campName, memberId }`；失败 `{ success:false, error:string }`
- **业务规则分支**（按代码顺序）：
  1. 组队码不存在 → `error:'组队码不存在'`（spec 5.2.1 禁止项 4 已满足：不会对已存在码报"不存在"）
  2. 成员数 ≥ max_members → `error:'小组成员已满'`
  3. 昵称命中已有成员 → `error:'该昵称已被使用，请换一个'`（spec 5.2.1 规则 2 已满足）
  4. 其余情况 → push 新成员，并以新昵称记录覆盖 `dream_joined_camps` 中同 code 记录（spec 5.2.1 规则 3"以新成员身份加入"已满足）
- **副作用**：写入 `dream_camps_data`（成员数组）与 `dream_joined_camps`（当前用户加入记录）
- **约束**：不改变组队码生成逻辑、不改变成员数据结构（spec 5.2.1 禁止项 5 已满足）
- **结论**：spec 5.2 全部业务规则在服务层已 100% 落地，本次增量**不修改 campService.js**

### 1.2.2 campFormView / campJoinView 渲染结构

- **渲染模式**：`app.innerHTML=''` 清空 → `createElement` 构建 `container.page-container` → `form.form-card` → `title` + `hint.form-hint` → `form.innerHTML += 表单HTML字符串` → 之后通过 `getElementById` 绑定事件
- **关键约束**：`form.innerHTML +=` 会重写 form 的子节点 HTML，但事件监听是在该语句之后通过 `addEventListener` 绑定到新取到的元素上，因此**在 `innerHTML +=` 之后追加 DOM 节点不会破坏事件绑定**
- **插入点选择**：免责提示需在"输入区下方"。表单 HTML 字符串末尾是 `.modal-btn-group`（按钮组），若把免责提示 append 到 form 末尾会落在按钮下方；若需严格"输入区下方、按钮上方"，应在 `innerHTML +=` 之后用 `insertBefore(disclaimer, btnGroup)` 插入。本设计采用 append 到 form 末尾（按钮下方），理由：spec 5.1.1 仅要求"输入区域下方"，按钮下方仍属输入区下方语义，且实现更稳、不依赖按钮组选择器稳定性

### 1.2.3 campListView 渲染结构

- **页面骨架**：`page.home-page` > [`backLink`, `hero.home-hero`, `section.home-goals`(`header.home-goals-header` > `title` + `btnGroup.camp-list-actions`[joinBtn, createBtn]) + 列表/空状态]
- **关键操作按钮位置**：`joinBtn`/`createBtn` 位于 header 右侧，属页面顶部区域
- **悬浮按钮定位约束**：spec 5.3.1 规则 4 要求不遮挡新建/加入按钮。新建/加入按钮在顶部右侧，悬浮按钮应放在**右下角**（`bottom:32px; right:32px`），与顶部按钮垂直分离，无遮挡风险
- **生命周期**：`campListView.render` 每次被路由调用时 `app.innerHTML=''` 清空旧 DOM，悬浮按钮若 append 到 `page`（在 app 内）会随路由切换自动销毁，天然满足 spec 5.3"仅在 #/camps 展示"

### 1.2.4 现有视觉风格约定（CSS 变量）

| 变量 | 值 | 用途 |
|------|----|----|
| `--color-text-muted` | `#9A9AB0` | 灰色弱化文字（免责提示复用） |
| `--color-primary` | `#4CAF50` | 主色（悬浮按钮边框/问号色） |
| `--color-card` | `#FFFFFF` | 卡片底色（悬浮按钮/弹层底色） |
| `--radius-lg` | `16px` | 圆角 |
| `--shadow-lg` | `0 12px 36px rgba(30,35,60,0.16)` | 大阴影（悬浮按钮/弹层） |
| `--ease-out` | （已定义） | 过渡缓动 |

复用上述变量即可保证新增 UI 与全站极简现代风格一致，不引入新设计体系（满足 spec 4.4.2）。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

```plantuml
@startuml
left to right direction
actor "引力场使用者" as user
rectangle "引力场UI提示优化" as comp {
  rectangle "免责提示渲染器" as disclaimer
  rectangle "悬浮帮助按钮+弹层" as helpFab
  rectangle "加入流程提示透传" as joinPass
}
storage "localStorage\ndream_camps_data" as ls
component "campService.join\n(不修改)" as svc

user --> disclaimer : 进入创建/加入页
user --> helpFab : 进入列表页/点击问号
user --> joinPass : 输入组队码+昵称提交
disclaimer --> user : 灰色免责小字
helpFab --> user : 悬浮按钮+帮助弹层
joinPass --> svc : campService.join(code,nick,...)
svc --> ls : 读写小组数据
svc --> joinPass : {success,error}
joinPass --> user : toast(result.error) 友好文案
@enduml
```

调用频率：免责提示与悬浮按钮为页面渲染时一次性创建；加入流程为用户点击提交时单次调用。

### 2.1.2 服务/组件总体架构

```plantuml
@startuml
package "本次增量改动范围" {
  component "campListView" as v1 <<view>>
  component "campFormView" as v2 <<view>>
  component "campJoinView" as v3 <<view>>
  component "main.css" as css <<style>>
  component "constants.js" as cst <<const>>
}

package "不修改（仅依赖）" {
  component "campService" as svc <<service>>
  component "modal" as m <<view>>
  component "main.js / 路由" as r <<router>>
  component "index.html" as h <<html>>
}

cst --> v1 : CAMP_UI_HINTS
cst --> v2 : CAMP_UI_HINTS
cst --> v3 : CAMP_UI_HINTS
v1 --> css : .camp-help-fab/.camp-help-overlay
v2 --> css : .form-disclaimer
v3 --> css : .form-disclaimer
v3 ..> svc : join() 透传文案
v1 ..> m : 不复用 modal.show
@enduml
```

模块职责：
- **constants.js**：新增 `CAMP_UI_HINTS` 常量对象，集中托管免责文案与帮助说明（满足 spec 4.4.1 集中维护）
- **campFormView / campJoinView**：渲染时追加 `p.form-disclaimer` 子节点
- **campListView**：渲染时创建悬浮问号按钮与帮助弹层，绑定切换逻辑
- **main.css**：新增 `.form-disclaimer`、`.camp-help-fab`、`.camp-help-overlay`、`.camp-help-dialog`、`.camp-help-close` 样式类

### 2.1.3 实现设计文档

#### 免责提示渲染流程（无状态，纯 DOM 追加）

```plantuml
@startuml
start
:进入 campFormView.render / campJoinView.render;
:清空 app.innerHTML;
:构建 container/form/title/hint;
:form.innerHTML += 表单HTML;
if (CAMP_UI_HINTS.DISCLAIMER_HINT 非空?) then (是)
  :创建 p.form-disclaimer\ntextContent = DISCLAIMER_HINT;
  :form.appendChild(disclaimer);
else (否)
  :跳过追加，不抛错;
endif
:绑定表单事件;
:app.appendChild(container);
stop
@enduml
```

异常处理：常量缺失时跳过追加（满足 spec 5.1.3 异常 2，不白屏）。

#### 悬浮帮助按钮状态机

```plantuml
@startuml
[*] --> Closed : 列表页渲染完成
Closed --> Open : 点击悬浮按钮
Open --> Closed : 点击关闭按钮
Open --> Closed : 点击遮罩空白
Open --> Closed : 再次点击悬浮按钮(切换)
Open --> Open : 列表滚动(按钮 fixed 保持可见)
@enduml
```

关键策略：点击悬浮按钮时先 `document.getElementById('camp-help-overlay')` 判断弹层是否已存在，存在则移除（切换关闭），不存在则创建（避免叠加，满足 spec 5.3.3 异常 1）。

## 2.2 接口设计

### 2.2.1 总体设计

本次增量**不新增对外 JS 接口/方法签名**，仅扩展现有三个 view 的 `render()` 内部渲染行为与 CSS 类表。`campService` 对外方法签名不变（满足 spec 4.5.3）。

| 改动面 | 类型 | 稳定性 | 说明 |
|--------|------|--------|------|
| `CAMP_UI_HINTS` 常量 | 新增导出常量 | 稳定 | 集中文案，后续国际化入口 |
| `.form-disclaimer` CSS 类 | 新增 | 稳定 | 免责提示样式 |
| `.camp-help-fab` CSS 类 | 新增 | 稳定 | 悬浮问号按钮 |
| `.camp-help-overlay/.camp-help-dialog/.camp-help-close` CSS 类 | 新增 | 稳定 | 帮助弹层 |
| `campFormView.render` 行为 | 扩展 | 稳定 | 末尾追加免责节点 |
| `campJoinView.render` 行为 | 扩展 | 稳定 | 末尾追加免责节点 |
| `campListView.render` 行为 | 扩展 | 稳定 | 追加悬浮按钮+弹层逻辑 |

### 2.2.2 接口清单

#### CAMP_UI_HINTS 常量

- **签名**：`export const CAMP_UI_HINTS = { DISCLAIMER_HINT: string, HELP_TITLE: string, HELP_CONTENT: string }`
- **业务说明**：集中托管本次新增的全部用户可见文案，满足 spec 4.4.1 可维护性
- **前置条件**：无
- **后置条件**：被三个 view import 引用
- **取值**：
  - `DISCLAIMER_HINT` = `'💡 提示：本功能为纯前端模拟，组队码仅在当前电脑/浏览器内生效。用于演示多人互动效果。'`（spec 6.1 固定文本）
  - `HELP_TITLE` = `'如何测试多人加入'`
  - `HELP_CONTENT` = 包含核心句"请打开无痕窗口模拟另一个成员加入"的多行指引文本（纯用户操作指引，无技术术语，满足 spec 5.3.1 禁止项 5）
- **异常映射**：无常量异常；view 侧使用前做非空判断

#### campFormView.render / campJoinView.render 扩展点

- **签名**：`render(): void`（不变）
- **业务说明**：在原有渲染流程末尾追加免责提示节点
- **前置条件**：`document.getElementById('app')` 存在
- **后置条件**：form 内多一个 `p.form-disclaimer` 子节点；原有 hint 与表单事件不受影响
- **异常映射**：常量为空 → 跳过追加，不抛错（spec 5.1.3 异常 2）

#### campListView.render 扩展点

- **签名**：`render(): void`（不变）
- **业务说明**：在页面渲染末尾追加悬浮问号按钮，绑定点击切换帮助弹层
- **前置条件**：`document.getElementById('app')` 存在
- **后置条件**：page 内多一个 `button.camp-help-fab`；点击可切换弹层显隐；路由离开时随 `app.innerHTML=''` 自动销毁
- **异常映射**：弹层已存在时点击按钮 → 移除弹层（切换关闭），不叠加

## 2.3 数据模型

### 2.3.1 设计目标

- 不引入新持久化数据，不修改 `dream_camps_data` / `dream_joined_camps` 结构（满足 spec 4.5.1）
- 新增内容均为静态文案常量与瞬态 DOM 节点，无生命周期持久化需求
- 兼容策略：现有 localStorage 数据无需迁移

### 2.3.2 模型实现

```plantuml
@startuml
class CAMP_UI_HINTS <<const>> {
  + DISCLAIMER_HINT : string
  + HELP_TITLE : string
  + HELP_CONTENT : string
}

class FormDisclaimer <<DOM>> {
  - tagName : "p"
  - className : "form-disclaimer"
  - textContent : CAMP_UI_HINTS.DISCLAIMER_HINT
}

class CampHelpFab <<DOM>> {
  - tagName : "button"
  - className : "camp-help-fab"
  - textContent : "?"
  - position : fixed
}

class CampHelpOverlay <<DOM>> {
  - tagName : "div"
  - className : "camp-help-overlay"
  - children : [dialog]
}

class CampHelpDialog <<DOM>> {
  - tagName : "div"
  - className : "camp-help-dialog"
  - children : [title, content, closeBtn]
}

CAMP_UI_HINTS ..> FormDisclaimer : 文案来源
CAMP_UI_HINTS ..> CampHelpDialog : 文案来源
CampHelpFab "1" --> "0..1" CampHelpOverlay : 点击切换
CampHelpOverlay "1" *-- "1" CampHelpDialog : 组合
@enduml
```

- **创建策略**：免责提示与悬浮按钮在各自 view 的 `render()` 内同步 `createElement` 创建，无懒加载
- **销毁策略**：依赖路由切换时 `app.innerHTML=''` 的现有清空机制，无需手动 remove；弹层关闭时手动 `removeChild` 或 `overlay.remove()`
- **持久化策略**：无持久化，纯瞬态 DOM

## 2.4 改动文件清单与最小化原则

| 文件 | 改动类型 | 改动范围 | 是否改核心逻辑 |
|------|---------|---------|--------------|
| `src/constants.js` | 新增 | 文件末尾追加 `CAMP_UI_HINTS` 导出常量 | 否 |
| `src/views/campFormView.js` | 修改 | `render()` 内 `form.innerHTML += …` 之后追加约 6 行：import 常量 + 创建 `p.form-disclaimer` + appendChild | 否（仅 UI） |
| `src/views/campJoinView.js` | 修改 | 同上，约 6 行 | 否（仅 UI） |
| `src/views/campListView.js` | 修改 | `render()` 末尾追加约 30 行：创建悬浮按钮 + 帮助弹层 + 切换/关闭事件 | 否（仅 UI） |
| `src/styles/main.css` | 新增 | 追加 `.form-disclaimer`、`.camp-help-fab`、`.camp-help-overlay`、`.camp-help-dialog`、`.camp-help-close` 五个类规则（约 50 行） | 否 |

**明确不修改**：`campService.js`、`campApiService.js`、`modal.js`、`main.js`、`index.html`、`campDetailView.js`、其他 view 与 service。

## 2.5 关键设计决策与理由

1. **免责提示 append 到 form 末尾而非 insertBefore 按钮组**：实现更稳，不依赖 `.modal-btn-group` 选择器稳定性；语义上"按钮下方"仍属"输入区下方"，满足 spec 5.1.1。
2. **不复用 `modal.show` 渲染帮助弹层**：`modal.show` 强制双按钮（取消/确认）且无标题位，语义为危险操作确认；帮助说明是纯展示型单关闭弹层，复用会引入语义错位。改为在 `campListView` 内自建弹层，复用 `.modal-overlay`/`.modal-dialog` 视觉类（仅类名复用，不改 `modal.js`）。
3. **悬浮按钮 append 到 `page` 而非 `document.body`**：路由切换时 `app.innerHTML=''` 会连带销毁 `page` 及其子按钮，天然满足"仅在 #/camps 展示"（spec 5.3 数据约束 4），无需手动清理。
4. **悬浮按钮定位右下角**：新建/加入按钮位于 header 顶部右侧，悬浮按钮放右下角 `bottom:32px;right:32px` 垂直分离，零遮挡风险（spec 5.3.1 规则 4）。
5. **5.2 重复加入逻辑不改代码**：经分析 `campService.join` 与 `campJoinView` 提交回调已 100% 满足 spec 5.2 全部规则与异常场景，本次仅在 design.md 中确认已实现，不产生代码改动，避免无谓变更引入风险。
6. **文案集中到 `constants.js` 的 `CAMP_UI_HINTS`**：满足 spec 4.4.1"集中定义为常量，便于统一维护与国际化"，且不污染现有 `CAMP_RULES` 等规则常量的语义边界。
7. **CSS 类名采用 camelCase 风格的 kebab-case CSS 类名**：与现有 `.form-hint`、`.camp-list-actions`、`.home-create-btn` 命名风格一致（CSS 类名按 BEM-like kebab-case，JS 变量/方法按 camelCase，符合项目既有约定）。

## 2.6 验收对照（spec → 设计落点）

| spec 条款 | 落点 |
|-----------|------|
| 5.1.1 创建表单免责提示 | `campFormView.render` 追加 `p.form-disclaimer`，文案取 `CAMP_UI_HINTS.DISCLAIMER_HINT` |
| 5.1.1 加入表单免责提示 | `campJoinView.render` 同上 |
| 5.1.1 文案样式弱化 | `.form-disclaimer` 字号 0.72rem、`color:var(--color-text-muted)`、`opacity:0.85`，比 `.form-hint`（0.8rem）更弱 |
| 5.1.4 与现有 hint 并存 | 新增独立节点，不改写现有 `hint.textContent` |
| 5.1.3 异常 2 常量缺失跳过 | view 侧 `if (CAMP_UI_HINTS.DISCLAIMER_HINT)` 判空后才追加 |
| 5.2.1 全部规则 | `campService.join` 已实现，不改 |
| 5.3.1 悬浮按钮存在 | `campListView.render` 创建 `button.camp-help-fab`，`position:fixed` 不随滚动消失 |
| 5.3.1 点击弹出指引 | 弹层 `HELP_CONTENT` 含"请打开无痕窗口模拟另一个成员加入" |
| 5.3.1 关闭方式 | 关闭按钮 + 遮罩点击 + 按钮再次点击切换，三途径 |
| 5.3.1 不遮挡关键按钮 | 右下角定位，与顶部按钮组垂直分离 |
| 5.3.3 异常 1 重复点击不叠加 | 点击按钮先判弹层是否存在，存在则移除 |
| 5.3 数据约束 4 仅列表页展示 | 按钮 append 到 `page`，路由切换自动销毁 |
| 4.5.2 路由 hash 不变 | 不改 `main.js`/路由 |
| 4.5.3 campService 签名不变 | 不改 `campService.js` |
