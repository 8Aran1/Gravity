# 粒子聚拢入场动画 — 编码任务列表

> 变更范围：新建 `src/utils/splashAnimation.js` + 修改 `src/main.js`（仅 +1 import、+1 调用）。不修改 `index.html`，不触碰任何 localStorage 键，不影响核心功能。
> 时序约束：聚拢 1200ms + 停留 500ms + 散开淡出 700ms = 2400ms（≤ 2500ms 上限）。
> 降级条件：GSAP 加载失败 / Canvas 2D 不支持 / `prefers-reduced-motion: reduce`。

## 1. 模块骨架与对外接口

### 1.1 创建 splashAnimation.js 模块骨架
- [ ] 新建 `src/utils/splashAnimation.js`，按既有工具模块风格 `export const splashAnimation = { play }` 导出唯一对外方法 `play(options?)`，返回 `Promise<void>` 且永不 reject（内部异常吞掉走降级）
- [ ] 在模块顶部定义配置常量对象 `AnimationConfig`：`particleCount=300`、`convergeMs=1200`、`holdMs=500`、`divergeMs=700`、`text="引力"`、`cdnUrl="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"`、`canvasZIndex=9999`
- [ ] 在模块顶部定义内部状态标志 `let played = false`，`play` 入口若 `played` 为 true 直接 resolve，保证全局仅播放一次
- **涉及文件**：`src/utils/splashAnimation.js`（新建）
- **依赖**：无
- **验收标准**：模块可被 `import { splashAnimation } from './utils/splashAnimation.js'` 导入；`splashAnimation.play` 为函数；重复调用第二次立即 resolve 不重复播放

## 2. GSAP CDN 动态加载器

### 2.1 实现 loadGsap 内部函数
- [ ] 实现 `loadGsap(cdnUrl)`：运行时 `document.createElement('script')`，设 `src` 为 CDN URL，追加到 `document.head`；返回 `Promise<GSAP实例|null>`
- [ ] 监听 `script.onload`：校验 `window.gsap` 存在则 resolve(gsap)，否则 resolve(null)；监听 `script.onerror`：resolve(null)
- [ ] 设置 1500ms 超时定时器，超时 resolve(null)；无论成功失败均在回调中 `clearTimeout` 清理定时器，避免泄漏
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1
- **验收标准**：CDN 可达时 resolve 出 gsap 实例；网络不可达/超时/`window.gsap` 未定义时 resolve(null)；不抛异常；超时定时器必被清理

## 3. 降级守卫与环境探测

### 3.1 实现 detectFallback 内部函数
- [ ] 实现 `detectFallback(gsap)`：返回布尔降级信号。任一成立即返回 true——`gsap` 为 null/undefined；`document.createElement('canvas').getContext('2d')` 为 null；`window.matchMedia('(prefers-reduced-motion: reduce)').matches` 为 true（matchMedia 不存在时忽略此项不降级）
- [ ] 降级处理函数 `applyFallback(appElement)`：将 `appElement`（默认 `document.getElementById('app')`）的 `style.opacity` 置为 '1'，不创建 Canvas，直接 resolve
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1
- **验收标准**：GSAP 缺失/Canvas 2D 不支持/无障碍偏好开启时返回 true；三者均正常时返回 false；降级路径 `#app` opacity 为 1 且未创建 Canvas

## 4. "引力"文字轮廓像素采样器

### 4.1 实现 sampleTextOutline 内部函数
- [ ] 实现 `sampleTextOutline(viewportWidth, viewportHeight, particleCount, text)`：创建离屏 canvas（宽高取视口尺寸），获取 2D 上下文；`getContext('2d')` 返回 null 时返回 null 触发降级
- [ ] 设置 `fillStyle`、`textAlign='center'`、`textBaseline='middle'`；字号按视口宽度自适应（桌面端约 `viewportWidth * 0.18`，移动端窄屏按比例缩减并设上限），`fillText("引力", width/2, height/2)` 居中绘制
- [ ] `getImageData(0,0,width,height)` 后遍历像素，收集 alpha > 阈值（如 128）的像素坐标；按 `particleCount` 步长均匀抽样为目标点数组 `{x,y}[]`
- [ ] 采样点不足（极端窄屏）时降级为以视口中心为圆心的小圆环目标点，保证聚拢效果仍成立；离屏 canvas 采样完成后脱离引用由 GC 回收
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1
- **验收标准**：正常视口下返回约 300 个目标点且点集构成"引力"文字轮廓形态；极端窄屏下仍返回 300 个点（圆环兜底）；Canvas 2D 不支持时返回 null

## 5. 粒子工厂

### 5.1 实现 createParticles 内部函数
- [ ] 实现 `createParticles(targetPoints, viewportWidth, viewportHeight)`：生成 `particleCount`（300）个粒子对象，每个粒子绑定一个聚拢目标点（按索引取 `targetPoints[i]`，目标点不足时循环取模）
- [ ] 粒子初始位置 `originX/originY`：在屏幕四条边随机取一边，再在该边上随机取点，并沿法线方向向屏外偏移一段距离，确保起始分布于四周而非中心
- [ ] 粒子散开终点 `divergeX/divergeY`：取其文字轮廓目标点沿"远离视口中心"方向延伸到屏外的坐标
- [ ] 每粒子初始化 `x=originX`、`y=originY`、`size`（如 2-3px）、`alpha=1`；返回粒子数组
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1、4.1
- **验收标准**：返回 300 个粒子；所有粒子初始位置位于屏幕四周（非中心聚集）；每粒子均绑定 target 与 diverge 坐标；size/alpha 字段存在

## 6. 全屏画布管理器

### 6.1 实现 createCanvas / removeCanvas 内部函数
- [ ] 实现 `createCanvas(viewportWidth, viewportHeight)`：`document.createElement('canvas')`，设 `width/height` 为视口像素尺寸；样式 `position:fixed`、`top:0`、`left:0`、`pointer-events:none`、`z-index:9999`；`document.body.appendChild(canvas)`；返回 `{canvas, ctx}`（ctx 为 2D 上下文）
- [ ] 实现 `removeCanvas(canvas)`：若 `canvas` 存在且为 `document.body` 子节点则 `document.body.removeChild(canvas)`；引用置空
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1
- **验收标准**：创建后 Canvas 铺满视口、`pointer-events:none`、`z-index:9999`、挂载于 body；移除后 body 不再含该 Canvas；动画期间点击事件穿透到下方按钮不被拦截

## 7. 动画编排器

### 7.1 实现 runTimeline 内部函数
- [ ] 实现 `runTimeline(gsap, particles, ctx, canvas, appElement, config)`：返回 `Promise<void>`。动画启动前置 `appElement.style.opacity = '0'`
- [ ] 用 `gsap.timeline()` 编排三段时序：① 聚拢段 `convergeMs=1200ms`，每粒子 `x/y` 由 origin 补间到 target；② 停留段 `holdMs=500ms` 无位移；③ 散开淡出段 `divergeMs=700ms`，每粒子 `x/y` 由 target 补间到 diverge 且 `alpha` 由 1 补间到 0，同步 `appElement.opacity` 由 0 补间到 1（同一 timeline 末段并行）
- [ ] 重绘驱动：不单独起 `requestAnimationFrame`，由 timeline 的 `onUpdate` 回调统一重绘——`ctx.clearRect` 清屏 → 逐粒子 `ctx.fillStyle = rgba(...,particle.alpha)` → `ctx.fillRect/arc` 绘制；保证动画结束即停止重绘无残留循环
- [ ] `onComplete` 中执行清理：`removeCanvas(canvas)`、`timeline.kill()`、粒子数组置空、`appElement.style.opacity` 兜底置 '1'；Promise resolve
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：1.1、5.1、6.1
- **验收标准**：动画呈现"四周聚拢→形成'引力'轮廓→停留约 0.5s→向四周散开淡出"且首页同步淡入；总时长 2400ms（≤2500ms）；动画结束后 Canvas 已移除、timeline 已 kill、无残留重绘循环、`#app` opacity 为 1

## 8. play 主流程串联

### 8.1 串联 play 内部全流程
- [ ] 在 `play(options?)` 中串联：① 标记 `played=true`，解析 `appElement`（默认 `document.getElementById('app')`）与 `totalDurationMs`（默认 2500）；② `await loadGsap(config.cdnUrl)`；③ `detectFallback(gsap)` 为 true 则 `applyFallback` 并 return；④ `sampleTextOutline` 返回 null 则降级；⑤ `createParticles`；⑥ `createCanvas`；⑦ `runTimeline`
- [ ] 全流程外层 `try/catch`：任何异常均 `console.warn` 记录后走 `applyFallback` 降级，`play` 永不 reject；降级时若已创建 Canvas 则先 `removeCanvas` 再置 `#app` opacity 为 1
- **涉及文件**：`src/utils/splashAnimation.js`
- **依赖**：2.1、3.1、4.1、5.1、6.1、7.1
- **验收标准**：正常环境走完整动画路径；GSAP 加载失败/Canvas 不支持/无障碍偏好/采样异常时走降级直接显示首页；任何情况下 `play` 不 reject、不白屏、不卡死

## 9. 接入主初始化流程

### 9.1 修改 main.js 接入动画
- [ ] 在 `src/main.js` 顶部 import 区追加一行 `import { splashAnimation } from './utils/splashAnimation.js';`（保持既有 import 顺序与风格）
- [ ] 在 `init()` 末尾 `try { onboardingTutorial.start(); } catch (e) {}`（第 77 行）之后追加一行 `splashAnimation.play();`（非阻塞，不 await）；既有全部步骤保持原位原序不变
- **涉及文件**：`src/main.js`
- **依赖**：8.1
- **验收标准**：`index.html` 结构不变；`init()` 既有步骤（initData/checkAndUnlock/applySavedTheme/mount/router/hashchange/onboardingTutorial）全部保持原序执行；动画在路由渲染首页后启动；回滚仅需删除新增 import 与调用两行 + 删除 `splashAnimation.js` 文件

## 10. 验证与测试

### 10.1 时序与视觉效果验证
- [ ] 测量从动画开始到首页完全显现的时长，确认 ≤ 2500ms（目标 2400ms）
- [ ] 目视确认：粒子起始分布于屏幕四周 → 聚拢形成"引力"文字轮廓 → 停留约 0.5s → 向四周散开且透明度归零 → 首页同步淡入
- [ ] 在移动端窄屏与桌面端分别验证：无白屏、无溢出、无卡顿、文字轮廓自适应可辨

### 10.2 降级与容错验证
- [ ] 模拟 GSAP CDN 不可达（断网/拦截请求）：确认直接显示首页、无白屏、无卡顿
- [ ] 模拟 Canvas 2D 不支持环境：确认降级直接显示首页
- [ ] 开启浏览器 `prefers-reduced-motion: reduce`：确认跳过动画直接显示首页
- [ ] 模拟采样异常/绘制异常：确认 `play` 不 reject、降级显示首页、控制台仅 `console.warn`

### 10.3 交互透传与资源清理验证
- [ ] 动画播放期间点击首页各按钮（创建引力源、引力场入口、打卡、引力小助手等）：确认点击事件正常生效，不被 Canvas 拦截
- [ ] 动画结束后检查 `document.body` 子节点：确认动画 Canvas 已移除无残留
- [ ] 动画结束后检查内存/运行时：确认无残留 `requestAnimationFrame` 循环、timeline 已 kill、粒子数组已置空

### 10.4 核心功能完好与回滚验证
- [ ] 动画结束后逐一操作核心功能：打卡、引力场（储蓄营）、引力小助手、逃逸速度（含冷静期倒计时），确认交互与数据行为与动画前完全一致
- [ ] 确认 localStorage 键 `dream_saving_camp_data`、`dream_camps_data`、`dream_joined_camps` 未被动画读写
- [ ] 回滚验证：删除 `main.js` 新增 import 与调用两行 + 删除 `splashAnimation.js` 文件，确认应用恢复动画前状态、核心功能完好
- [ ] 路由切换/主题切换/返回首页：确认入场动画不重复播放