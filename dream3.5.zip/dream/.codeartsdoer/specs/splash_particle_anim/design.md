# 一、需求与存量功能关系分析

## 1.1 需求功能与存量功能对比

### 1.1.1 已实现功能

本需求为纯增量视觉开场动画，与既有业务功能无功能重叠，但高度依赖既有"应用主初始化流程""首页渲染""工具模块组织"三个接入点。下列存量功能与需求存在直接复用关系：

| 需求功能 | 存量功能 | 代码位置 | 匹配度 |
|---------|---------|---------|--------|
| 动画接入应用启动时机 | 应用主初始化流程 `init()`，末尾直接调用 `init()` | `src/main.js:65-80` | 100% |
| 动画结束后首页内容淡入 | 首页渲染 `homeView.render()`，构建首页 DOM 挂载到 `#app` | `src/views/homeView.js:10-34` | 100% |
| 动画期间不破坏路由分发 | 路由 `router()`，依据 hash 分发各视图到 `#app` | `src/main.js:17-63` | 100% |
| 新模块遵循既有工具模块组织 | `src/utils/` 下已有 `idUtils.js`/`moneyUtils.js`/`dateUtils.js`/`fileUtils.js`，ES module + 对象字面量导出 | `src/utils/idUtils.js:1-5` | 100% |
| 动画画面挂载到文档主体 | `index.html` 中 `<body>` 含 `<div id="app">` 与 `main.js` 脚本，body 可由 JS 动态追加 Canvas | `index.html:9-12` | 100% |
| 降级时首页正常可用 | `init()` 内 `router()` 同步渲染首页到 `#app`，无动画时首页立即可见 | `src/main.js:75` | 100% |

### 1.1.2 需要扩展的功能

| 需求功能 | 存量功能 | 差异说明 | 扩展方向 |
|---------|---------|---------|---------|
| 主初始化流程末尾触发动画 | `init()` 末尾为 `onboardingTutorial.start()`，其后无其他逻辑 | 既有流程在路由渲染后即结束，需求要求在此之后追加一次非阻塞动画启动调用；不改变既有任何步骤顺序 | 在 `init()` 末尾追加一行 `splashAnimation.play()` 调用，导入新模块；既有步骤全部保持原位原序 |
| 首页内容显现方式由"立即可见"改为"动画期间暂缓、散开时淡入" | `router()` 调用后 `#app` 立即可见（默认 opacity:1） | 输出差异：需求要求动画期间 `#app` 透明度由低渐变至完全显现；既有为瞬时可见 | 由动画模块接管 `#app` 的 opacity 过渡：动画启动前置 `#app` opacity 为 0，散开阶段 GSAP 同步将 opacity 补间到 1；降级路径直接置 1。不修改 `homeView`/`router` 任何代码 |
| 入口引入 GSAP 动画引擎 | `index.html` 仅引入 `main.css` 与 `main.js`，无任何第三方脚本 | 需求要求通过 CDN 引入 GSAP，但约束禁止修改 `index.html` 结构 | 由动画模块在运行时动态创建 `<script>` 标签加载 GSAP CDN，加载完成回调中启动动画；加载失败走降级。`index.html` 结构不变 |

### 1.1.3 需要新增的功能或接口

本需求的核心交付物为全新模块 `src/utils/splashAnimation.js`，存量代码中无任何对应实现。按内部职责分组如下：

**A. 对外动画入口（模块导出接口）**
- 功能点：`splashAnimation.play(options?)`，启动粒子聚拢入场动画并控制首页淡入，结束后自动清理
- 输入：可选配置对象（首页容器引用、总时长上限等，均有默认值）
- 输出：`Promise<void>`，动画结束或降级完成时 resolve
- 依赖：浏览器 DOM、Canvas 2D API、动态加载的 GSAP

**B. GSAP CDN 动态加载器（模块内部）**
- 功能点：运行时创建 `<script>` 标签引入指定 CDN URL，监听 `load`/`error` 事件
- 输入：CDN URL
- 输出：`Promise<GSAP 实例 | null>`，失败时 resolve(null) 触发降级
- 依赖：`document.head`、网络可达性

**C. 降级守卫（模块内部）**
- 功能点：在动画启动前检测是否应直接降级（GSAP 未加载、Canvas 不支持、`prefers-reduced-motion` 等）
- 输入：GSAP 加载结果、环境能力探测结果
- 输出：布尔降级信号
- 依赖：`window`、`document.createElement('canvas').getContext` 探测

**D. "引力"文字轮廓像素采样器（模块内部）**
- 功能点：离屏 Canvas 绘制"引力"二字，读取像素数据，采样非透明像素坐标作为粒子聚拢目标点池
- 输入：视口宽高、目标粒子数
- 输出：目标点坐标数组（已按粒子数均匀采样）
- 依赖：离屏 Canvas 2D `getImageData`

**E. 粒子工厂（模块内部）**
- 功能点：生成约 300 个粒子对象，初始位置随机分布于屏幕四周，绑定各自聚拢目标点
- 输入：目标点数组、视口宽高
- 输出：粒子对象数组
- 依赖：无

**F. 画布管理器（模块内部）**
- 功能点：动态创建全屏 `<canvas>` 挂载到 `body`，设置 `pointer-events:none`、`position:fixed`、高 `z-index`；动画结束后从 `body` 移除
- 输入：视口宽高
- 输出：canvas 元素引用与 2D 上下文
- 依赖：`document.body`

**G. 动画编排器（模块内部）**
- 功能点：使用 GSAP `timeline` 编排"聚拢 → 停留 → 散开淡出 + 首页淡入"三段时序，每帧重绘粒子
- 输入：粒子数组、canvas 上下文、`#app` 引用、时序配置
- 输出：动画结束 Promise
- 依赖：GSAP `timeline`/`to`、`requestAnimationFrame`（由 GSAP 驱动）

## 1.2 存量功能详细分析

### 1.2.1 `init()` 接口契约（`src/main.js:65-80`）

- **入参**：无
- **出参**：`Promise<void>`（`async function`）
- **业务规则**：先 `await localStorageAdapter.initData()` 并 `achievementService.checkAndUnlock()`（外层 try/catch，失败时再次 `initData` 兜底）；随后依次同步执行 `themeService.applySavedTheme()` → `advisorView.mount()` → `router()` → 注册 `hashchange` 监听 → `onboardingTutorial.start()`（内层 try/catch 吞异常）
- **副作用**：初始化 localStorage 数据、应用已存主题、挂载引力小助手、渲染当前路由对应视图、注册路由监听、启动新手引导
- **扩展点**：无显式钩子；接入新逻辑只能在函数体内追加语句
- **约束**：`initData` 为异步 await 点；`router()` 同步执行后 `#app` 立即包含完整首页 DOM；函数末尾被 `init()` 直接调用（`main.js:80`）

### 1.2.2 `router()` 接口契约（`src/main.js:17-63`）

- **入参**：无（读取 `window.location.hash`）
- **出参**：无
- **业务规则**：按 hash 前缀匹配分发到各视图的 `render()`；含 camp/withdraw/edit/detail 正则匹配；未匹配回退 `homeView.render()`
- **副作用**：将对应视图 DOM 写入 `#app`
- **约束**：同步函数；外层 try/catch 出错时向 `#app` 写入错误兜底 DOM。动画不得在此函数内接入，以免污染所有路由视图

### 1.2.3 `homeView.render()` 接口契约（`src/views/homeView.js:10-34`）

- **入参**：无
- **出参**：无
- **业务规则**：清空 `#app.innerHTML`，构建首页各区块（身份栏/Hero/统计/激励/徽章/目标列表/免责声明/设置入口）并 `appendChild` 到 `#app`
- **副作用**：`#app` 内容被完整替换为首页 DOM
- **约束**：同步函数；调用后 `#app` 立即可见（默认 opacity:1）。动画模块仅对其 opacity 做过渡，不修改本函数

### 1.2.4 既有工具模块风格约束（`src/utils/idUtils.js`）

- **接口契约**：`export const <moduleName> = { ...方法 }`，对象字面量聚合方法，camelCase 命名
- **约束**：ES module 原生 import/export，无构建工具无类型注解；新模块 `splashAnimation.js` 必须遵循同一风格

### 1.2.5 接入点约束综合分析

1. **接入位置唯一性**：动画必须在 `router()` 渲染首页 DOM 之后启动（否则无 `#app` 内容可淡入），又必须在 `init()` 内调用以符合"主初始化流程启动时触发"。`init()` 中 `router()` 位于第 75 行，其后仅剩 `hashchange` 监听与 `onboardingTutorial.start()`，二者均为非阻塞注册/启动，动画在其后启动不破坏其执行结果。因此动画调用追加在 `init()` 末尾（`onboardingTutorial.start()` 之后）为唯一合理接入点。
2. **非阻塞要求**：`init()` 末尾的动画调用不得阻塞页面交互。动画模块内部用 GSAP timeline 驱动，`play()` 返回 Promise 但 `init()` 不必 await（避免延长 `init()` 的异步完成对后续潜在依赖的影响）；即便 await，既有步骤已全部执行完毕，符合"不打乱顺序"约束。
3. **回滚保障**：动画接入仅两处改动——`main.js` 顶部一行 import + 末尾一行调用。回滚仅需删除这两行并删除 `splashAnimation.js` 文件，既有功能零影响。
4. **结构不变约束**：`index.html` 不动；Canvas 由 `splashAnimation.js` 运行时创建/移除；GSAP 由运行时动态 `<script>` 加载，不落入 `index.html`。

# 二、增量设计方案

## 2.1 实现模型

### 2.1.1 上下文视图

本模块为纯前端展示组件，无后端、无持久化、无消息队列。上下文关系集中在"被主初始化流程调用"与"调用浏览器渲染能力 + 动态加载 CDN"两端。

```plantuml
@startuml
left to right direction
rectangle "应用主初始化流程\nsrc/main.js init()" as InitFlow {
  rectangle "router() 渲染首页到 #app" as Router
}
rectangle "粒子聚拢入场动画\nsrc/utils/splashAnimation.js" as Splash
cloud "GSAP CDN\ncdn.jsdelivr.net/npm/gsap@3.14.2" as GsapCDN
rectangle "浏览器渲染引擎" as Browser {
  rectangle "Canvas 2D API" as CanvasApi
  rectangle "DOM (body / #app)" as Dom
}
rectangle "首页既有视觉增强\n(星空/玻璃拟态/文字浮现)" as HomeVisual

InitFlow --> Splash : init() 末尾调用 play()\n(非阻塞, 一次性)
Splash --> GsapCDN : 运行时动态 <script> 加载\n(失败则降级)
Splash --> CanvasApi : 绘制 ~300 粒子\n(每帧重绘)
Splash --> Dom : 创建/移除 canvas\n控制 #app opacity 淡入
Browser --> Splash : 提供视口尺寸\n与 requestAnimationFrame
Splash ..> HomeVisual : 动画结束后让位\n(pointer-events:none 不遮挡)
@enduml
```

**调用频率**：`play()` 仅在应用首次加载时由 `init()` 调用一次；路由切换、主题切换不重复触发（由 `init()` 仅执行一次保证）。

### 2.1.2 服务/组件总体架构

模块内部按单一职责划分为七个内部组件，仅 `play` 对外暴露。所有内部组件为模块内函数，不单独导出，保证可维护性与可回滚性。

```plantuml
@startuml
package "splashAnimation (src/utils/splashAnimation.js)" {
  component "play\n(对外唯一入口)" as Play
  component "loadGsap\n(CDN 动态加载器)" as LoadGsap
  component "detectFallback\n(降级守卫)" as Detect
  component "sampleTextOutline\n(文字轮廓采样器)" as Sample
  component "createParticles\n(粒子工厂)" as CreateP
  component "createCanvas / removeCanvas\n(画布管理器)" as CanvasMgr
  component "runTimeline\n(动画编排器)" as RunT
}

component "GSAP" as Gsap
component "Canvas 2D ctx" as Ctx
component "#app DOM" as App

Play --> LoadGsap : 1. 加载引擎
LoadGsap --> Gsap : 动态 <script>
Play --> Detect : 2. 判定是否降级
Play --> Sample : 3. 采样"引力"轮廓
Play --> CreateP : 4. 生成粒子
Play --> CanvasMgr : 5. 创建全屏 canvas
Play --> RunT : 6. 编排时序
RunT --> Gsap : timeline.to
RunT --> Ctx : 每帧重绘粒子
RunT --> App : 散开阶段 opacity 0->1
RunT --> CanvasMgr : 7. 结束移除 canvas
@enduml
```

**配置项及取值策略**：

| 配置项 | 取值 | 策略依据 |
|--------|------|---------|
| 粒子数 `particleCount` | 300 | spec 明确约 300；Canvas 2D 绘制 300 粒子无性能压力 |
| 聚拢时长 `convergeMs` | 1200ms | 给粒子由四周到中心足够收束感 |
| 停留时长 `holdMs` | 500ms | spec 明确约 0.5s 使文字清晰可辨 |
| 散开淡出时长 `divergeMs` | 700ms | 与首页淡入同步完成 |
| 总时长 | 2400ms | 1200+500+700=2400 ≤ 2500ms 上限，留 100ms 余量 |
| 文字内容 | "引力" | 品牌名，spec 明确 |
| CDN URL | `https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js` | spec 指定版本 |
| canvas `z-index` | 9999 | 确保覆盖首页内容，但 `pointer-events:none` 不挡点击 |
| 降级触发条件 | GSAP 加载失败 / Canvas 2D 不支持 / `prefers-reduced-motion: reduce` | 兼顾无网络、老旧环境、无障碍偏好 |

### 2.1.3 实现设计文档

动画为显式状态流转场景，采用状态机设计。每个状态标注触发条件与处理策略；降级路径在任何前置失败时均汇入 `FALLBACK`，保证绝不白屏。

```plantuml
@startuml
[*] --> IDLE : init() 调用 play()

IDLE --> LOADING_GSAP : 动态创建 <script> 加载 CDN
LOADING_GSAP --> SAMPLING : script.onload 成功\n(window.gsap 可用)
LOADING_GSAP --> FALLBACK : script.onerror / 超时 / gsap 未定义

SAMPLING --> CONVERGING : 离屏 canvas 绘"引力"\ngetImageData 采样目标点\n生成 300 粒子(四周随机起点)
SAMPLING --> FALLBACK : getContext('2d') 返回 null

CONVERGING --> HOLDING : 1200ms 聚拢完成\n粒子到达文字轮廓目标点
HOLDING --> DIVERGING : 500ms 停留完成
DIVERGING --> CLEANUP : 700ms 散开+淡出+首页淡入完成\n(粒子 alpha->0, #app opacity->1)

CLEANUP --> DONE : body.removeChild(canvas)\nkill timeline\n释放粒子数组
FALLBACK --> DONE : #app opacity 直接置 1\n不创建 canvas

DONE --> [*]
@enduml
```

**关键分支处理策略**：

1. **GSAP 加载分支**：`loadGsap` 创建 `<script>`，设 `src` 为 CDN URL，`onload` 中校验 `window.gsap` 存在性；同时设置 1500ms 超时定时器，超时或 `onerror` 均 resolve(null)。无论成功失败均移除超时定时器，避免泄漏。
2. **降级分支**：`detectFallback` 综合判断——GSAP 为 null、`document.createElement('canvas').getContext('2d')` 为 null、或 `window.matchMedia('(prefers-reduced-motion: reduce)').matches` 为 true，任一成立即降级。降级仅将 `#app` opacity 置 1，不创建 Canvas，直接 resolve。
3. **文字轮廓采样分支**：离屏 canvas 尺寸取视口宽高；`fillText("引力")` 居中，字号按视口宽度自适应（桌面端约 `viewportWidth * 0.18`，移动端窄屏按比例缩减并设上限）；`getImageData` 后遍历像素，收集 alpha > 阈值的像素坐标；按 `particleCount` 步长均匀抽样为目标点池。若采样点不足（极端窄屏），降级为以视口中心为圆心的小圆环目标点，保证聚拢效果仍成立。
4. **粒子初始位置分支**：每个粒子初始 `(x,y)` 在屏幕四条边随机取一边，再在该边上随机取点，并沿法线方向向屏外偏移一段距离，确保"起始分布于四周而非中心"。
5. **散开方向分支**：散开阶段每粒子目标取其当前文字轮廓点沿"远离中心"方向延伸到屏外的坐标，alpha 由 1 补间到 0；同时 `#app` opacity 由 0 补间到 1，二者在同一 GSAP timeline 的末段并行。
6. **重绘驱动**：不单独起 `requestAnimationFrame`，由 GSAP timeline 的 `onUpdate` 回调统一重绘所有粒子（`clearRect` → 逐粒子 `fillStyle` 带 alpha → `fillRect`/`arc`），保证动画结束即停止重绘，无残留循环。
7. **清理分支**：timeline `onComplete` 中执行 `body.removeChild(canvas)`、`timeline.kill()`、粒子数组置空、`#app` opacity 兜底置 1；即便中途异常也走降级清理。

## 2.2 接口设计

### 2.2.1 总体设计

本模块对外仅暴露一个接口 `play`，遵循既有 `export const <moduleName> = { ... }` 风格。内部函数不导出。接口变更策略：`play` 签名稳定，配置参数全部可选且具默认值，后续如需扩展（如自定义文字、自定义配色）仅追加可选字段，不破坏既有调用。

| 接口名 | 分类 | 暴露层级 | 稳定性 |
|--------|------|---------|--------|
| `splashAnimation.play(options?)` | 动画入口 | 模块导出 | 稳定 |
| `loadGsap` | CDN 加载 | 模块内部 | 内部 |
| `detectFallback` | 环境守卫 | 模块内部 | 内部 |
| `sampleTextOutline` | 轮廓采样 | 模块内部 | 内部 |
| `createParticles` | 粒子生成 | 模块内部 | 内部 |
| `createCanvas` / `removeCanvas` | 画布生命周期 | 模块内部 | 内部 |
| `runTimeline` | 时序编排 | 模块内部 | 内部 |

### 2.2.2 接口清单

#### `splashAnimation.play`

**接口签名**：
```js
play(options?: {
  appElement?: HTMLElement;   // 首页容器，默认 document.getElementById('app')
  totalDurationMs?: number;   // 总时长上限，默认 2500
}): Promise<void>
```

**业务说明**：启动粒子聚拢入场动画。依次执行 GSAP 动态加载 → 降级判定 → 文字轮廓采样 → 粒子生成 → 全屏 Canvas 创建 → 三段时序编排（聚拢/停留/散开淡出+首页淡入）→ Canvas 移除。任一前置失败均走降级，直接显示首页。仅应在应用主初始化流程末尾调用一次。

**前置条件**：
1. DOM 已就绪（`document.body` 与 `#app` 存在）。
2. 调用时机晚于 `router()`，确保 `#app` 已含首页内容（动画对其 opacity 做淡入过渡）。
3. 全局仅调用一次；重复调用由内部状态标志拦截（已播放则直接 resolve）。

**后置条件**：
1. 动画成功路径：`#app` opacity 为 1，Canvas 已从 `body` 移除，GSAP timeline 已 kill，无残留 `requestAnimationFrame`。
2. 降级路径：`#app` opacity 为 1，未创建 Canvas。
3. 不修改 `index.html`，不触碰任何 localStorage 键，不影响任何核心功能。

**异常映射**：模块内部所有异常（加载失败、采样异常、绘制异常）均被捕获并转为降级路径，`play` 永不 reject（吞异常以保证不白屏）；异常信息仅 `console.warn` 记录，不外抛。

**调用示例**（`src/main.js` 末尾）：
```js
import { splashAnimation } from './utils/splashAnimation.js';

async function init() {
  // ...既有全部步骤保持原序不变...
  try { onboardingTutorial.start(); } catch (e) {}

  splashAnimation.play();   // 非阻塞，动画自行控制 #app 淡入与清理
}
```

## 2.3 数据模型

### 2.3.1 设计目标

1. **支持的业务场景**：约 300 粒子由屏幕四周聚拢至"引力"文字轮廓、停留 0.5s、向四周散开并淡出，同步首页淡入；移动端窄屏与桌面端均自适应。
2. **性能目标**：总时长 ≤2.5s；300 粒子 Canvas 2D 重绘单帧耗时远低于 16ms，无掉帧；动画结束即释放全部运行时对象，零残留。
3. **容量目标**：运行时仅持有 300 个粒子对象 + 1 个离屏 canvas + 1 个全屏 canvas，内存占用可忽略。
4. **扩展性目标**：文字内容、粒子数、时序、配色均为配置项，后续可扩展。
5. **与存量数据兼容策略**：无持久化，不读写任何 localStorage 键（`dream_saving_camp_data`/`dream_camps_data`/`dream_joined_camps` 等均不触碰），与存量数据完全隔离。

### 2.3.2 模型实现

核心领域对象为运行时粒子与采样结果，无持久化策略（动画结束即销毁）。对象间为组合/依赖关系。

```plantuml
@startuml
class Particle {
  + x : number
  + y : number
  + originX : number
  + originY : number
  + targetX : number
  + targetY : number
  + divergeX : number
  + divergeY : number
  + size : number
  + alpha : number
}
note right of Particle
  运行时对象，动画结束置空
  x,y     : 当前坐标(由 GSAP tween)
  origin  : 四周起始位置
  target  : 文字轮廓聚拢目标
  diverge : 散开终点(屏外)
end note

class OutlineSample {
  + points : Point[]
  + width : number
  + height : number
}
class Point {
  + x : number
  + y : number
}

class AnimationConfig {
  + particleCount : number
  + convergeMs : number
  + holdMs : number
  + divergeMs : number
  + text : string
  + cdnUrl : string
}

class CanvasHandle {
  + canvas : HTMLCanvasElement
  + ctx : CanvasRenderingContext2D
}

OutlineSample "1" o-- "300" Point : 采样目标点池
Particle "300" ..> Point : 各绑定一个聚拢目标
CanvasHandle "1" --> Particle : 每帧重绘

note bottom of AnimationConfig
  纯配置值对象，模块内常量
end note
@enduml
```

**对象生命周期与创建/销毁策略**：

| 对象 | 创建时机 | 销毁时机 | 销毁方式 |
|------|---------|---------|---------|
| `AnimationConfig` | 模块加载时（常量） | 不销毁 | 常驻，无副作用 |
| `OutlineSample` + `Point[]` | `sampleTextOutline` 执行时 | 动画结束后 | 随粒子数组一并置空 |
| `Particle[]` | `createParticles` 执行时 | timeline `onComplete` | 数组置空，解除引用 |
| `CanvasHandle`（离屏采样 canvas） | `sampleTextOutline` 内 | 采样完成后 | 脱离引用，由 GC 回收 |
| `CanvasHandle`（全屏动画 canvas） | `createCanvas` 执行时 | timeline `onComplete` | `body.removeChild` + 引用置空 |

**持久化策略**：无。全部对象为运行时内存对象，不落 localStorage、不落 IndexedDB、不发网络请求（GSAP CDN 除外）。与存量数据模型完全解耦。

**与存量代码边界**：本模块仅通过 `play` 的 `appElement` 参数（默认 `document.getElementById('app')`）与首页容器发生 opacity 过渡关系，不读取/修改 `#app` 的 innerHTML、不调用任何 view/service/storage 模块。回滚时删除 `main.js` 中 import 与调用两行、删除 `splashAnimation.js` 文件即可，存量代码零改动。
