const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '..')));

app.get('/api/data', (req, res) => {
  try {
    const data = db.getData();
    if (data) {
      res.json(data);
    } else {
      res.json({ _version: 1, goals: [], records: [], checkIns: [], camps: [], achievements: [] });
    }
  } catch (e) {
    console.error('GET /api/data 错误:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/data', (req, res) => {
  try {
    db.saveData(req.body);
    res.json({ success: true });
  } catch (e) {
    console.error('POST /api/data 错误:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/camp/create', (req, res) => {
  try {
    const { name, nickname, goalName, progress, maxMembers } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: '请输入小组名称' });
    if (!nickname || !nickname.trim()) return res.status(400).json({ error: '请输入昵称' });
    const result = db.createCamp(name.trim(), nickname.trim(), goalName, progress || 0, maxMembers);
    res.json(result);
  } catch (e) {
    console.error('POST /api/camp/create 错误:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/camp/join', (req, res) => {
  try {
    const { code, nickname, goalName, progress } = req.body;
    if (!code) return res.status(400).json({ error: '请输入组队码' });
    if (!nickname || !nickname.trim()) return res.status(400).json({ error: '请输入昵称' });
    const result = db.joinCamp(String(code).trim(), nickname.trim(), goalName, progress || 0);
    res.json(result);
  } catch (e) {
    console.error('POST /api/camp/join 错误:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/camp/:code', (req, res) => {
  try {
    const data = db.getCampByCode(req.params.code);
    if (!data) return res.status(404).json({ error: '储蓄营不存在' });
    res.json(data);
  } catch (e) {
    console.error('GET /api/camp/:code 错误:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/camp/:code/progress', (req, res) => {
  try {
    const { memberId, progress, goalName } = req.body;
    const result = db.updateMemberProgress(req.params.code, memberId, progress, goalName);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/camp/:code/message', (req, res) => {
  try {
    const { memberId, nickname, text } = req.body;
    if (!text || !text.trim()) return res.status(400).json({ error: '留言不能为空' });
    const result = db.addCampMessage(req.params.code, memberId, nickname, text.trim());
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/camp/:code/message/:msgId', (req, res) => {
  try {
    const result = db.removeCampMessage(req.params.code, req.params.msgId);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/camp/:code/leave', (req, res) => {
  try {
    const { memberId } = req.body;
    const result = db.leaveCamp(req.params.code, memberId);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/camp/:code', (req, res) => {
  try {
    const result = db.disbandCamp(req.params.code);
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => {
  console.log('');
  console.log('  ┌──────────────────────────────────────────────┐');
  console.log('  │   梦想储蓄营后端服务已启动                   │');
  console.log(`  │   地址: http://localhost:${PORT}              │`);
  console.log('  │   数据库: SQLite (server/data.db)            │');
  console.log('  │   联机组队: 已启用                           │');
  console.log('  └──────────────────────────────────────────────┘');
  console.log('');
});
