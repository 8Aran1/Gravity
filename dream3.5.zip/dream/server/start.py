import subprocess
import sys
import os

def run(cmd, cwd=None):
    print(f"\n>>> {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd)
    if result.returncode != 0:
        print(f"命令失败 (返回码 {result.returncode})")
        sys.exit(1)

if __name__ == "__main__":
    server_dir = os.path.dirname(os.path.abspath(__file__))

    print("=" * 50)
    print("  梦想储蓄营后端服务 - Python 启动脚本")
    print("=" * 50)

    # 1. 检查 Node.js
    node_check = subprocess.run("node --version", shell=True, capture_output=True, text=True)
    if node_check.returncode != 0:
        print("\n[错误] 未检测到 Node.js，请先安装：")
        print("  下载地址: https://nodejs.org")
        print("  要求版本: >= 18 LTS")
        sys.exit(1)
    print(f"\n[OK] Node.js 版本: {node_check.stdout.strip()}")

    # 2. 检查 npm
    npm_check = subprocess.run("npm --version", shell=True, capture_output=True, text=True)
    if npm_check.returncode != 0:
        print("\n[错误] 未检测到 npm")
        sys.exit(1)
    print(f"[OK] npm 版本: {npm_check.stdout.strip()}")

    # 3. 安装依赖
    print("\n[步骤 1/2] 安装依赖...")
    run("npm install", cwd=server_dir)

    # 4. 启动服务器
    print("\n[步骤 2/2] 启动服务器...")
    print("  浏览器访问: http://localhost:3000")
    print("  按 Ctrl+C 停止服务器\n")
    run("node server.js", cwd=server_dir)