# 梦想储蓄营 - 后端服务

Node.js + Express + SQLite 后端，为前端提供数据持久化 API。

## 技术栈

| 组件 | 技术 | 说明 |
|------|------|------|
| 运行时 | Node.js ≥ 18 | 后端运行环境 |
| Web 框架 | Express 4 | HTTP 路由与静态文件服务 |
| 数据库 | SQLite (better-sqlite3) | 嵌入式数据库，无需单独安装 |

## 目录结构

```
dream/
├── index.html              # 前端入口
├── src/                    # 前端源码
│   ├── main.js             # 应用入口（async init）
│   ├── storage/
│   │   └── localStorageAdapter.js  # 已改为调用后端 API
│   └── ...
└── server/                 # 后端（本目录）
    ├── package.json        # 依赖声明
    ├── server.js           # Express 服务器
    ├── db.js               # SQLite 数据库操作
    ├── data.db             # SQLite 数据库文件（自动生成）
    └── README.md           # 本文件
```

## 安装与运行

### 1. 确认 Node.js 已安装

```bash
node --version
```

如果未安装或版本低于 18，请前往 https://nodejs.org 下载并安装 LTS 版本。

### 2. 安装依赖

```bash
cd server
npm install
```

这会安装 `express`、`better-sqlite3`、`cors` 三个依赖包。

### 3. 启动服务器

```bash
npm start
```

或直接：

```bash
node server.js
```

启动成功后会显示：

```
  ┌──────────────────────────────────────────┐
  │   梦想储蓄营后端服务已启动               │
  │   地址: http://localhost:3000            │
  │   数据库: SQLite (server/data.db)        │
  └──────────────────────────────────────────┘
```

### 4. 打开应用

在浏览器中访问 **http://localhost:3000**

> 注意：现在通过 Express 服务器（端口 3000）访问应用，不再需要 `python -m http.server`。

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/data` | 获取全部数据（目标、记录、打卡、成就、储蓄营） |
| POST | `/api/data` | 保存全部数据 |

前端 `localStorageAdapter.js` 会自动调用这两个接口，原有 localStorage 中的数据会在首次加载时自动迁移到 SQLite。

## 数据存储

所有数据保存在 `server/data.db`（SQLite 文件）。删除此文件会重置所有数据。

## 常见问题

**Q: `npm install` 报错 / `better-sqlite3` 编译失败？**

A: `better-sqlite3` 需要预编译二进制文件。大多数情况下 npm 会自动下载对应平台的预编译版本。如果失败：
- Windows: 安装 [Visual Studio Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) 后重试
- 或改用 Node.js 18 LTS 版本

**Q: 端口 3000 被占用？**

A: 修改 `server.js` 中的 `const PORT = 3000` 为其他端口。