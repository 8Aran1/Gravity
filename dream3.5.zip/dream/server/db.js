const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');

const db = new Database(path.join(__dirname, 'data.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS app_data (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    data TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS camps (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    max_members INTEGER DEFAULT 3,
    creator_member_id TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS camp_members (
    id TEXT PRIMARY KEY,
    camp_id TEXT NOT NULL,
    nickname TEXT NOT NULL,
    goal_name TEXT,
    progress INTEGER DEFAULT 0,
    joined_at TEXT NOT NULL,
    FOREIGN KEY (camp_id) REFERENCES camps(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS camp_messages (
    id TEXT PRIMARY KEY,
    camp_id TEXT NOT NULL,
    member_id TEXT NOT NULL,
    nickname TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (camp_id) REFERENCES camps(id) ON DELETE CASCADE
  );
`);

try { db.exec('ALTER TABLE camps ADD COLUMN max_members INTEGER DEFAULT 3'); } catch (e) { }
try { db.exec('ALTER TABLE camps ADD COLUMN creator_member_id TEXT'); } catch (e) { }

function getData() {
  const row = db.prepare('SELECT data FROM app_data WHERE id = 1').get();
  return row ? JSON.parse(row.data) : null;
}

function saveData(data) {
  db.prepare(`
    INSERT OR REPLACE INTO app_data (id, data, updated_at)
    VALUES (1, ?, datetime('now'))
  `).run(JSON.stringify(data));
}

function genId() {
  return crypto.randomUUID();
}

function generateUniqueCode() {
  for (let i = 0; i < 100; i++) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const existing = db.prepare('SELECT 1 FROM camps WHERE code = ?').get(code);
    if (!existing) return code;
  }
  throw new Error('无法生成唯一组队码');
}

function createCamp(name, nickname, goalName, progress, maxMembers) {
  const id = genId();
  const code = generateUniqueCode();
  const now = new Date().toISOString().slice(0, 10);
  const max = Math.min(10, Math.max(2, maxMembers || 3));
  const memberId = genId();
  db.prepare('INSERT INTO camps (id, code, name, max_members, creator_member_id, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(id, code, name, max, memberId, now);
  db.prepare('INSERT INTO camp_members (id, camp_id, nickname, goal_name, progress, joined_at) VALUES (?, ?, ?, ?, ?, ?)').run(memberId, id, nickname, goalName || null, progress || 0, now);
  return { campId: id, code, memberId };
}

function joinCamp(code, nickname, goalName, progress) {
  const camp = db.prepare('SELECT * FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '组队码不存在' };
  const memberCount = db.prepare('SELECT COUNT(*) as count FROM camp_members WHERE camp_id = ?').get(camp.id).count;
  if (memberCount >= (camp.max_members || 3)) return { success: false, error: '小组成员已满' };
  const dup = db.prepare('SELECT 1 FROM camp_members WHERE camp_id = ? AND nickname = ?').get(camp.id, nickname);
  if (dup) return { success: false, error: '该昵称已被使用，请换一个' };
  const memberId = genId();
  const now = new Date().toISOString().slice(0, 10);
  db.prepare('INSERT INTO camp_members (id, camp_id, nickname, goal_name, progress, joined_at) VALUES (?, ?, ?, ?, ?, ?)').run(memberId, camp.id, nickname, goalName || null, progress || 0, now);
  return { success: true, campId: camp.id, campName: camp.name, memberId };
}

function getCampByCode(code) {
  const camp = db.prepare('SELECT * FROM camps WHERE code = ?').get(code);
  if (!camp) return null;
  const members = db.prepare('SELECT * FROM camp_members WHERE camp_id = ? ORDER BY joined_at').all(camp.id);
  const messages = db.prepare('SELECT * FROM camp_messages WHERE camp_id = ? ORDER BY created_at').all(camp.id);
  return { camp, members, messages };
}

function updateMemberProgress(code, memberId, progress, goalName) {
  const camp = db.prepare('SELECT id FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '储蓄营不存在' };
  db.prepare('UPDATE camp_members SET progress = ?, goal_name = ? WHERE id = ? AND camp_id = ?').run(progress || 0, goalName || null, memberId, camp.id);
  return { success: true };
}

function addCampMessage(code, memberId, nickname, text) {
  const camp = db.prepare('SELECT id FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '储蓄营不存在' };
  const id = genId();
  const now = Date.now();
  db.prepare('INSERT INTO camp_messages (id, camp_id, member_id, nickname, text, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(id, camp.id, memberId, nickname, text, now);
  return { success: true, message: { id, memberId, nickname, text, createdAt: now } };
}

function removeCampMessage(code, msgId) {
  const camp = db.prepare('SELECT id FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '储蓄营不存在' };
  db.prepare('DELETE FROM camp_messages WHERE id = ? AND camp_id = ?').run(msgId, camp.id);
  return { success: true };
}

function leaveCamp(code, memberId) {
  const camp = db.prepare('SELECT id FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '储蓄营不存在' };
  db.prepare('DELETE FROM camp_members WHERE id = ? AND camp_id = ?').run(memberId, camp.id);
  db.prepare('DELETE FROM camp_messages WHERE member_id = ? AND camp_id = ?').run(memberId, camp.id);
  return { success: true };
}

function disbandCamp(code) {
  const camp = db.prepare('SELECT id FROM camps WHERE code = ?').get(code);
  if (!camp) return { success: false, error: '储蓄营不存在' };
  db.prepare('DELETE FROM camp_messages WHERE camp_id = ?').run(camp.id);
  db.prepare('DELETE FROM camp_members WHERE camp_id = ?').run(camp.id);
  db.prepare('DELETE FROM camps WHERE id = ?').run(camp.id);
  return { success: true };
}

module.exports = {
  getData, saveData,
  createCamp, joinCamp, getCampByCode,
  updateMemberProgress, addCampMessage, removeCampMessage,
  leaveCamp, disbandCamp
};
